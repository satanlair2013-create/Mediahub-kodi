"""MediaHub Sync - Watch together: two Kodis in the house play the same film or
episode in step, and a pause, a play or a skip on one does the same on the other.

The Kodis talk directly over the home network (UDP port 8586, while MediaHub Sync
runs): "Watch together" (the player bar's button) asks who's there (a broadcast),
you pick a room, and that Kodi asks whether to start it (from its own library: the
same film, matched like Sync matches them). While together, each side says what it
did and the one that started it says where it is every few seconds, so the other
catches up when it drifts.

  Window(Home) MHS.Together: the other room's name, while watching together
  MHS.Together.Req: "start" (the button; RunScript(service.mediahub.sync,together))
"""
import json
import os
import socket
import threading
import time
import uuid

import xbmc
import xbmcaddon
import xbmcgui

import sync

PORT = int(os.environ.get("MEDIAHUB_TOGETHER_PORT") or 8586)
FIND_TIME = 1.5     # seconds to wait for the others to answer
BEAT = 4            # seconds between "where I am" while together
DRIFT = 1.5         # seconds apart before the other one catches up
QUIET = 2.0         # seconds our own player's news is ignored after doing what the other said
PROP = "MHS.Together"


def text(string_id):
    return xbmcaddon.Addon(sync.ADDON_ID).getLocalizedString(string_id)


def now_playing():
    """(kind, dbid, position in seconds, paused) of the library film or episode playing, or None."""
    players = sync.rpc("Player.GetActivePlayers") or []
    video = next((p for p in players if p.get("type") == "video"), None)
    if not video:
        return None
    item = (sync.rpc("Player.GetItem", playerid=video["playerid"]) or {}).get("item") or {}
    props = sync.rpc("Player.GetProperties", playerid=video["playerid"], properties=["time", "speed"]) or {}
    if item.get("type") not in ("movie", "episode") or not isinstance(item.get("id"), int):
        return None
    t = props.get("time") or {}
    at = t.get("hours", 0) * 3600 + t.get("minutes", 0) * 60 + t.get("seconds", 0) + t.get("milliseconds", 0) / 1000.0
    return item["type"], item["id"], at, props.get("speed") == 0


def position(seconds):
    seconds = max(0.0, seconds)
    return {"hours": int(seconds // 3600), "minutes": int(seconds // 60 % 60), "seconds": int(seconds % 60),
            "milliseconds": int(seconds * 1000) % 1000}


class Together:
    def __init__(self):
        self.me, self.name = sync.device()
        self.sock = None
        self.found = {}          # device id: (address, name) of the Kodis that answered
        self.session = None      # {"sid", "peer": address, "name", "host": bool}
        self.quiet_until = 0.0
        self.next_beat = 0.0
        self.lock = threading.Lock()

    # ------------------------------------------------------------------ the network
    def open(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            s.bind(("", PORT))
            s.settimeout(0.5)
        except OSError as exc:
            xbmc.log("MediaHub Sync: watch together: port %d: %r" % (PORT, exc), xbmc.LOGWARNING)
            return
        self.sock = s
        threading.Thread(target=self.listen, daemon=True).start()

    def close(self):
        if self.session:
            self.leave()
        if self.sock:
            self.sock.close()
            self.sock = None

    def send(self, peer, op, **fields):
        """peer: (address, port) - the port a message came from, or PORT."""
        if not self.sock:
            return
        fields.update(op=op, v=1, id=self.me, name=self.name)
        try:
            self.sock.sendto(json.dumps(fields).encode("utf-8"), tuple(peer))
        except OSError as exc:
            xbmc.log("MediaHub Sync: watch together: %r" % exc, xbmc.LOGDEBUG)

    def listen(self):
        while self.sock:
            try:
                data, peer = self.sock.recvfrom(8192)
                msg = json.loads(data.decode("utf-8"))
            except socket.timeout:
                continue
            except (OSError, ValueError, UnicodeDecodeError):
                if not self.sock:
                    return
                continue
            if isinstance(msg, dict) and msg.get("v") == 1 and msg.get("id") != self.me:
                try:
                    self.receive(peer[:2], msg)
                except Exception as exc:  # (a bad message never stops it)
                    xbmc.log("MediaHub Sync: watch together: %r" % exc, xbmc.LOGWARNING)

    # ------------------------------------------------------------------ messages
    def receive(self, peer, msg):
        op = msg.get("op")
        if op == "hello":
            self.send(peer, "here")
        elif op == "here":
            self.found[msg["id"]] = (peer, str(msg.get("name") or "Kodi"))
        elif op == "invite":
            threading.Thread(target=self.invited, args=(peer, msg), daemon=True).start()
        elif not self.session or msg.get("sid") != self.session["sid"]:
            return
        elif op == "joined":
            self.session["peer"] = peer
            xbmcgui.Dialog().notification(text(30060), text(30064) % msg.get("name", ""),
                                          xbmcaddon.Addon(sync.ADDON_ID).getAddonInfo("icon"), 4000, False)
            self.beat()
        elif op == "no":
            self.end(text(30065) % msg.get("name", ""))
        elif op == "state":
            self.follow(msg)
        elif op == "leave":
            self.end(text(30066) % msg.get("name", ""))

    def invited(self, peer, msg):
        """Someone wants to watch together: ask, find it here, and start it where they are."""
        title = str(msg.get("title") or "")
        if self.session or not xbmcgui.Dialog().yesno(text(30060), text(30063) % (msg.get("name", ""), title),
                                                      autoclose=60000):
            return self.send(peer, "no", sid=msg.get("sid"))
        local = sync.library().get(msg.get("key") or "")
        if not local or local[1][0] not in ("movie", "episode"):
            xbmcgui.Dialog().ok(text(30060), text(30067) % title)
            return self.send(peer, "no", sid=msg.get("sid"))
        kind, dbid, _tags = local[1]
        self.session = {"sid": msg.get("sid"), "peer": peer, "name": str(msg.get("name") or ""), "host": False}
        xbmcgui.Window(10000).setProperty(PROP, self.session["name"])
        self.quiet_until = time.time() + 8  # (starting it isn't news to send back)
        sync.rpc("Player.Open", item={kind + "id": dbid},
                 options={"resume": position(float(msg.get("pos") or 0) + 2)})
        self.send(peer, "joined", sid=msg.get("sid"))

    def follow(self, msg):
        """The other one paused, played or skipped (or says where it is): do the same here."""
        here = now_playing()
        if not here:
            return
        _kind, _dbid, at, paused = here
        want_paused, want_at = bool(msg.get("paused")), float(msg.get("pos") or 0)
        players = [p for p in sync.rpc("Player.GetActivePlayers") or [] if p.get("type") == "video"]
        if not players:
            return
        pid = players[0]["playerid"]
        if want_paused != paused:
            self.quiet_until = time.time() + QUIET
            sync.rpc("Player.PlayPause", playerid=pid, play=not want_paused)
        if abs(at - want_at) > DRIFT:
            self.quiet_until = time.time() + QUIET
            sync.rpc("Player.Seek", playerid=pid, value={"time": position(want_at)})

    # ------------------------------------------------------------------ this side
    def find(self):
        self.found = {}
        self.send(("255.255.255.255", PORT), "hello")
        for address in self.shared_folder_addresses():
            self.send((address, PORT), "hello")
        xbmc.sleep(int(FIND_TIME * 1000))
        return dict(self.found)

    def shared_folder_addresses(self):
        """The other Kodis' addresses from the Sync folder (for a network where broadcasts don't reach)."""
        path = xbmcaddon.Addon(sync.ADDON_ID).getSetting("folder")
        if not path:
            return []
        try:
            return [o["address"] for o in sync.Folder(path).others(self.me) if o.get("address")]
        except Exception:
            return []

    def start(self):
        """The player bar's Watch together: pick a room and invite it (or stop watching together)."""
        if self.session:
            if xbmcgui.Dialog().yesno(text(30060), text(30068) % self.session["name"]):
                self.leave()
            return
        here = now_playing()
        if not here:
            return xbmcgui.Dialog().ok(text(30060), text(30069))
        if not self.sock:
            return xbmcgui.Dialog().ok(text(30060), text(30071) % PORT)
        kind, dbid, _at, _paused = here
        key, _resume, d = sync.stopped_item(kind, dbid)
        found = self.find()
        if not found:
            return xbmcgui.Dialog().ok(text(30060), text(30070))
        rooms = sorted(found.items(), key=lambda kv: kv[1][1].lower())
        pick = xbmcgui.Dialog().select(text(30062), [name for _id, (_addr, name) in rooms])
        if pick < 0:
            return
        peer, name = rooms[pick][1]
        here = now_playing() or here
        self.session = {"sid": uuid.uuid4().hex[:10], "peer": peer, "name": name, "host": True}
        xbmcgui.Window(10000).setProperty(PROP, name)
        self.send(peer, "invite", sid=self.session["sid"], key=key, title=d.get("title", ""), pos=here[2])

    def leave(self):
        if self.session:
            self.send(self.session["peer"], "leave", sid=self.session["sid"])
        self.end()

    def end(self, why=""):
        self.session = None
        xbmcgui.Window(10000).clearProperty(PROP)
        if why:
            xbmcgui.Dialog().notification(text(30060), why, xbmcaddon.Addon(sync.ADDON_ID).getAddonInfo("icon"),
                                          5000, False)

    def beat(self):
        here = now_playing()
        if self.session and here:
            self.send(self.session["peer"], "state", sid=self.session["sid"], pos=here[2], paused=here[3])

    def on_player(self, method):
        """Player.OnPause / OnResume / OnSeek here: tell the other one (unless it was them)."""
        if not self.session or time.time() < self.quiet_until:
            return
        if method == "Player.OnStop":
            return self.leave()
        xbmc.sleep(200)  # (the new position, once Kodi has it)
        self.beat()

    def tick(self):
        if xbmcgui.Window(10000).getProperty(PROP + ".Req"):
            xbmcgui.Window(10000).clearProperty(PROP + ".Req")
            threading.Thread(target=self.start, daemon=True).start()
        if self.session and self.session["host"] and time.time() >= self.next_beat:
            self.next_beat = time.time() + BEAT
            self.beat()
