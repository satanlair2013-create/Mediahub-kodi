"""MediaHub Classics - old films and TV that are free to watch.

Continue watching, My List, and the Internet Archive's public-domain films by kind
(feature films, film noir, science fiction and horror, comedy, westerns, silent
films, cartoons, classic TV), most watched first, and search. Films resume where
you stopped and get a tick once watched.
"""
import json
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import films  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name")
FANART = os.path.join(ADDON.getAddonInfo("path"), "resources", "fanart.jpg")


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def kodi(string_id):
    return xbmc.getLocalizedString(string_id)


def url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)


def notify(message, error=False):
    xbmcgui.Dialog().notification(NAME, message, xbmcgui.NOTIFICATION_WARNING if error else
                                  xbmcgui.NOTIFICATION_INFO, 4000, False)


def kids_mode():
    return xbmc.getCondVisibility("Skin.HasSetting(MH.KidsMode)")


def folder(label, target, icon="DefaultFolder.png"):
    item = xbmcgui.ListItem(label)
    item.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=True)


def end(content="", title=""):
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.setPluginCategory(HANDLE, title or NAME)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def careful(work):
    try:
        work()
    except films.Error as exc:
        xbmc.log("MediaHub Classics: %s" % exc, xbmc.LOGWARNING)
        notify(text(30020), True)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def clock(seconds):
    seconds = int(seconds)
    return "%d:%02d:%02d" % (seconds // 3600, seconds // 60 % 60, seconds % 60) if seconds >= 3600 else \
        "%d:%02d" % (seconds // 60, seconds % 60)


# --------------------------------------------------------------------------- pages

def root():
    kids = kids_mode()
    if films.continue_watching(1) and not kids:
        folder(text(30001), url(mode="continue"), "DefaultInProgressShows.png")
    if films.my_list() and not kids:
        folder(text(30002), url(mode="mylist"), "DefaultPlaylist.png")
    for section, string_id, _q in films.SECTIONS:
        if not kids or section in films.KIDS_SECTIONS:
            folder(text(string_id), url(mode="section", id=section), "DefaultMovies.png")
    if not kids:
        folder(kodi(137), url(mode="search"), "DefaultAddonsSearch.png")
    end()


def film_item(f):
    item = xbmcgui.ListItem(f.get("title", ""))
    art = f.get("art") or films.picture(f["id"])
    item.setArt({"icon": art, "thumb": art, "poster": art, "landscape": art, "fanart": art})
    tag = item.getVideoInfoTag()
    tag.setMediaType("movie")
    tag.setTitle(f.get("title", ""))
    if f.get("year"):
        tag.setYear(int(f["year"]))
    tag.setPlot(f.get("plot", ""))
    # (no resume point on the item: Kodi would ask "Resume from" as well as the add-on)
    pos, total, done = films.state(f["id"])
    if done:
        tag.setPlaycount(1)
    if total:
        tag.setDuration(int(total))
    info = json.dumps({k: f.get(k, "") for k in ("id", "title", "year")})
    listed = films.in_list(f["id"])
    item.addContextMenuItems([
        (text(30004) if listed else text(30003), "RunPlugin(%s)" % url(mode="list_set", on=int(not listed), film=info)),
        (kodi(16103) if not done else kodi(16104), "RunPlugin(%s)" % url(mode="watched", on=int(not done), film=info))])
    item.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(HANDLE, films.play_address(f["id"]), item, isFolder=False)


def list_page(query, title, sort="downloads desc"):
    page = int(ARGS.get("page", 1))
    found = films.search(query, sort, page)
    for f in found:
        film_item(f)
    if len(found) >= films.PAGE:
        folder(kodi(33078), url(mode=ARGS.get("mode"), id=ARGS.get("id", ""), q=ARGS.get("q", ""), page=page + 1))
    end("movies", title)


def section_page():
    section = ARGS.get("id", "films")
    if kids_mode() and section not in films.KIDS_SECTIONS:
        return end()
    title = next((text(i) for s, i, _q in films.SECTIONS if s == section), NAME)
    list_page(films.section_query(section), title)


def search():
    words = ARGS.get("q")
    if not words:
        words = xbmcgui.Dialog().input(text(30005))
        if not words:
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        xbmc.executebuiltin("Container.Update(%s,replace)" % url(mode="search", q=words))
        return end()
    list_page(films.words_query(words), '%s: "%s"' % (kodi(137), words))


def continue_page():
    for p in films.continue_watching():
        f = films.cached_film(p["id"]) or {"id": p["id"], "title": p.get("title", ""), "year": p.get("year", 0)}
        film_item(f)
    end("movies", text(30001))


def mylist_page():
    for m in films.my_list():
        f = films.cached_film(m["id"]) or m
        film_item(f)
    end("movies", text(30002))


# --------------------------------------------------------------------------- playing

def play():
    film_id = ARGS["id"]
    try:
        f = films.film(film_id)
    except films.Error:
        notify(text(30020), True)
        return xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    if not f.get("url"):
        notify(text(30021), True)
        return xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    pos, _total, done = films.state(film_id)
    offset = 0
    if ARGS.get("resume") is not None:
        offset = pos if ARGS["resume"] == "1" and not done else 0
    elif pos > 60 and not done:
        pick = xbmcgui.Dialog().contextmenu([kodi(12022).format(clock(pos)), kodi(12021)])
        if pick < 0:
            return xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        offset = pos if pick == 0 else 0
    item = xbmcgui.ListItem(f["title"], path=f["url"])
    item.setArt({"thumb": f["art"], "poster": f["art"], "fanart": f["art"]})
    tag = item.getVideoInfoTag()
    tag.setMediaType("movie")
    tag.setTitle(f["title"])
    tag.setPlot(f.get("plot", ""))
    if f.get("year"):
        tag.setYear(int(f["year"]))
    if f.get("genres"):
        tag.setGenres(f["genres"])
    if offset:
        item.setProperty("StartOffset", str(int(offset)))
    entry = {"id": f["id"], "title": f["title"], "year": f.get("year", 0)}
    # (a list item plays as the add-on's own address; the home row's as the file's)
    xbmcgui.Window(10000).setProperty(films.NOW, json.dumps({f["url"]: entry, BASE + sys.argv[2]: entry}))
    if HANDLE >= 0:
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
    else:  # (MediaHub's home row: run, not a list item)
        xbmc.Player().play(f["url"], item)


def main():
    mode = ARGS.get("mode")
    if mode is None:
        root()
    elif mode == "section":
        careful(section_page)
    elif mode == "search":
        careful(search)
    elif mode == "continue":
        continue_page()
    elif mode == "mylist":
        mylist_page()
    elif mode == "play":
        play()
    elif mode == "list_set":
        f = json.loads(ARGS.get("film") or "{}")
        if f.get("id"):
            films.set_list(f, ARGS.get("on") == "1")
            notify(text(30006) if ARGS.get("on") == "1" else text(30007))
            xbmc.executebuiltin("Container.Refresh")
    elif mode == "watched":
        f = json.loads(ARGS.get("film") or "{}")
        if f.get("id"):
            films.set_watched(f, ARGS.get("on") == "1")
            xbmc.executebuiltin("Container.Refresh")


if __name__ == "__main__":
    main()
