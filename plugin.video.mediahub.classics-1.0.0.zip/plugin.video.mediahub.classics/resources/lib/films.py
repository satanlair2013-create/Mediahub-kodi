"""MediaHub Classics - public-domain films and TV from the Internet Archive.

The Internet Archive keeps thousands of old films and TV episodes that are free
to watch (out of copyright): its feature films, film noir, science fiction and
horror, comedies, westerns, silent films, cartoons and classic TV. Its search is
free, and each film's details say which video files it has. No account or key.

Kept in the add-on's data folder:
- progress.json: {id: {title, year, pos, total, done, t}} (resume, Continue watching)
- mylist.json: My List [{id, title, year, t}]
- films/: each film's details and video address as last read; lists/: pages of lists
- home.json: ready-made cards for MediaHub's home rows (Classics: Continue Watching,
  Classic Films)
"""
import gzip
import hashlib
import html
import json
import os
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.mediahub.classics"
ARCHIVE = os.environ.get("MEDIAHUB_ARCHIVE", "https://archive.org").rstrip("/")  # (a test server can stand in)
CERTS = "special://xbmc/system/certs/cacert.pem"
FILM_AGE = 30 * 86400
LIST_AGE = 12 * 3600
PAGE = 40
WATCHED = 0.9
NOW = "MHL.Now"  # what the add-on started playing: {address: {id, title, year}}
HOME_CARDS = 20
# (id, string id, the Archive's search for it)
SECTIONS = [("films", 30010, "collection:(feature_films)"),
            ("noir", 30011, "collection:(Film_Noir)"),
            ("scifi", 30012, "collection:(SciFi_Horror)"),
            ("comedy", 30013, "collection:(Comedy_Films)"),
            ("western", 30014, "collection:(feature_films) AND subject:(western)"),
            ("silent", 30015, "collection:(silent_films)"),
            ("cartoons", 30016, "collection:(classic_cartoons)"),
            ("tv", 30017, "collection:(classic_tv)")]
KIDS_SECTIONS = ("cartoons",)
VIDEO_FORMATS = ("h.264", "h.264 IA", "MPEG4", "512Kb MPEG4", "Ogg Video", "Matroska")


class Error(Exception):
    pass


def text(string_id):
    return xbmcaddon.Addon(ADDON_ID).getLocalizedString(string_id)


# --------------------------------------------------------------------------- files

def profile(name=""):
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)


def load_json(name, default):
    try:
        with open(profile(name), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(name, data):
    path = profile(name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def key(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()[:16]


# --------------------------------------------------------------------------- the Internet Archive

def ssl_context():
    certs = xbmcvfs.translatePath(CERTS)
    try:
        return ssl.create_default_context(cafile=certs) if os.path.exists(certs) else ssl.create_default_context()
    except (OSError, ssl.SSLError):
        return ssl.create_default_context()


def fetch_json(url, timeout=15):
    request = urllib.request.Request(url, headers={"User-Agent": xbmc.getUserAgent(), "Accept-Encoding": "gzip"})
    try:
        with urllib.request.urlopen(request, timeout=timeout, context=ssl_context()) as reply:
            body = reply.read(8 * 1024 * 1024)
        if body[:2] == b"\x1f\x8b":
            body = gzip.decompress(body)
        return json.loads(body.decode("utf-8", "replace") or "null")
    except urllib.error.HTTPError as exc:
        raise Error("HTTP %d" % exc.code)
    except (OSError, ValueError, ssl.SSLError) as exc:
        raise Error(repr(exc))


def plain(value):
    if isinstance(value, list):
        value = " ".join(str(v) for v in value)
    value = re.sub(r"<(br|p|/p|li)[^>]*>", "\n", str(value or ""), flags=re.I)
    value = html.unescape(re.sub(r"<[^>]+>", "", value))
    return re.sub(r"\n\s*\n+", "\n\n", re.sub(r"[ \t]+", " ", value)).strip()


def first(value):
    return (value[0] if value else "") if isinstance(value, list) else (value or "")


def year_of(value):
    found = re.search(r"(1[89]\d\d|20\d\d)", str(first(value) or ""))
    return int(found.group(1)) if found else 0


def picture(film_id):
    return "%s/services/img/%s" % (ARCHIVE, urllib.parse.quote(film_id))


def search(query, sort="downloads desc", page=1, rows=PAGE):
    """[{id, title, year, plot, art}] from the Internet Archive's search (films only)."""
    q = "mediatype:(movies) AND (%s)" % query
    params = [("q", q), ("rows", rows), ("page", page), ("output", "json"), ("sort[]", sort)]
    params += [("fl[]", f) for f in ("identifier", "title", "year", "date", "description", "downloads")]
    cache = "lists/%s.json" % key(q, sort, page, rows)
    kept = load_json(cache, {})
    if kept.get("docs") is not None and time.time() - kept.get("t", 0) < LIST_AGE:
        return kept["docs"]
    reply = fetch_json("%s/advancedsearch.php?%s" % (ARCHIVE, urllib.parse.urlencode(params)))
    docs = [{"id": d["identifier"], "title": plain(first(d.get("title"))) or d["identifier"],
             "year": year_of(d.get("year") or d.get("date")), "plot": plain(d.get("description"))[:1500],
             "art": picture(d["identifier"])}
            for d in ((reply or {}).get("response") or {}).get("docs") or [] if d.get("identifier")]
    save_json(cache, {"docs": docs, "t": time.time()})
    return docs


def section_query(section_id):
    return next((q for s, _, q in SECTIONS if s == section_id), SECTIONS[0][2])


def words_query(words):
    words = re.sub(r'[^\w\s\'-]+', " ", words or "").strip()
    rule = " OR ".join(q for _, _, q in SECTIONS)
    return "(%s) AND title:(%s)" % (rule, words) if words else ""


def seconds(value):
    value = str(value or "").strip()
    if ":" in value:
        total = 0
        for part in value.split(":"):
            total = total * 60 + (float(part) if part.replace(".", "", 1).isdigit() else 0)
        return int(total)
    try:
        return int(float(value))
    except ValueError:
        return 0


def film(film_id, max_age=FILM_AGE):
    """{id, title, year, plot, art, url, duration, genres} - url: the video to play."""
    path = "films/%s.json" % key(film_id)
    kept = load_json(path, {})
    if kept.get("url") and time.time() - kept.get("t", 0) < max_age:
        return kept
    try:
        reply = fetch_json("%s/metadata/%s" % (ARCHIVE, urllib.parse.quote(film_id)))
    except Error:
        if kept.get("url"):
            return kept
        raise
    meta = (reply or {}).get("metadata") or {}
    files = [f for f in (reply or {}).get("files") or [] if f.get("format") in VIDEO_FORMATS]
    # (the first of the formats Kodi plays best; the biggest of that kind, which is the whole film)
    chosen = None
    for kind in VIDEO_FORMATS:
        same = [f for f in files if f.get("format") == kind]
        if same:
            chosen = max(same, key=lambda f: int(f.get("size") or 0))
            break
    subjects = meta.get("subject") or []
    if isinstance(subjects, str):
        subjects = re.split(r"\s*;\s*", subjects)
    found = {"id": film_id, "title": plain(first(meta.get("title"))) or film_id,
             "year": year_of(meta.get("year") or meta.get("date")), "plot": plain(meta.get("description"))[:3000],
             "art": picture(film_id), "genres": [s.strip().title() for s in subjects[:3] if s.strip()],
             "url": "%s/download/%s/%s" % (ARCHIVE, urllib.parse.quote(film_id), urllib.parse.quote(chosen["name"]))
             if chosen else "",
             "duration": seconds(chosen.get("length")) if chosen else 0, "t": time.time()}
    save_json(path, found)
    return found


def cached_film(film_id):
    return load_json("films/%s.json" % key(film_id), {})


# --------------------------------------------------------------------------- My List

def my_list():
    return [f for f in load_json("mylist.json", []) if isinstance(f, dict) and f.get("id")]


def in_list(film_id):
    return any(f["id"] == film_id for f in my_list())


def set_list(f, on):
    found = [x for x in my_list() if x["id"] != f["id"]]
    if on:
        found.insert(0, {"id": f["id"], "title": f.get("title", ""), "year": f.get("year", 0), "t": time.time()})
    save_json("mylist.json", found)


# --------------------------------------------------------------------------- progress

def progress():
    return load_json("progress.json", {})


def state(film_id):
    """(position, total, watched)"""
    p = progress().get(film_id) or {}
    return p.get("pos", 0), p.get("total", 0), bool(p.get("done"))


def record(entry, pos, total, furthest):
    data = progress()
    done = total > 0 and furthest >= WATCHED
    data[entry["id"]] = {"title": entry.get("title", ""), "year": entry.get("year", 0),
                         "pos": 0 if done else int(pos), "total": int(total), "done": done, "t": time.time()}
    save_json("progress.json", data)
    write_home()


def set_watched(f, done):
    data = progress()
    data[f["id"]] = {"title": f.get("title", ""), "year": f.get("year", 0), "pos": 0,
                     "total": (data.get(f["id"]) or {}).get("total", 0), "done": bool(done), "t": time.time()}
    save_json("progress.json", data)
    write_home()


def continue_watching(limit=30):
    return [dict(p, id=i) for i, p in sorted(progress().items(), key=lambda kv: -kv[1].get("t", 0))
            if p.get("pos", 0) > 60 and not p.get("done")][:limit]


def play_address(film_id, resume=None):
    params = {"mode": "play", "id": film_id}
    if resume is not None:
        params["resume"] = int(bool(resume))
    return "plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode(params))


def write_home():
    """home.json: MediaHub's Classics: Continue Watching and Classic Films rows."""
    cards = {"clcontinue": [], "clfilms": []}
    for p in continue_watching(HOME_CARDS):
        cards["clcontinue"].append({
            "Label": p.get("title", ""), "Label2": str(p.get("year") or ""), "Title": p.get("title", ""),
            "Landscape": picture(p["id"]), "Poster": picture(p["id"]), "Plot": p.get("plot", ""),
            "Percent": str(int(100 * p["pos"] / p["total"])) if p.get("total") else "",
            "Action": "classics|run|" + play_address(p["id"], resume=True), "Kind": "classic", "kids": False})
    popular = load_json("popular.json", [])
    for f in popular[:HOME_CARDS]:
        cards["clfilms"].append({
            "Label": f.get("title", ""), "Label2": str(f.get("year") or ""), "Title": f.get("title", ""),
            "Landscape": picture(f["id"]), "Poster": picture(f["id"]), "Plot": f.get("plot", ""),
            "Action": "classics|run|" + play_address(f["id"]), "Kind": "classic", "kids": False})
    save_json("home.json", cards)
    xbmcgui.Window(10000).setProperty("MHL.Home", str(time.time()))  # (the helper refreshes the rows)


def refresh_popular():
    """A day's pick of well-liked films for the Classic Films row (a different page each day)."""
    day = int(time.time() // 86400)
    try:
        found = search(section_query("films"), "downloads desc", 1 + day % 5, 20)
    except Error:
        return
    save_json("popular.json", [{"id": f["id"], "title": f["title"], "year": f["year"], "plot": f["plot"][:400]}
                               for f in found])
    write_home()
