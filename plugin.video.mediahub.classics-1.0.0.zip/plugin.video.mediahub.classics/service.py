"""MediaHub Classics - in the background while Kodi runs.

- Notes how far into a film from the add-on you are while it plays (resume, the
  watched tick, Continue watching).
- Once a day, picks the films for MediaHub's Classic Films home row.
"""
import json
import os
import sys
import threading
import time

import xbmc
import xbmcgui

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import films  # noqa: E402

FIRST_PICK = 90  # seconds after Kodi starts
PICK_EVERY = 24 * 3600


class Tracker:
    def __init__(self):
        self.next = 0.0
        self.path = None
        self.entry = None
        self.pos = self.total = self.furthest = 0.0
        self.saved = 0.0

    def tick(self):
        now = time.time()
        if now < self.next:
            return
        self.next = now + 2.0
        path = xbmc.getInfoLabel("Player.Filenameandpath") if xbmc.getCondVisibility("Player.HasVideo") else ""
        if path != self.path:
            self.finish()
            self.path = path
            if path:
                try:
                    playing = json.loads(xbmcgui.Window(10000).getProperty(films.NOW) or "{}")
                except ValueError:
                    playing = {}
                self.entry = playing.get(path)
        if not self.entry:
            return
        try:
            player = xbmc.Player()
            self.pos, self.total = player.getTime(), player.getTotalTime()
        except RuntimeError:
            return
        if self.total > 0:
            self.furthest = max(self.furthest, self.pos / self.total)
        if now - self.saved > 15:
            self.record()
            self.saved = now

    def record(self):
        if self.entry and self.total > 0 and self.pos >= 5:
            films.record(self.entry, self.pos, self.total, self.furthest)

    def finish(self):
        if self.entry:
            self.record()
        self.entry = None
        self.pos = self.total = self.furthest = 0.0


class Service(xbmc.Monitor):
    def run(self):
        tracker = Tracker()
        next_pick = time.time() + FIRST_PICK
        while not self.waitForAbort(1):
            try:
                tracker.tick()
                if time.time() >= next_pick and not xbmc.getCondVisibility("Player.HasVideo"):
                    next_pick = time.time() + PICK_EVERY
                    threading.Thread(target=films.refresh_popular, daemon=True).start()
            except Exception as exc:  # (never take the service down)
                xbmc.log("MediaHub Classics: %r" % exc, xbmc.LOGERROR)
        tracker.finish()


if __name__ == "__main__":
    Service().run()
