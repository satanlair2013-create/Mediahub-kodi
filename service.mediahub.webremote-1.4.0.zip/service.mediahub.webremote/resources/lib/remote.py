"""MediaHub Web Remote - what the phone page asks Kodi for.

Everything goes through Kodi's own JSON-RPC (xbmc.executeJSONRPC), so Kodi's web
server doesn't have to be on. A phone has to be paired once: it gets a key that
it sends with every request (a header, so another web page can't send it).
"""
import json
import os
import re
import secrets
import struct
import time
import urllib.parse
import zlib

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "service.mediahub.webremote"
XTREAM = "plugin.video.mediahub.xtream"
RADIO = "plugin.audio.mediahub.radio"
PAIR = "MHW.Pair"  # Window(Home) property: {"code": "4821", "until": epoch} while a code is on the TV
PAIR_TIME = 180
MAX_TRIES = 8
# Input.ExecuteAction names the page may send
ACTIONS = {"up", "down", "left", "right", "select", "back", "info", "contextmenu", "osd", "playpause", "stop",
           "skipnext", "skipprevious", "stepforward", "stepback", "bigstepforward", "bigstepback", "volumeup",
           "volumedown", "mute", "fullscreen", "nextsubtitle", "showsubtitles", "audionextlanguage",
           "pageup", "pagedown", "channelup", "channeldown"}
AUDIO_STEP = 0.025  # (a press of Kodi's audio offset; the subtitle offset's is 0.1)


def profile(name=""):
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)


def load_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(path, data):
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                       "params": params})))
    return reply.get("result")


def has_addon(addon_id):
    return xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id)


def text(string_id):
    return xbmcaddon.Addon(ADDON_ID).getLocalizedString(string_id)


# --------------------------------------------------------------------------- pairing

def tokens():
    return load_json(profile("phones.json"), {})


def valid(token):
    return bool(token) and token in tokens()


def new_code(multi=False, lifetime=PAIR_TIME):
    """A pairing code for the TV to show (and the QR code to carry). A multi code (the
    movie quiz's lobby) pairs every phone that uses it while it lasts."""
    code = "%04d" % secrets.randbelow(10000)
    xbmcgui.Window(10000).setProperty(PAIR, json.dumps({"code": code, "until": time.time() + lifetime,
                                                        "tries": 0, "multi": multi}))
    return code


def current_code():
    try:
        pair = json.loads(xbmcgui.Window(10000).getProperty(PAIR) or "{}")
    except ValueError:
        return None
    return pair if pair.get("until", 0) > time.time() and pair.get("tries", 0) < MAX_TRIES else None


def pair(code, name):
    """The phone's key when the code is the one on the TV (None otherwise)."""
    pending = current_code()
    if not pending:
        return None
    if not secrets.compare_digest(str(code), pending["code"]):
        pending["tries"] = pending.get("tries", 0) + 1
        xbmcgui.Window(10000).setProperty(PAIR, json.dumps(pending))
        return None
    if not pending.get("multi"):
        xbmcgui.Window(10000).clearProperty(PAIR)
    token = secrets.token_urlsafe(24)
    phones = tokens()
    phones[token] = {"name": (name or "Phone")[:60], "added": time.time()}
    save_json(profile("phones.json"), phones)
    if not pending.get("multi"):
        xbmc.executebuiltin("Dialog.Close(okdialog)")  # (the code on the TV isn't needed now)
    xbmcgui.Dialog().notification(xbmcaddon.Addon(ADDON_ID).getAddonInfo("name"), text(30012) % phones[token]["name"],
                                  xbmcaddon.Addon(ADDON_ID).getAddonInfo("icon"), 4000, False)
    return token


def forget_phones():
    save_json(profile("phones.json"), {})


def address():
    """This Kodi's address on the home network, for the phone."""
    port = port_setting()
    ip = xbmc.getIPAddress() or "127.0.0.1"
    return "http://%s:%d" % (ip, port)


def port_setting():
    try:
        return int(xbmcaddon.Addon(ADDON_ID).getSetting("port") or 8585)
    except ValueError:
        return 8585


# --------------------------------------------------------------------------- QR code

def qr_png(data, path, scale=10, border=3):
    """Write data as a QR code, black on white, to a PNG file."""
    import qrcodegen
    qr = qrcodegen.QrCode.encode_text(data, qrcodegen.QrCode.Ecc.MEDIUM)
    size = qr.get_size() + 2 * border
    rows = []
    for y in range(size):
        line = bytearray()
        for x in range(size):
            dark = qr.get_module(x - border, y - border)
            line += (b"\x00\x00\x00" if dark else b"\xff\xff\xff") * scale  # (RGB: Kodi's direct loader
            # doesn't read a grey-only PNG)
        rows += [bytes(line)] * scale
    width = size * scale
    raw = b"".join(b"\x00" + r for r in rows)

    def chunk(kind, body):
        return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body) & 0xffffffff)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, width, 8, 2, 0, 0, 0)) + \
        chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(png)
    return path


# --------------------------------------------------------------------------- what's playing

def art_url(image):
    """An address the phone can load a Kodi picture from (through this service)."""
    if not image or not ("://" in image or image.startswith("/")):
        return ""  # (Kodi's own icons, like DefaultAudio.png, only exist inside the skin)
    return "/art?u=" + urllib.parse.quote(image, safe="")


def state(token=""):
    players = rpc("Player.GetActivePlayers") or []
    app = rpc("Application.GetProperties", properties=["volume", "muted"]) or {}
    home = xbmcgui.Window(10000)
    out = {"volume": app.get("volume", 0), "muted": app.get("muted", False), "playing": None,
           "iptv": has_addon(XTREAM), "radio": has_addon(RADIO),
           "live": bool(home.getProperty("MHX.OSD")), "window": xbmc.getInfoLabel("System.CurrentWindow")}
    asked = kids_question()
    if asked:
        out["ask"] = {"id": asked["id"], "kind": asked["kind"], "pin": not grown_up(token)}
    if not players:
        return out
    player = players[0]
    pid = player["playerid"]
    item = (rpc("Player.GetItem", playerid=pid, properties=["title", "artist", "album", "showtitle", "season",
                                                              "episode", "art", "thumbnail", "file", "year"]) or {}
            ).get("item") or {}
    props = rpc("Player.GetProperties", playerid=pid, properties=["time", "totaltime", "speed", "percentage",
                                                                  "live"]) or {}
    art = item.get("art") or {}
    title = item.get("title") or item.get("label") or ""
    if item.get("showtitle"):
        sub = "%s  •  S%d E%d" % (item["showtitle"], item.get("season") or 0, item.get("episode") or 0)
    elif item.get("artist"):
        sub = ", ".join(item["artist"]) + ("  •  %s" % item["album"] if item.get("album") else "")
    else:
        sub = str(item.get("year") or "") if item.get("year") else ""
    live_name = home.getProperty("MHX.Live.Name")
    if home.getProperty("MHX.OSD") and live_name:  # (a MediaHub IPTV channel: what's on it)
        title, sub = home.getProperty("MHX.Now.Title") or live_name, live_name
    picture = art.get("poster") or art.get("thumb") or art.get("tvshow.poster") or art.get("album.thumb") or \
        item.get("thumbnail") or art.get("fanart") or ""

    def secs(t):
        return (t or {}).get("hours", 0) * 3600 + (t or {}).get("minutes", 0) * 60 + (t or {}).get("seconds", 0)
    out["playing"] = {"type": player.get("type"), "title": title, "sub": sub, "art": art_url(picture),
                      "fanart": art_url(art.get("fanart") or ""), "time": secs(props.get("time")),
                      "total": secs(props.get("totaltime")), "paused": props.get("speed") == 0,
                      "live": bool(props.get("live"))}
    out["queue"] = up_next(pid)
    out["take"] = player.get("type") == "audio" and not home.getProperty("MHQ.Phase")  # (not a quiz's tune)
    if player.get("type") == "video":  # (for "out of sync?": Kodi keeps these for each film)
        out["sync"] = {"sub": offset("Player.SubtitleDelay"), "audio": offset("Player.AudioDelay")}
    out["key"] = "%s:%s" % (item.get("type") or "", item.get("id") or item.get("file") or title)
    return out


def player_id():
    players = rpc("Player.GetActivePlayers") or []
    return players[0]["playerid"] if players else None


def do(action):
    if action == "home":
        rpc("GUI.ActivateWindow", window="home")
    elif action in ("channelup", "channeldown") and xbmcgui.Window(10000).getProperty("MHX.OSD"):
        # (a MediaHub IPTV channel: the next one in the list it came from)
        xbmc.executebuiltin("RunPlugin(plugin://%s/?mode=channelstep&step=%d)" % (XTREAM, 1 if action == "channelup"
                                                                                  else -1))
    elif action == "lastchannel":
        xbmc.executebuiltin("RunPlugin(plugin://%s/?mode=lastchannel)" % XTREAM)
    elif action in ACTIONS:
        rpc("Input.ExecuteAction", action=action)


def offset(label):
    """Kodi's subtitle or audio offset now, in seconds (its label reads like "-0.100 s")."""
    try:
        return round(float(re.sub(r"[^0-9.\-]", "", xbmc.getInfoLabel(label)) or 0), 3)
    except ValueError:
        return 0.0


def nudge(what, way):
    """Subtitles or the sound out of step with the picture. what: "sub" or "audio"; way:
    "early" (they come too early: 0.1 s later), "late" (0.1 s earlier) or "reset". Kodi's own
    offset, so it shows its slider on the TV and remembers it for this video."""
    if player_id() is None or what not in ("sub", "audio"):
        return
    step = 0.1 if what == "sub" else AUDIO_STEP
    name = "subtitledelay" if what == "sub" else "audiodelay"
    # (a positive offset brings subtitles, or the sound, earlier)
    if way == "reset":
        now = offset("Player.SubtitleDelay" if what == "sub" else "Player.AudioDelay")
        presses, way = int(round(abs(now) / step)), "late" if now < 0 else "early"
    else:
        presses = int(round(0.1 / step))
    for _ in range(min(presses, 400)):
        rpc("Input.ExecuteAction", action=name + ("plus" if way == "late" else "minus"))


def seek(percent=None, seconds=None):
    pid = player_id()
    if pid is None:
        return
    if percent is not None:
        rpc("Player.Seek", playerid=pid, value={"percentage": max(0.0, min(100.0, float(percent)))})
    elif seconds is not None:
        rpc("Player.Seek", playerid=pid, value={"seconds": int(seconds)})


def volume(level=None, step=None, mute=None):
    if mute is not None:
        rpc("Application.SetMute", mute="toggle")
    elif step is not None:
        rpc("Application.SetVolume", volume="increment" if step > 0 else "decrement")
    elif level is not None:
        rpc("Application.SetVolume", volume=max(0, min(100, int(level))))


def send_text(words, done=True):
    rpc("Input.SendText", text=words, done=done)


# --------------------------------------------------------------------------- finding things

def directory(path, limit=40):
    reply = rpc("Files.GetDirectory", directory=path, media="files", properties=["thumbnail", "art"],
                limits={"start": 0, "end": limit}) or {}
    found = []
    for f in reply.get("files") or []:
        art = f.get("art") or {}
        found.append({"label": re.sub(r"\[/?[A-Z]+[^\]]*\]", "", f.get("label") or ""),
                      "art": art_url(art.get("thumb") or art.get("icon") or f.get("thumbnail") or ""),
                      "open": {"file": f.get("file"), "folder": f.get("filetype") == "directory"}})
    return found


def search(words):
    words = (words or "").strip()
    if not words:
        return []
    groups = []
    rule = {"field": "title", "operator": "contains", "value": words}
    movies = (rpc("VideoLibrary.GetMovies", filter=rule, properties=["year", "art"],
                  limits={"start": 0, "end": 12}) or {}).get("movies") or []
    if movies:
        groups.append({"title": xbmc.getLocalizedString(342), "items": [
            {"label": m["label"], "sub": str(m.get("year") or ""),
             "art": art_url((m.get("art") or {}).get("poster", "")), "open": {"movieid": m["movieid"]}}
            for m in movies]})
    shows = (rpc("VideoLibrary.GetTVShows", filter=rule, properties=["year", "art"],
                 limits={"start": 0, "end": 12}) or {}).get("tvshows") or []
    if shows:
        groups.append({"title": xbmc.getLocalizedString(20343), "items": [
            {"label": s["label"], "sub": str(s.get("year") or ""),
             "art": art_url((s.get("art") or {}).get("poster", "")), "open": {"tvshowid": s["tvshowid"]}}
            for s in shows]})
    if has_addon(XTREAM):
        found = directory("plugin://%s/?mode=search&q=%s" % (XTREAM, urllib.parse.quote(words)), 30)
        if found:
            groups.append({"title": "IPTV", "items": found})
    return groups


def channels():
    """MediaHub IPTV's My channels and Recent channels, and MediaHub Radio's stations."""
    groups = []
    if has_addon(XTREAM):
        for mode, title in (("favourites", text(30020)), ("recentchannels", text(30021))):
            found = directory("plugin://%s/?mode=%s" % (XTREAM, mode))
            if found:
                groups.append({"title": title, "items": found})
    if has_addon(RADIO):
        mine = load_json(xbmcvfs.translatePath("special://profile/addon_data/%s/favourites.json" % RADIO), [])
        items = []
        for s in mine:
            if isinstance(s, dict) and s.get("id"):
                target = "plugin://%s/?%s" % (RADIO, urllib.parse.urlencode(
                    {"mode": "play", "id": s["id"], "name": s.get("name", ""), "url": s.get("url", ""),
                     "icon": s.get("icon", "")}))
                items.append({"label": s.get("name", ""), "art": art_url(s.get("icon", "")),
                              "open": {"file": target, "folder": False}})
        if items:
            groups.append({"title": text(30022), "items": items})
    return groups


def open_item(what):
    if what.get("movieid"):
        rpc("Player.Open", item={"movieid": int(what["movieid"])}, options={"resume": True})
    elif what.get("episodeid"):
        rpc("Player.Open", item={"episodeid": int(what["episodeid"])}, options={"resume": True})
    elif what.get("tvshowid"):
        rpc("GUI.ActivateWindow", window="videos", parameters=["videodb://tvshows/titles/%d/" % int(what["tvshowid"])])
    elif what.get("setid"):  # (a collection: its films, on the TV)
        rpc("GUI.ActivateWindow", window="videos", parameters=["videodb://movies/sets/%d/" % int(what["setid"])])
    elif what.get("file"):
        target = str(what["file"])
        if not re.match(r"^(plugin|videodb|musicdb|special|https?|smb|nfs)://", target):
            return
        if what.get("folder"):
            window = "Music" if target.startswith("plugin://plugin.audio.") else "Videos"
            xbmc.executebuiltin("ActivateWindow(%s,%s,return)" % (window, target))
        elif target.startswith("plugin://"):
            xbmc.executebuiltin("RunPlugin(%s)" % target)
        else:
            rpc("Player.Open", item={"file": target})


# --------------------------------------------------------------------------- the play-next queue
# (Kodi's own playlist: what comes after the thing playing now)

QUEUE_MAX = 30


def playlist_of(pid):
    return (rpc("Player.GetProperties", playerid=pid, properties=["playlistid", "position"]) or {})


def up_next(pid):
    props = playlist_of(pid)
    plid, position = props.get("playlistid"), props.get("position", -1)
    if plid is None or plid < 0:
        return []
    items = (rpc("Playlist.GetItems", playlistid=plid, properties=["title", "showtitle", "season", "episode",
                                                                     "artist", "art", "thumbnail", "year"]) or {}
             ).get("items") or []
    out = []
    for i, it in enumerate(items):
        if i <= position:
            continue
        art = it.get("art") or {}
        if it.get("showtitle"):
            sub = "%s  •  S%d E%d" % (it["showtitle"], it.get("season") or 0, it.get("episode") or 0)
        elif it.get("artist"):
            sub = ", ".join(it["artist"])
        else:
            sub = str(it.get("year") or "") if it.get("year") else ""
        out.append({"index": i, "title": it.get("title") or it.get("label") or "", "sub": sub,
                    "art": art_url(art.get("poster") or art.get("thumb") or art.get("tvshow.poster") or
                                   it.get("thumbnail") or "")})
        if len(out) >= QUEUE_MAX:
            break
    return out


def queue_item(what):
    """(playlist id, Kodi's playlist item) for a search result; a TV show is its next
    episode not watched yet."""
    if what.get("movieid"):
        return 1, {"movieid": int(what["movieid"])}
    if what.get("episodeid"):
        return 1, {"episodeid": int(what["episodeid"])}
    if what.get("tvshowid"):
        eps = (rpc("VideoLibrary.GetEpisodes", tvshowid=int(what["tvshowid"]),
                   filter={"field": "playcount", "operator": "is", "value": "0"},
                   sort={"method": "episode"}, limits={"start": 0, "end": 1}) or {}).get("episodes") or []
        return (1, {"episodeid": eps[0]["episodeid"]}) if eps else (None, None)
    target = str(what.get("file") or "")
    if target and not what.get("folder") and re.match(r"^(plugin|videodb|musicdb|special|https?|smb|nfs)://", target):
        return (0 if target.startswith(("plugin://plugin.audio.", "musicdb://")) else 1), {"file": target}
    return None, None


def queue(what, how="next"):
    """how: "now" (play it), "next" (after what's playing) or "end" (at the end of the queue).
    With nothing playing, it just plays."""
    plid, item = queue_item(what)
    if item is None:
        return False
    pid = player_id()
    props = playlist_of(pid) if pid is not None else {}
    if how == "now" or pid is None or props.get("playlistid") != plid:
        if what.get("tvshowid"):
            rpc("Player.Open", item=item, options={"resume": True})
        else:
            open_item(what)
        return True
    if how == "next":
        rpc("Playlist.Insert", playlistid=plid, position=props.get("position", 0) + 1, item=item)
    else:
        rpc("Playlist.Add", playlistid=plid, item=item)
    return True


def queue_change(index, how):
    """how: "up", "down" or "remove", for the entry at index (not the one playing)."""
    pid = player_id()
    if pid is None:
        return
    props = playlist_of(pid)
    plid, position = props.get("playlistid"), props.get("position", -1)
    size = len((rpc("Playlist.GetItems", playlistid=plid) or {}).get("items") or [])
    index = int(index)
    if index <= position or index >= size:
        return
    if how == "remove":
        rpc("Playlist.Remove", playlistid=plid, position=index)
    elif how == "up" and index - 1 > position:
        rpc("Playlist.Swap", playlistid=plid, position1=index, position2=index - 1)
    elif how == "down" and index + 1 < size:
        rpc("Playlist.Swap", playlistid=plid, position1=index, position2=index + 1)


# --------------------------------------------------------------------------- second screen
# (while a film or an episode from the library plays: its story, its cast, and what's next)

def poster(art, fallback=""):
    art = art or {}
    return art_url(art.get("poster") or art.get("tvshow.poster") or art.get("thumb") or fallback)


def playing_details():
    pid = player_id()
    if pid is None:
        return {}
    item = (rpc("Player.GetItem", playerid=pid, properties=["plot", "cast", "genre", "rating", "tagline", "tvshowid",
                                                              "season", "episode", "year", "runtime", "director"])
            or {}).get("item") or {}
    kind, dbid = item.get("type"), item.get("id")
    if kind not in ("movie", "episode") or not dbid:
        return {}
    out = {"key": "%s:%s" % (kind, dbid), "plot": item.get("plot") or "", "tagline": item.get("tagline") or "",
           "facts": "  •  ".join(x for x in [str(item.get("year") or ""), ", ".join((item.get("genre") or [])[:3]),
                                             ("%.1f" % item["rating"]) if item.get("rating") else "",
                                             ", ".join((item.get("director") or [])[:2])] if x and x != "0"),
           "cast": [{"name": c.get("name", ""), "role": c.get("role", ""), "art": art_url(c.get("thumbnail", ""))}
                    for c in (item.get("cast") or [])[:24] if c.get("name")]}
    if kind == "episode" and (item.get("tvshowid") or 0) > 0:
        eps = (rpc("VideoLibrary.GetEpisodes", tvshowid=item["tvshowid"], properties=["title", "season", "episode",
                                                                                      "art", "plot"],
                   sort={"method": "episode"}) or {}).get("episodes") or []
        here = (item.get("season") or 0, item.get("episode") or 0)
        later = [e for e in eps if (e.get("season") or 0, e.get("episode") or 0) > here and e.get("season")]
        if later:
            e = later[0]
            out["next"] = {"label": e.get("title") or e.get("label", ""),
                           "sub": "S%d E%d" % (e.get("season") or 0, e.get("episode") or 0),
                           "art": art_url((e.get("art") or {}).get("thumb", "")), "plot": e.get("plot") or "",
                           "open": {"episodeid": e["episodeid"]}}
    return out


def actor(name):
    """What else a cast member is in, from this library."""
    name = (name or "").strip()
    if not name:
        return []
    rule = {"field": "actor", "operator": "is", "value": name}
    groups = []
    movies = (rpc("VideoLibrary.GetMovies", filter=rule, properties=["year", "art"], sort={"method": "year",
                                                                                         "order": "descending"},
                  limits={"start": 0, "end": 40}) or {}).get("movies") or []
    if movies:
        groups.append({"title": xbmc.getLocalizedString(342), "items": [
            {"label": m["label"], "sub": str(m.get("year") or ""), "art": poster(m.get("art")),
             "open": {"movieid": m["movieid"]}} for m in movies]})
    shows = (rpc("VideoLibrary.GetTVShows", filter=rule, properties=["year", "art"],
                 limits={"start": 0, "end": 40}) or {}).get("tvshows") or []
    if shows:
        groups.append({"title": xbmc.getLocalizedString(20343), "items": [
            {"label": x["label"], "sub": str(x.get("year") or ""), "art": poster(x.get("art")),
             "open": {"tvshowid": x["tvshowid"]}} for x in shows]})
    return groups


# --------------------------------------------------------------------------- ask a grown-up
# (Kids mode's bedtime and screen-time screens ask the phones: the MediaHub Helper's asking.py)

def kids_question():
    try:
        asked = json.loads(xbmcgui.Window(10000).getProperty("MH.Ask") or "{}")
    except ValueError:
        return None
    return asked if asked.get("id") and time.time() - asked.get("t", 0) < 15 * 60 else None


def grown_up(token):
    """A phone that has answered with the Kids mode PIN once (or any phone, with no PIN set)."""
    return not xbmc.getInfoLabel("Skin.String(MH.KidsPin)") or bool(tokens().get(token, {}).get("grownup"))


def ask_answer(token, ask_id, answer, pin=""):
    """"ok", "pin" (the Kids mode PIN is needed, or was wrong) or "gone"."""
    asked = kids_question()
    if not asked or str(ask_id) != asked["id"] or str(answer) not in ("yes", "no", "15", "30", "60", "day"):
        return "gone"
    if not grown_up(token):
        if not pin or not secrets.compare_digest(str(pin), xbmc.getInfoLabel("Skin.String(MH.KidsPin)")):
            return "pin"
        phones = tokens()
        if token in phones:
            phones[token]["grownup"] = True
            save_json(profile("phones.json"), phones)
    who = tokens().get(token, {}).get("name", "")
    xbmcgui.Window(10000).setProperty("MH.Ask.Answer", json.dumps({"id": asked["id"], "answer": str(answer),
                                                                    "who": who}))
    return "ok"


# --------------------------------------------------------------------------- reactions
# (a phone's emoji floating up over the picture: the MediaHub Helper shows them)

REACTIONS = ("laugh", "wow", "love", "clap", "scared", "like", "popcorn", "sad")
_sent = {}  # key: the times of its last few reactions


def react(token, kind, name):
    if kind not in REACTIONS:
        return False
    now = time.time()
    recent = [t for t in _sent.get(token, []) if now - t < 2]
    if len(recent) >= 6:  # (a few a second at most, however fast someone taps)
        return False
    _sent[token] = recent + [now]
    who = re.sub(r"\s+", " ", str(name or "")).strip()[:16] or tokens().get(token, {}).get("name", "")
    home = xbmcgui.Window(10000)
    try:
        waiting = json.loads(home.getProperty("MH.React.In") or "[]")
    except ValueError:
        waiting = []
    home.setProperty("MH.React.In", json.dumps((waiting if isinstance(waiting, list) else [])[-20:] +
                                               [{"k": kind, "n": who}]))
    return True


# --------------------------------------------------------------------------- your library, from the phone
# (My List and the thumbs go through the MediaHub Helper, so the TV's rows and badges follow)

HELPER = "script.mediahub.helper"


def item_ref(what):
    for kind in ("movie", "tvshow", "episode"):
        if str(what.get(kind + "id") or "").isdigit():
            return kind, int(what[kind + "id"])
    return None, None


def item_info(what):
    """{kind, mylist, watched, rating} of a film, show or episode."""
    kind, dbid = item_ref(what)
    if not kind:
        return {}
    method = {"movie": "VideoLibrary.GetMovieDetails", "tvshow": "VideoLibrary.GetTVShowDetails",
              "episode": "VideoLibrary.GetEpisodeDetails"}[kind]
    props = ["userrating", "playcount"] + (["tag"] if kind != "episode" else []) + \
        (["watchedepisodes", "episode"] if kind == "tvshow" else [])
    d = (rpc(method, **{kind + "id": dbid, "properties": props}) or {}).get(kind + "details") or {}
    if not d:
        return {}
    watched = d.get("watchedepisodes", 0) >= d.get("episode", 1) > 0 if kind == "tvshow" else bool(d.get("playcount"))
    return {"kind": kind, "mylist": "My List" in (d.get("tag") or []), "watched": watched,
            "rating": d.get("userrating") or 0, "helper": has_addon(HELPER), "canlist": kind != "episode"}


def library_action(what, action):
    """mylist (on / off), watched, unwatched, up, down (a thumb; the same again takes it off)."""
    kind, dbid = item_ref(what)
    if not kind:
        return False
    home = xbmcgui.Window(10000)
    if action == "mylist" and kind != "episode" and has_addon(HELPER):
        home.setProperty("MH.Req.Action", "mylist|%s|%d" % (kind, dbid))
    elif action in ("up", "down") and has_addon(HELPER):
        home.setProperty("MH.Req.Action", "rate|%s|%d|%d" % (kind, dbid, 8 if action == "up" else 2))
    elif action in ("watched", "unwatched"):
        count = 1 if action == "watched" else 0
        if kind == "tvshow":
            for e in (rpc("VideoLibrary.GetEpisodes", tvshowid=dbid) or {}).get("episodes") or []:
                rpc("VideoLibrary.SetEpisodeDetails", episodeid=e["episodeid"], playcount=count,
                    resume={"position": 0, "total": 0})
        else:
            rpc("VideoLibrary.Set%sDetails" % ("Movie" if kind == "movie" else "Episode"),
                **{kind + "id": dbid, "playcount": count, "resume": {"position": 0, "total": 0}})
    else:
        return False
    return True


# --------------------------------------------------------------------------- browse
# (the library on the phone: the rows the TV's home screen starts with)

BROWSE_MAX = 30


def movie_tile(m):
    return {"label": m.get("title") or m.get("label", ""), "sub": str(m.get("year") or ""), "art": poster(m.get("art")),
            "open": {"movieid": m["movieid"]}}


def episode_tile(e):
    return {"label": e.get("showtitle") or e.get("label", ""),
            "sub": "S%d E%d  %s" % (e.get("season") or 0, e.get("episode") or 0, e.get("title") or ""),
            "art": poster(e.get("art")), "open": {"episodeid": e["episodeid"]}}


def browse(setid=None):
    if setid:
        found = (rpc("VideoLibrary.GetMovieSetDetails", setid=int(setid), properties=["title"],
                     movies={"properties": ["title", "year", "art"], "sort": {"method": "year"}}) or {}
                 ).get("setdetails") or {}
        movies = found.get("movies") or []
        return [{"title": "", "items": [movie_tile(m) for m in movies]}] if movies else []
    groups = []
    going = {"field": "inprogress", "operator": "true", "value": ""}
    latest = {"method": "lastplayed", "order": "descending"}
    started = [(m.get("lastplayed") or "", movie_tile(m)) for m in
               (rpc("VideoLibrary.GetMovies", filter=going, sort=latest, properties=["title", "year", "art", "lastplayed"],
                    limits={"start": 0, "end": BROWSE_MAX}) or {}).get("movies") or []]
    started += [(e.get("lastplayed") or "", episode_tile(e)) for e in
                (rpc("VideoLibrary.GetEpisodes", filter=going, sort=latest,
                     properties=["title", "showtitle", "season", "episode", "art", "lastplayed"],
                     limits={"start": 0, "end": BROWSE_MAX}) or {}).get("episodes") or []]
    started.sort(key=lambda x: x[0], reverse=True)
    if started:
        groups.append({"title": text(30176), "items": [t for _, t in started[:BROWSE_MAX]]})
    movies = (rpc("VideoLibrary.GetRecentlyAddedMovies", properties=["title", "year", "art"],
                  limits={"start": 0, "end": BROWSE_MAX}) or {}).get("movies") or []
    if movies:
        groups.append({"title": text(30177), "items": [movie_tile(m) for m in movies]})
    eps = (rpc("VideoLibrary.GetRecentlyAddedEpisodes", properties=["title", "showtitle", "season", "episode", "art"],
               limits={"start": 0, "end": BROWSE_MAX}) or {}).get("episodes") or []
    if eps:
        groups.append({"title": text(30178), "items": [episode_tile(e) for e in eps]})
    mine = {"field": "tag", "operator": "is", "value": "My List"}  # (MediaHub's My List)
    listed = [movie_tile(m) for m in (rpc("VideoLibrary.GetMovies", filter=mine, properties=["title", "year", "art"])
                                      or {}).get("movies") or []]
    listed += [{"label": x["label"], "sub": str(x.get("year") or ""), "art": poster(x.get("art")),
                "open": {"tvshowid": x["tvshowid"]}}
               for x in (rpc("VideoLibrary.GetTVShows", filter=mine, properties=["year", "art"]) or {}
                         ).get("tvshows") or []]
    if listed:
        groups.append({"title": text(30179), "items": listed[:60]})
    sets = (rpc("VideoLibrary.GetMovieSets", properties=["title", "art"], sort={"method": "sorttitle"}) or {}
            ).get("sets") or []
    if sets:
        groups.append({"title": text(30180), "items": [
            {"label": x.get("title") or x.get("label", ""), "art": poster(x.get("art")), "open": {"setid": x["setid"]}}
            for x in sets]})
    return groups


# --------------------------------------------------------------------------- take it with you
# (what's playing on the TV carries on in the phone's browser from the same second, and the TV
# stops; "Back to the TV" hands it back from wherever the phone got to)

TAKEN = "MHW.Taken"  # Window(Home): what the TV was playing, to hand it back
TAKE_MAX = 100
_files = {}  # token: a file only Kodi can read (the library's music, a downloaded episode), for /media
KEPT = ("MHB.Now", "MHP.Now")  # (MediaHub Audiobooks' and Podcasts': which book or episode this is)


def media_file(token):
    return _files.get(token)


def phone_address(path):
    """An address the phone's browser can play path from: itself when it's on the web, or else
    through this service."""
    if re.match(r"^https?://", path, re.I) and not re.match(r"^https?://(127\.|localhost[:/]|\[::1\])", path, re.I):
        return path  # (Kodi's own machine's addresses mean nothing to the phone: those come through here)
    if not path or path.startswith(("plugin://", "pvr://", "upnp://")) or re.search(r"\.(strm|m3u8?|pls)$", path, re.I):
        return None
    token = secrets.token_urlsafe(12)
    _files[token] = path
    return "/media/" + token


def plugin_stream(plugin_url):
    """The stream a MediaHub Radio station's plugin address stands for."""
    query = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(plugin_url).query))
    return query.get("url") or ""


def takeaway():
    pid = player_id()
    players = rpc("Player.GetActivePlayers") or []
    if pid is None or players[0].get("type") != "audio":
        return {"error": "nothing"}
    props = rpc("Player.GetProperties", playerid=pid, properties=["time", "totaltime", "live", "playlistid",
                                                                  "position"]) or {}
    total = props.get("totaltime") or {}
    live = bool(props.get("live")) or not (total.get("hours") or total.get("minutes") or total.get("seconds"))
    fields = ["title", "artist", "album", "art", "thumbnail", "file", "duration"]
    plid, position = props.get("playlistid", -1), props.get("position", -1)
    items = []
    if plid is not None and plid >= 0 and position >= 0:
        items = ((rpc("Playlist.GetItems", playlistid=plid, properties=fields) or {}).get("items") or []
                 )[position:position + TAKE_MAX]
    if not items:
        items = [(rpc("Player.GetItem", playerid=pid, properties=fields) or {}).get("item") or {}]
    _files.clear()
    tracks = []
    for n, it in enumerate(items):
        path = it.get("file") or ""
        if path.startswith("plugin://") and n == 0:
            try:
                playing = xbmc.Player().getPlayingFile()
            except RuntimeError:
                playing = ""
            path = playing if playing and not playing.startswith("plugin://") else plugin_stream(path)
        where = phone_address(path)
        if not where:
            break  # (a phone can't carry on from here)
        art = it.get("art") or {}
        tracks.append({"url": where, "title": it.get("title") or it.get("label") or "",
                       "sub": ", ".join(it.get("artist") or []) or it.get("album") or "",
                       "art": art_url(art.get("thumb") or art.get("album.thumb") or it.get("thumbnail") or ""),
                       "live": live if n == 0 else not it.get("duration")})
    if not tracks:
        return {"error": "cant"}
    t = props.get("time") or {}
    at = 0 if tracks[0]["live"] else t.get("hours", 0) * 3600 + t.get("minutes", 0) * 60 + t.get("seconds", 0)
    home = xbmcgui.Window(10000)
    keep = {k: home.getProperty(k) for k in KEPT if home.getProperty(k)}
    home.setProperty(TAKEN, json.dumps({"items": items[:len(tracks)], "keep": keep, "playlist": plid,
                                        "live": tracks[0]["live"]}))
    rpc("Player.Stop", playerid=pid)
    return {"ok": True, "tracks": tracks, "time": at}


def takeback(index, seconds):
    """Hand it back to the TV: the track the phone had got to, from that second."""
    try:
        taken = json.loads(xbmcgui.Window(10000).getProperty(TAKEN) or "{}")
    except ValueError:
        taken = {}
    items = taken.get("items") or []
    index = max(0, min(int(index or 0), len(items) - 1)) if items else 0
    if not items:
        return False
    home = xbmcgui.Window(10000)
    for k, v in (taken.get("keep") or {}).items():
        home.setProperty(k, v)
    playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    playlist.clear()
    for n, it in enumerate(items[index:]):
        item = xbmcgui.ListItem(it.get("title") or it.get("label") or "", path=it.get("file"))
        item.setArt(it.get("art") or {})
        tag = item.getMusicInfoTag()
        tag.setTitle(it.get("title") or it.get("label") or "")
        tag.setArtist(", ".join(it.get("artist") or []))
        tag.setAlbum(it.get("album") or "")
        if it.get("duration"):
            tag.setDuration(int(it["duration"]))
        if n == 0 and seconds and not taken.get("live"):
            item.setProperty("StartOffset", str(int(seconds)))
        playlist.add(it.get("file"), item)
    xbmc.Player().play(playlist)
    home.clearProperty(TAKEN)
    return True


# --------------------------------------------------------------------------- pictures

def picture(image):
    """(bytes, type) of a Kodi picture: image://<address>/ or an address Kodi can read."""
    inner = image
    if image.startswith("image://"):
        inner = urllib.parse.unquote(image[len("image://"):].rstrip("/"))
    if not re.match(r"^(https?|special|smb|nfs|/)", inner) and not re.match(r"^[A-Za-z]:\\", inner):
        return None, None
    if re.search(r"\.(py|xml|json|db|txt|log)$", inner.split("?")[0], re.I):
        return None, None  # (pictures only)
    f = xbmcvfs.File(inner)
    try:
        body = f.readBytes(8 * 1024 * 1024)
    finally:
        f.close()
    if not body:
        return None, None
    kind = "image/png" if body[:4] == b"\x89PNG" else "image/gif" if body[:3] == b"GIF" else \
        "image/webp" if body[8:12] == b"WEBP" else "image/jpeg"
    if not kind.startswith("image/") or (kind == "image/jpeg" and body[:2] != b"\xff\xd8"):
        return None, None
    return bytes(body), kind



# --------------------------------------------------------------------------- send to TV

YOUTUBE = "plugin.video.youtube"
YOUTUBE_ID = re.compile(r"(?:youtube\.com/(?:watch\?(?:.*&)?v=|shorts/|live/|embed/)|youtu\.be/)([A-Za-z0-9_-]{11})")
MEDIA_TYPES = ("video/", "audio/", "application/vnd.apple.mpegurl", "application/x-mpegurl",
               "application/dash+xml", "application/octet-stream")
MEDIA_EXT = re.compile(r"\.(mp4|m4v|mkv|webm|mov|avi|ts|m3u8|mpd|mp3|m4a|aac|flac|ogg|opus|wav)$", re.I)
PICTURE_EXT = (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp")
VIDEO_EXT = (".mp4", ".m4v", ".mov", ".mkv", ".webm", ".3gp", ".avi")
UPLOAD_MAX = 4 * 1024 * 1024 * 1024  # 4 GB a file


def inbox(batch=""):
    """The folder where pictures and videos sent from a phone go (the photo frame shows them too)."""
    folder = os.path.join(profile(), "inbox", batch) if batch else os.path.join(profile(), "inbox")
    os.makedirs(folder, exist_ok=True)
    return folder


def media_type(url):
    """'media', 'page' or '' (not reachable): what an address is, from its answer."""
    import urllib.request
    try:
        request = urllib.request.Request(url, headers={"Range": "bytes=0-0", "User-Agent": "Kodi"})
        with urllib.request.urlopen(request, timeout=6) as reply:
            kind = (reply.headers.get("Content-Type") or "").lower()
    except Exception:
        return ""
    if kind.startswith("image/"):
        return "picture"
    return "media" if kind.startswith(MEDIA_TYPES) else "page"


def play_link(url):
    """A link from the phone: a YouTube video (with the YouTube add-on), a video / audio file or
    stream, or a picture. {"ok": True} or {"error": "youtube" | "notmedia" | "link"}."""
    url = (url or "").strip()
    found = YOUTUBE_ID.search(url)
    if found:
        if not has_addon(YOUTUBE):
            return {"error": "youtube"}
        rpc("Player.Open", item={"file": "plugin://%s/play/?video_id=%s" % (YOUTUBE, found.group(1))})
        return {"ok": True, "kind": "youtube"}
    if not re.match(r"^https?://[^\s/]+", url, re.I):
        return {"error": "link"}
    path = urllib.parse.urlparse(url).path
    kind = "media" if MEDIA_EXT.search(path) else "picture" if path.lower().endswith(PICTURE_EXT) else \
        media_type(url)
    if kind == "picture":
        xbmc.executebuiltin('ShowPicture("%s")' % url.replace('"', "%22"))
    elif kind == "media":
        rpc("Player.Open", item={"file": url})
    else:
        return {"error": "notmedia"}
    return {"ok": True, "kind": kind}


def install_youtube():
    """Kodi asks on the TV whether to install the YouTube add-on."""
    xbmc.executebuiltin("InstallAddon(%s)" % YOUTUBE)


def safe_name(name):
    name = os.path.basename(str(name or "").replace("\\", "/"))
    name = re.sub(r"[^\w.\- ()]+", "_", name, flags=re.UNICODE).strip(" .") or "file"
    return name[-100:]


def save_upload(stream, size, batch, name):
    """Write a picture or video from the phone into the inbox. Its path, or None."""
    name = safe_name(name)
    if not name.lower().endswith(PICTURE_EXT + VIDEO_EXT) or not 0 < size <= UPLOAD_MAX:
        return None
    batch = re.sub(r"[^0-9-]", "", str(batch or ""))[:20] or time.strftime("%Y%m%d-%H%M%S")
    path = os.path.join(inbox(batch), name)
    left = size
    with open(path + ".part", "wb") as f:
        while left > 0:
            block = stream.read(min(left, 1024 * 1024))
            if not block:
                break
            f.write(block)
            left -= len(block)
    if left:
        os.remove(path + ".part")
        return None
    os.replace(path + ".part", path)
    return path


def show_batch(batch):
    """After an upload: play the video, or show the pictures as a slideshow (one: just it)."""
    batch = re.sub(r"[^0-9-]", "", str(batch or ""))[:20]
    folder = os.path.join(profile(), "inbox", batch)
    if not batch or not os.path.isdir(folder):
        return
    files = sorted(os.path.join(folder, f) for f in os.listdir(folder) if not f.endswith(".part"))
    videos = [f for f in files if f.lower().endswith(VIDEO_EXT)]
    pictures = [f for f in files if f.lower().endswith(PICTURE_EXT)]
    if videos:
        rpc("Player.Open", item={"file": videos[0]})
    elif len(pictures) == 1:
        xbmc.executebuiltin('ShowPicture("%s")' % pictures[0])
    elif pictures:
        xbmc.executebuiltin('SlideShow("%s",notrandom)' % folder)


def inbox_info():
    count = size = 0
    for root, _dirs, files in os.walk(inbox()):
        for f in files:
            if not f.endswith(".part"):
                count += 1
                size += os.path.getsize(os.path.join(root, f))
    return {"count": count, "mb": round(size / 1048576.0, 1)}


def clear_inbox():
    import shutil
    shutil.rmtree(inbox(), ignore_errors=True)
    inbox()


# --------------------------------------------------------------------------- movie quiz

QUIZ_PLAYERS = 4
_quiz_lock = __import__("threading").Lock()


def quiz_prop(name):
    return xbmcgui.Window(10000).getProperty("MHQ." + name)


def quiz_key(token):
    import hashlib
    return hashlib.sha256(token.encode("utf-8")).hexdigest()[:16]


def quiz_slot(token):
    key = quiz_key(token)
    for n in range(1, QUIZ_PLAYERS + 1):
        if quiz_prop("P%d.Key" % n) == key and quiz_prop("P%d.Name" % n):
            return n
    return 0


def quiz_state(token):
    """What a phone shows: the question and its four answers (not the picture: that's on the
    TV), how it went, and the scores."""
    phase = quiz_prop("Phase")
    out = {"phase": phase}
    if not phase:
        return out
    me = quiz_slot(token)
    players = []
    for n in range(1, QUIZ_PLAYERS + 1):
        if quiz_prop("P%d.Name" % n):
            players.append({"slot": n, "name": quiz_prop("P%d.Name" % n), "score": int(quiz_prop("P%d.Score" % n) or 0),
                            "rank": int(quiz_prop("P%d.Rank" % n) or 0), "me": n == me})
    game = quiz_prop("Game") or "quiz"
    out["game"] = game
    if game == "match":
        if phase in ("match", "matched", "nomatch"):
            try:
                deck = json.loads(quiz_prop("Deck") or "[]")
            except ValueError:
                deck = []
            out["deck"] = [{"i": c["i"], "title": c["title"], "year": c["year"], "genre": c["genre"],
                            "plot": c["plot"], "art": art_url(c["poster"])} for c in deck]
            if phase in ("matched", "nomatch") and quiz_prop("Matched").isdigit():
                card = next((c for c in out["deck"] if c["i"] == int(quiz_prop("Matched"))), None)
                out["matched"] = card or {}
        if me:
            out["seen"] = int(quiz_prop("Seen.%d" % me) or 0)
    out.update({"players": players, "me": me, "num": quiz_prop("Num"), "total": quiz_prop("Total"),
                "qid": quiz_prop("Qid"), "kind": quiz_prop("Kind"), "left": int(quiz_prop("Left") or 0),
                "winner": quiz_prop("Winner"), "solo": bool(quiz_prop("Solo"))})
    if phase in ("question", "reveal"):
        question = quiz_prop("Question")
        out["question"] = "" if out["kind"] == "still" else question
        out["options"] = [quiz_prop("Opt%d" % i) for i in range(1, 5)]
        if me:
            out["answered"] = bool(quiz_prop("P%d.Answered" % me))
    if phase == "reveal":
        out["correct"] = int(quiz_prop("Correct") or 0)
        if me:
            out["right"] = quiz_prop("P%d.Right" % me) == "1"
            out["gain"] = quiz_prop("P%d.Gain" % me)
    return out


def quiz_join(token, name):
    """A phone joins the quiz (in the lobby, or between games). Its player number, or 0."""
    name = re.sub(r"\s+", " ", str(name or "")).strip()[:16] or "Player"
    home = xbmcgui.Window(10000)
    with _quiz_lock:
        if quiz_prop("Phase") not in ("lobby", "end", "matched", "nomatch"):
            return quiz_slot(token)
        n = quiz_slot(token)
        if not n:
            n = next((i for i in range(1, QUIZ_PLAYERS + 1) if not quiz_prop("P%d.Name" % i) or
                      (quiz_prop("Solo") and not quiz_prop("P%d.Key" % i))), 0)
        if n:
            home.setProperty("MHQ.P%d.Name" % n, name)
            home.setProperty("MHQ.P%d.Key" % n, quiz_key(token))
            home.setProperty("MHQ.P%d.Score" % n, quiz_prop("P%d.Score" % n) or "0")
        return n


def quiz_answer(token, qid, choice):
    n = quiz_slot(token)
    if n and quiz_prop("Phase") == "question" and str(qid) == quiz_prop("Qid") and str(choice) in "1234":
        xbmcgui.Window(10000).setProperty("MHQ.In.%d" % n, "%s|%s" % (qid, choice))
        return True
    return False


def match_vote(token, index, yes):
    """A phone's yes or no on the next card of the pile (cards go in order)."""
    n = quiz_slot(token)
    if not n or quiz_prop("Phase") != "match":
        return False
    home = xbmcgui.Window(10000)
    with _quiz_lock:
        seen = int(quiz_prop("Seen.%d" % n) or 0)
        if str(index) != str(seen):
            return False
        if yes:
            likes = [x for x in quiz_prop("Likes.%d" % n).split(",") if x]
            home.setProperty("MHQ.Likes.%d" % n, ",".join(likes + [str(seen)]))
        home.setProperty("MHQ.Seen.%d" % n, str(seen + 1))
    return True


def quiz_qr_file(code):
    return os.path.join(xbmcvfs.translatePath("special://temp/"), "mhquiz-qr-%s.png" % code)


def quiz_qr():
    """The quiz lobby's QR code: the Web Remote's address with a code any phone can pair with
    for half an hour. Window(Home) MHW.QuizQR / MHW.QuizUrl / MHW.QuizCode."""
    home = xbmcgui.Window(10000)
    if not xbmcaddon.Addon(ADDON_ID).getSettingBool("enabled") or not home.getProperty("MHW.Address"):
        for name in ("MHW.QuizQR", "MHW.QuizUrl", "MHW.QuizCode"):
            home.clearProperty(name)
        return
    code = new_code(multi=True, lifetime=30 * 60)
    where = address()
    temp = xbmcvfs.translatePath("special://temp/")
    for name in os.listdir(temp):  # (the last lobby's)
        if name.startswith("mhquiz-qr-"):
            try:
                os.remove(os.path.join(temp, name))
            except OSError:
                pass
    qr_png("%s/#code=%s&quiz" % (where, code), quiz_qr_file(code), scale=8, border=2)
    # (the skin loads it from this service: Kodi sometimes won't show a picture file that has
    # only just been written, and never tries that file again)
    home.setProperty("MHW.QuizQR", "http://127.0.0.1:%d/quizqr.png?c=%s" % (port_setting(), code))
    home.setProperty("MHW.QuizUrl", where.replace("http://", ""))
    home.setProperty("MHW.QuizCode", code)
