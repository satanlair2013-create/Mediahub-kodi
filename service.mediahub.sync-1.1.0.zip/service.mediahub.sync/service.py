"""MediaHub Sync - in the background while Kodi runs: a sync a little after Kodi
starts, every so often (MediaHub Sync settings), and shortly after something stops
playing (so the next device knows where you got to)."""
import json
import os
import sys
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import sync  # noqa: E402

FIRST = 30  # seconds after Kodi starts
AFTER_STOP = 20  # seconds after playback stops
STATUS = "MHS.Status"  # Window(Home) property: when it last synced and with whom (Skin settings shows it)


class Service(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.next = time.time() + FIRST
        self.worker = None

    def every(self):
        try:
            return max(5, int(xbmcaddon.Addon().getSetting("every") or 15)) * 60
        except ValueError:
            return 15 * 60

    def onNotification(self, sender, method, data):
        if method == "Player.OnStop":
            try:
                info = json.loads(data or "{}")
                sync.note_stopped(info.get("item"), bool(info.get("end")))
            except (ValueError, TypeError, AttributeError):
                pass
        if method == "Player.OnPlay":  # (playing it here: no need to offer it from elsewhere)
            try:
                item = json.loads(data or "{}").get("item") or {}
            except (ValueError, AttributeError):
                item = {}
            home = xbmcgui.Window(10000)
            if item.get("type") == home.getProperty(sync.HANDOFF + ".Kind") and \
                    str(item.get("id")) == home.getProperty(sync.HANDOFF + ".DBID"):
                home.clearProperty(sync.HANDOFF)
        if method in ("Player.OnStop", "VideoLibrary.OnScanFinished"):
            self.next = min(self.next, time.time() + AFTER_STOP)

    def onSettingsChanged(self):
        self.next = time.time() + 3

    def work(self):
        try:
            show(sync.run())
        except Exception as exc:  # (never take the service down)
            xbmc.log("MediaHub Sync: %r" % exc, xbmc.LOGERROR)

    def run(self):
        show(sync.load_json(sync.profile("status.json"), {}))
        home = xbmcgui.Window(10000)
        while not self.waitForAbort(2):
            asked = home.getProperty("MHS.Now")
            busy = self.worker is not None and self.worker.is_alive()
            if busy or not (asked or time.time() >= self.next):
                continue
            home.clearProperty("MHS.Now")
            self.next = time.time() + self.every()
            if not xbmcaddon.Addon().getSetting("folder"):
                continue
            if xbmc.getCondVisibility("Player.HasVideo + Window.IsActive(fullscreenvideo)") and not asked:
                self.next = time.time() + 60  # (not while a film plays: after it)
                continue
            self.worker = threading.Thread(target=self.work, daemon=True)
            self.worker.start()


def show(status):
    """MHS.Status: "Synced 22:14 with Bedroom, Kitchen" (or what went wrong)."""
    addon = xbmcaddon.Addon()
    if not status.get("t"):
        text = addon.getLocalizedString(30050) if not addon.getSetting("folder") else ""
    elif not status.get("ok"):
        text = addon.getLocalizedString(30051 if status.get("error") == "folder" else 30050)
    else:
        when = time.strftime(xbmc.getRegion("time").replace(":%S", ""), time.localtime(status["t"]))
        others = ", ".join(status.get("devices") or [])
        text = addon.getLocalizedString(30052) % (when, others) if others else addon.getLocalizedString(30053) % when
    xbmcgui.Window(10000).setProperty(STATUS, text)


if __name__ == "__main__":
    Service().run()
