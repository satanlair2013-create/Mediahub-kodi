"""MediaHub Helper - plugin entry point.

plugin://script.mediahub.helper/?action=nextup[&limit=25]
    The next episode to watch for every in-progress TV show, most recently
    watched show first. A partly watched episode counts as "next".
plugin://script.mediahub.helper/?action=play&episodeid=<id>
    Plays that episode (resuming if it was started) with the next few
    episodes queued, so the following one starts automatically.
"""
import json
import sys
import time
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

HOME = xbmcgui.Window(10000)
CACHE_SECONDS = 20
EPISODE_PROPS = ["title", "showtitle", "season", "episode", "playcount", "resume", "lastplayed",
                 "file", "art", "plot", "runtime", "firstaired", "rating", "tvshowid"]


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return reply.get("result", {})


def show_episodes(tvshowid):
    eps = rpc("VideoLibrary.GetEpisodes", tvshowid=tvshowid, properties=EPISODE_PROPS,
              sort={"method": "episode", "order": "ascending"}).get("episodes", [])
    return [e for e in eps if e.get("season", 0) > 0]  # specials don't count


def next_episode(eps):
    """The partly watched episode, or the first unwatched one after the last watched."""
    started = [e for e in eps if e["playcount"] > 0 or e["resume"]["position"] > 0]
    if not started:
        return None
    last = max(started, key=lambda e: e.get("lastplayed") or "")
    if last["playcount"] == 0 and last["resume"]["position"] > 0:
        return last
    idx = eps.index(last)
    for e in eps[idx + 1:]:
        if e["playcount"] == 0:
            return e
    return None


def up_next(limit):
    cached = HOME.getProperty("MH.UpNext.Cache")
    if cached:
        stamp, key, data = json.loads(cached)
        if time.time() - stamp < CACHE_SECONDS and key == HOME.getProperty("MH.Reload") + str(limit):
            return data
    shows = rpc("VideoLibrary.GetTVShows", properties=["title"],
                filter={"field": "inprogress", "operator": "true", "value": ""}).get("tvshows", [])
    found = []
    for show in shows:
        eps = show_episodes(show["tvshowid"])
        ep = next_episode(eps)
        if ep:
            watched = max((e.get("lastplayed") or "" for e in eps), default="")
            found.append((watched, ep))
    # Most recently watched show first
    found.sort(key=lambda pair: pair[0], reverse=True)
    result = [ep for _, ep in found[:limit]]
    HOME.setProperty("MH.UpNext.Cache", json.dumps([time.time(), HOME.getProperty("MH.Reload") + str(limit), result]))
    return result


def list_item(ep):
    label = "%s  S%02dE%02d  %s" % (ep["showtitle"], ep["season"], ep["episode"], ep["title"])
    li = xbmcgui.ListItem(label, ep["title"], offscreen=True)
    tag = li.getVideoInfoTag()
    tag.setMediaType("episode")
    tag.setDbId(ep["episodeid"])
    tag.setTitle(ep["title"])
    tag.setTvShowTitle(ep["showtitle"])
    tag.setSeason(ep["season"])
    tag.setEpisode(ep["episode"])
    tag.setPlot(ep.get("plot", ""))
    tag.setPlaycount(ep["playcount"])
    tag.setFirstAired(ep.get("firstaired", ""))
    tag.setDuration(int(ep.get("runtime") or 0))
    tag.setRating(float(ep.get("rating") or 0))
    if ep["resume"]["position"] > 0:
        tag.setResumePoint(ep["resume"]["position"], ep["resume"]["total"])
    li.setArt(ep.get("art", {}))
    li.setProperty("IsPlayable", "false")
    return li


def main():
    handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
    params = dict(parse_qsl(sys.argv[2][1:] if len(sys.argv) > 2 else ""))
    action = params.get("action", "nextup")

    if action == "play":
        if handle >= 0:
            # Opened from a list: Kodi is waiting for a directory, so tell it there
            # isn't one and start the playlist ourselves.
            xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        play(int(params["episodeid"]))
        return

    items = []
    for ep in up_next(int(params.get("limit", 25))):
        url = sys.argv[0] + "?" + urlencode({"action": "play", "episodeid": ep["episodeid"]})
        items.append((url, list_item(ep), False))
    xbmcplugin.setContent(handle, "episodes")
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def play(episodeid):
    """Queue this episode and the rest of its show, then start playing (resuming if started)."""
    ep = rpc("VideoLibrary.GetEpisodeDetails", episodeid=episodeid, properties=["tvshowid"])["episodedetails"]
    eps = show_episodes(ep["tvshowid"])
    ids = [e["episodeid"] for e in eps]
    start = ids.index(episodeid) if episodeid in ids else 0
    queue = ids[start:start + 10] or [episodeid]
    rpc("Playlist.Clear", playlistid=1)
    for eid in queue:
        rpc("Playlist.Add", playlistid=1, item={"episodeid": eid})
    rpc("Player.Open", item={"playlistid": 1, "position": 0}, options={"resume": True})


if __name__ == "__main__":
    main()
