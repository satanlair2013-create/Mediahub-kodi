"""MediaHub Scores - fixtures, results and league tables for your teams.

From TheSportsDB (thesportsdb.com): its free key ("3") answers team searches, a
team's next and last five matches and league tables; a key of your own (Patreon)
goes in the settings. Any sport it knows: football, rugby, basketball, ice hockey,
American football, cricket...

Kept in the add-on's data folder:
- teams.json: your teams [{id, name, badge, league, league_id, sport}]
- matches.json: {team id: {"next": [...], "last": [...], "t": when read}}
- told.json: the matches already announced (kick-off, final score)
- home.json: MediaHub's Scores: Your Teams row
Window(Home): MHF.Home (set when the cards change).
"""
import datetime
import gzip
import json
import os
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.mediahub.scores"
API = os.environ.get("MEDIAHUB_SPORTSDB", "https://www.thesportsdb.com/api/v1/json").rstrip("/")
CERTS = "special://xbmc/system/certs/cacert.pem"
HOME_CARDS = 20
RECENT_DAYS = 4       # results this recent go on the home row
SOON_DAYS = 10        # and matches this soon
FINISHED = ("match finished", "ft", "aet", "pen", "finished", "full time", "ended", "aot", "ap")


class Error(Exception):
    pass


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def text(string_id):
    return addon().getLocalizedString(string_id)


def profile(name=""):
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)


def load_json(name, default):
    try:
        with open(profile(name), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(name, data):
    path = profile(name)
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def ssl_context():
    certs = xbmcvfs.translatePath(CERTS)
    try:
        return ssl.create_default_context(cafile=certs) if os.path.exists(certs) else ssl.create_default_context()
    except (OSError, ssl.SSLError):
        return ssl.create_default_context()


def api(method, **params):
    key = addon().getSetting("sportsdb_key").strip() or "3"
    address = "%s/%s/%s?%s" % (API, urllib.parse.quote(key), method, urllib.parse.urlencode(params))
    request = urllib.request.Request(address, headers={"User-Agent": xbmc.getUserAgent(), "Accept-Encoding": "gzip"})
    try:
        with urllib.request.urlopen(request, timeout=15, context=ssl_context()) as reply:
            body = reply.read(4 * 1024 * 1024)
        if body[:2] == b"\x1f\x8b":
            body = gzip.decompress(body)
        data = json.loads(body.decode("utf-8", "replace") or "null")
    except urllib.error.HTTPError as exc:
        raise Error("HTTP %d" % exc.code)
    except (OSError, ValueError, ssl.SSLError) as exc:
        raise Error(repr(exc))
    return data if isinstance(data, dict) else {}


# --------------------------------------------------------------------------- teams

def teams():
    return load_json("teams.json", [])


def search_teams(words):
    found = api("searchteams.php", t=words).get("teams") or []
    return [team_of(t) for t in found if isinstance(t, dict) and t.get("idTeam")]


def team_of(t):
    return {"id": str(t["idTeam"]), "name": t.get("strTeam") or "", "badge": t.get("strBadge") or t.get("strTeamBadge") or "",
            "league": t.get("strLeague") or "", "league_id": str(t.get("idLeague") or ""),
            "sport": t.get("strSport") or "", "country": t.get("strCountry") or ""}


def add_team(team):
    mine = [t for t in teams() if t["id"] != team["id"]]
    save_json("teams.json", mine + [team])


def remove_team(team_id):
    save_json("teams.json", [t for t in teams() if t["id"] != team_id])
    matches = load_json("matches.json", {})
    matches.pop(team_id, None)
    save_json("matches.json", matches)


# --------------------------------------------------------------------------- matches

def kickoff(e):
    """A match's start as epoch seconds (TheSportsDB gives UTC), or 0."""
    stamp = e.get("strTimestamp") or ""
    if not stamp and e.get("dateEvent"):
        stamp = "%sT%s" % (e["dateEvent"], (e.get("strTime") or "00:00:00")[:8])
    try:
        d = datetime.datetime.fromisoformat(stamp.replace("Z", "")[:19])
    except ValueError:
        return 0
    return int(d.replace(tzinfo=datetime.timezone.utc).timestamp())


def match_of(e):
    home, away = e.get("intHomeScore"), e.get("intAwayScore")
    status = (e.get("strStatus") or "").strip()
    scored = home not in (None, "") and away not in (None, "")
    return {"id": str(e.get("idEvent") or ""), "home": e.get("strHomeTeam") or "", "away": e.get("strAwayTeam") or "",
            "home_id": str(e.get("idHomeTeam") or ""), "away_id": str(e.get("idAwayTeam") or ""),
            "score": "%s – %s" % (home, away) if scored else "", "status": status,
            "done": scored and (status.lower() in FINISHED or not status),
            "t": kickoff(e), "league": e.get("strLeague") or "", "round": str(e.get("intRound") or ""),
            "venue": e.get("strVenue") or "", "picture": e.get("strThumb") or e.get("strBanner") or "",
            "home_badge": e.get("strHomeTeamBadge") or "", "away_badge": e.get("strAwayTeamBadge") or "",
            "sport": e.get("strSport") or ""}


def fetch_team(team_id):
    upcoming = [match_of(e) for e in api("eventsnext.php", id=team_id).get("events") or [] if isinstance(e, dict)]
    results = [match_of(e) for e in api("eventslast.php", id=team_id).get("results") or [] if isinstance(e, dict)]
    results.sort(key=lambda m: m["t"], reverse=True)
    upcoming.sort(key=lambda m: m["t"])
    return {"next": upcoming, "last": results, "t": time.time()}


def matches():
    return load_json("matches.json", {})


def refresh(announce=True):
    """Every team's next and last matches; what's new to say (kick-off soon, full time)."""
    kept = matches()
    for team in teams():
        try:
            kept[team["id"]] = fetch_team(team["id"])
        except Error as exc:
            xbmc.log("MediaHub Scores: %s: %s" % (team["name"], exc), xbmc.LOGWARNING)
    save_json("matches.json", kept)
    if announce:
        tell(kept)
    write_home(kept)
    return kept


def table(league_id, season=""):
    params = {"l": league_id}
    if season:
        params["s"] = season
    rows = api("lookuptable.php", **params).get("table") or []
    return [{"rank": r.get("intRank") or "", "team": r.get("strTeam") or "", "badge": r.get("strBadge") or r.get("strTeamBadge") or "",
             "played": r.get("intPlayed") or "", "won": r.get("intWin") or "", "drawn": r.get("intDraw") or "",
             "lost": r.get("intLoss") or "", "gd": r.get("intGoalDifference") or "", "points": r.get("intPoints") or ""}
            for r in rows if isinstance(r, dict)]


# --------------------------------------------------------------------------- saying so

def title(m):
    return "%s %s %s" % (m["home"], m["score"] or "v", m["away"])


def when_label(t):
    if not t:
        return ""
    local = time.localtime(t)
    today = datetime.date.today()
    day = datetime.date(local.tm_year, local.tm_mon, local.tm_mday)
    clock = time.strftime(xbmc.getRegion("time").replace(":%S", ""), local)
    if day == today:
        return "%s %s" % (xbmc.getLocalizedString(33006), clock)  # Today
    if day == today + datetime.timedelta(days=1):
        return "%s %s" % (text(30040), clock)
    if day == today - datetime.timedelta(days=1):
        return "%s %s" % (text(30041), clock)
    return "%s %s" % (time.strftime(xbmc.getRegion("dateshort"), local), clock)


def status_label(m):
    """"Full time" (or the likes of "AET", "Pen"), or when it starts."""
    if not m["done"]:
        return when_label(m["t"])
    plain_end = m["status"].lower() in ("match finished", "ft", "finished", "full time", "ended", "")
    return text(30044) if plain_end else m["status"]


def tell(kept):
    """A notification when one of your teams kicks off within the quarter hour, and the final score."""
    told = load_json("told.json", {})
    now = time.time()
    badges = {t["id"]: t["badge"] for t in teams()}
    for team_id, found in kept.items():
        for m in found.get("next") or []:
            key = "k" + m["id"]
            if m["id"] and 0 < m["t"] - now <= 15 * 60 and key not in told:
                told[key] = now
                notify(text(30042) % (m["home"], m["away"]), badges.get(team_id))
        for m in found.get("last") or []:
            key = "f" + m["id"]
            if m["id"] and m["done"] and key not in told and now - m["t"] < 8 * 3600:
                told[key] = now
                notify(text(30043) % title(m), badges.get(team_id))
            elif m["id"] and m["done"]:
                told.setdefault(key, now)  # (old results: never announced)
    save_json("told.json", {k: v for k, v in told.items() if now - v < 30 * 86400})


def notify(message, icon=None):
    xbmcgui.Dialog().notification(addon().getAddonInfo("name"), message, icon or addon().getAddonInfo("icon"),
                                  8000, True)


def match_address(m):
    return "plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode({"mode": "match", "id": m["id"]}))


def find_match(match_id):
    for found in matches().values():
        for m in (found.get("next") or []) + (found.get("last") or []):
            if m["id"] == match_id:
                return m
    return None


def write_home(kept=None):
    kept = matches() if kept is None else kept
    now = time.time()
    seen, recent, soon = set(), [], []
    for found in kept.values():
        for m in found.get("last") or []:
            if m["id"] not in seen and now - m["t"] < RECENT_DAYS * 86400:
                seen.add(m["id"])
                recent.append(m)
        for m in found.get("next") or []:
            if m["id"] not in seen and m["t"] - now < SOON_DAYS * 86400:
                seen.add(m["id"])
                soon.append(m)
    recent.sort(key=lambda m: m["t"], reverse=True)
    soon.sort(key=lambda m: m["t"])
    # (what's on today first, then the latest results, then what's coming)
    today = [m for m in soon if m["t"] - now < 12 * 3600]
    ordered = today + recent + [m for m in soon if m not in today]
    cards = [{"Label": title(m), "Label2": status_label(m),
              "Title": title(m), "Landscape": m["picture"] or m["home_badge"], "Poster": m["home_badge"] or m["picture"],
              "Square": m["home_badge"], "Plot": "%s\n%s" % (m["venue"], m["league"]),
              "Action": "scores|run|" + match_address(m), "Kind": "scores", "kids": True}
             for m in ordered[:HOME_CARDS]]
    save_json("home.json", {"scoresteams": cards})
    xbmcgui.Window(10000).setProperty("MHF.Home", str(time.time()))  # (the MediaHub Helper refreshes the rows)


def match_day():
    """True from an hour before one of your matches until three hours after it began."""
    now = time.time()
    for found in matches().values():
        for m in found.get("next") or []:
            if m["t"] and m["t"] - 3600 <= now <= m["t"] + 3 * 3600:
                return True
        for m in found.get("last") or []:
            if m["t"] and 0 < now - m["t"] < 3 * 3600 and not m["done"]:
                return True
    return False
