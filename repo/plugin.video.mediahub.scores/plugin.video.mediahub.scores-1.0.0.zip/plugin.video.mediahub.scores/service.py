"""MediaHub Scores - in the background: your teams' matches every half hour, and
every few minutes on match days (kick-off and full-time notifications)."""
import os
import sys
import threading
import time

import xbmc

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import scores  # noqa: E402

FIRST = 50          # seconds after Kodi starts
EVERY = 30 * 60
MATCH_DAY = 4 * 60  # while one of your teams is playing


class Service(xbmc.Monitor):
    def run(self):
        scores.write_home()  # (what was kept, straight away)
        due = time.time() + FIRST
        worker = None
        while not self.waitForAbort(5):
            if time.time() >= due and not (worker and worker.is_alive()):
                if not scores.teams():
                    due = time.time() + 60  # (none yet: look again soon)
                    continue
                due = time.time() + (MATCH_DAY if scores.match_day() else EVERY)
                worker = threading.Thread(target=self.refresh, daemon=True)
                worker.start()

    def refresh(self):
        try:
            scores.refresh()
        except Exception as exc:  # (never take the service down)
            xbmc.log("MediaHub Scores: %r" % exc, xbmc.LOGWARNING)


if __name__ == "__main__":
    Service().run()
