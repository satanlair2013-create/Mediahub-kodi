"""MediaHub Scores - your teams' fixtures, results and league tables.

Add your teams (any sport TheSportsDB knows); each one shows its next matches,
its latest results and its league's table. On match days MediaHub says when your
team kicks off and the final score. (Watching the matches isn't part of it:
there's no free, legal stream of them.)
"""
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import scores  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name")
FANART = os.path.join(ADDON.getAddonInfo("path"), "resources", "fanart.jpg")


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)


def notify(message, error=False):
    xbmcgui.Dialog().notification(NAME, message, xbmcgui.NOTIFICATION_WARNING if error else
                                  xbmcgui.NOTIFICATION_INFO, 4000, False)


def entry(label, target, icon, folder=True, label2="", menu=None):
    item = xbmcgui.ListItem(label, label2)
    item.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
    if menu:
        item.addContextMenuItems(menu)
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=folder)


def end(content="", title=""):
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.setPluginCategory(HANDLE, title or NAME)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def careful(work):
    try:
        work()
    except scores.Error as exc:
        xbmc.log("MediaHub Scores: %s" % exc, xbmc.LOGWARNING)
        notify(text(30020), True)
        if HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


# --------------------------------------------------------------------------- pages

def root():
    for team in scores.teams():
        entry(team["name"], url(mode="team", id=team["id"]), team["badge"] or "DefaultAddonService.png",
              label2=team["league"], menu=[(text(30005), "RunPlugin(%s)" % url(mode="remove", id=team["id"]))])
    entry(text(30001), url(mode="add"), "DefaultAddSource.png", folder=False)
    end()


def match_item(m, note=""):
    label2 = note or scores.status_label(m)
    item = xbmcgui.ListItem(scores.title(m), label2)
    picture = m["picture"] or m["home_badge"] or "DefaultAddonService.png"
    item.setArt({"thumb": m["home_badge"] or picture, "icon": m["home_badge"] or picture,
                 "landscape": picture, "fanart": m["picture"] or FANART})
    tag = item.getVideoInfoTag()
    tag.setTitle(scores.title(m))
    tag.setPlot("\n".join(x for x in (m["league"], m["venue"]) if x))
    xbmcplugin.addDirectoryItem(HANDLE, url(mode="match", id=m["id"]), item, isFolder=False)


def team_page(team_id):
    team = next((t for t in scores.teams() if t["id"] == team_id), None)
    if not team:
        return end()
    found = scores.matches().get(team_id)
    if not found:
        found = scores.refresh(announce=False).get(team_id) or {}
    if found.get("next"):
        entry("[B]%s[/B]" % text(30002), url(mode="noop"), "DefaultIconInfo.png", folder=False)
        for m in found["next"]:
            match_item(m)
    if found.get("last"):
        entry("[B]%s[/B]" % text(30003), url(mode="noop"), "DefaultIconInfo.png", folder=False)
        for m in found["last"]:
            match_item(m)
    if team.get("league_id"):
        entry(text(30004) % team["league"], url(mode="table", league=team["league_id"], name=team["league"]),
              "DefaultAddonService.png")
    end("videos", team["name"])


def table_page(league_id, name):
    rows = scores.table(league_id)
    if not rows:
        notify(text(30021), True)
    mine = {t["name"] for t in scores.teams()}
    for r in rows:
        label = "%s.  %s" % (r["rank"], "[B]%s[/B]" % r["team"] if r["team"] in mine else r["team"])
        label2 = text(30006) % (r["played"], r["won"], r["drawn"], r["lost"], r["gd"], r["points"])
        entry(label, url(mode="noop"), r["badge"] or "DefaultAddonService.png", folder=False, label2=label2)
    end("", name)


def match_page(match_id):
    m = scores.find_match(match_id)
    if not m:
        return
    lines = ["[B]%s[/B]" % scores.title(m)]
    lines.append(scores.status_label(m))
    lines += ["", "  •  ".join(x for x in (m["league"], text(30007) % m["round"] if m["round"] and m["round"] != "0"
                                           else "", m["venue"]) if x)]
    xbmcgui.Dialog().textviewer(NAME, "\n".join(lines))


# --------------------------------------------------------------------------- your teams

def add():
    words = xbmcgui.Dialog().input(text(30001))
    if not words:
        return
    found = scores.search_teams(words)
    if not found:
        return xbmcgui.Dialog().ok(NAME, text(30022) % words)
    items = []
    for t in found:
        item = xbmcgui.ListItem(t["name"], "  •  ".join(x for x in (t["sport"], t["league"], t["country"]) if x))
        item.setArt({"icon": t["badge"] or "DefaultAddonService.png", "thumb": t["badge"] or "DefaultAddonService.png"})
        items.append(item)
    pick = xbmcgui.Dialog().select(text(30001), items, useDetails=True)
    if pick < 0:
        return
    scores.add_team(found[pick])
    notify(text(30008) % found[pick]["name"])
    scores.refresh(announce=False)
    xbmc.executebuiltin("Container.Refresh")


def remove(team_id):
    scores.remove_team(team_id)
    scores.write_home()
    xbmc.executebuiltin("Container.Refresh")


def main():
    mode = ARGS.get("mode")
    if mode is None:
        root()
    elif mode == "team":
        careful(lambda: team_page(ARGS["id"]))
    elif mode == "table":
        careful(lambda: table_page(ARGS["league"], ARGS.get("name", "")))
    elif mode == "match":
        match_page(ARGS.get("id", ""))
    elif mode == "add":
        careful(add)
    elif mode == "remove":
        remove(ARGS.get("id", ""))
    elif mode == "refresh":
        careful(scores.refresh)


if __name__ == "__main__":
    main()
