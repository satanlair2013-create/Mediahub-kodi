"""MediaHub Concerts - live shows from the Internet Archive's Live Music Archive.

The Live Music Archive (the Internet Archive's "etree" collection) keeps hundreds of
thousands of concert recordings from bands that allow taping and sharing: each band
is a collection, each show an item with its tracks (the setlist). Its search is free,
and no account or key is needed.

Kept in the add-on's data folder:
- progress.json: {show id: {band, title, date, venue, track, pos, tracks, done, t}}
  (Continue listening: a show carries on at the track and moment you stopped)
- mine.json: My shows [{id, band, title, date, venue, t}]
- shows/: each show's details and tracks as last read; lists/: pages of lists
- home.json: cards for MediaHub's Concerts: Continue Listening home row
"""
import gzip
import hashlib
import html
import json
import os
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.audio.mediahub.concerts"
ARCHIVE = os.environ.get("MEDIAHUB_ARCHIVE", "https://archive.org").rstrip("/")  # (a test server can stand in)
CERTS = "special://xbmc/system/certs/cacert.pem"
SHOW_AGE = 30 * 86400
LIST_AGE = 12 * 3600
YEARS_AGE = 7 * 86400
PAGE = 50
NOW = "MHO.Now"  # what the add-on started playing: {address: {id, track}}
HOME_CARDS = 20
AUDIO_FORMATS = ("VBR MP3", "MP3", "128Kbps MP3", "64Kbps MP3", "Ogg Vorbis")
FIRST_YEAR = 1960


class Error(Exception):
    pass


def text(string_id):
    return xbmcaddon.Addon(ADDON_ID).getLocalizedString(string_id)


# --------------------------------------------------------------------------- files

def profile(name=""):
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)


def load_json(name, default):
    try:
        with open(profile(name), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(name, data):
    path = profile(name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def key(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()[:16]


# --------------------------------------------------------------------------- the Internet Archive

def ssl_context():
    certs = xbmcvfs.translatePath(CERTS)
    try:
        return ssl.create_default_context(cafile=certs) if os.path.exists(certs) else ssl.create_default_context()
    except (OSError, ssl.SSLError):
        return ssl.create_default_context()


def fetch_json(url, timeout=20):
    request = urllib.request.Request(url, headers={"User-Agent": xbmc.getUserAgent(), "Accept-Encoding": "gzip"})
    try:
        with urllib.request.urlopen(request, timeout=timeout, context=ssl_context()) as reply:
            body = reply.read(16 * 1024 * 1024)
        if body[:2] == b"\x1f\x8b":
            body = gzip.decompress(body)
        return json.loads(body.decode("utf-8", "replace") or "null")
    except urllib.error.HTTPError as exc:
        raise Error("HTTP %d" % exc.code)
    except (OSError, ValueError, ssl.SSLError) as exc:
        raise Error(repr(exc))


def plain(value):
    if isinstance(value, list):
        value = " ".join(str(v) for v in value)
    value = re.sub(r"<(br|p|/p|li)[^>]*>", "\n", str(value or ""), flags=re.I)
    value = html.unescape(re.sub(r"<[^>]+>", "", value))
    return re.sub(r"\n\s*\n+", "\n\n", re.sub(r"[ \t]+", " ", value)).strip()


def first(value):
    return (value[0] if value else "") if isinstance(value, list) else (value or "")


def picture(identifier):
    return "%s/services/img/%s" % (ARCHIVE, urllib.parse.quote(identifier))


def search(query, sort, page=1, rows=PAGE, fields=("identifier", "title", "date", "venue", "coverage", "creator",
                                                    "downloads"), max_age=LIST_AGE):
    params = [("q", query), ("rows", rows), ("page", page), ("output", "json")]
    params += [("sort[]", sort)] if sort else []
    params += [("fl[]", f) for f in fields]
    cache = "lists/%s.json" % key(query, sort, page, rows, ",".join(fields))
    kept = load_json(cache, {})
    if kept.get("docs") is not None and time.time() - kept.get("t", 0) < max_age:
        return kept["docs"]
    try:
        reply = fetch_json("%s/advancedsearch.php?%s" % (ARCHIVE, urllib.parse.urlencode(params)))
    except Error:
        if kept.get("docs") is not None:
            return kept["docs"]
        raise
    docs = ((reply or {}).get("response") or {}).get("docs") or []
    save_json(cache, {"docs": docs, "t": time.time()})
    return docs


def band_of(doc):
    return plain(first(doc.get("creator"))) or plain(first(doc.get("title"))).split(" Live at ")[0]


def show_of(doc):
    """{id, band, title, date, venue, art} from a search result."""
    date = str(first(doc.get("date")) or "")[:10]
    return {"id": doc["identifier"], "band": band_of(doc), "title": plain(first(doc.get("title"))) or doc["identifier"],
            "date": date, "venue": plain(first(doc.get("venue"))),
            "place": plain(first(doc.get("coverage"))), "art": picture(doc["identifier"])}


def bands(page=1, words=""):
    """[{id, name, art}]: the bands (collections in the Live Music Archive), most played first."""
    q = "collection:(etree) AND mediatype:(collection)"
    if words:
        q += " AND title:(%s)" % re.sub(r"[^\w\s'-]+", " ", words).strip()
    docs = search(q, "downloads desc", page, fields=("identifier", "title", "downloads"))
    return [{"id": d["identifier"], "name": plain(first(d.get("title"))) or d["identifier"], "art": picture(d["identifier"])}
            for d in docs if d.get("identifier")]


def band_shows(band_id, year="", sort="date desc", page=1):
    q = "collection:(%s) AND mediatype:(etree)" % band_id
    if year:
        q += " AND year:(%s)" % year
    return [show_of(d) for d in search(q, sort, page) if d.get("identifier")]


def band_years(band_id):
    """[(year, shows that year)], newest first."""
    docs = search("collection:(%s) AND mediatype:(etree)" % band_id, "", 1, 10000, ("year",), YEARS_AGE)
    counts = {}
    for d in docs:
        y = str(first(d.get("year")) or "")[:4]
        if y.isdigit():
            counts[y] = counts.get(y, 0) + 1
    return sorted(counts.items(), reverse=True)


def year_shows(year, page=1):
    q = "collection:(etree) AND mediatype:(etree) AND year:(%s)" % year
    return [show_of(d) for d in search(q, "downloads desc", page) if d.get("identifier")]


def most_played(page=1):
    return [show_of(d) for d in search("collection:(etree) AND mediatype:(etree)", "downloads desc", page)
            if d.get("identifier")]


def seconds(value):
    value = str(value or "").strip()
    if ":" in value:
        total = 0
        for part in value.split(":"):
            total = total * 60 + (float(part) if part.replace(".", "", 1).isdigit() else 0)
        return int(total)
    try:
        return int(float(value))
    except ValueError:
        return 0


def track_number(f):
    found = re.match(r"\d+", str(f.get("track") or ""))
    return int(found.group(0)) if found else 10000


def show(show_id, max_age=SHOW_AGE):
    """{id, band, title, date, venue, place, notes, source, art, tracks: [{title, url, duration}]}"""
    path = "shows/%s.json" % key(show_id)
    kept = load_json(path, {})
    if kept.get("tracks") and time.time() - kept.get("t", 0) < max_age:
        return kept
    try:
        reply = fetch_json("%s/metadata/%s" % (ARCHIVE, urllib.parse.quote(show_id)))
    except Error:
        if kept.get("tracks"):
            return kept
        raise
    meta = (reply or {}).get("metadata") or {}
    files = (reply or {}).get("files") or []
    chosen = []
    for kind in AUDIO_FORMATS:  # (one kind of file: the first of these the show has)
        chosen = [f for f in files if f.get("format") == kind and f.get("name")]
        if chosen:
            break
    chosen.sort(key=lambda f: (track_number(f), f["name"]))
    tracks = [{"title": plain(f.get("title")) or re.sub(r"\.\w+$", "", f["name"]),
               "url": "%s/download/%s/%s" % (ARCHIVE, urllib.parse.quote(show_id), urllib.parse.quote(f["name"])),
               "duration": seconds(f.get("length"))} for f in chosen]
    found = {"id": show_id, "band": plain(first(meta.get("creator"))), "title": plain(first(meta.get("title"))) or show_id,
             "date": str(first(meta.get("date")) or "")[:10], "venue": plain(first(meta.get("venue"))),
             "place": plain(first(meta.get("coverage"))), "notes": plain(meta.get("description") or meta.get("notes"))[:3000],
             "source": plain(first(meta.get("source")))[:300], "art": picture(show_id), "tracks": tracks, "t": time.time()}
    save_json(path, found)
    return found


def cached_show(show_id):
    return load_json("shows/%s.json" % key(show_id), {})


def setlist(s):
    return "\n".join("%d. %s" % (n, t["title"]) for n, t in enumerate(s.get("tracks") or [], 1))


def when_where(s):
    return "  •  ".join(x for x in (nice_date(s.get("date", "")), s.get("venue", ""), s.get("place", "")) if x)


def nice_date(date):
    try:
        return time.strftime("%d %b %Y", time.strptime(date[:10], "%Y-%m-%d")).lstrip("0")
    except ValueError:
        return date


# --------------------------------------------------------------------------- My shows

def mine():
    return [m for m in load_json("mine.json", []) if isinstance(m, dict) and m.get("id")]


def is_mine(show_id):
    return any(m["id"] == show_id for m in mine())


def set_mine(s, on):
    found = [m for m in mine() if m["id"] != s["id"]]
    if on:
        entry = {k: s.get(k, "") for k in ("id", "band", "title", "date", "venue")}
        entry["t"] = time.time()
        found.insert(0, entry)
    save_json("mine.json", found)


# --------------------------------------------------------------------------- progress

def progress():
    return load_json("progress.json", {})


def place(show_id):
    """(track, position) to carry on from."""
    p = progress().get(show_id) or {}
    if p.get("done"):
        return 0, 0
    return int(p.get("track", 0)), float(p.get("pos", 0))


def record(s, track, pos, total):
    data = progress()
    tracks = len(s.get("tracks") or [])
    done = track >= tracks - 1 and total > 0 and pos >= total - 5
    data[s["id"]] = {"band": s.get("band", ""), "title": s.get("title", ""), "date": s.get("date", ""),
                     "venue": s.get("venue", ""), "track": track, "pos": 0 if done else int(pos), "tracks": tracks,
                     "done": done, "t": time.time()}
    save_json("progress.json", data)
    write_home()


def continue_listening(limit=30):
    return [dict(p, id=i) for i, p in sorted(progress().items(), key=lambda kv: -kv[1].get("t", 0))
            if not p.get("done") and (p.get("track", 0) > 0 or p.get("pos", 0) > 30)][:limit]


def play_address(show_id, track=None):
    params = {"mode": "play", "id": show_id}
    if track is not None:
        params["track"] = track
    return "plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode(params))


def write_home():
    """home.json: MediaHub's Concerts: Continue Listening row."""
    cards = {"concontinue": []}
    for p in continue_listening(HOME_CARDS):
        tracks = p.get("tracks") or 0
        cards["concontinue"].append({
            "Label": p.get("band") or p.get("title", ""),
            "Label2": "  •  ".join(x for x in (nice_date(p.get("date", "")), p.get("venue", ""),
                                               text(30016) % (p.get("track", 0) + 1)) if x),
            "Title": p.get("title", ""), "Square": picture(p["id"]),
            "Percent": str(int(100 * p.get("track", 0) / tracks)) if tracks else "",
            "Action": "concerts|run|" + play_address(p["id"]), "Kind": "concert", "kids": True,
            "T": int(p.get("t") or 0)})  # (when: for MediaHub's Continue anywhere row)
    save_json("home.json", cards)
    xbmcgui.Window(10000).setProperty("MHO.Home", str(time.time()))  # (the helper refreshes the row)
