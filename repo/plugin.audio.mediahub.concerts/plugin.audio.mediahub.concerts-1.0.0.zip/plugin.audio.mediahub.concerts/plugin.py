"""MediaHub Concerts - live shows from the Internet Archive's Live Music Archive.

Continue listening, My shows, the most played shows, bands (most played first, or
search) with their shows by year, and every show from a year. A show lists its
setlist; play it all or from any song, and it carries on where you stopped.
"""
import datetime
import json
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import shows  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name")
FANART = os.path.join(ADDON.getAddonInfo("path"), "resources", "fanart.jpg")


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def kodi(string_id):
    return xbmc.getLocalizedString(string_id)


def url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)


def notify(message, error=False):
    xbmcgui.Dialog().notification(NAME, message, xbmcgui.NOTIFICATION_WARNING if error else
                                  xbmcgui.NOTIFICATION_INFO, 4000, False)


def folder(label, target, icon="DefaultFolder.png", plot="", label2=""):
    item = xbmcgui.ListItem(label, label2)
    item.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
    if plot:
        item.getMusicInfoTag().setComment(plot)
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=True)


def end(title="", content="albums"):
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.setPluginCategory(HANDLE, title or NAME)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def careful(work):
    try:
        work()
    except shows.Error as exc:
        xbmc.log("MediaHub Concerts: %s" % exc, xbmc.LOGWARNING)
        notify(text(30020), True)
        if HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def more(page, **params):
    folder(kodi(33078), url(page=page + 1, **params), "DefaultFolder.png")


# --------------------------------------------------------------------------- pages

def root():
    if shows.continue_listening(1):
        folder(text(30001), url(mode="continue"), "DefaultInProgressShows.png")
    if shows.mine():
        folder(text(30002), url(mode="mine"), "DefaultPlaylist.png")
    folder(text(30003), url(mode="popular"), "DefaultMusicTop100.png")
    folder(text(30004), url(mode="bands"), "DefaultMusicArtists.png")
    folder(text(30005), url(mode="years"), "DefaultMusicYears.png")
    folder(kodi(137), url(mode="search"), "DefaultAddonsSearch.png")
    end(content="")


def show_folder(s, label=None, in_band=False):
    if not label:
        date = shows.nice_date(s.get("date", ""))
        label = "  •  ".join(x for x in ((date, s.get("venue", "")) if in_band else (s.get("band") or s["title"], date)) if x)
    item = xbmcgui.ListItem(label, shows.when_where(s))
    item.setArt({"icon": s["art"], "thumb": s["art"], "fanart": FANART})
    tag = item.getMusicInfoTag()
    tag.setMediaType("album")
    tag.setAlbum(s["title"])
    tag.setArtist(s.get("band", ""))
    if s.get("date", "")[:4].isdigit():
        tag.setYear(int(s["date"][:4]))
    tag.setComment(shows.when_where(s))
    listed = shows.is_mine(s["id"])
    info = json.dumps({k: s.get(k, "") for k in ("id", "band", "title", "date", "venue")})
    item.addContextMenuItems([
        (kodi(208), "RunPlugin(%s)" % url(mode="play", id=s["id"])),
        (text(30009) if listed else text(30008), "RunPlugin(%s)" % url(mode="mine_set", on=int(not listed), show=info))])
    xbmcplugin.addDirectoryItem(HANDLE, url(mode="show", id=s["id"]), item, isFolder=True)


def show_list(found, title, page=None, in_band=False, **params):
    for s in found:
        show_folder(s, in_band=in_band)
    if page is not None and len(found) >= shows.PAGE:
        more(page, **params)
    end(title)


def bands_page():
    page = int(ARGS.get("page", 1))
    words = ARGS.get("q", "")
    found = shows.bands(page, words)
    for b in found:
        folder(b["name"], url(mode="band", id=b["id"], name=b["name"]), b["art"])
    if len(found) >= shows.PAGE:
        more(page, mode="bands", q=words)
    end('%s: "%s"' % (kodi(137), words) if words else text(30004), "artists")


def band_page():
    band_id, name = ARGS["id"], ARGS.get("name", "")
    folder(text(30006), url(mode="bandshows", id=band_id, name=name, sort="downloads desc"), "DefaultMusicTop100.png")
    folder(text(30007), url(mode="bandshows", id=band_id, name=name, sort="date desc"), "DefaultMusicRecentlyAdded.png")
    for year, count in shows.band_years(band_id):
        folder(year, url(mode="bandshows", id=band_id, name=name, year=year, sort="date asc"), shows.picture(band_id),
               label2=text(30015) % count)
    end(name, "")


def band_shows_page():
    page = int(ARGS.get("page", 1))
    found = shows.band_shows(ARGS["id"], ARGS.get("year", ""), ARGS.get("sort", "date desc"), page)
    title = "%s %s" % (ARGS.get("name", ""), ARGS.get("year", "")) if ARGS.get("year") else ARGS.get("name", "")
    show_list(found, title, page, True, mode="bandshows", id=ARGS["id"], name=ARGS.get("name", ""),
              year=ARGS.get("year", ""), sort=ARGS.get("sort", "date desc"))


def years_page():
    for year in range(datetime.date.today().year, shows.FIRST_YEAR - 1, -1):
        folder(str(year), url(mode="year", year=year), "DefaultMusicYears.png")
    end(text(30005), "")


def search():
    words = ARGS.get("q")
    if not words:
        words = xbmcgui.Dialog().input(text(30010))
        if not words:
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        xbmc.executebuiltin("Container.Update(%s,replace)" % url(mode="bands", q=words))
        return end()


def show_page():
    s = shows.show(ARGS["id"])
    if not s["tracks"]:
        notify(text(30021), True)
    here, pos = shows.place(s["id"])
    play_all = xbmcgui.ListItem(text(30011) if not (here or pos > 30) else text(30012) % (here + 1),
                                shows.when_where(s))
    play_all.setArt({"icon": s["art"], "thumb": s["art"], "fanart": FANART})
    tag = play_all.getMusicInfoTag()
    tag.setComment("%s\n\n%s\n\n%s" % (shows.when_where(s), shows.setlist(s), s.get("notes", "")))
    xbmcplugin.addDirectoryItem(HANDLE, url(mode="play", id=s["id"]), play_all, isFolder=False)
    for n, t in enumerate(s["tracks"]):
        item = xbmcgui.ListItem("%d. %s" % (n + 1, t["title"]))
        item.setArt({"icon": s["art"], "thumb": s["art"], "fanart": FANART})
        tag = item.getMusicInfoTag()
        tag.setMediaType("song")
        tag.setTitle(t["title"])
        tag.setArtist(s.get("band", ""))
        tag.setAlbum(s["title"])
        tag.setTrack(n + 1)
        if t.get("duration"):
            tag.setDuration(int(t["duration"]))
        tag.setComment(shows.when_where(s))
        xbmcplugin.addDirectoryItem(HANDLE, url(mode="play", id=s["id"], track=n), item, isFolder=False)
    end("%s  •  %s" % (s.get("band") or s["title"], shows.nice_date(s.get("date", ""))), "songs")


def continue_page():
    for p in shows.continue_listening():
        s = dict(p, art=shows.picture(p["id"]))
        show_folder(s, "%s  •  %s" % (p.get("band") or p.get("title", ""), text(30016) % (p.get("track", 0) + 1)))
    end(text(30001))


def mine_page():
    for m in shows.mine():
        show_folder(dict(m, art=shows.picture(m["id"])))
    end(text(30002))


# --------------------------------------------------------------------------- playing

def play():
    """The show from a song on (or from where you stopped), as one playlist."""
    s = shows.show(ARGS["id"])
    tracks = s.get("tracks") or []
    if not tracks:
        return notify(text(30021), True)
    here, pos = shows.place(s["id"])
    if ARGS.get("track") is not None:
        start = int(ARGS["track"])
        offset = pos if here == start and pos > 30 else 0
    else:
        start, offset = here, pos
    start = max(0, min(start, len(tracks) - 1))
    playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    playlist.clear()
    now = {}
    for n in range(start, len(tracks)):
        t = tracks[n]
        item = xbmcgui.ListItem(t["title"], path=t["url"])
        item.setArt({"thumb": s["art"], "icon": s["art"], "fanart": FANART})
        tag = item.getMusicInfoTag()
        tag.setTitle(t["title"])
        tag.setArtist(s.get("band", ""))
        tag.setAlbum("%s  •  %s" % (shows.nice_date(s.get("date", "")), s.get("venue", "")) if s.get("venue") else s["title"])
        tag.setTrack(n + 1)
        if t.get("duration"):
            tag.setDuration(int(t["duration"]))
        if n == start and offset:
            item.setProperty("StartOffset", str(int(offset)))
        playlist.add(t["url"], item)
        now[t["url"]] = {"id": s["id"], "track": n}
    xbmcgui.Window(10000).setProperty(shows.NOW, json.dumps(now))
    xbmc.Player().play(playlist)


def main():
    mode = ARGS.get("mode")
    if mode is None:
        root()
    elif mode == "popular":
        page = int(ARGS.get("page", 1))
        careful(lambda: show_list(shows.most_played(page), text(30003), page, mode="popular"))
    elif mode == "bands":
        careful(bands_page)
    elif mode == "band":
        careful(band_page)
    elif mode == "bandshows":
        careful(band_shows_page)
    elif mode == "years":
        years_page()
    elif mode == "year":
        page = int(ARGS.get("page", 1))
        careful(lambda: show_list(shows.year_shows(ARGS["year"], page), ARGS["year"], page, mode="year",
                                  year=ARGS["year"]))
    elif mode == "search":
        search()
    elif mode == "show":
        careful(show_page)
    elif mode == "continue":
        continue_page()
    elif mode == "mine":
        mine_page()
    elif mode == "play":
        careful(play)
    elif mode == "mine_set":
        s = json.loads(ARGS.get("show") or "{}")
        if s.get("id"):
            shows.set_mine(s, ARGS.get("on") == "1")
            notify(text(30013) if ARGS.get("on") == "1" else text(30014))
            xbmc.executebuiltin("Container.Refresh")


if __name__ == "__main__":
    main()
