"""MediaHub Sync - Sync now (and, the first time, pick the folder)."""
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import sync  # noqa: E402

ADDON = xbmcaddon.Addon()


def main():
    dialog = xbmcgui.Dialog()
    name = ADDON.getAddonInfo("name")
    if not ADDON.getSetting("folder"):
        dialog.ok(name, ADDON.getLocalizedString(30054))
        folder = dialog.browse(3, ADDON.getLocalizedString(30010), "files")
        if not folder:
            return
        ADDON.setSetting("folder", folder)
    progress = xbmcgui.DialogProgress()
    progress.create(name, ADDON.getLocalizedString(30055))
    try:
        status = sync.run()
    finally:
        progress.close()
    import service
    service.show(status)
    if status.get("ok"):
        others = ", ".join(status.get("devices") or []) or ADDON.getLocalizedString(30056)
        dialog.ok(name, ADDON.getLocalizedString(30057) % (others, status.get("changed", 0)))
    else:
        dialog.ok(name, ADDON.getLocalizedString(30051))


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "handoff":  # (MediaHub's Carry on watching banner)
        sync.play_handoff()
    elif len(sys.argv) > 1 and sys.argv[1] == "together":  # (the player bar's Watch together: the service asks)
        import xbmcgui
        xbmcgui.Window(10000).setProperty("MHS.Together.Req", "start")
    elif len(sys.argv) > 1 and sys.argv[1] == "handoffdismiss":
        sync.dismiss_handoff()
    else:
        main()
