"""MediaHub Sync - keeps what you've watched, My List and your add-ons' lists the
same on every Kodi, through a folder they can all reach (a network share, a NAS,
or a folder a cloud drive keeps in step).

Each Kodi writes only its own file in <folder>/MediaHub Sync/ (<device id>.json)
and reads the others', so two devices never write the same file.

- Library: per film, show and episode (matched by IMDb / TMDB / TVDB id, or title
  and year; episodes by their show and number): watched, where you stopped, when
  you last watched it, your thumbs (rating) and My List. The latest change wins.
- Lists (MediaHub's Family List, MediaHub IPTV's My channels, My List, reminders
  and hidden categories, MediaHub Radio's stations, MediaHub Podcasts' podcasts):
  the latest change wins; the first time, the lists are put together.
- Progress (MediaHub IPTV's films and episodes, MediaHub Podcasts' episodes): the
  latest entry of each one wins.
"""
import datetime
import hashlib
import json
import os
import time
import uuid

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = "service.mediahub.sync"
SUBFOLDER = "MediaHub Sync"
MYLIST_TAG = "My List"  # (the MediaHub Helper's tag for My List)
FORMAT = 1


def profile(name=""):
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)


def load_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(data, f)
    os.replace(path + ".tmp", path)


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                       "params": params})))
    return reply.get("result")


def digest(data):
    return hashlib.sha1(json.dumps(data, sort_keys=True).encode("utf-8")).hexdigest()


def device():
    """This Kodi's id (made once) and name."""
    info = load_json(profile("device.json"), {})
    if not info.get("id"):
        info = {"id": uuid.uuid4().hex[:12]}
        save_json(profile("device.json"), info)
    name = xbmcaddon.Addon(ADDON_ID).getSetting("name").strip() or xbmc.getInfoLabel("System.FriendlyName") or "Kodi"
    return info["id"], name


# --------------------------------------------------------------------------- the shared folder

class Folder:
    def __init__(self, path):
        self.path = path.rstrip("/\\") + "/" + SUBFOLDER + "/"

    def ready(self):
        if not xbmcvfs.exists(self.path):
            xbmcvfs.mkdirs(self.path)
        return xbmcvfs.exists(self.path)

    def others(self, own):
        """The other devices' files: [payload]."""
        found = []
        _, files = xbmcvfs.listdir(self.path)
        for name in files:
            if not name.endswith(".json") or name == own + ".json":
                continue
            f = xbmcvfs.File(self.path + name)
            try:
                body = f.readBytes()
            finally:
                f.close()
            try:
                data = json.loads(bytes(body).decode("utf-8"))
            except ValueError:
                continue
            if isinstance(data, dict) and data.get("format") == FORMAT:
                found.append(data)
        return found

    def write(self, own, payload):
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        temp, final = self.path + own + ".tmp", self.path + own + ".json"
        f = xbmcvfs.File(temp, "w")
        try:
            ok = f.write(body)
        finally:
            f.close()
        if not ok:
            raise OSError("can't write to the sync folder")
        if xbmcvfs.exists(final):
            xbmcvfs.delete(final)
        if not xbmcvfs.rename(temp, final):  # (some shares can't rename: write it directly)
            f = xbmcvfs.File(final, "w")
            try:
                f.write(body)
            finally:
                f.close()
            xbmcvfs.delete(temp)


# --------------------------------------------------------------------------- library

def ids_key(kind, d):
    ids = d.get("uniqueid") or {}
    for source in ("imdb", "tmdb", "tvdb"):
        if ids.get(source):
            return "%s|%s:%s" % (kind, source, str(ids[source]).lower())
    return "%s|t:%s|%s" % (kind, (d.get("title") or d.get("label") or "").strip().lower(), d.get("year") or "")


def epoch(lastplayed):
    try:
        return int(time.mktime(datetime.datetime.strptime(lastplayed, "%Y-%m-%d %H:%M:%S").timetuple()))
    except (TypeError, ValueError, OverflowError):
        return 0


def library():
    """{key: (record, (kind, dbid, tags))} for every film, show and episode."""
    found = {}
    movies = (rpc("VideoLibrary.GetMovies", properties=["title", "year", "uniqueid", "playcount", "resume",
                                                         "lastplayed", "userrating", "tag"]) or {}).get("movies") or []
    for m in movies:
        resume = m.get("resume") or {}
        found[ids_key("movie", m)] = ({"pc": m.get("playcount") or 0, "pos": int(resume.get("position") or 0),
                                       "tot": int(resume.get("total") or 0), "lp": m.get("lastplayed") or "",
                                       "ur": m.get("userrating") or 0, "ml": MYLIST_TAG in (m.get("tag") or [])},
                                      ("movie", m["movieid"], m.get("tag") or []))
    shows = (rpc("VideoLibrary.GetTVShows", properties=["title", "year", "uniqueid", "userrating", "tag"]) or {}
             ).get("tvshows") or []
    show_keys = {}
    for s in shows:
        key = ids_key("show", s)
        show_keys[s["tvshowid"]] = key
        found[key] = ({"ur": s.get("userrating") or 0, "ml": MYLIST_TAG in (s.get("tag") or [])},
                      ("tvshow", s["tvshowid"], s.get("tag") or []))
    episodes = (rpc("VideoLibrary.GetEpisodes", properties=["tvshowid", "season", "episode", "playcount", "resume",
                                                             "lastplayed", "userrating"]) or {}).get("episodes") or []
    for e in episodes:
        show = show_keys.get(e.get("tvshowid"))
        if not show:
            continue
        resume = e.get("resume") or {}
        key = "ep|%s|%d|%d" % (show.split("|", 1)[1], e.get("season") or 0, e.get("episode") or 0)
        found[key] = ({"pc": e.get("playcount") or 0, "pos": int(resume.get("position") or 0),
                       "tot": int(resume.get("total") or 0), "lp": e.get("lastplayed") or "",
                       "ur": e.get("userrating") or 0},
                      ("episode", e["episodeid"], None))
    return found


def is_default(record):
    return not any(record.get(k) for k in ("pc", "pos", "ur", "ml"))


def apply_record(ref, record):
    kind, dbid, tags = ref
    if kind == "tvshow":
        params = {"tvshowid": dbid, "userrating": record.get("ur") or 0}
    else:
        params = {kind + "id": dbid, "playcount": record.get("pc") or 0, "userrating": record.get("ur") or 0,
                  "resume": {"position": record.get("pos") or 0, "total": record.get("tot") or 0}}
        if record.get("lp"):
            params["lastplayed"] = record["lp"]
    if tags is not None and bool(record.get("ml")) != (MYLIST_TAG in tags):
        params["tag"] = [t for t in tags if t != MYLIST_TAG] + ([MYLIST_TAG] if record.get("ml") else [])
        note_mylist(kind, dbid, bool(record.get("ml")))
    rpc({"movie": "VideoLibrary.SetMovieDetails", "tvshow": "VideoLibrary.SetTVShowDetails",
         "episode": "VideoLibrary.SetEpisodeDetails"}[kind], **params)


def note_mylist(kind, dbid, on):
    """The MediaHub Helper keeps My List's order in mylist.json: [kind, dbid, added]."""
    path = xbmcvfs.translatePath("special://profile/addon_data/script.mediahub.helper/mylist.json")
    if not os.path.exists(os.path.dirname(path)):
        return
    entries = [e for e in load_json(path, []) if not (e[0] == kind and e[1] == dbid)]
    if on:
        entries.insert(0, [kind, dbid, int(time.time())])
    save_json(path, entries)


def sync_library(others, now):
    """Returns (this device's library records, how many were changed here, the library)."""
    state_path = profile("library.json")
    state = load_json(state_path, {})
    first = not state
    local = library()
    # what changed here since last time (the first time: when it was last watched)
    for key, (record, _) in local.items():
        known = state.get(key)
        if known is None:
            if not is_default(record):
                state[key] = {"r": record, "t": (epoch(record.get("lp")) or 1) if first else now}
        elif known["r"] != record:
            state[key] = {"r": record, "t": now}
    # the newest from the other devices
    best = {}
    for other in others:
        for key, entry in (other.get("library") or {}).items():
            if isinstance(entry, dict) and key in local and entry.get("t", 0) > best.get(key, {}).get("t", 0):
                best[key] = entry
    changed = 0
    for key, entry in best.items():
        mine = state.get(key, {"t": 0})
        record, ref = local[key]
        if entry["t"] > mine["t"] and entry.get("r") != record:
            try:
                apply_record(ref, dict(record, **entry["r"]))
                changed += 1
            except Exception as exc:  # (one item never stops the rest)
                xbmc.log("MediaHub Sync: %s: %r" % (key, exc), xbmc.LOGWARNING)
                continue
            state[key] = {"r": dict(record, **entry["r"]), "t": entry["t"]}
    save_json(state_path, state)
    return {k: v for k, v in state.items() if k in local}, changed, local


# --------------------------------------------------------------------------- add-ons' files

def documents():
    """The files to keep in step: [(name, path, how, key fields)]. how: "list"
    (the latest wins; the first time the lists are put together), "whole" (the
    latest wins) or "entries" (a dict of entries with "t": the latest of each)."""
    addon = xbmcaddon.Addon(ADDON_ID)
    data = xbmcvfs.translatePath("special://profile/addon_data/")
    docs = []
    if addon.getSettingBool("mediahub"):
        docs.append(("helper/family", xbmcvfs.translatePath(
            "special://masterprofile/addon_data/script.mediahub.helper/family.json"), "list", ("type", "title", "year")))
    if addon.getSettingBool("iptv"):
        root = os.path.join(data, "plugin.video.mediahub.xtream")
        if os.path.isdir(root):
            for acc in sorted(os.listdir(root)):
                if acc.startswith("acc-") and acc != "acc-none" and os.path.isdir(os.path.join(root, acc)):
                    folder = os.path.join(root, acc)
                    docs += [("iptv/%s/progress" % acc, os.path.join(folder, "progress.json"), "entries", None),
                             ("iptv/%s/favourites" % acc, os.path.join(folder, "favourites.json"), "list", ("id",)),
                             ("iptv/%s/mylist" % acc, os.path.join(folder, "mylist.json"), "list", ("kind", "id")),
                             ("iptv/%s/reminders" % acc, os.path.join(folder, "reminders.json"), "list",
                              ("id", "start")),
                             ("iptv/%s/hidden" % acc, os.path.join(folder, "hidden.json"), "whole", None)]
    if addon.getSettingBool("radio"):
        folder = os.path.join(data, "plugin.audio.mediahub.radio")
        docs += [("radio/favourites", os.path.join(folder, "favourites.json"), "list", ("id",))]
    if addon.getSettingBool("podcasts"):
        folder = os.path.join(data, "plugin.audio.mediahub.podcasts")
        docs += [("podcasts/subscriptions", os.path.join(folder, "subscriptions.json"), "list", ("feed",)),
                 ("podcasts/progress", os.path.join(folder, "progress.json"), "entries", None)]
    return docs


def read_doc(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def join_lists(lists, fields):
    """The lists put together, each entry once (the first list's order first)."""
    seen, out = set(), []
    for entries in lists:
        for e in entries or []:
            if not isinstance(e, dict):
                continue
            k = tuple(str(e.get(f, "")).lower() for f in fields)
            if k not in seen:
                seen.add(k)
                out.append(e)
    return out


def sync_documents(others, now):
    """Returns (this device's documents, the names of the ones changed here)."""
    state_path = profile("documents.json")
    state = load_json(state_path, {})
    mine, changed = {}, []
    for name, path, how, fields in documents():
        local = read_doc(path)
        known = state.get(name)
        remote = [o["documents"][name] for o in others
                  if isinstance(o.get("documents"), dict) and isinstance(o["documents"].get(name), dict)]
        if how == "entries":
            merged = dict(local) if isinstance(local, dict) else {}
            for doc in remote:
                for k, entry in (doc.get("data") or {}).items():
                    if isinstance(entry, dict) and entry.get("t", 0) > (merged.get(k) or {}).get("t", 0):
                        merged[k] = entry
            if merged != (local or {}) and (merged or local is not None):
                write_doc(path, merged)
                changed.append(name)
            mine[name] = {"data": merged, "t": now}
            state[name] = {"h": digest(merged), "t": now}
            continue
        if known is None:
            t = 0  # (the first time: see below)
        elif local is not None and digest(local) != known["h"]:
            t = now  # (changed here)
        else:
            t = known["t"]
        newest = max(remote, key=lambda d: d.get("t", 0), default=None)
        result = local
        if newest is not None and newest.get("t", 0) > t:
            if t == 0 and how == "list" and isinstance(local, list) and local:
                result, t = join_lists([newest.get("data"), local], fields), now  # (both lists, together)
            else:
                result, t = newest.get("data"), newest["t"]
        elif t == 0 and local is not None:
            t = now  # (the first time, and nobody has a newer one: this is it)
        if result is not None and result != local:
            write_doc(path, result)
            changed.append(name)
        if result is not None:
            state[name] = {"h": digest(result), "t": t}
            mine[name] = {"data": result, "t": t}
    save_json(state_path, state)
    return mine, changed


def write_doc(path, data):
    save_json(path, data)


def after_changes(names):
    """Tell the add-ons whose files changed, so their pages and MediaHub's home rows follow."""
    import xbmcgui
    home = xbmcgui.Window(10000)
    if any(n.startswith("iptv/") for n in names):
        home.setProperty("MHX.Changed", str(time.time()))
    if any(n.startswith("radio/") for n in names):
        xbmc.executebuiltin("RunPlugin(plugin://plugin.audio.mediahub.radio/?mode=refreshhome)")
    if any(n.startswith("podcasts/") for n in names):
        xbmc.executebuiltin("RunPlugin(plugin://plugin.audio.mediahub.podcasts/?mode=refreshhome)")
    if any(n.startswith("helper/") for n in names):
        home.setProperty("MH.Req.Rows", str(time.time()))


# --------------------------------------------------------------------------- carry on watching

HANDOFF_HOURS = 12  # a film or episode stopped on another Kodi is offered for this long
HANDOFF = "MHS.Handoff"  # Window(Home) properties for MediaHub's "Carry on watching" banner


def note_stopped(item, ended):
    """Player.OnStop: what was stopped here, and where (for the other devices)."""
    kind, dbid = (item or {}).get("type"), (item or {}).get("id")
    if ended or kind not in ("movie", "episode") or not isinstance(dbid, int) or dbid < 0:
        return
    for _ in range(4):  # (Kodi saves the resume point just after it says playback stopped)
        found = stopped_item(kind, dbid)
        if found[1].get("position"):
            break
        xbmc.sleep(750)
    key, resume, d = found
    if key and resume.get("position"):
        save_json(profile("handoff.json"), {"key": key, "kind": kind, "title": d.get("title", ""),
                                            "pos": int(resume["position"]), "total": int(resume.get("total") or 0),
                                            "t": int(time.time())})


def stopped_item(kind, dbid):
    """(sync key, resume point, details) of a film or episode."""
    if kind == "movie":
        d = (rpc("VideoLibrary.GetMovieDetails", movieid=dbid, properties=["title", "year", "uniqueid", "resume"])
             or {}).get("moviedetails") or {}
        key = ids_key("movie", d) if d else None
    else:
        d = (rpc("VideoLibrary.GetEpisodeDetails", episodeid=dbid,
                 properties=["title", "tvshowid", "season", "episode", "resume"]) or {}).get("episodedetails") or {}
        show = (rpc("VideoLibrary.GetTVShowDetails", tvshowid=d.get("tvshowid", -1),
                    properties=["title", "year", "uniqueid"]) or {}).get("tvshowdetails") if d else None
        key = "ep|%s|%d|%d" % (ids_key("show", show).split("|", 1)[1], d.get("season") or 0,
                               d.get("episode") or 0) if show else None
    return key, (d or {}).get("resume") or {}, d or {}


def own_handoff():
    h = load_json(profile("handoff.json"), {})
    return h if h.get("t", 0) > time.time() - HANDOFF_HOURS * 3600 else {}


def clock(seconds):
    seconds = int(seconds)
    return "%d:%02d:%02d" % (seconds // 3600, seconds // 60 % 60, seconds % 60) if seconds >= 3600 else \
        "%d:%02d" % (seconds // 60, seconds % 60)


def offer_handoff(others, local):
    """The newest film or episode stopped on another Kodi (and not finished here since):
    MHS.Handoff.* for MediaHub's "Carry on watching" banner."""
    import xbmcgui
    home = xbmcgui.Window(10000)
    dismissed = load_json(profile("handoff_seen.json"), {}).get("t", 0)
    mine = own_handoff().get("t", 0)
    offers = [(o["handoff"], o.get("name", "")) for o in others if isinstance(o.get("handoff"), dict)
              and o["handoff"].get("key") in local and o["handoff"].get("t", 0) > max(dismissed, mine)
              and o["handoff"]["t"] > time.time() - HANDOFF_HOURS * 3600]
    if not offers:
        for p in ("", ".Title", ".Sub", ".Device", ".At", ".Art", ".Kind", ".DBID", ".T"):
            home.clearProperty(HANDOFF + p)
        return
    h, device_name = max(offers, key=lambda o: o[0]["t"])
    _, (kind, dbid, _) = local[h["key"]]
    art, sub = {}, ""
    if kind == "movie":
        d = (rpc("VideoLibrary.GetMovieDetails", movieid=dbid, properties=["title", "art", "year"]) or {}
             ).get("moviedetails") or {}
        art, sub = d.get("art") or {}, str(d.get("year") or "")
    elif kind == "episode":
        d = (rpc("VideoLibrary.GetEpisodeDetails", episodeid=dbid, properties=["title", "art", "showtitle",
                                                                                "season", "episode"]) or {}
             ).get("episodedetails") or {}
        art, sub = d.get("art") or {}, "%s  •  S%d E%d" % (d.get("showtitle", ""), d.get("season") or 0,
                                                           d.get("episode") or 0)
    else:
        return
    home.setProperty(HANDOFF + ".Title", d.get("title") or h.get("title", ""))
    home.setProperty(HANDOFF + ".Sub", sub)
    home.setProperty(HANDOFF + ".Device", device_name)
    home.setProperty(HANDOFF + ".At", clock(h.get("pos", 0)))
    home.setProperty(HANDOFF + ".Art", art.get("fanart") or art.get("tvshow.fanart") or art.get("thumb") or "")
    home.setProperty(HANDOFF + ".Kind", kind)
    home.setProperty(HANDOFF + ".DBID", str(dbid))
    home.setProperty(HANDOFF + ".T", str(h["t"]))
    home.setProperty(HANDOFF, "1")


def dismiss_handoff():
    import xbmcgui
    home = xbmcgui.Window(10000)
    save_json(profile("handoff_seen.json"), {"t": int(home.getProperty(HANDOFF + ".T") or time.time())})
    home.clearProperty(HANDOFF)


def play_handoff():
    """Play what was stopped on the other Kodi, from where it stopped (Sync has already
    brought its resume point here)."""
    import xbmcgui
    home = xbmcgui.Window(10000)
    kind, dbid = home.getProperty(HANDOFF + ".Kind"), home.getProperty(HANDOFF + ".DBID")
    dismiss_handoff()
    if kind in ("movie", "episode") and dbid.isdigit():
        rpc("Player.Open", item={kind + "id": int(dbid)}, options={"resume": True})


# --------------------------------------------------------------------------- a sync

def run():
    """One sync. Returns a status dict (also kept in status.json)."""
    addon = xbmcaddon.Addon(ADDON_ID)
    path = addon.getSetting("folder")
    status = {"t": time.time(), "ok": False, "devices": [], "changed": 0}
    if not path:
        status["error"] = "nofolder"
        return status
    own, name = device()
    folder = Folder(path)
    try:
        if not folder.ready():
            raise OSError("can't reach the sync folder")
        others = folder.others(own)
        now = int(time.time())
        lib, lib_changed, local = sync_library(others, now) if addon.getSettingBool("library") else ({}, 0, {})
        docs, doc_changed = sync_documents(others, now)
        folder.write(own, {"format": FORMAT, "device": own, "name": name, "t": now, "library": lib,
                           "documents": docs, "handoff": own_handoff(),
                           "address": xbmc.getIPAddress()})  # (for Watch together)
        offer_handoff(others, local)
        after_changes(doc_changed)
        status.update(ok=True, devices=[o.get("name", "?") for o in others], changed=lib_changed + len(doc_changed))
    except Exception as exc:
        xbmc.log("MediaHub Sync: %r" % exc, xbmc.LOGWARNING)
        status["error"] = "folder"
    save_json(profile("status.json"), status)
    return status
