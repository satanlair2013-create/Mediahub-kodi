"""MediaHub Audiobooks - free audiobooks from LibriVox.

Continue listening, My books, the most popular and the newest books, genres, and
search by title or author. A book plays chapter after chapter and carries on
where you stopped, next time too.
"""
import json
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import books  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name")
FANART = os.path.join(ADDON.getAddonInfo("path"), "resources", "fanart.jpg")


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def kodi(string_id):
    return xbmc.getLocalizedString(string_id)


def url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)


def notify(message, error=False):
    xbmcgui.Dialog().notification(NAME, message, xbmcgui.NOTIFICATION_WARNING if error else
                                  xbmcgui.NOTIFICATION_INFO, 4000, False)


def folder(label, target, icon="DefaultFolder.png"):
    item = xbmcgui.ListItem(label)
    item.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=True)


def end(content="", title=""):
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.setPluginCategory(HANDLE, title or NAME)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED, labelMask="%L", label2Mask="%A")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def careful(work):
    try:
        work()
    except books.Error as exc:
        xbmc.log("MediaHub Audiobooks: %s" % exc, xbmc.LOGWARNING)
        notify(text(30017), True)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def clock(seconds):
    seconds = int(seconds)
    return "%d:%02d:%02d" % (seconds // 3600, seconds // 60 % 60, seconds % 60) if seconds >= 3600 else \
        "%d:%02d" % (seconds // 60, seconds % 60)


# --------------------------------------------------------------------------- pages

def root():
    if books.continue_listening(1):
        folder(text(30001), url(mode="continue"), "DefaultInProgressShows.png")
    if books.mine():
        folder(text(30002), url(mode="mine"), "DefaultMusicPlaylists.png")
    folder(text(30003), url(mode="list", sort="downloads desc"), "DefaultMusicTop100.png")
    folder(text(30004), url(mode="list", sort="publicdate desc"), "DefaultMusicRecentlyAdded.png")
    folder(text(30005), url(mode="genres"), "DefaultMusicGenres.png")
    folder(kodi(137), url(mode="search"), "DefaultAddonsSearch.png")
    end()


def book_folder(b, sub=""):
    item = xbmcgui.ListItem(b.get("title", ""))
    art = b.get("art") or books.cover(b["id"])
    item.setArt({"icon": art, "thumb": art, "poster": art, "fanart": FANART})
    tag = item.getMusicInfoTag()
    tag.setTitle(b.get("title", ""))
    tag.setArtist(sub or b.get("author", ""))
    tag.setAlbum(b.get("title", ""))
    tag.setComment(b.get("plot", ""))
    info = json.dumps({k: b.get(k, "") for k in ("id", "title", "author")})
    mine = books.in_mine(b["id"])
    item.addContextMenuItems([
        (text(30008) if mine else text(30007), "RunPlugin(%s)" % url(mode="mine_set", on=int(not mine), book=info)),
        (text(30014), "RunPlugin(%s)" % url(mode="done", on=1, book=info))])
    xbmcplugin.addDirectoryItem(HANDLE, url(mode="book", id=b["id"]), item, isFolder=True)


def list_page(query, sort, title):
    page = int(ARGS.get("page", 1))
    found = books.search_books(query, sort, page)
    for b in found:
        book_folder(b)
    if len(found) >= books.PAGE:
        folder(kodi(33078), url(mode=ARGS.get("mode"), sort=sort, q=ARGS.get("q", ""), genre=ARGS.get("genre", ""),
                                page=page + 1), "DefaultFolder.png")
    end("albums", title)


def genres():
    for word, string_id in books.GENRES:
        folder(text(string_id), url(mode="genre", genre=word), "DefaultMusicGenres.png")
    end("", text(30005))


def search():
    words = ARGS.get("q")
    if not words:
        words = xbmcgui.Dialog().input(text(30016))
        if not words:
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        xbmc.executebuiltin("Container.Update(%s,replace)" % url(mode="search", q=words))
        return end()
    list_page(books.words_rule(words), "downloads desc", '%s: "%s"' % (kodi(137), words))


def continue_page():
    for p in books.continue_listening():
        book_folder({"id": p["id"], "title": p.get("title", ""), "author": p.get("author", "")},
                    "  •  ".join(x for x in (p.get("author", ""), books.time_left(p)) if x))
    end("albums", text(30001))


def mine_page():
    for b in books.mine():
        book_folder(b)
    end("albums", text(30002))


def book_page():
    b = books.book(ARGS["id"])
    chapter, pos = books.place(b["id"])
    started = chapter or pos > 30
    chapters = b.get("chapters") or []
    if not chapters:
        notify(text(30018), True)
    if started and chapter < len(chapters):
        item = xbmcgui.ListItem("[B]%s[/B]" % (text(30010) % chapters[chapter]["title"]))
        item.setArt({"icon": b["art"], "thumb": b["art"], "fanart": FANART})
        tag = item.getMusicInfoTag()
        tag.setTitle(chapters[chapter]["title"])
        tag.setArtist(books.time_left(dict(books.progress().get(b["id"]) or {}, id=b["id"])))
        item.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(HANDLE, books.play_address(b["id"]), item, isFolder=False)
    for n, c in enumerate(chapters):
        item = xbmcgui.ListItem(c["title"])
        item.setArt({"icon": b["art"], "thumb": b["art"], "fanart": FANART})
        tag = item.getMusicInfoTag()
        tag.setTitle(c["title"])
        tag.setTrack(n + 1)
        tag.setArtist(b.get("author", ""))
        tag.setAlbum(b.get("title", ""))
        if c.get("duration"):
            tag.setDuration(int(c["duration"]))
        if n < chapter:
            tag.setPlayCount(1)
        xbmcplugin.addDirectoryItem(HANDLE, books.play_address(b["id"], n), item, isFolder=False)
    end("songs", b.get("title", ""))


# --------------------------------------------------------------------------- playing

def play():
    """The book from a chapter on (or from where you stopped), as one playlist."""
    b = books.book(ARGS["id"])
    chapters = b.get("chapters") or []
    if not chapters:
        return notify(text(30018), True)
    if ARGS.get("chapter") is not None:
        start, offset = int(ARGS["chapter"]), 0
        here, pos = books.place(b["id"])
        if here == start and pos > 30:
            offset = pos
    else:
        start, offset = books.place(b["id"])
    start = max(0, min(start, len(chapters) - 1))
    playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    playlist.clear()
    now = {}
    for n in range(start, len(chapters)):
        c = chapters[n]
        item = xbmcgui.ListItem(c["title"], path=c["url"])
        item.setArt({"thumb": b["art"], "icon": b["art"], "fanart": FANART})
        tag = item.getMusicInfoTag()
        tag.setTitle(c["title"])
        tag.setArtist(b.get("author", ""))
        tag.setAlbum(b.get("title", ""))
        tag.setTrack(n + 1)
        if c.get("duration"):
            tag.setDuration(int(c["duration"]))
        if n == start and offset:
            item.setProperty("StartOffset", str(int(offset)))
        playlist.add(c["url"], item)
        now[c["url"]] = {"id": b["id"], "chapter": n}
    xbmcgui.Window(10000).setProperty(books.NOW, json.dumps(now))
    xbmc.Player().play(playlist)


def main():
    mode = ARGS.get("mode")
    if mode is None:
        root()
    elif mode == "list":
        careful(lambda: list_page("", ARGS.get("sort", "downloads desc"),
                                  text(30004) if ARGS.get("sort", "").startswith("publicdate") else text(30003)))
    elif mode == "genres":
        genres()
    elif mode == "genre":
        word = ARGS.get("genre", "")
        title = next((text(i) for w, i in books.GENRES if w == word), word)
        careful(lambda: list_page(' AND subject:("%s")' % word.replace('"', ""), "downloads desc", title))
    elif mode == "search":
        careful(search)
    elif mode == "continue":
        continue_page()
    elif mode == "mine":
        mine_page()
    elif mode == "book":
        careful(book_page)
    elif mode == "play":
        try:
            play()
        except books.Error:
            notify(text(30017), True)
    elif mode == "mine_set":
        b = json.loads(ARGS.get("book") or "{}")
        if b.get("id"):
            books.set_mine(b, ARGS.get("on") == "1")
            xbmc.executebuiltin("Container.Refresh")
    elif mode == "done":
        b = json.loads(ARGS.get("book") or "{}")
        if b.get("id"):
            books.set_done(b, ARGS.get("on") == "1")
            notify(text(30015))
            xbmc.executebuiltin("Container.Refresh")


if __name__ == "__main__":
    main()
