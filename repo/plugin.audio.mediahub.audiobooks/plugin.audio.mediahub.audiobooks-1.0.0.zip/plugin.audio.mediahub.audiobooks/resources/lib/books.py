"""MediaHub Audiobooks - LibriVox's free audiobooks, through the Internet Archive.

LibriVox volunteers read books that are out of copyright; every recording is kept
at the Internet Archive (the librivoxaudio collection), which has a free search
and each book's chapters as MP3 files. No account or key.

Kept in the add-on's data folder:
- progress.json: {book id: {title, author, chapter, chapters, pos, total, done, t}}
- mine.json: My books [{id, title, author, t}]
- books/: each book's details and chapters as last read
- home.json: ready-made cards for MediaHub's home row (Audiobooks: Continue Listening)
"""
import gzip
import hashlib
import html
import json
import os
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.audio.mediahub.audiobooks"
ARCHIVE = os.environ.get("MEDIAHUB_ARCHIVE", "https://archive.org").rstrip("/")  # (a test server can stand in)
CERTS = "special://xbmc/system/certs/cacert.pem"
COLLECTION = "librivoxaudio"
BOOK_AGE = 30 * 86400
LIST_AGE = 12 * 3600
PAGE = 40
DONE = 0.97  # this far through the last chapter counts as finished
NOW = "MHB.Now"  # what the add-on started playing: {chapter address: {id, chapter}}
HOME_CARDS = 20
# the genres offered (Internet Archive subjects LibriVox uses), with their string ids
GENRES = [("mystery", 30030), ("science fiction", 30031), ("adventure", 30032), ("children", 30033),
          ("poetry", 30034), ("romance", 30035), ("horror", 30036), ("history", 30037),
          ("philosophy", 30038), ("humor", 30039), ("short stories", 30040), ("fantasy", 30041)]


class Error(Exception):
    pass


def text(string_id):
    return xbmcaddon.Addon(ADDON_ID).getLocalizedString(string_id)


# --------------------------------------------------------------------------- files

def profile(name=""):
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)


def load_json(name, default):
    try:
        with open(profile(name), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(name, data):
    path = profile(name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def key(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()[:16]


# --------------------------------------------------------------------------- the Internet Archive

def ssl_context():
    certs = xbmcvfs.translatePath(CERTS)
    try:
        return ssl.create_default_context(cafile=certs) if os.path.exists(certs) else ssl.create_default_context()
    except (OSError, ssl.SSLError):
        return ssl.create_default_context()


def fetch_json(url, timeout=15):
    request = urllib.request.Request(url, headers={"User-Agent": xbmc.getUserAgent(), "Accept-Encoding": "gzip"})
    try:
        with urllib.request.urlopen(request, timeout=timeout, context=ssl_context()) as reply:
            body = reply.read(8 * 1024 * 1024)
        if body[:2] == b"\x1f\x8b":
            body = gzip.decompress(body)
        return json.loads(body.decode("utf-8", "replace") or "null")
    except urllib.error.HTTPError as exc:
        raise Error("HTTP %d" % exc.code)
    except (OSError, ValueError, ssl.SSLError) as exc:
        raise Error(repr(exc))


def plain(value):
    if isinstance(value, list):
        value = " ".join(str(v) for v in value)
    value = re.sub(r"<(br|p|/p|li)[^>]*>", "\n", str(value or ""), flags=re.I)
    value = html.unescape(re.sub(r"<[^>]+>", "", value))
    return re.sub(r"\n\s*\n+", "\n\n", re.sub(r"[ \t]+", " ", value)).strip()


def first(value):
    return (value[0] if value else "") if isinstance(value, list) else (value or "")


def cover(book_id):
    return "%s/services/img/%s" % (ARCHIVE, urllib.parse.quote(book_id))


def language_rule():
    language = xbmcaddon.Addon(ADDON_ID).getSetting("language")
    return " AND language:(%s)" % language if language and language != "any" else ""


def search_books(query, sort="downloads desc", page=1, rows=PAGE):
    """[{id, title, author, plot, art}] from the Internet Archive's search."""
    q = "collection:(%s) AND mediatype:(audio)%s%s" % (COLLECTION, language_rule(), query)
    params = [("q", q), ("rows", rows), ("page", page), ("output", "json"), ("sort[]", sort)]
    params += [("fl[]", f) for f in ("identifier", "title", "creator", "description", "downloads")]
    cache = "lists/%s.json" % key(q, sort, page, rows)
    kept = load_json(cache, {})
    if kept.get("docs") is not None and time.time() - kept.get("t", 0) < LIST_AGE:
        return kept["docs"]
    reply = fetch_json("%s/advancedsearch.php?%s" % (ARCHIVE, urllib.parse.urlencode(params)))
    docs = [{"id": d["identifier"], "title": plain(first(d.get("title"))) or d["identifier"],
             "author": plain(first(d.get("creator"))), "plot": plain(d.get("description"))[:1500],
             "art": cover(d["identifier"])}
            for d in ((reply or {}).get("response") or {}).get("docs") or [] if d.get("identifier")]
    save_json(cache, {"docs": docs, "t": time.time()})
    return docs


def words_rule(words):
    words = re.sub(r'[^\w\s\'-]+', " ", words or "").strip()
    return " AND (title:(%s) OR creator:(%s))" % (words, words) if words else ""


def seconds(value):
    value = str(value or "").strip()
    if ":" in value:
        total = 0
        for part in value.split(":"):
            total = total * 60 + (float(part) if part.replace(".", "", 1).isdigit() else 0)
        return int(total)
    try:
        return int(float(value))
    except ValueError:
        return 0


def book(book_id, max_age=BOOK_AGE):
    """{id, title, author, plot, art, chapters: [{title, url, duration}]} (the last copy
    when the Archive can't be reached)."""
    path = "books/%s.json" % key(book_id)
    kept = load_json(path, {})
    if kept.get("chapters") and time.time() - kept.get("t", 0) < max_age:
        return kept
    try:
        reply = fetch_json("%s/metadata/%s" % (ARCHIVE, urllib.parse.quote(book_id)))
    except Error:
        if kept.get("chapters"):
            return kept
        raise
    meta = (reply or {}).get("metadata") or {}
    files = (reply or {}).get("files") or []
    chapters = []
    for kind in ("64Kbps MP3", "128Kbps MP3", "VBR MP3", "MP3"):
        chosen = [f for f in files if f.get("format") == kind and f.get("name", "").lower().endswith(".mp3")]
        if chosen:
            break
    else:
        chosen = []

    def order(f):
        track = re.match(r"\d+", str(f.get("track") or ""))
        return (int(track.group()) if track else 9999, f.get("name", ""))
    for n, f in enumerate(sorted(chosen, key=order), 1):
        chapters.append({"title": plain(f.get("title")) or text(30011) % n,
                         "url": "%s/download/%s/%s" % (ARCHIVE, urllib.parse.quote(book_id),
                                                       urllib.parse.quote(f["name"])),
                         "duration": seconds(f.get("length"))})
    found = {"id": book_id, "title": plain(first(meta.get("title"))) or book_id,
             "author": plain(first(meta.get("creator"))), "plot": plain(meta.get("description"))[:3000],
             "art": cover(book_id), "chapters": chapters, "t": time.time()}
    save_json(path, found)
    return found


def cached_book(book_id):
    return load_json("books/%s.json" % key(book_id), {})


# --------------------------------------------------------------------------- My books

def mine():
    return [b for b in load_json("mine.json", []) if isinstance(b, dict) and b.get("id")]


def in_mine(book_id):
    return any(b["id"] == book_id for b in mine())


def set_mine(b, on):
    found = [x for x in mine() if x["id"] != b["id"]]
    if on:
        found.insert(0, {"id": b["id"], "title": b.get("title", ""), "author": b.get("author", ""), "t": time.time()})
    save_json("mine.json", found)


# --------------------------------------------------------------------------- progress

def progress():
    return load_json("progress.json", {})


def place(book_id):
    """(chapter index, position) to carry on from; (0, 0) for a book not started or finished."""
    p = progress().get(book_id) or {}
    if p.get("done"):
        return 0, 0
    return int(p.get("chapter", 0)), int(p.get("pos", 0))


def record(b, chapter, pos, total):
    data = progress()
    chapters = len(b.get("chapters") or []) or int(b.get("count") or 0)
    done = chapter >= chapters - 1 and total > 0 and pos >= total * DONE
    data[b["id"]] = {"title": b.get("title", ""), "author": b.get("author", ""), "chapter": chapter,
                     "chapters": chapters, "pos": 0 if done else int(pos), "total": int(total), "done": done,
                     "t": time.time()}
    save_json("progress.json", data)
    write_home()


def set_done(b, done):
    data = progress()
    old = data.get(b["id"]) or {}
    data[b["id"]] = dict(old, title=b.get("title", old.get("title", "")), author=b.get("author", old.get("author", "")),
                         chapter=0, pos=0, done=bool(done), t=time.time())
    save_json("progress.json", data)
    write_home()


def continue_listening(limit=30):
    return [dict(p, id=i) for i, p in sorted(progress().items(), key=lambda kv: -kv[1].get("t", 0))
            if not p.get("done") and (p.get("pos", 0) > 30 or p.get("chapter", 0) > 0)][:limit]


def play_address(book_id, chapter=None):
    params = {"mode": "play", "id": book_id}
    if chapter is not None:
        params["chapter"] = int(chapter)
    return "plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode(params))


def time_left(p):
    """How much of the book is left, roughly ("3 h 20 min left"), from the chapters kept."""
    b = cached_book(p["id"])
    chapters = b.get("chapters") or []
    if not chapters:
        return ""
    left = sum(c.get("duration") or 0 for c in chapters[p.get("chapter", 0):]) - p.get("pos", 0)
    minutes = max(1, int(left) // 60)
    span = "%d h %d min" % (minutes // 60, minutes % 60) if minutes >= 60 else "%d min" % minutes
    return text(30012) % span


def write_home():
    """home.json: MediaHub's Audiobooks: Continue Listening row."""
    cards = {"abcontinue": []}
    for p in continue_listening(HOME_CARDS):
        chapters = p.get("chapters") or 0
        cards["abcontinue"].append({
            "Label": p.get("title", ""),
            "Label2": "  •  ".join(x for x in (p.get("author", ""), text(30011) % (p.get("chapter", 0) + 1)) if x),
            "Title": p.get("title", ""), "Square": cover(p["id"]),
            "Percent": str(int(100 * p.get("chapter", 0) / chapters)) if chapters else "",
            "Action": "audiobook|run|" + play_address(p["id"]), "Kind": "audiobook", "kids": True})
    save_json("home.json", cards)
    xbmcgui.Window(10000).setProperty("MHB.Home", str(time.time()))  # (the helper refreshes the row)
