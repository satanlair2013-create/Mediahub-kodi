"""MediaHub Audiobooks - in the background while Kodi runs.

Notes which chapter of a book from the add-on is playing and how far into it you
are, so the book carries on there next time (and MediaHub's Audiobooks: Continue
Listening row is up to date).
"""
import json
import os
import sys
import time

import xbmc
import xbmcgui

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import books  # noqa: E402

SAVE_EVERY = 15


class Tracker:
    def __init__(self):
        self.next = 0.0
        self.path = None
        self.entry = None
        self.pos = self.total = 0.0
        self.saved = 0.0

    def tick(self):
        now = time.time()
        if now < self.next:
            return
        self.next = now + 2.0
        path = xbmc.getInfoLabel("Player.Filenameandpath") if xbmc.getCondVisibility("Player.HasAudio") else ""
        if path != self.path:
            self.finish()
            self.path = path
            if path:
                try:
                    playing = json.loads(xbmcgui.Window(10000).getProperty(books.NOW) or "{}")
                except ValueError:
                    playing = {}
                self.entry = playing.get(path)
                if self.entry:
                    self.saved = 0.0
        if not self.entry:
            return
        try:
            player = xbmc.Player()
            self.pos, self.total = player.getTime(), player.getTotalTime()
        except RuntimeError:
            return
        if now - self.saved > SAVE_EVERY:
            self.record()
            self.saved = now

    def record(self):
        if self.entry and self.total > 0:
            b = books.cached_book(self.entry["id"]) or {"id": self.entry["id"]}
            books.record(b, self.entry["chapter"], self.pos, self.total)

    def finish(self):
        if self.entry:
            # (a chapter played to its end: the next one is where to carry on)
            if self.total > 0 and self.pos >= self.total - 5:
                b = books.cached_book(self.entry["id"]) or {"id": self.entry["id"]}
                last = len(b.get("chapters") or []) - 1
                if self.entry["chapter"] < last:
                    books.record(b, self.entry["chapter"] + 1, 0, 1)
                else:
                    books.record(b, self.entry["chapter"], self.total, self.total)
            else:
                self.record()
        self.entry = None
        self.pos = self.total = 0.0


class Service(xbmc.Monitor):
    def run(self):
        tracker = Tracker()
        while not self.waitForAbort(1):
            try:
                tracker.tick()
            except Exception as exc:  # (never take the service down)
                xbmc.log("MediaHub Audiobooks: %r" % exc, xbmc.LOGERROR)
        tracker.finish()


if __name__ == "__main__":
    Service().run()
