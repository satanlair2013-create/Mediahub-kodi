"""MediaHub IPTV - what's kept between visits.

- progress.json: how far into each film and episode you are (resume, the watched
  tick, Continue Watching). The service notes it while something from here plays.
- hidden.json: the categories left out of the pages. Until you choose, the ones
  that look adult are.
- index.db: every live channel, film and series by name, for Search, Recently
  added and MediaHub's home rows. The service reads the categories one at a time
  once a day (so even a huge service never has to be loaded in one go).
"""
import json
import os
import re
import sqlite3
import threading
import time
import urllib.parse

import xbmc
import xbmcgui

import xtream

KEEP = 300  # progress entries kept (the oldest go)
WATCHED = 0.9  # this far through counts as watched
NOW = "MHX.Now"  # what the add-on started playing: {address: entry}
ADULT = re.compile(r"adult|xxx|porn|\+18|18\+|for adults|erotic", re.I)
KIDS = re.compile(r"kid|child|cartoon|anim|family|famil|disney|junior|jeunesse|enfant|kinder|infantil|bambin|"
                  r"crian|nick|boomerang|baby", re.I)
KINDS = ("live", "vod", "series")
BUILDING = threading.Lock()


def load_json(name, default):
    try:
        with open(xtream.profile(name), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(name, data):
    path = xtream.profile(name)
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def kids_category(name):
    return bool(KIDS.search(name or ""))


def kids_mode():
    """MediaHub's Kids mode: only categories that look like children's ones."""
    return xbmc.getCondVisibility("Skin.HasSetting(MH.KidsMode)")


# --------------------------------------------------------------------------- categories

def hidden(kind, categories=None):
    """The category ids of this kind left out. Until you choose, the adult-looking ones."""
    chosen = load_json("hidden.json", {})
    if kind in chosen:
        return set(str(c) for c in chosen[kind])
    return set(str(c.get("category_id")) for c in categories or [] if ADULT.search(c.get("category_name") or ""))


def set_hidden(kind, ids):
    chosen = load_json("hidden.json", {})
    chosen[kind] = [str(i) for i in ids]
    save_json("hidden.json", chosen)


def visible(kind, categories):
    """The categories to show: not hidden, and in Kids mode only children's ones."""
    gone = hidden(kind, categories)
    kids = kids_mode()
    return [c for c in categories if str(c.get("category_id")) not in gone
            and (not kids or KIDS.search(c.get("category_name") or ""))]


# --------------------------------------------------------------------------- progress

def load():
    return load_json("progress.json", {})


def save(data):
    if len(data) > KEEP:
        data = dict(sorted(data.items(), key=lambda kv: kv[1].get("t", 0))[-KEEP:])
    save_json("progress.json", data)


def key(kind, stream_id):
    return "%s:%s" % (kind, stream_id)


def resume_point(kind, stream_id):
    """(position, total, watched)."""
    p = load().get(key(kind, stream_id)) or {}
    return p.get("pos", 0), p.get("total", 0), bool(p.get("watched"))


def bare(address):
    return address.split("|", 1)[0]


class Tracker:
    """Notes how far into a film or episode from this add-on you are while it plays."""

    def __init__(self):
        self.next = 0.0
        self.path = None
        self.entry = None
        self.pos = self.total = self.furthest = 0.0
        self.saved = 0.0

    def tick(self):
        now = time.time()
        if now < self.next:
            return
        self.next = now + 2.0
        path = xbmc.getInfoLabel("Player.Filenameandpath") if xbmc.getCondVisibility("Player.HasVideo") else ""
        if path != self.path:
            self.finish()
            self.path = path
            if path:
                try:
                    playing = json.loads(xbmcgui.Window(10000).getProperty(NOW) or "{}")
                except ValueError:
                    playing = {}
                self.entry = next((e for a, e in playing.items() if bare(a) == bare(path)), None)
        if not self.entry:
            return
        try:
            player = xbmc.Player()
            self.pos, self.total = player.getTime(), player.getTotalTime()
        except RuntimeError:
            return
        if self.total > 0:
            self.furthest = max(self.furthest, self.pos / self.total)
        if now - self.saved > 15:
            self.record()
            self.saved = now

    def record(self):
        e = self.entry
        if not e or e.get("kind") not in ("movie", "episode") or self.total <= 0 or self.pos < 5:
            return
        data = load()
        watched = self.furthest >= WATCHED
        data[key(e["kind"], e["id"])] = dict(e, pos=0 if watched else int(self.pos), total=int(self.total),
                                            watched=watched, t=time.time())
        save(data)
        xbmcgui.Window(10000).setProperty("MHX.Changed", str(time.time()))  # (MediaHub's home row)

    def finish(self):
        if self.entry:
            self.record()
        self.entry = None
        self.pos = self.total = self.furthest = 0.0


def continue_watching(limit=30, kids=None):
    """What you're part-way through, and the next episode of a series whose last
    episode you finished: entries, most recent first. kids: only children's
    (None: when MediaHub's Kids mode is on)."""
    found, series = [], set()
    kids = kids_mode() if kids is None else kids
    for _, p in sorted(load().items(), key=lambda kv: -kv[1].get("t", 0)):
        if kids and not p.get("kids"):
            continue
        if p.get("kind") == "episode":
            if p.get("series_id") in series:
                continue
            series.add(p.get("series_id"))
        if p.get("watched"):
            nxt = p.get("next")
            if p.get("kind") != "episode" or not nxt:
                continue
            found.append(dict(nxt, pos=0, total=0))
        elif p.get("pos"):
            found.append(p)
        if len(found) >= limit:
            break
    return found


# --------------------------------------------------------------------------- the index

def index_path():
    return xtream.profile("index.db")


def connect(path=None):
    con = sqlite3.connect(path or index_path(), timeout=10)
    con.execute("CREATE TABLE IF NOT EXISTS items (kind TEXT, id TEXT, name TEXT, key TEXT, icon TEXT, cat TEXT,"
                " catname TEXT, added INTEGER, rating REAL, year INTEGER, ext TEXT, archive INTEGER, fanart TEXT,"
                " PRIMARY KEY (kind, id))")
    con.execute("CREATE TABLE IF NOT EXISTS meta (name TEXT PRIMARY KEY, value TEXT)")
    if "fanart" not in [c[1] for c in con.execute("PRAGMA table_info(items)")]:
        con.execute("ALTER TABLE items ADD COLUMN fanart TEXT")  # (an index from a test build)
    return con


def sort_key(name):
    name = re.sub(r"^\s*(?:\|[A-Z]{2,4}\||\[[A-Z]{2,4}\]|[A-Z]{2,4}\s+-\s+|[A-Z]{2,4}\s*\|)\s*", "", name or "")
    name = re.sub(r"^(the|a|an)\s+", "", name.strip().lower())
    return re.sub(r"[^\w]+", " ", name).strip()


def backdrop(entry):
    b = entry.get("backdrop_path")
    return (b[0] if isinstance(b, list) and b else b if isinstance(b, str) else "") or ""


def built():
    """When the index was last built (0: never)."""
    if not os.path.exists(index_path()):
        return 0
    con = connect()
    try:
        row = con.execute("SELECT value FROM meta WHERE name='built'").fetchone()
        return float(row[0]) if row else 0
    finally:
        con.close()


def build(account, monitor, progress=None, timeout=8):
    """Read every category of every kind into a new index, then swap it in. progress:
    a function(percent, text) (the foreground build); False if it stopped part-way."""
    if not account.ready() or not BUILDING.acquire(blocking=False):
        return False
    temp = index_path() + ".new"
    try:
        if os.path.exists(temp):
            os.remove(temp)
        con = connect(temp)
        try:
            jobs = []
            for kind in KINDS:
                try:
                    jobs += [(kind, c) for c in account.categories(kind, timeout=timeout, monitor=monitor)]
                except xtream.Error:
                    return False
            for n, (kind, cat) in enumerate(jobs):
                if monitor.abortRequested() or (progress and progress(100 * n // max(1, len(jobs)),
                                                                        cat.get("category_name") or "") is False):
                    return False
                cid = str(cat.get("category_id"))
                try:
                    entries = account.streams(kind, cid, max_age=12 * xtream.HOUR, timeout=timeout,
                                              monitor=monitor)
                except xtream.Error:
                    continue
                rows = []
                for s in entries:
                    sid = s.get("series_id") if kind == "series" else s.get("stream_id")
                    if sid in (None, ""):
                        continue
                    name = s.get("name") or ""
                    rows.append((kind, str(sid), name, sort_key(name),
                                 s.get("cover") if kind == "series" else s.get("stream_icon") or "",
                                 cid, cat.get("category_name") or "",
                                 xtream.number(s.get("last_modified") if kind == "series" else s.get("added")),
                                 xtream.rating(s.get("rating")), xtream.year_of(s),
                                 s.get("container_extension") or "", 1 if xtream.number(s.get("tv_archive")) else 0,
                                 backdrop(s)))
                con.executemany("INSERT OR REPLACE INTO items VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
                con.commit()
                monitor.waitForAbort(0.2)
            con.execute("CREATE INDEX IF NOT EXISTS keys ON items (key)")
            con.execute("CREATE INDEX IF NOT EXISTS added ON items (kind, added)")
            con.execute("INSERT OR REPLACE INTO meta VALUES ('built', ?)", (str(time.time()),))
            con.commit()
        finally:
            con.close()
        os.replace(temp, index_path())
        return True
    finally:
        try:
            os.remove(temp)
        except OSError:
            pass
        BUILDING.release()


def query(sql, params=()):
    if not os.path.exists(index_path()):
        return []
    con = connect()
    try:
        return con.execute(sql, params).fetchall()
    finally:
        con.close()


COLUMNS = "kind, id, name, icon, cat, catname, added, rating, year, ext, archive, fanart"


def as_dict(row):
    return dict(zip([c.strip() for c in COLUMNS.split(",")], row))


def allowed(entries, kids=None):
    """Leave out the entries of hidden categories (and in Kids mode, non-children's ones)."""
    chosen = {k: set(str(i) for i in ids) for k, ids in load_json("hidden.json", {}).items()}
    kids = kids_mode() if kids is None else kids

    def left_out(e):
        if e["kind"] in chosen:
            return e["cat"] in chosen[e["kind"]]
        return bool(ADULT.search(e["catname"] or ""))  # (not chosen yet: the adult-looking ones)
    return [e for e in entries if not left_out(e) and (not kids or KIDS.search(e["catname"] or ""))]


def search(words, limit=60):
    like = "%" + sort_key(words) + "%"
    found = {}
    for kind in KINDS:
        rows = query("SELECT %s FROM items WHERE kind=? AND key LIKE ? ORDER BY key LIMIT ?" % COLUMNS,
                     (kind, like, limit * 2))
        found[kind] = allowed([as_dict(r) for r in rows])[:limit]
    return found


def recent(kind, limit=60, kids=None):
    rows = query("SELECT %s FROM items WHERE kind=? ORDER BY added DESC LIMIT ?" % COLUMNS, (kind, limit * 3))
    return allowed([as_dict(r) for r in rows], kids)[:limit]


def archive_channels():
    rows = query("SELECT %s FROM items WHERE kind='live' AND archive=1 ORDER BY key" % COLUMNS)
    return allowed([as_dict(r) for r in rows])


# --------------------------------------------------------------------------- MediaHub's home rows

def write_home(account, monitor):
    """home.json: ready-made cards for MediaHub's home rows (Continue Watching: IPTV,
    IPTV: New Movies, IPTV: New Series), which the MediaHub Helper shows. Each card
    says whether it's from a children's category, so Kids mode can keep only those."""
    def plugin(**params):
        return "plugin://%s/?%s" % (xtream.ADDON_ID, urllib.parse.urlencode(params))
    cards = {"iptvcontinue": [], "iptvmovies": [], "iptvseries": []}
    for e in continue_watching(20, kids=False):
        if e.get("kind") == "episode":
            label, label2 = e.get("show") or "", "S%d E%d" % (e.get("season", 0), e.get("episode", 0))
            target = plugin(mode="play", kind="episode", id=e["id"], series=e.get("series_id", ""),
                            kids=int(bool(e.get("kids"))), resume=1)
        else:
            label, label2 = e.get("title") or "", ""
            target = plugin(mode="play", kind="movie", id=e["id"], ext=e.get("ext") or "mp4",
                            kids=int(bool(e.get("kids"))), title=e.get("title") or "", resume=1)
        total, pos = e.get("total") or 0, e.get("pos") or 0
        cards["iptvcontinue"].append({
            "Label": label, "Label2": label2, "Title": e.get("title") or label,
            "Landscape": e.get("fanart") or e.get("thumb") or e.get("poster") or "",
            "Poster": e.get("poster") or "", "Percent": str(int(100 * pos / total)) if total and pos else "",
            "Action": "xtream|run|" + target, "Kind": "iptv", "kids": bool(e.get("kids"))})
    for e in recent("vod", 20, kids=False):
        info = (account.peek(action="get_vod_info", vod_id=e["id"]) or {}).get("info") or {} \
            if account.ready() else {}
        if not isinstance(info, dict):
            info = {}
        name = xtream.clean_name(e["name"])
        cards["iptvmovies"].append({
            "Label": name, "Label2": str(e["year"] or ""), "Title": name,
            "Landscape": backdrop(info) or e["icon"] or "", "Poster": e["icon"] or "",
            "Action": "xtream|run|" + plugin(mode="play", kind="movie", id=e["id"], ext=e["ext"] or "mp4",
                                             kids=int(kids_category(e["catname"])), title=name),
            "Kind": "iptv", "kids": kids_category(e["catname"])})
    for e in recent("series", 20, kids=False):
        cards["iptvseries"].append({
            "Label": e["name"], "Label2": str(e["year"] or ""), "Title": e["name"],
            "Landscape": e["fanart"] or e["icon"] or "", "Poster": e["icon"] or "",
            "Action": "xtream|open|" + plugin(mode="seasons", series=e["id"],
                                              kids=int(kids_category(e["catname"]))),
            "Kind": "iptv", "kids": kids_category(e["catname"])})
    save_json("home.json", cards)
    xbmcgui.Window(10000).setProperty("MHX.Home", str(time.time()))  # (the helper refreshes the rows)
