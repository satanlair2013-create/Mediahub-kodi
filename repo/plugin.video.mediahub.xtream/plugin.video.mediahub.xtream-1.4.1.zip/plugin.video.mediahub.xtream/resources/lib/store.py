"""MediaHub IPTV - what's kept between visits.

- progress.json: how far into each film and episode you are (resume, the watched
  tick, Continue Watching). The service notes it while something from here plays.
- hidden.json: the categories left out of the pages. Until you choose, the ones
  that look adult are.
- index.db: every live channel, film and series by name, for Search, Recently
  added and MediaHub's home rows. The service reads the categories one at a time
  once a day (so even a huge service never has to be loaded in one go).
"""
import json
import os
import re
import sqlite3
import threading
import time
import urllib.parse

import xbmc
import xbmcgui

import xtream

KEEP = 300  # progress entries kept (the oldest go)
WATCHED = 0.9  # this far through counts as watched
NOW = "MHX.Now"  # what the add-on started playing: {address: entry}
LIVE = "MHX.Live"  # the live channel it's playing: {id, name, icon, archive, live, over}
OSD = "MHX.OSD"  # "live" (a live channel with catch-up: Start over) or "over" (started over: Back to live)
ADULT = re.compile(r"adult|xxx|porn|\+18|18\+|for adults|erotic", re.I)
KIDS = re.compile(r"kid|child|cartoon|anim|family|famil|disney|junior|jeunesse|enfant|kinder|infantil|bambin|"
                  r"crian|nick|boomerang|baby", re.I)
KINDS = ("live", "vod", "series")
BUILDING = threading.Lock()


def load_json(name, default, shared=False):
    """A file of the signed-in account's (shared: the add-on's own, for all accounts)."""
    try:
        with open(xtream.profile(name) if shared else xtream.data(name), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(name, data, shared=False):
    path = xtream.profile(name) if shared else xtream.data(name)
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def kids_category(name):
    return bool(KIDS.search(name or ""))


def kids_mode():
    """MediaHub's Kids mode: only categories that look like children's ones."""
    return xbmc.getCondVisibility("Skin.HasSetting(MH.KidsMode)")


# --------------------------------------------------------------------------- categories

def hidden(kind, categories=None):
    """The category ids of this kind left out. Until you choose, the adult-looking ones."""
    chosen = load_json("hidden.json", {})
    if kind in chosen:
        return set(str(c) for c in chosen[kind])
    return set(str(c.get("category_id")) for c in categories or [] if ADULT.search(c.get("category_name") or ""))


def set_hidden(kind, ids):
    chosen = load_json("hidden.json", {})
    chosen[kind] = [str(i) for i in ids]
    save_json("hidden.json", chosen)


def visible(kind, categories):
    """The categories to show: not hidden, and in Kids mode only children's ones."""
    gone = hidden(kind, categories)
    kids = kids_mode()
    return [c for c in categories if str(c.get("category_id")) not in gone
            and (not kids or KIDS.search(c.get("category_name") or ""))]


# --------------------------------------------------------------------------- progress

def load():
    return load_json("progress.json", {})


def save(data):
    if len(data) > KEEP:
        data = dict(sorted(data.items(), key=lambda kv: kv[1].get("t", 0))[-KEEP:])
    save_json("progress.json", data)


def key(kind, stream_id):
    return "%s:%s" % (kind, stream_id)


def resume_point(kind, stream_id):
    """(position, total, watched)."""
    p = load().get(key(kind, stream_id)) or {}
    return p.get("pos", 0), p.get("total", 0), bool(p.get("watched"))


def bare(address):
    return address.split("|", 1)[0]


def live_state(path):
    """Tell MediaHub's player bar what it can offer for the channel playing."""
    home = xbmcgui.Window(10000)
    try:
        live = json.loads(home.getProperty(LIVE) or "{}")
    except ValueError:
        live = {}
    if path and live.get("over") and bare(path) == bare(live["over"]):
        home.setProperty(OSD, "over")
    elif path and live.get("archive") and bare(path) == bare(live.get("live") or ""):
        home.setProperty(OSD, "live")
    else:
        home.clearProperty(OSD)


# --------------------------------------------------------------------------- accounts

def accounts():
    """[{key, server, username, password}] you've signed in with (accounts.json)."""
    return [a for a in load_json("accounts.json", {}, shared=True).get("accounts") or [] if isinstance(a, dict)]


def remember_account(server, username, password):
    found = [a for a in accounts() if a.get("key") != xtream.account_key(server, username)]
    found.append({"key": xtream.account_key(server, username), "server": server, "username": username,
                  "password": password})
    save_json("accounts.json", {"accounts": found}, shared=True)


def forget_account(key):
    import shutil
    save_json("accounts.json", {"accounts": [a for a in accounts() if a.get("key") != key]}, shared=True)
    shutil.rmtree(xtream.profile("acc-%s/" % key), ignore_errors=True)


def account_label(a):
    host = re.sub(r"^https?://", "", a.get("server") or "")
    return "%s  (%s)" % (a.get("username") or "", host)


# --------------------------------------------------------------------------- favourite channels

def favourites():
    """[{id, name, icon, archive, kids}] in the order added."""
    return [f for f in load_json("favourites.json", []) if isinstance(f, dict) and f.get("id")]


def is_favourite(stream_id):
    return any(f["id"] == str(stream_id) for f in favourites())


def set_favourite(channel, on):
    found = [f for f in favourites() if f["id"] != str(channel["id"])]
    if on:
        found.append({"id": str(channel["id"]), "name": channel.get("name") or "", "icon": channel.get("icon") or "",
                      "archive": bool(channel.get("archive")), "kids": bool(channel.get("kids"))})
    save_json("favourites.json", found)
    xbmcgui.Window(10000).setProperty("MHX.Changed", str(time.time()))


class Tracker:
    """Notes how far into a film or episode from this add-on you are while it plays."""

    def __init__(self):
        self.next = 0.0
        self.path = None
        self.entry = None
        self.pos = self.total = self.furthest = 0.0
        self.saved = 0.0

    def tick(self):
        now = time.time()
        if now < self.next:
            return
        self.next = now + 2.0
        path = xbmc.getInfoLabel("Player.Filenameandpath") if xbmc.getCondVisibility("Player.HasVideo") else ""
        if path != self.path:
            self.finish()
            self.path = path
            live_state(path)
            if path:
                try:
                    playing = json.loads(xbmcgui.Window(10000).getProperty(NOW) or "{}")
                except ValueError:
                    playing = {}
                self.entry = next((e for a, e in playing.items() if bare(a) == bare(path)), None)
        if not self.entry:
            return
        try:
            player = xbmc.Player()
            self.pos, self.total = player.getTime(), player.getTotalTime()
        except RuntimeError:
            return
        if self.total > 0:
            self.furthest = max(self.furthest, self.pos / self.total)
        if now - self.saved > 15:
            self.record()
            self.saved = now

    def record(self):
        e = self.entry
        if not e or e.get("kind") not in ("movie", "episode") or self.total <= 0 or self.pos < 5:
            return
        data = load()
        watched = self.furthest >= WATCHED
        data[key(e["kind"], e["id"])] = dict(e, pos=0 if watched else int(self.pos), total=int(self.total),
                                            watched=watched, t=time.time())
        save(data)
        xbmcgui.Window(10000).setProperty("MHX.Changed", str(time.time()))  # (MediaHub's home row)

    def finish(self):
        if self.entry:
            self.record()
        self.entry = None
        self.pos = self.total = self.furthest = 0.0


def continue_watching(limit=30, kids=None):
    """What you're part-way through, and the next episode of a series whose last
    episode you finished: entries, most recent first. kids: only children's
    (None: when MediaHub's Kids mode is on)."""
    found, series = [], set()
    kids = kids_mode() if kids is None else kids
    for _, p in sorted(load().items(), key=lambda kv: -kv[1].get("t", 0)):
        if kids and not p.get("kids"):
            continue
        if p.get("kind") == "episode":
            if p.get("series_id") in series:
                continue
            series.add(p.get("series_id"))
        if p.get("watched"):
            nxt = p.get("next")
            if p.get("kind") != "episode" or not nxt:
                continue
            found.append(dict(nxt, pos=0, total=0, new=bool(p.get("new"))))
        elif p.get("pos"):
            found.append(p)
        if len(found) >= limit:
            break
    return found


# --------------------------------------------------------------------------- recent channels

def recent_channels():
    """The live channels you watched, most recent first (recent.json)."""
    return [c for c in load_json("recent.json", []) if isinstance(c, dict) and c.get("id")]


def note_channel(channel):
    """A channel started playing: to the front of the recent ones. Returns the one
    watched before it (for Last channel), or None."""
    found = recent_channels()
    before = next((c for c in found if c["id"] != str(channel["id"])), None)
    found = [dict(channel, id=str(channel["id"]))] + [c for c in found if c["id"] != str(channel["id"])]
    save_json("recent.json", found[:20])
    return before


def channel_by_number(number):
    rows = query("SELECT %s FROM items WHERE kind='live' AND num=? LIMIT 1" % COLUMNS, (int(number),))
    found = allowed([as_dict(r) for r in rows])
    return found[0] if found else None


# --------------------------------------------------------------------------- reminders

def reminders():
    """Programmes to be reminded of: [{id, name, icon, archive, title, start, stop}]."""
    return sorted([r for r in load_json("reminders.json", []) if isinstance(r, dict) and r.get("start")],
                  key=lambda r: r["start"])


def has_reminder(stream_id, start):
    return any(r["id"] == str(stream_id) and r["start"] == start for r in reminders())


def set_reminder(entry, on):
    found = [r for r in reminders() if not (r["id"] == str(entry["id"]) and r["start"] == entry["start"])]
    if on:
        found.append(dict(entry, id=str(entry["id"])))
    save_json("reminders.json", [r for r in found if r.get("stop", r["start"]) > time.time()])


# --------------------------------------------------------------------------- recordings

RECORD_EARLY = 60    # seconds before a programme starts that recording begins ...
RECORD_LATE = 3 * 60  # ... and after it ends that it stops (guides are rarely exact)
RECORDINGS_LOCK = threading.Lock()


def recordings():
    """Programmes to record or recorded: [{id, name, icon, title, plot, start, stop, start_text,
    archive, state (waiting / recording / done / failed), file}], newest first."""
    found = [r for r in load_json("recordings.json", []) if isinstance(r, dict) and r.get("start")]
    return sorted(found, key=lambda r: -r["start"])


def recording(stream_id, start):
    return next((r for r in recordings() if r["id"] == str(stream_id) and r["start"] == int(start)), None)


def save_recording(entry, remove=False):
    with RECORDINGS_LOCK:
        found = [r for r in recordings() if not (r["id"] == str(entry["id"]) and r["start"] == int(entry["start"]))]
        if not remove:
            found.append(dict(entry, id=str(entry["id"]), start=int(entry["start"])))
        save_json("recordings.json", found)


def recordings_folder():
    """MediaHub's downloads folder (so recordings are in Downloads too), or the add-on's own."""
    folder = xbmc.getInfoLabel("Skin.String(MH.DownloadFolder)")
    if not folder and xbmc.getCondVisibility("System.HasAddon(script.mediahub.helper)"):
        folder = "special://profile/addon_data/script.mediahub.helper/downloads/"
    if not folder:
        folder = "special://profile/addon_data/%s/recordings/" % xtream.ADDON_ID
    return folder if folder.endswith(("/", "\\")) else folder + "/"


def recording_name(r):
    when = time.strftime("%Y-%m-%d %H.%M", time.localtime(r["start"]))
    name = "%s - %s (%s)" % (r.get("name") or "", r.get("title") or "", when)
    return re.sub(r'[\\/:*?"<>|]+', "", name).strip() + ".ts"


# --------------------------------------------------------------------------- series recordings

def title_key(title):
    return re.sub(r"[^a-z0-9]+", "", (title or "").lower())


def plot_key(plot):
    """How a repeat is known: the same description as an episode already recorded."""
    return re.sub(r"[^a-z0-9]+", "", (plot or "").lower())[:120]


def series_rules():
    """Record every episode: [{id (channel), name, icon, archive, title, t}] (series.json)."""
    return [r for r in load_json("series.json", []) if isinstance(r, dict) and r.get("id") and r.get("title")]


def has_series(stream_id, title):
    return any(r["id"] == str(stream_id) and title_key(r["title"]) == title_key(title) for r in series_rules())


def set_series(entry, on):
    found = [r for r in series_rules()
             if not (r["id"] == str(entry["id"]) and title_key(r["title"]) == title_key(entry["title"]))]
    if on:
        found.append(dict(entry, id=str(entry["id"]), t=time.time()))
    else:  # (and the episodes it had lined up that haven't started)
        for r in recordings():
            if r.get("series") and r["id"] == str(entry["id"]) and title_key(r.get("title")) == title_key(
                    entry["title"]) and r.get("state") == "waiting" and r["start"] > time.time():
                save_recording(r, remove=True)
    save_json("series.json", found)


def schedule_series(account, only=None):
    """Line up the next episodes of each Record every episode, from the channel's guide:
    not a repeat of one recorded or lined up already (the same description), nor one over.
    Returns how many were added."""
    now = time.time()
    added = 0
    recs = recordings()
    seen = {(title_key(r.get("title")), plot_key(r.get("plot"))) for r in recs
            if plot_key(r.get("plot")) and r.get("state") != "failed"}
    for rule in series_rules():
        if only and not (rule["id"] == str(only["id"]) and title_key(rule["title"]) == title_key(only["title"])):
            continue
        try:
            progs = account.channel_epg(rule["id"])
        except xtream.Error:
            continue
        key = title_key(rule["title"])
        for p in progs:
            if title_key(p["title"]) != key or p["stop"] <= now or recording(rule["id"], p["start"]):
                continue
            mark = (key, plot_key(p.get("plot")))
            if mark[1] and mark in seen:
                continue  # (a repeat)
            save_recording({"id": rule["id"], "name": rule.get("name", ""), "icon": rule.get("icon", ""),
                            "title": p["title"], "plot": (p.get("plot") or "")[:300], "start": p["start"],
                            "stop": p["stop"], "start_text": p.get("start_text", ""),
                            "archive": bool(rule.get("archive")), "state": "waiting", "file": "", "series": 1})
            seen.add(mark)
            added += 1
    return added


# --------------------------------------------------------------------------- My List

def my_list():
    """Films and series you've added: [{kind (vod or series), id, name, icon, fanart,
    ext, year, kids, t}], newest first (mylist.json)."""
    found = [m for m in load_json("mylist.json", []) if isinstance(m, dict) and m.get("id")]
    return sorted(found, key=lambda m: -m.get("t", 0))


def in_my_list(kind, item_id):
    return any(m["kind"] == kind and m["id"] == str(item_id) for m in my_list())


def set_my_list(entry, on):
    found = [m for m in my_list() if not (m["kind"] == entry["kind"] and m["id"] == str(entry["id"]))]
    if on:
        found.append(dict(entry, id=str(entry["id"]), t=time.time()))
    save_json("mylist.json", found)
    xbmcgui.Window(10000).setProperty("MHX.Changed", str(time.time()))


# --------------------------------------------------------------------------- series

def series_art(s):
    cover = s.get("cover") or s.get("icon") or ""
    backdrop = s.get("backdrop_path")
    backdrop = backdrop[0] if isinstance(backdrop, list) and backdrop else backdrop if isinstance(backdrop, str) else ""
    return {"poster": cover, "thumb": cover, "icon": cover or "DefaultTVShows.png", "fanart": backdrop or ""}


def episodes_of(data):
    """{season: [episodes]} (numbers), from get_series_info."""
    raw = data.get("episodes") or {}
    if isinstance(raw, list):  # (some panels send a list of lists)
        raw = {str(i + 1): eps for i, eps in enumerate(raw)}
    found = {}
    for season, eps in raw.items():
        for e in eps or []:
            found.setdefault(xtream.number(e.get("season"), xtream.number(season)), []).append(e)
    for eps in found.values():
        eps.sort(key=lambda e: xtream.number(e.get("episode_num")))
    return found


def episode_entry(series_id, info, e, kids):
    ei = e.get("info") or {}
    if not isinstance(ei, dict):
        ei = {}
    art = series_art(info)
    show = info.get("name") or ""
    title = e.get("title") or ""
    # (panels often name an episode "Show - S01E02 - Title": keep the title part)
    if " - " in title and show and title.startswith(show):
        title = title.rsplit(" - ", 1)[-1]
    return {"kind": "episode", "id": str(e.get("id")), "ext": e.get("container_extension") or "mp4",
            "series_id": str(series_id), "show": show, "season": xtream.number(e.get("season")),
            "episode": xtream.number(e.get("episode_num")), "title": title,
            "plot": ei.get("plot") or "", "thumb": ei.get("movie_image") or "", "poster": art["poster"],
            "fanart": art["fanart"], "duration": xtream.number(ei.get("duration_secs")), "kids": bool(kids)}


def latest_by_series(data=None):
    """{series_id: the latest progress entry of an episode of it}."""
    latest = {}
    for p in (data if data is not None else load()).values():
        sid = p.get("series_id") if p.get("kind") == "episode" else None
        if sid and (sid not in latest or p.get("t", 0) > latest[sid].get("t", 0)):
            latest[sid] = p
    return latest


def new_series():
    """The series you follow that have new episodes you haven't started."""
    return {sid for sid, p in latest_by_series().items() if p.get("new")}


def check_new_episodes(account, monitor):
    """After the daily read of the list: a series you've watched whose list changed
    since (the service's last_modified) and whose last episode you finished gets its
    next episode in Continue Watching, marked NEW EPISODES."""
    data = load()
    latest = latest_by_series(data)
    if not latest:
        return
    ids = list(latest)
    modified = dict(query("SELECT id, added FROM items WHERE kind='series' AND id IN (%s)" % ",".join("?" * len(ids)),
                          ids))
    changed = False
    for sid, p in latest.items():
        if monitor.abortRequested():
            return
        now = modified.get(sid) or 0
        if not now or now <= (p.get("series_modified") or 0):
            continue
        p["series_modified"] = now
        changed = True
        if not p.get("watched") or p.get("next"):
            continue  # (still in Continue Watching as it is)
        try:
            info = account.series_info(sid, max_age=xtream.HOUR, timeout=8)
        except xtream.Error:
            continue
        ordered = [e for _, eps in sorted(episodes_of(info).items()) for e in eps]
        watched = {v.get("id") for v in data.values() if v.get("series_id") == sid and v.get("watched")}
        at = next((n for n, e in enumerate(ordered) if str(e.get("id")) == p.get("id")), None)
        nxt = next((e for e in ordered[at + 1:] if str(e.get("id")) not in watched), None) if at is not None else None
        if nxt:
            p["next"] = episode_entry(sid, info.get("info") or {}, nxt, p.get("kids"))
            p["new"] = True
            p["t"] = time.time()  # (to the front of Continue Watching)
        monitor.waitForAbort(0.2)
    if changed:
        save(data)


# --------------------------------------------------------------------------- the index

def index_path():
    return xtream.data("index.db")


def connect(path=None):
    con = sqlite3.connect(path or index_path(), timeout=10)
    con.execute("CREATE TABLE IF NOT EXISTS items (kind TEXT, id TEXT, name TEXT, key TEXT, icon TEXT, cat TEXT,"
                " catname TEXT, added INTEGER, rating REAL, year INTEGER, ext TEXT, archive INTEGER, fanart TEXT,"
                " num INTEGER, PRIMARY KEY (kind, id))")
    con.execute("CREATE TABLE IF NOT EXISTS meta (name TEXT PRIMARY KEY, value TEXT)")
    columns = [c[1] for c in con.execute("PRAGMA table_info(items)")]
    for column, kind in (("fanart", "TEXT"), ("num", "INTEGER")):  # (an index from an older version)
        if column not in columns:
            con.execute("ALTER TABLE items ADD COLUMN %s %s" % (column, kind))
    return con


def sort_key(name):
    name = re.sub(r"^\s*(?:\|[A-Z]{2,4}\||\[[A-Z]{2,4}\]|[A-Z]{2,4}\s+-\s+|[A-Z]{2,4}\s*\|)\s*", "", name or "")
    name = re.sub(r"^(the|a|an)\s+", "", name.strip().lower())
    return re.sub(r"[^\w]+", " ", name).strip()


def backdrop(entry):
    b = entry.get("backdrop_path")
    return (b[0] if isinstance(b, list) and b else b if isinstance(b, str) else "") or ""


def built():
    """When the index was last built (0: never)."""
    if not os.path.exists(index_path()):
        return 0
    con = connect()
    try:
        row = con.execute("SELECT value FROM meta WHERE name='built'").fetchone()
        return float(row[0]) if row else 0
    finally:
        con.close()


def build(account, monitor, progress=None, timeout=8):
    """Read every category of every kind into a new index, then swap it in. progress:
    a function(percent, text) (the foreground build); False if it stopped part-way."""
    if not account.ready() or not BUILDING.acquire(blocking=False):
        return False
    temp = index_path() + ".new"
    try:
        if os.path.exists(temp):
            os.remove(temp)
        con = connect(temp)
        try:
            jobs = []
            for kind in KINDS:
                try:
                    jobs += [(kind, c) for c in account.categories(kind, timeout=timeout, monitor=monitor)]
                except xtream.Error:
                    return False
            for n, (kind, cat) in enumerate(jobs):
                if monitor.abortRequested() or (progress and progress(100 * n // max(1, len(jobs)),
                                                                        cat.get("category_name") or "") is False):
                    return False
                cid = str(cat.get("category_id"))
                try:
                    entries = account.streams(kind, cid, max_age=xtream.HOUR, timeout=timeout,
                                              monitor=monitor)
                except xtream.Error:
                    continue
                rows = []
                for s in entries:
                    sid = s.get("series_id") if kind == "series" else s.get("stream_id")
                    if sid in (None, ""):
                        continue
                    name = s.get("name") or ""
                    rows.append((kind, str(sid), name, sort_key(name),
                                 s.get("cover") if kind == "series" else s.get("stream_icon") or "",
                                 cid, cat.get("category_name") or "",
                                 xtream.number(s.get("last_modified") if kind == "series" else s.get("added")),
                                 xtream.rating(s.get("rating")), xtream.year_of(s),
                                 s.get("container_extension") or "", 1 if xtream.number(s.get("tv_archive")) else 0,
                                 backdrop(s), xtream.number(s.get("num"))))
                con.executemany("INSERT OR REPLACE INTO items VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
                con.commit()
                monitor.waitForAbort(0.2)
            con.execute("CREATE INDEX IF NOT EXISTS keys ON items (key)")
            con.execute("CREATE INDEX IF NOT EXISTS added ON items (kind, added)")
            con.execute("INSERT OR REPLACE INTO meta VALUES ('built', ?)", (str(time.time()),))
            con.commit()
        finally:
            con.close()
        os.replace(temp, index_path())
        return True
    finally:
        try:
            os.remove(temp)
        except OSError:
            pass
        BUILDING.release()


def query(sql, params=()):
    if not os.path.exists(index_path()):
        return []
    con = connect()
    try:
        return con.execute(sql, params).fetchall()
    finally:
        con.close()


COLUMNS = "kind, id, name, icon, cat, catname, added, rating, year, ext, archive, fanart, num"


def as_dict(row):
    return dict(zip([c.strip() for c in COLUMNS.split(",")], row))


def allowed(entries, kids=None):
    """Leave out the entries of hidden categories (and in Kids mode, non-children's ones)."""
    chosen = {k: set(str(i) for i in ids) for k, ids in load_json("hidden.json", {}).items()}
    kids = kids_mode() if kids is None else kids

    def left_out(e):
        if e["kind"] in chosen:
            return e["cat"] in chosen[e["kind"]]
        return bool(ADULT.search(e["catname"] or ""))  # (not chosen yet: the adult-looking ones)
    return [e for e in entries if not left_out(e) and (not kids or KIDS.search(e["catname"] or ""))]


def search(words, limit=60):
    like = "%" + sort_key(words) + "%"
    found = {}
    for kind in KINDS:
        rows = query("SELECT %s FROM items WHERE kind=? AND key LIKE ? ORDER BY key LIMIT ?" % COLUMNS,
                     (kind, like, limit * 2))
        found[kind] = allowed([as_dict(r) for r in rows])[:limit]
    return found


def recent(kind, limit=60, kids=None):
    rows = query("SELECT %s FROM items WHERE kind=? ORDER BY added DESC LIMIT ?" % COLUMNS, (kind, limit * 3))
    return allowed([as_dict(r) for r in rows], kids)[:limit]


def live_channels():
    """Every channel, in channel-number order."""
    rows = query("SELECT %s FROM items WHERE kind='live' ORDER BY num, key" % COLUMNS)
    return allowed([as_dict(r) for r in rows])


def archive_channels():
    rows = query("SELECT %s FROM items WHERE kind='live' AND archive=1 ORDER BY key" % COLUMNS)
    return allowed([as_dict(r) for r in rows])


# --------------------------------------------------------------------------- MediaHub's home rows

def write_home(account, monitor):
    """home.json: ready-made cards for MediaHub's home rows (Continue Watching: IPTV,
    IPTV: New Movies, IPTV: New Series), which the MediaHub Helper shows. Each card
    says whether it's from a children's category, so Kids mode can keep only those."""
    def plugin(**params):
        return "plugin://%s/?%s" % (xtream.ADDON_ID, urllib.parse.urlencode(params))
    cards = {"iptvcontinue": [], "iptvmovies": [], "iptvseries": [], "iptvchannels": [], "iptvmylist": []}
    for f in favourites():
        try:
            progs = account.short_epg(f["id"], 4, timeout=4) if account.ready() else []
        except xtream.Error:
            progs = []
        cards["iptvchannels"].append(dict(f, programmes=[{"title": p["title"], "start": p["start"], "stop": p["stop"]}
                                                         for p in progs],
                                          action="xtream|run|" + plugin(mode="play", kind="live", id=f["id"],
                                                                        name=f["name"], icon=f["icon"],
                                                                        archive=int(f["archive"]))))
        if monitor.abortRequested():
            return
    for e in continue_watching(20, kids=False):
        if e.get("kind") == "episode":
            label, label2 = e.get("show") or "", "S%d E%d" % (e.get("season", 0), e.get("episode", 0))
            target = plugin(mode="play", kind="episode", id=e["id"], series=e.get("series_id", ""),
                            kids=int(bool(e.get("kids"))), resume=1)
        else:
            label, label2 = e.get("title") or "", ""
            target = plugin(mode="play", kind="movie", id=e["id"], ext=e.get("ext") or "mp4",
                            kids=int(bool(e.get("kids"))), title=e.get("title") or "", resume=1)
        total, pos = e.get("total") or 0, e.get("pos") or 0
        cards["iptvcontinue"].append({
            "Label": label, "Label2": label2, "Title": e.get("title") or label,
            "Landscape": e.get("fanart") or e.get("thumb") or e.get("poster") or "",
            "Poster": e.get("poster") or "", "Percent": str(int(100 * pos / total)) if total and pos else "",
            "Action": "xtream|run|" + target, "Kind": "iptv", "New": "2" if e.get("new") else "",
            "kids": bool(e.get("kids")), "T": int(e.get("t") or 0)})  # (T: for MediaHub's Continue anywhere)
    for e in recent("vod", 20, kids=False):
        info = (account.peek(action="get_vod_info", vod_id=e["id"]) or {}).get("info") or {} \
            if account.ready() else {}
        if not isinstance(info, dict):
            info = {}
        name = xtream.clean_name(e["name"])
        cards["iptvmovies"].append({
            "Label": name, "Label2": str(e["year"] or ""), "Title": name,
            "Landscape": backdrop(info) or e["icon"] or "", "Poster": e["icon"] or "",
            "Action": "xtream|run|" + plugin(mode="play", kind="movie", id=e["id"], ext=e["ext"] or "mp4",
                                             kids=int(kids_category(e["catname"])), title=name),
            "Kind": "iptv", "kids": kids_category(e["catname"])})
    for m in my_list()[:20]:
        if m["kind"] == "series":
            action = "xtream|open|" + plugin(mode="seasons", series=m["id"], kids=int(bool(m.get("kids"))))
        else:
            action = "xtream|run|" + plugin(mode="play", kind="movie", id=m["id"], ext=m.get("ext") or "mp4",
                                            kids=int(bool(m.get("kids"))), title=m.get("name") or "")
        cards["iptvmylist"].append({
            "Label": m.get("name") or "", "Label2": str(m.get("year") or ""), "Title": m.get("name") or "",
            "Landscape": m.get("fanart") or m.get("icon") or "", "Poster": m.get("icon") or "",
            "Action": action, "Kind": "iptv", "kids": bool(m.get("kids"))})
    fresh = new_series()
    for e in recent("series", 20, kids=False):
        cards["iptvseries"].append({"New": "2" if e["id"] in fresh else "",
            "Label": e["name"], "Label2": str(e["year"] or ""), "Title": e["name"],
            "Landscape": e["fanart"] or e["icon"] or "", "Poster": e["icon"] or "",
            "Action": "xtream|open|" + plugin(mode="seasons", series=e["id"],
                                              kids=int(kids_category(e["catname"]))),
            "Kind": "iptv", "kids": kids_category(e["catname"])})
    save_json("home.json", cards, shared=True)  # (the MediaHub Helper reads it from here)
    xbmcgui.Window(10000).setProperty("MHX.Home", str(time.time()))  # (the helper refreshes the rows)
