"""MediaHub IPTV - an Xtream Codes service in Kodi.

Live TV (by category, with what's on now and next), Catch-up, Movies and Series
(by category, with the service's own posters and plots), Continue Watching,
Recently added, Search, the account, and help to use the same service in Kodi's
own Live TV. Films and episodes resume where you stopped, and an episode queues
the next ones, so the Up Next card offers them.
"""
import json
import os
import sys
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import store  # noqa: E402
import xtream  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name")
PAGE = 200
EPG_CHANNELS = 150  # channels in a list that get now / next
EPG_BUDGET = 6.0  # seconds a channel list may wait for now / next
ZAP_FOCUS = 3  # the Channels panel's highlighted row (Custom_1132_IPTVChannels.xml)
ZAP_ROWS = 9  # rows the panel shows at once: a shorter list would show channels twice


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def kodi(string_id):
    return xbmc.getLocalizedString(string_id)


def url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)


def notify(message, error=False):
    xbmcgui.Dialog().notification(NAME, message, xbmcgui.NOTIFICATION_WARNING if error else
                                  xbmcgui.NOTIFICATION_INFO, 4000, False)


def folder(label, target, icon="DefaultFolder.png", label2="", art=None, plot="", menu=None):
    item = xbmcgui.ListItem(label, label2)
    item.setArt(dict({"icon": icon, "thumb": icon}, **(art or {})))
    if plot:
        item.getVideoInfoTag().setPlot(plot)
    if menu:
        item.addContextMenuItems(menu)
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=True)


def action(label, target, icon="DefaultIconInfo.png", label2=""):
    """An item that does something (a dialog) rather than opening a page."""
    item = xbmcgui.ListItem(label, label2)
    item.setArt({"icon": icon, "thumb": icon})
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=False)


def end(content="", title="", sort=False, cache=True):
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.setPluginCategory(HANDLE, title or NAME)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED, labelMask="%L")
    if sort:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)


def account():
    return xtream.Account()


def careful(work):
    """Run a page; if the service can't be reached, say so instead of failing."""
    try:
        work()
    except xtream.Error as exc:
        xbmc.log("MediaHub IPTV: %s" % exc, xbmc.LOGWARNING)
        notify(text(30017), True)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def time_label(seconds):
    seconds = int(seconds)
    return "%d:%02d:%02d" % (seconds // 3600, seconds // 60 % 60, seconds % 60) if seconds >= 3600 else \
        "%d:%02d" % (seconds // 60, seconds % 60)


from plugin_text import clock  # noqa: E402


# --------------------------------------------------------------------------- root

def root():
    acc = account()
    if not acc.ready():
        action(text(30011), url(mode="signin"), "DefaultUser.png")
        action(text(30039), url(mode="settings"), "DefaultAddonProgram.png")
        return end()
    action(text(30072), url(mode="guidewindow"), "DefaultTVShows.png")
    folder(text(30005), url(mode="continue"), "DefaultInProgressShows.png")
    if store.favourites():
        folder(text(30055), url(mode="favourites"), "DefaultFavourites.png")
    if store.recent_channels():
        folder(text(30063), url(mode="recentchannels"), "DefaultRecentlyAddedEpisodes.png")
    if store.my_list():
        folder(text(30064), url(mode="mylistpage"), "DefaultPlaylist.png")
    if store.reminders():
        folder(text(30066), url(mode="reminders"), "DefaultIconInfo.png")
    folder(text(30001), url(mode="categories", kind="live"), "DefaultAddonPVRClient.png")
    folder(text(30002), url(mode="categories", kind="vod"), "DefaultMovies.png")
    folder(text(30003), url(mode="categories", kind="series"), "DefaultTVShows.png")
    folder(text(30004), url(mode="catchup"), "DefaultRecentlyAddedEpisodes.png")
    folder(text(30006), url(mode="recent", kind="vod"), "DefaultRecentlyAddedMovies.png")
    folder(text(30007), url(mode="recent", kind="series"), "DefaultRecentlyAddedEpisodes.png")
    folder(kodi(137), url(mode="search"), "DefaultAddonsSearch.png")
    action(text(30065), url(mode="gotonumber"), "DefaultAddonPVRClient.png")
    action(text(30009), url(mode="account"), "DefaultUser.png", text(30042) % acc.username)
    action(text(30010), url(mode="livetv"), "DefaultAddonPVRClient.png")
    action(text(30039), url(mode="settings"), "DefaultAddonProgram.png")
    end(cache=False)


def signin():
    """Ask for the server, username and password, check them, and keep them."""
    dialog = xbmcgui.Dialog()
    server = dialog.input(text(30012), ADDON.getSetting("server") or "http://")
    if not server:
        return
    username = dialog.input(text(30013), ADDON.getSetting("username"))
    if not username:
        return
    password = dialog.input(text(30014), option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not password:
        return
    acc = xtream.Account(server, username, password)
    busy = xbmcgui.DialogProgress()
    busy.create(NAME, text(30011))
    try:
        acc.login()
    except xtream.Error as exc:
        busy.close()
        dialog.ok(NAME, text(30016) if str(exc) == "login" else text(30017))
        return
    busy.close()
    use_account(acc.server, acc.username, acc.password)
    notify(text(30015))
    xbmcgui.Window(10000).setProperty("MHX.Build", str(time.time()))  # (the service reads the list)
    xbmc.executebuiltin("Container.Refresh")


def use_account(server, username, password):
    """Sign in to this account (it's remembered for Switch account)."""
    ADDON.setSetting("server", server)
    ADDON.setSetting("username", username)
    ADDON.setSetting("password", password)
    store.remember_account(server, username, password)
    home = xbmcgui.Window(10000)
    home.setProperty("MHX.Changed", str(time.time()))  # (MediaHub's rows: this account's)
    if not store.built():
        home.setProperty("MHX.Build", str(time.time()))


def switch_account():
    """Pick another account you've signed in with, or add one."""
    current = xtream.account_key()
    others = [a for a in store.accounts() if a.get("key") != current]
    pick = xbmcgui.Dialog().select(text(30060), [store.account_label(a) for a in others] + [text(30061)])
    if pick < 0:
        return
    if pick == len(others):
        return signin()
    a = others[pick]
    use_account(a["server"], a["username"], a["password"])
    notify(text(30062) % store.account_label(a))
    xbmc.executebuiltin("Container.Update(%s,replace)" % BASE)


def signout():
    """Sign out of this account: its progress, lists and settings on this device go."""
    if not xbmcgui.Dialog().yesno(NAME, text(30043)):
        return
    store.forget_account(xtream.account_key())
    others = store.accounts()
    if others:
        use_account(others[0]["server"], others[0]["username"], others[0]["password"])
    else:
        for setting in ("username", "password"):
            ADDON.setSetting(setting, "")
        xbmcgui.Window(10000).setProperty("MHX.Changed", str(time.time()))
    xbmc.executebuiltin("Container.Update(%s,replace)" % BASE)


def show_account():
    try:
        data = account().login()
    except xtream.Error as exc:
        xbmcgui.Dialog().ok(NAME, text(30016) if str(exc) == "login" else text(30017))
        return
    info = data.get("user_info") or {}
    expiry = xtream.number(info.get("exp_date"))
    lines = [text(30042) % info.get("username", ""),
             text(30028) % info.get("status", ""),
             text(30029) % (time.strftime(xbmc.getRegion("datelong"), time.localtime(expiry)) if expiry
                            else text(30030)),
             text(30031) % (xtream.number(info.get("active_cons")), xtream.number(info.get("max_connections")))]
    if str(info.get("is_trial")) == "1":
        lines.append(text(30032))
    acc = account()
    store.remember_account(acc.server, acc.username, acc.password)
    choice = xbmcgui.Dialog().select(text(30009), lines + [text(30060), text(30040)])
    if choice == len(lines):
        switch_account()
    elif choice == len(lines) + 1:
        signout()


def live_tv_help():
    """How to have this service in Kodi's own Live TV (the guide, reminders, recording):
    IPTV Simple Client with the playlist and guide addresses."""
    acc = account()
    body = "%s[CR][CR]%s[CR][B]%s[/B][CR][CR]%s[CR][B]%s[/B][CR][CR]%s" % (
        text(30033), text(30034), acc.playlist_url(), text(30035), acc.epg_url(), text(30036))
    xbmcgui.Dialog().textviewer(text(30010), body)
    installed = xbmc.getCondVisibility("System.HasAddon(pvr.iptvsimple)")
    if xbmcgui.Dialog().yesno(text(30010), text(30044), nolabel=kodi(222),
                              yeslabel=text(30037) if installed else text(30038)):
        xbmc.executebuiltin("Addon.OpenSettings(pvr.iptvsimple)" if installed else "InstallAddon(pvr.iptvsimple)")


# --------------------------------------------------------------------------- categories

KIND_TITLE = {"live": 30001, "vod": 30002, "series": 30003}


def categories(kind):
    cats = account().categories(kind)
    shown = store.visible(kind, cats)
    for c in shown:
        folder(c.get("category_name") or "?", url(mode="list", kind=kind, cat=c.get("category_id"),
                                                  name=c.get("category_name") or ""),
               {"live": "DefaultAddonPVRClient.png", "vod": "DefaultMovies.png",
                "series": "DefaultTVShows.png"}[kind])
    gone = len(cats) - len(store.visible(kind, cats)) if not store.kids_mode() else 0
    if not store.kids_mode():
        action(text(30018), url(mode="hide", kind=kind), "DefaultAddonsRepo.png", text(30019) % gone if gone else "")
    end("files", text(KIND_TITLE[kind]))


def choose_hidden(kind):
    """Pick the categories to leave out. With a MediaHub Kids mode PIN set, it's asked first."""
    pin = xbmc.getInfoLabel("Skin.String(MH.KidsPin)")
    if pin and xbmcgui.Dialog().numeric(0, text(30020), "", True) != pin:
        notify(kodi(12342), True)  # "Incorrect password"
        return
    cats = account().categories(kind)
    if not cats:
        return
    gone = store.hidden(kind, cats)
    pick = xbmcgui.Dialog().multiselect(text(30018), [c.get("category_name") or "?" for c in cats],
                                        preselect=[i for i, c in enumerate(cats) if str(c.get("category_id")) in gone])
    if pick is None:
        return
    store.set_hidden(kind, [cats[i].get("category_id") for i in pick])
    xbmcgui.Window(10000).setProperty("MHX.Changed", str(time.time()))  # (MediaHub's home rows)
    xbmc.executebuiltin("Container.Refresh")


def in_kids_category(name):
    return bool(store.KIDS.search(name or ""))


def entry_list(kind, cat, name, page):
    acc = account()
    cats = store.visible(kind, acc.categories(kind))
    if not any(str(c.get("category_id")) == str(cat) for c in cats):
        return end()  # (hidden, or not for Kids mode)
    entries = acc.streams(kind, cat)
    first = page * PAGE
    shown = entries[first:first + PAGE]
    kids = in_kids_category(name)
    if kind == "live":
        live_items(acc, shown, kids, "cat:%s" % cat)
        content = "videos"
    elif kind == "vod":
        movie_items(acc, shown, kids)
        content = "movies"
    else:
        series_items(shown, kids)
        content = "tvshows"
    if len(entries) > first + PAGE:
        folder("%s (%d)" % (kodi(33078), page + 2), url(mode="list", kind=kind, cat=cat, name=name, page=page + 1),
               "DefaultFolder.png")  # "Next page"
    end(content, name)


# --------------------------------------------------------------------------- live

def now_next(acc, channels):
    """{stream_id: [programmes]} for the channels, fetched side by side, as many as
    come back within EPG_BUDGET seconds."""
    if ADDON.getSetting("live_epg") == "false" or not channels:
        return {}
    from concurrent.futures import ThreadPoolExecutor, wait
    ids = [str(c.get("stream_id")) for c in channels[:EPG_CHANNELS] if c.get("epg_channel_id") or c.get("stream_id")]
    pool = ThreadPoolExecutor(max_workers=8)
    jobs = {pool.submit(acc.short_epg, i, 3, 5): i for i in ids}
    done, _ = wait(jobs, timeout=EPG_BUDGET)
    pool.shutdown(wait=False, cancel_futures=True)
    found = {}
    for job in done:
        try:
            found[jobs[job]] = job.result()
        except Exception:
            pass
    return found


def programme_text(progs, later=False):
    now = time.time()
    current = next((p for p in progs if p["start"] <= now < p["stop"]), progs[0] if progs else None)
    following = next((p for p in progs if current and p["start"] >= current["stop"]), None)
    if later:
        after = next((p for p in progs if following and p["start"] >= following["stop"]), None)
        return current, following, after
    return current, following


def live_items(acc, channels, kids=False, ctx=""):
    """Channel items. ctx: the list they're from ("cat:<id>", "fav", "recent"), so the
    player's Channels panel can go up and down it."""
    epg = now_next(acc, channels)
    for c in channels:
        sid = str(c.get("stream_id"))
        name = c.get("name") or ""
        icon = c.get("stream_icon") or ""
        archive = int(bool(xtream.number(c.get("tv_archive"))))
        current, following, after = programme_text(epg.get(sid) or [], later=True)
        item = xbmcgui.ListItem(name, current["title"] if current else "")
        # (the TV guide page: now, next and later as three columns)
        for key, p in (("Now", current), ("Next", following), ("Later", after)):
            if p:
                item.setProperty(key, p["title"])
                item.setProperty(key + "Time", "%s - %s" % (clock(p["start"]), clock(p["stop"])) if key == "Now"
                                 else clock(p["start"]))
        if c.get("num"):
            item.setProperty("Number", str(c["num"]))
        tag = item.getVideoInfoTag()
        tag.setTitle(name)
        tag.setMediaType("video")
        lines = []
        if current:
            lines.append("[B]%s[/B]  %s - %s" % (text(30021) % current["title"], clock(current["start"]),
                                                 clock(current["stop"])))
            if current["plot"]:
                lines.append(current["plot"])
        if following:
            lines.append(text(30022) % "%s  %s" % (clock(following["start"]), following["title"]))
        tag.setPlot("[CR]".join(lines))
        if current and current["stop"] > current["start"]:
            item.setProperty("NowPercent", str(int(100 * (time.time() - current["start"]) /
                                                   (current["stop"] - current["start"]))))
        item.setArt({"icon": icon or "DefaultAddonPVRClient.png", "thumb": icon, "poster": icon,
                     "clearlogo": icon})
        menu = [(text(30023), "Container.Update(%s)" % url(mode="guide", id=sid, name=name, archive=archive))]
        if archive:
            menu.insert(0, (text(30053), "RunPlugin(%s)" % url(mode="startover", id=sid, name=name, icon=icon)))
            menu.append((text(30004), "Container.Update(%s)" % url(mode="days", id=sid, name=name, icon=icon,
                                                                  days=xtream.number(c.get("tv_archive_duration"), 7))))
        favourite = store.is_favourite(sid)
        menu.append((text(30057) if favourite else text(30056), "RunPlugin(%s)" % url(
            mode="favourite", id=sid, name=name, icon=icon, archive=archive, kids=int(kids), on=int(not favourite))))
        item.addContextMenuItems(menu)
        xbmcplugin.addDirectoryItem(HANDLE, url(mode="play", kind="live", id=sid, name=name, icon=icon,
                                                archive=archive, ctx=ctx), item, isFolder=False)


def guide(sid, name, archive=False):
    """A channel's programmes from now on (and catch-up ones before, when it has them)."""
    progs = account().channel_epg(sid)
    now = time.time()
    for p in progs:
        if p["stop"] < now - 3 * 3600 and not p["archive"]:
            continue
        day = time.strftime("%a", time.localtime(p["start"]))
        label = "%s %s  %s" % (day, clock(p["start"]), p["title"])
        item = xbmcgui.ListItem(label)
        tag = item.getVideoInfoTag()
        tag.setTitle(p["title"])
        tag.setPlot(p["plot"])
        if p["start"] <= now < p["stop"] or p["start"] > now:
            target = url(mode="play", kind="live", id=sid, name=name, archive=int(archive))
            if archive and p["start"] <= now:
                item.addContextMenuItems([(text(30053), "RunPlugin(%s)" % url(mode="startover", id=sid, name=name))])
            elif p["start"] > now:
                on = not store.has_reminder(sid, p["start"])
                item.addContextMenuItems([(text(30067) if on else text(30068), "RunPlugin(%s)" % url(
                    mode="remind", id=sid, name=name, archive=int(archive), title=p["title"], start=p["start"],
                    stop=p["stop"], on=int(on)))])
                if not on:
                    item.setLabel("%s  (%s)" % (label, text(30066)))
        elif p["archive"]:
            target = url(mode="play", kind="catchup", id=sid, name=name, title=p["title"], start=p["start_text"],
                         minutes=max(1, (p["stop"] - p["start"]) // 60))
        else:
            continue
        xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=False)
    end("videos", name)


def catchup_channels():
    """The channels you can watch earlier programmes of."""
    channels = store.archive_channels()
    if not channels and not store.built():
        return build_first(url(mode="catchup"))
    folder(text(30071), url(mode="catchsearch"), "DefaultAddonsSearch.png")
    for c in channels:
        folder(c["name"], url(mode="days", id=c["id"], name=c["name"], icon=c["icon"], days=7),
               c["icon"] or "DefaultAddonPVRClient.png", art={"poster": c["icon"]} if c["icon"] else None)
    end("files", text(30004), sort=True)


def days(sid, name, icon, count):
    today = time.mktime(time.localtime()[:3] + (0, 0, 0, 0, 0, -1))
    for n in range(min(max(1, count), 14)):
        stamp = today - n * 86400
        label = text(30024) if n == 0 else text(30025) if n == 1 else \
            time.strftime(xbmc.getRegion("datelong"), time.localtime(stamp))
        folder(label, url(mode="day", id=sid, name=name, day=int(stamp)), icon or "DefaultYear.png")
    end("files", "%s: %s" % (text(30004), name))


def day(sid, name, start):
    now = time.time()
    for p in account().channel_epg(sid):
        if not (start <= p["start"] < start + 86400) or not p["archive"] or p["stop"] > now:
            continue
        item = xbmcgui.ListItem("%s  %s" % (clock(p["start"]), p["title"]))
        tag = item.getVideoInfoTag()
        tag.setTitle(p["title"])
        tag.setPlot(p["plot"])
        tag.setDuration(max(0, p["stop"] - p["start"]))
        xbmcplugin.addDirectoryItem(HANDLE, url(mode="play", kind="catchup", id=sid, name=name, title=p["title"],
                                                start=p["start_text"], minutes=max(1, (p["stop"] - p["start"]) // 60)),
                                    item, isFolder=False)
    end("videos", name)


# --------------------------------------------------------------------------- movies

def movie_info(acc, sid):
    data = acc.peek(action="get_vod_info", vod_id=sid)
    return (data or {}).get("info") or {} if isinstance(data, dict) else {}


def trailer(youtube):
    return "plugin://plugin.video.youtube/play/?video_id=%s" % youtube if youtube else ""


def movie_item(acc, m, kids):
    """m: an entry of get_vod_streams (or the index)."""
    sid = str(m.get("stream_id") or m.get("id"))
    info = movie_info(acc, sid)
    name = xtream.clean_name(m.get("name") or info.get("name") or "")
    year = xtream.year_of(m) or xtream.year_of(info)
    item = xbmcgui.ListItem("%s (%d)" % (name, year) if year else name)
    tag = item.getVideoInfoTag()
    tag.setTitle(name)
    tag.setMediaType("movie")
    if year:
        tag.setYear(year)
    r = xtream.rating(m.get("rating") or info.get("rating"))
    if r:
        tag.setRating(r)
    if info.get("plot") or info.get("description"):
        tag.setPlot(info.get("plot") or info.get("description"))
    if info.get("genre"):
        tag.setGenres([g.strip() for g in info["genre"].split(",") if g.strip()])
    if info.get("director"):
        tag.setDirectors([d.strip() for d in info["director"].split(",") if d.strip()])
    if info.get("cast"):
        tag.setCast([xbmc.Actor(a.strip()) for a in info["cast"].split(",")[:12] if a.strip()])
    if xtream.number(info.get("duration_secs")):
        tag.setDuration(xtream.number(info["duration_secs"]))
    if info.get("youtube_trailer"):
        tag.setTrailer(trailer(info["youtube_trailer"]))
    poster = m.get("stream_icon") or m.get("icon") or info.get("movie_image") or ""
    backdrop = (info.get("backdrop_path") or [""])[0] if isinstance(info.get("backdrop_path"), list) else ""
    item.setArt({"poster": poster, "thumb": poster, "icon": poster or "DefaultMovies.png", "fanart": backdrop})
    ext = m.get("container_extension") or m.get("ext") or "mp4"
    position, total, watched = store.resume_point("movie", sid)
    if watched:
        tag.setPlaycount(1)
    elif position and total:
        tag.setResumePoint(float(position), float(total))
    item.addContextMenuItems([my_list_menu("vod", sid, name, poster, backdrop, ext, year, kids)] +
                             download_menu("movie", sid, ext, "%s (%d)" % (name, year) if year else name))
    xbmcplugin.addDirectoryItem(HANDLE, url(mode="play", kind="movie", id=sid, ext=ext, kids=int(kids), title=name),
                                item, isFolder=False)
    return None if info else sid


def movie_items(acc, films, kids):
    wanted = [w for w in (movie_item(acc, m, kids) for m in films) if w]
    if wanted:  # (the service fetches the plots and backdrops, and refreshes the page)
        xbmcgui.Window(10000).setProperty("MHX.Want", json.dumps(
            {"path": sys.argv[0] + sys.argv[2], "ids": wanted[:PAGE]}))  # (the page's own address)


# --------------------------------------------------------------------------- series



def series_tag(tag, s):
    tag.setTitle(s.get("name") or "")
    tag.setTvShowTitle(s.get("name") or "")
    if s.get("plot"):
        tag.setPlot(s["plot"])
    y = xtream.year_of(s)
    if y:
        tag.setYear(y)
    r = xtream.rating(s.get("rating"))
    if r:
        tag.setRating(r)
    if s.get("genre"):
        tag.setGenres([g.strip() for g in s["genre"].split(",") if g.strip()])
    if s.get("cast"):
        tag.setCast([xbmc.Actor(a.strip()) for a in s["cast"].split(",")[:12] if a.strip()])
    if s.get("youtube_trailer"):
        tag.setTrailer(trailer(s["youtube_trailer"]))


def series_items(shows, kids):
    fresh = store.new_series()
    for s in shows:
        sid = str(s.get("series_id") or s.get("id"))
        item = xbmcgui.ListItem(s.get("name") or "")
        tag = item.getVideoInfoTag()
        series_tag(tag, s)
        tag.setMediaType("tvshow")
        art = store.series_art(s)
        item.setArt(art)
        item.addContextMenuItems([my_list_menu("series", sid, s.get("name") or "", art["poster"], art["fanart"], "",
                                               xtream.year_of(s), kids)])
        if sid in fresh:
            item.setProperty("New", "2")  # (MediaHub's NEW EPISODES badge)
        xbmcplugin.addDirectoryItem(HANDLE, url(mode="seasons", series=sid, kids=int(kids)), item, isFolder=True)




def seasons(series_id, kids):
    data = account().series_info(series_id)
    info = data.get("info") or {}
    found = store.episodes_of(data)
    about = {xtream.number(s.get("season_number")): s for s in data.get("seasons") or []}
    art = store.series_art(info)
    if len(found) == 1:  # (just the one season: straight to its episodes)
        return episodes(series_id, next(iter(found)), kids)
    for number in sorted(found):
        s = about.get(number) or {}
        item = xbmcgui.ListItem(s.get("name") or kodi(20358).format(number), "%d" % len(found[number]))
        tag = item.getVideoInfoTag()
        series_tag(tag, info)
        tag.setMediaType("season")
        tag.setSeason(number)
        if s.get("overview"):
            tag.setPlot(s["overview"])
        season_art = dict(art)
        if s.get("cover") or s.get("cover_big"):
            season_art.update({"poster": s.get("cover_big") or s["cover"], "thumb": s.get("cover_big") or s["cover"]})
        season_art["tvshow.poster"] = art["poster"]
        item.setArt(season_art)
        xbmcplugin.addDirectoryItem(HANDLE, url(mode="episodes", series=series_id, season=number, kids=kids), item,
                                    isFolder=True)
    end("seasons", info.get("name") or "")




def episode_listitem(e):
    title = e["title"] or "%s %d" % (kodi(20359), e["episode"])
    item = xbmcgui.ListItem("%dx%02d. %s" % (e["season"], e["episode"], title))
    tag = item.getVideoInfoTag()
    tag.setTitle(title)
    tag.setMediaType("episode")
    tag.setTvShowTitle(e["show"])
    tag.setSeason(e["season"])
    tag.setEpisode(e["episode"])
    if e.get("plot"):
        tag.setPlot(e["plot"])
    if e.get("duration"):
        tag.setDuration(e["duration"])
    thumb = e.get("thumb") or e.get("fanart") or e.get("poster")
    item.setArt({"thumb": thumb, "icon": thumb or "DefaultTVShows.png", "fanart": e.get("fanart") or "",
                 "tvshow.poster": e.get("poster") or "", "poster": e.get("poster") or ""})
    return item, tag


def episodes(series_id, season, kids):
    data = account().series_info(series_id)
    info = data.get("info") or {}
    for e in store.episodes_of(data).get(season, []):
        entry = store.episode_entry(series_id, info, e, kids)
        item, tag = episode_listitem(entry)
        position, total, watched = store.resume_point("episode", entry["id"])
        if watched:
            tag.setPlaycount(1)
        elif position and total:
            tag.setResumePoint(float(position), float(total))
        item.addContextMenuItems(download_menu("episode", entry["id"], entry["ext"], "%s S%02dE%02d %s" % (
            entry["show"], entry["season"], entry["episode"], entry["title"]), series_id))
        xbmcplugin.addDirectoryItem(HANDLE, url(mode="play", kind="episode", id=entry["id"], series=series_id,
                                                kids=int(kids)), item, isFolder=False)
    end("episodes", "%s - %s" % (info.get("name") or "", kodi(20358).format(season)))


# --------------------------------------------------------------------------- continue, recent, search

def continue_page():
    for e in store.continue_watching():
        if e["kind"] == "episode":
            item, tag = episode_listitem(e)
            item.setLabel("%s  %s" % (e.get("show") or "", item.getLabel()))
            if e.get("new"):
                item.setProperty("New", "2")
            target = url(mode="play", kind="episode", id=e["id"], series=e["series_id"], kids=int(e.get("kids")))
        else:
            item = xbmcgui.ListItem(e.get("title") or "")
            tag = item.getVideoInfoTag()
            tag.setTitle(e.get("title") or "")
            tag.setMediaType("movie")
            if e.get("plot"):
                tag.setPlot(e["plot"])
            item.setArt({"poster": e.get("poster") or "", "thumb": e.get("poster") or "",
                         "fanart": e.get("fanart") or ""})
            target = url(mode="play", kind="movie", id=e["id"], ext=e.get("ext") or "mp4", kids=int(e.get("kids")),
                         title=e.get("title") or "")
        if e.get("pos") and e.get("total"):
            tag.setResumePoint(float(e["pos"]), float(e["total"]))
        xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=False)
    end("videos", text(30005), cache=False)


def build_first(back):
    """Search, Catch-up and Recently added use the index: offer to make it now."""
    if not xbmcgui.Dialog().yesno(NAME, text(30052)):
        return end()
    if build_now():
        xbmc.executebuiltin("Container.Update(%s,replace)" % back)
    end()


def build_now():
    bar = xbmcgui.DialogProgress()
    bar.create(NAME, text(30026))

    def progress(percent, name):
        bar.update(percent, "%s[CR]%s" % (text(30026), name))
        return False if bar.iscanceled() else None
    try:
        return store.build(account(), xbmc.Monitor(), progress, timeout=20)
    finally:
        bar.close()


def recent(kind):
    if not store.built():
        return build_first(url(mode="recent", kind=kind))
    acc = account()
    entries = store.recent(kind)
    if kind == "vod":
        movie_items(acc, [{"stream_id": e["id"], "name": e["name"], "stream_icon": e["icon"], "rating": e["rating"],
                           "year": e["year"], "container_extension": e["ext"]} for e in entries], False)
        end("movies", text(30006))
    else:
        series_items([{"series_id": e["id"], "name": e["name"], "cover": e["icon"], "rating": e["rating"],
                       "year": e["year"]} for e in entries], False)
        end("tvshows", text(30007))


def search(words):
    if not words:
        words = xbmcgui.Dialog().input(kodi(137))
        if not words:
            return end()
        xbmc.executebuiltin("Container.Update(%s,replace)" % url(mode="search", q=words))
        return end()
    if not store.built():
        return build_first(url(mode="search", q=words))
    found = store.search(words)
    acc = account()
    live_items(acc, [{"stream_id": c["id"], "name": c["name"], "stream_icon": c["icon"], "tv_archive": c["archive"]}
                     for c in found["live"]])
    movie_items(acc, [{"stream_id": e["id"], "name": e["name"], "stream_icon": e["icon"], "rating": e["rating"],
                       "year": e["year"], "container_extension": e["ext"]} for e in found["vod"]], False)
    series_items([{"series_id": e["id"], "name": e["name"], "cover": e["icon"], "rating": e["rating"],
                   "year": e["year"]} for e in found["series"]], False)
    end("videos", "%s: %s" % (kodi(137), words))


# --------------------------------------------------------------------------- playing

def start(items, offset=0):
    """Play these (address, listitem, entry) in order; the first from offset seconds."""
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    playing = {}
    for n, (address, item, entry) in enumerate(items):
        if n == 0 and offset:
            item.setProperty("StartOffset", str(int(offset)))
        playlist.add(address, item)
        if entry:
            playing[address] = entry
    xbmcgui.Window(10000).setProperty(store.NOW, json.dumps(playing))
    xbmc.Player().play(playlist)


def live_now():
    try:
        return json.loads(xbmcgui.Window(10000).getProperty(store.LIVE) or "{}")
    except ValueError:
        return {}


def play_live(acc, sid, name, icon, archive, over=None, title="", ctx=None):
    """A live channel (or, over: the start-over address of its programme). MediaHub's
    player bar then offers Start over (or Back to live), Last channel and Channels
    (store.live_state)."""
    item = xbmcgui.ListItem(name)
    item.getVideoInfoTag().setTitle("%s - %s" % (name, title) if title else name)
    item.setArt({"thumb": icon, "icon": icon})
    home = xbmcgui.Window(10000)
    before = live_now()
    if ctx is None:  # (Start over, Back to live, the Channels panel: the same list as before)
        ctx = before.get("from", "")
    prev = before.get("prev")
    if not over and str(before.get("id")) != str(sid):
        prev = store.note_channel({"id": sid, "name": name, "icon": icon, "archive": bool(archive)})
    home.setProperty(store.NOW, "{}")
    home.setProperty(store.LIVE, json.dumps({"id": str(sid), "name": name, "icon": icon, "archive": bool(archive),
                                             "live": acc.live_url(sid), "over": over or "", "from": ctx or "",
                                             "prev": prev}))
    home.setProperty("MHX.Prev.Name", (prev or {}).get("name", ""))
    home.setProperty("MHX.Live.Name", name)  # (MediaHub's mini guide)
    home.setProperty("MHX.Live.Icon", icon)
    xbmc.Player().play(over or acc.live_url(sid), item)


def start_over(args):
    """Play the programme on now from its beginning (the channel's catch-up)."""
    acc = account()
    try:
        live = json.loads(xbmcgui.Window(10000).getProperty(store.LIVE) or "{}")
    except ValueError:
        live = {}
    sid = args.get("id") or live.get("id")
    if not sid:
        return
    name, icon = args.get("name") or live.get("name", ""), args.get("icon") or live.get("icon", "")
    now = time.time()
    current = next((p for p in acc.short_epg(sid, 3, 8) if p["start"] <= now < p["stop"] and p["start_text"]), None)
    if not current:
        return notify(text(30054), True)
    over = acc.catchup_url(sid, current["start_text"], max(1, (current["stop"] - current["start"]) // 60))
    play_live(acc, sid, name, icon, True, over, current["title"])


def back_to_live():
    live = live_now()
    if live.get("id"):
        play_live(account(), live["id"], live.get("name", ""), live.get("icon", ""), live.get("archive"))


def last_channel():
    prev = live_now().get("prev")
    if prev:
        play_live(account(), prev["id"], prev.get("name", ""), prev.get("icon", ""), prev.get("archive"))


def channels_of(ctx):
    """The channels of a list ("cat:<id>", "fav", "recent"), as get_live_streams entries."""
    if ctx.startswith("cat:"):
        return account().streams("live", ctx[4:])
    found = store.favourites() if ctx == "fav" else store.recent_channels()
    return [{"stream_id": c["id"], "name": c.get("name", ""), "stream_icon": c.get("icon", ""),
             "tv_archive": int(bool(c.get("archive")))} for c in found]


def zap():
    """The player's Channels panel: the list the channel playing came from, starting at
    it (a looping list, so Up / Down go to the channels either side)."""
    live = live_now()
    ctx = live.get("from") or "recent"
    channels = channels_of(ctx)
    if len(channels) < ZAP_ROWS:  # (the rest of the channels after the list's own)
        have = {str(c.get("stream_id")) for c in channels}
        channels += [{"stream_id": c["id"], "name": c["name"], "stream_icon": c["icon"],
                      "tv_archive": int(bool(c["archive"]))} for c in store.live_channels() if str(c["id"]) not in have]
    at = next((n for n, c in enumerate(channels) if str(c.get("stream_id")) == live.get("id")), 0)
    # (the panel's looping list starts with its highlight on the 4th row down, Custom_1132's
    # focusposition 3: put the channel playing there, the ones before it above)
    count = min(len(channels), EPG_CHANNELS)
    first = at - (ZAP_FOCUS % count if count else 0)
    around = [channels[(first + i) % len(channels)] for i in range(count)]
    live_items(account(), around, ctx=ctx)
    end("videos", text(30082), cache=False)


def go_to_number():
    number = xbmcgui.Dialog().numeric(0, text(30077))
    if not number:
        return
    if not store.built():
        return notify(text(30052).split(".")[0], True)
    c = store.channel_by_number(number)
    if not c:
        return notify(text(30073) % int(number), True)
    play_live(account(), c["id"], c["name"], c["icon"], c["archive"], ctx="cat:%s" % c["cat"])


def remind(args):
    entry = {"id": args["id"], "name": args.get("name", ""), "icon": args.get("icon", ""),
             "archive": args.get("archive") == "1", "title": args.get("title", ""),
             "start": int(args["start"]), "stop": int(args.get("stop") or args["start"])}
    on = args.get("on") == "1"
    store.set_reminder(entry, on)
    notify(text(30074) % entry["title"] if on else text(30068))
    xbmc.executebuiltin("Container.Refresh")


def reminders_page():
    for r in store.reminders():
        label = "%s %s  %s: %s" % (time.strftime("%a", time.localtime(r["start"])), clock(r["start"]),
                                   r["name"], r["title"])
        item = xbmcgui.ListItem(label)
        item.setArt({"icon": r.get("icon") or "DefaultAddonPVRClient.png", "thumb": r.get("icon", "")})
        item.addContextMenuItems([(text(30068), "RunPlugin(%s)" % url(mode="remind", on=0, **{
            k: r[k] for k in ("id", "start", "stop", "title", "name")}))])
        xbmcplugin.addDirectoryItem(HANDLE, url(mode="play", kind="live", id=r["id"], name=r["name"],
                                                icon=r.get("icon", ""), archive=int(bool(r.get("archive")))),
                                    item, isFolder=False)
    end("videos", text(30066), cache=False)


def my_list_toggle(args):
    entry = {k: args.get(k, "") for k in ("kind", "id", "name", "icon", "fanart", "ext")}
    entry["year"], entry["kids"] = xtream.number(args.get("year")), args.get("kids") == "1"
    on = args.get("on") == "1"
    store.set_my_list(entry, on)
    notify(text(30079) if on else text(30080))
    xbmc.executebuiltin("Container.Refresh")


def my_list_page():
    entries = [m for m in store.my_list() if m.get("kids") or not store.kids_mode()]
    acc = account()
    movie_items(acc, [{"stream_id": m["id"], "name": m["name"], "stream_icon": m.get("icon"), "year": m.get("year"),
                       "container_extension": m.get("ext")} for m in entries if m["kind"] == "vod"], False)
    series_items([{"series_id": m["id"], "name": m["name"], "cover": m.get("icon"), "year": m.get("year"),
                   "backdrop_path": [m.get("fanart")] if m.get("fanart") else []}
                  for m in entries if m["kind"] == "series"], False)
    end("videos", text(30064), cache=False)


def my_list_menu(kind, item_id, name, icon, fanart, ext, year, kids):
    on = not store.in_my_list(kind, item_id)
    return (text(30069) if on else text(30070), "RunPlugin(%s)" % url(
        mode="mylist", kind=kind, id=item_id, name=name, icon=icon or "", fanart=fanart or "", ext=ext or "",
        year=year or 0, kids=int(bool(kids)), on=int(on)))


def download_menu(kind, item_id, ext, name, series=""):
    """Download (MediaHub's Downloads; not on Apple TV, whose system may delete big files)."""
    if not xbmc.getCondVisibility("System.HasAddon(script.mediahub.helper) + !System.Platform.TVOS"):
        return []
    return [(text(30076), "RunPlugin(%s)" % url(mode="download", kind=kind, id=item_id, ext=ext or "mp4",
                                                name=name, series=series))]


def download(args):
    acc = account()
    address = acc.movie_url(args["id"], args.get("ext")) if args.get("kind") == "movie" else \
        acc.episode_url(args["id"], args.get("ext"))
    home = xbmcgui.Window(10000)
    home.setProperty("MH.Req.Download", json.dumps({"url": address, "name": args.get("name") or args["id"],
                                                    "ext": "." + (args.get("ext") or "mp4")}))
    home.setProperty("MH.Req.Action", "downloadfile")


def search_catchup(words):
    """Programmes you can still watch on the channels with catch-up whose title or
    description has the words (your channels first; as many as answer in time)."""
    if not words:
        words = xbmcgui.Dialog().input(text(30071))
        if words:
            xbmc.executebuiltin("Container.Update(%s,replace)" % url(mode="catchsearch", q=words))
        return end()
    if not store.built():
        return build_first(url(mode="catchsearch", q=words))
    acc = account()
    mine = [c["id"] for c in store.favourites() + store.recent_channels() if c.get("archive")]
    channels = {c["id"]: c for c in store.archive_channels()}
    order = list(dict.fromkeys([i for i in mine if i in channels] + list(channels)))[:80]
    from concurrent.futures import ThreadPoolExecutor, wait
    pool = ThreadPoolExecutor(max_workers=8)
    jobs = {pool.submit(acc.channel_epg, i): i for i in order}
    done, _ = wait(jobs, timeout=12)
    pool.shutdown(wait=False, cancel_futures=True)
    wanted = words.lower()
    now = time.time()
    found = []
    for job in done:
        try:
            progs = job.result()
        except Exception:
            continue
        c = channels[jobs[job]]
        found += [(p, c) for p in progs if p["archive"] and p["stop"] <= now and
                  (wanted in p["title"].lower() or wanted in p["plot"].lower())]
    for p, c in sorted(found, key=lambda pc: -pc[0]["start"])[:100]:
        label = "%s %s  %s: %s" % (time.strftime("%a", time.localtime(p["start"])), clock(p["start"]), c["name"],
                                   p["title"])
        item = xbmcgui.ListItem(label)
        tag = item.getVideoInfoTag()
        tag.setTitle(p["title"])
        tag.setPlot(p["plot"])
        item.setArt({"icon": c["icon"] or "DefaultAddonPVRClient.png", "thumb": c["icon"]})
        xbmcplugin.addDirectoryItem(HANDLE, url(mode="play", kind="catchup", id=c["id"], name=c["name"],
                                                title=p["title"], start=p["start_text"],
                                                minutes=max(1, (p["stop"] - p["start"]) // 60)), item, isFolder=False)
    end("videos", "%s: %s" % (text(30071), words))


def grid_categories():
    """The TV guide page's list on the left: your channels, recent ones, and the categories."""
    def entry(label, ctx, icon):
        item = xbmcgui.ListItem(label)
        item.setArt({"icon": icon, "thumb": icon})
        item.setProperty("GridPath", url(mode="grid", list=ctx))
        xbmcplugin.addDirectoryItem(HANDLE, url(mode="grid", list=ctx), item, isFolder=False)
    if store.favourites():
        entry(text(30055), "fav", "DefaultFavourites.png")
    if store.recent_channels():
        entry(text(30063), "recent", "DefaultRecentlyAddedEpisodes.png")
    for c in store.visible("live", account().categories("live")):
        entry(c.get("category_name") or "?", "cat:%s" % c.get("category_id"), "DefaultAddonPVRClient.png")
    end("files", text(30072), cache=False)


def grid(ctx):
    live_items(account(), channels_of(ctx)[:EPG_CHANNELS], ctx=ctx)
    end("videos", text(30072))


def open_guide():
    """TV guide: MediaHub's guide page (skin window 1133), or the channel lists elsewhere."""
    if xbmc.getSkinDir() != "skin.mediahub":
        return xbmc.executebuiltin("ActivateWindow(Videos,%s,return)" % url(mode="categories", kind="live"))
    first = "fav" if store.favourites() else "recent" if store.recent_channels() else ""
    if not first:
        cats = store.visible("live", account().categories("live"))
        first = "cat:%s" % cats[0].get("category_id") if cats else ""
    xbmcgui.Window(10000).setProperty("MHX.GridPath", url(mode="grid", list=first) if first else "")
    xbmc.executebuiltin("ActivateWindow(1133)")


def hero():
    """MediaHub's home banner (Skin Settings > Banner: IPTV): the newest films and
    series, from the list (nothing is asked of the service here)."""
    acc = account()
    films, shows = store.recent("vod", 6), store.recent("series", 4)
    mixed = [x for pair in zip(films, shows) for x in pair] + films[len(shows):] + shows[len(films):]
    for e in mixed[:10]:
        if e["kind"] == "vod":
            info = movie_info(acc, e["id"])
            name = xtream.clean_name(e["name"])
            item = xbmcgui.ListItem(name)
            tag = item.getVideoInfoTag()
            tag.setMediaType("movie")
            if info.get("plot"):
                tag.setPlot(info["plot"])
            if info.get("genre"):
                tag.setGenres([g.strip() for g in info["genre"].split(",") if g.strip()])
            if xtream.number(info.get("duration_secs")):
                tag.setDuration(xtream.number(info["duration_secs"]))
            fanart = store.backdrop(info) or e["icon"]
            target, is_folder = url(mode="play", kind="movie", id=e["id"], ext=e["ext"] or "mp4", title=name), False
        else:
            name = e["name"]
            item = xbmcgui.ListItem(name)
            tag = item.getVideoInfoTag()
            tag.setMediaType("tvshow")
            tag.setTvShowTitle(name)
            fanart = e["fanart"] or e["icon"]
            target, is_folder = url(mode="seasons", series=e["id"], kids=0), True
        tag.setTitle(name)
        if e["year"]:
            tag.setYear(e["year"])
        if e["rating"]:
            tag.setRating(e["rating"])
        item.setArt({"poster": e["icon"], "thumb": e["icon"], "fanart": fanart, "landscape": fanart})
        xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=is_folder)
    end("videos", NAME, cache=False)


def favourite(args):
    store.set_favourite({"id": args["id"], "name": args.get("name", ""), "icon": args.get("icon", ""),
                         "archive": args.get("archive") == "1", "kids": args.get("kids") == "1"}, args.get("on") == "1")
    notify(text(30058) if args.get("on") == "1" else text(30059))
    xbmc.executebuiltin("Container.Refresh")


def my_channels():
    favs = [f for f in store.favourites() if f.get("kids") or not store.kids_mode()]
    live_items(account(), [{"stream_id": f["id"], "name": f["name"], "stream_icon": f["icon"],
                            "tv_archive": int(f["archive"])} for f in favs], ctx="fav")
    end("videos", text(30055))


def ask_resume(kind, sid, forced=None):
    """0: from the start, a position: resume there, None: cancelled."""
    position, _, _ = store.resume_point(kind, sid)
    if forced is not None:
        return position if forced == "1" else 0
    if position <= 30:
        return 0
    pick = xbmcgui.Dialog().contextmenu([kodi(12022).format(time_label(position)), kodi(12021)])
    return None if pick < 0 else position if pick == 0 else 0


def play(args):
    acc = account()
    kind, sid = args.get("kind"), args.get("id", "")
    if kind == "live":
        play_live(acc, sid, args.get("name", ""), args.get("icon", ""), args.get("archive") == "1",
                  ctx=args.get("ctx"))
    elif kind == "catchup":
        item = xbmcgui.ListItem(args.get("title", ""))
        item.getVideoInfoTag().setTitle("%s - %s" % (args.get("name", ""), args.get("title", "")))
        xbmcgui.Window(10000).setProperty(store.NOW, "{}")
        xbmc.Player().play(acc.catchup_url(sid, args.get("start", ""), xtream.number(args.get("minutes"), 60)), item)
    elif kind == "movie":
        offset = ask_resume("movie", sid, args.get("resume"))
        if offset is None:
            return
        info = movie_info(acc, sid)
        if not info:
            try:
                info = acc.vod_info(sid, timeout=10).get("info") or {}
            except xtream.Error:
                info = {}
        name = args.get("title") or xtream.clean_name(info.get("name") or "")
        item = xbmcgui.ListItem(name)
        tag = item.getVideoInfoTag()
        tag.setTitle(name)
        tag.setMediaType("movie")
        if info.get("plot"):
            tag.setPlot(info["plot"])
        poster = info.get("movie_image") or ""
        backdrop = (info.get("backdrop_path") or [""])[0] if isinstance(info.get("backdrop_path"), list) else ""
        item.setArt({"poster": poster, "thumb": poster, "fanart": backdrop})
        entry = {"kind": "movie", "id": sid, "ext": args.get("ext") or "mp4", "title": name, "poster": poster,
                 "fanart": backdrop, "plot": info.get("plot") or "", "kids": args.get("kids") == "1"}
        start([(acc.movie_url(sid, entry["ext"]), item, entry)], offset)
    elif kind == "episode":
        offset = ask_resume("episode", sid, args.get("resume"))
        if offset is None:
            return
        series_id = args.get("series", "")
        data = acc.series_info(series_id)
        info = data.get("info") or {}
        ordered = [e for season in sorted(store.episodes_of(data).items()) for e in season[1]]
        at = next((n for n, e in enumerate(ordered) if str(e.get("id")) == sid), None)
        if at is None:
            return notify(text(30017), True)
        kids = args.get("kids") == "1"
        chain = [store.episode_entry(series_id, info, e, kids) for e in ordered[at:at + 6]]
        modified = xtream.number(info.get("last_modified")) or next(iter(store.query(
            "SELECT added FROM items WHERE kind='series' AND id=?", (series_id,))), [0])[0]
        for entry in chain:  # (so a change to the series later means new episodes: store.check_new_episodes)
            entry["series_modified"] = modified
        for this, nxt in zip(chain, chain[1:]):  # (Continue Watching: the one after a finished episode)
            this["next"] = dict(nxt)
        items = []
        for entry in chain:
            item, _ = episode_listitem(entry)
            items.append((acc.episode_url(entry["id"], entry["ext"]), item, entry))
        start(items, offset)


# --------------------------------------------------------------------------- dispatch

def main():
    mode = ARGS.get("mode", "")
    acc_needed = mode not in ("", "signin", "settings")
    if acc_needed and not account().ready():
        if HANDLE >= 0 and mode != "play":
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return signin()
    if mode == "":
        root()
    elif mode == "signin":
        signin()
    elif mode == "settings":
        ADDON.openSettings()
    elif mode == "account":
        show_account()
    elif mode == "livetv":
        live_tv_help()
    elif mode == "categories":
        careful(lambda: categories(ARGS["kind"]))
    elif mode == "hide":
        choose_hidden(ARGS["kind"])
    elif mode == "list":
        careful(lambda: entry_list(ARGS["kind"], ARGS["cat"], ARGS.get("name", ""), int(ARGS.get("page", 0))))
    elif mode == "seasons":
        careful(lambda: seasons(ARGS["series"], ARGS.get("kids") == "1"))
    elif mode == "episodes":
        careful(lambda: episodes(ARGS["series"], int(ARGS["season"]), ARGS.get("kids") == "1"))
    elif mode == "guide":
        careful(lambda: guide(ARGS["id"], ARGS.get("name", ""), ARGS.get("archive") == "1"))
    elif mode == "catchup":
        careful(catchup_channels)
    elif mode == "days":
        days(ARGS["id"], ARGS.get("name", ""), ARGS.get("icon", ""), int(ARGS.get("days", 7)))
    elif mode == "day":
        careful(lambda: day(ARGS["id"], ARGS.get("name", ""), int(ARGS["day"])))
    elif mode == "continue":
        continue_page()
    elif mode == "recent":
        careful(lambda: recent(ARGS["kind"]))
    elif mode == "search":
        careful(lambda: search(ARGS.get("q", "")))
    elif mode == "build":
        build_now()
    elif mode == "recentchannels":
        careful(lambda: (live_items(account(), channels_of("recent"), ctx="recent"),
                         end("videos", text(30063), cache=False)))
    elif mode == "lastchannel":
        last_channel()
    elif mode == "zap":
        careful(zap)
    elif mode == "gotonumber":
        go_to_number()
    elif mode == "remind":
        remind(ARGS)
    elif mode == "reminders":
        reminders_page()
    elif mode == "mylist":
        my_list_toggle(ARGS)
    elif mode == "mylistpage":
        careful(my_list_page)
    elif mode == "download":
        download(ARGS)
    elif mode == "catchsearch":
        careful(lambda: search_catchup(ARGS.get("q", "")))
    elif mode == "gridcats":
        careful(grid_categories)
    elif mode == "grid":
        careful(lambda: grid(ARGS.get("list", "")))
    elif mode == "guidewindow":
        open_guide()
    elif mode == "hero":
        careful(hero)
    elif mode == "favourites":
        careful(my_channels)
    elif mode == "favourite":
        favourite(ARGS)
    elif mode == "startover":
        try:
            start_over(ARGS)
        except xtream.Error:
            notify(text(30017), True)
    elif mode == "golive":
        back_to_live()
    elif mode == "play":
        try:
            play(ARGS)
        except xtream.Error:
            notify(text(30017), True)


if __name__ == "__main__":
    main()
