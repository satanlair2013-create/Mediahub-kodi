"""MediaHub IPTV - in the background while Kodi runs.

- Notes how far into a film or episode from the add-on you are (store.Tracker).
- Fetches the plots and backdrops of the films on the page you're looking at
  (the film lists only have names and posters), then refreshes the page.
- Once a day, while nothing plays, reads the list of channels, films and series
  for Search, Catch-up, Recently added and MediaHub's home rows (store.build).

Requests from here wait at most a few seconds, and it checks between each one
whether Kodi wants it to stop, so Kodi never has to force it.
"""
import json
import os
import sys
import threading
import time

import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import store  # noqa: E402
import xtream  # noqa: E402

EVERY_DAY = 24 * 3600
FIRST_BUILD = 90  # seconds after Kodi starts before the first daily read
CHANNELS_EVERY = 30 * 60  # what's on your favourite channels, for MediaHub's row


def watching():
    """Something plays full screen (not MediaHub's trailer previews on the home
    screen): leave the network and the disk alone until it ends."""
    return xbmc.getCondVisibility("Player.HasMedia + Window.IsActive(fullscreenvideo)")


class Service(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.tracker = store.Tracker()
        self.worker = None
        self.started = time.time()
        self.next_build_check = self.started + FIRST_BUILD
        self.changed = None  # MHX.Changed when home.json was last written
        self.home_written = 0.0
        self.next_reminders = 0.0
        self.next_live_info = 0.0
        self.live_info_for = None

    def busy(self):
        return self.worker is not None and self.worker.is_alive()

    def run_in_background(self, target, *args):
        self.worker = threading.Thread(target=self.guard, args=(target,) + args, daemon=True)
        self.worker.start()

    @staticmethod
    def guard(target, *args):
        try:
            target(*args)
        except Exception as exc:  # (never take the service down)
            xbmc.log("MediaHub IPTV: %r" % exc, xbmc.LOGERROR)

    def fetch_wanted(self, request):
        acc = xtream.Account()
        if not acc.ready():
            return
        got = 0
        for vod_id in request.get("ids") or []:
            if self.abortRequested():
                return
            if acc.peek(action="get_vod_info", vod_id=vod_id) is not None:
                continue
            try:
                acc.vod_info(vod_id, timeout=4, monitor=self)
                got += 1
            except xtream.Error:
                pass
            if self.waitForAbort(0.2):
                return
        if got and xbmc.getInfoLabel("Container.FolderPath") == request.get("path"):
            xbmc.executebuiltin("Container.Refresh")

    def build(self):
        acc = xtream.Account()
        if store.build(acc, self, timeout=4):
            # (the newest films' plots and backdrops, for MediaHub's IPTV: New Movies row)
            self.fetch_wanted({"ids": [e["id"] for e in store.recent("vod", 20, kids=False)]})
            store.check_new_episodes(acc, self)
            self.write_home()

    def write_home(self):
        self.home_written = time.time()
        store.write_home(xtream.Account(), self)

    def reminders(self):
        """A minute before a programme you asked to be reminded of: ask to watch it."""
        now = time.time()
        if now < self.next_reminders:
            return
        self.next_reminders = now + 15
        for r in store.reminders():
            if r["start"] - 60 <= now:
                store.set_reminder(r, False)
                if now < r.get("stop", r["start"] + 3600):
                    threading.Thread(target=self.guard, args=(self.ask_to_watch, r), daemon=True).start()

    @staticmethod
    def ask_to_watch(r):
        addon = xbmcaddon.Addon()
        if xbmcgui.Dialog().yesno(addon.getAddonInfo("name"), addon.getLocalizedString(30075) % (r["name"], r["title"]),
                                  autoclose=60000):
            xbmc.executebuiltin("RunPlugin(plugin://%s/?%s)" % (xtream.ADDON_ID, urllib.parse.urlencode({
                "mode": "play", "kind": "live", "id": r["id"], "name": r["name"], "icon": r.get("icon", ""),
                "archive": int(bool(r.get("archive")))})))

    def live_info(self):
        """While a live IPTV channel plays: what's on it now and next (MHX.Now.*, MHX.Next.*,
        for MediaHub's player info), and when this programme ends (MHX.ProgrammeEnd, for
        "Stop after this one")."""
        home = xbmcgui.Window(10000)
        state = home.getProperty(store.OSD)
        now = time.time()
        if not state:
            if self.live_info_for:
                self.live_info_for = None
                for p in ("Now.Title", "Now.Time", "Now.Plot", "Now.Percent", "Next.Title", "Next.Time",
                          "ProgrammeEnd"):
                    home.clearProperty("MHX." + p)
            return
        try:
            live = json.loads(home.getProperty(store.LIVE) or "{}")
        except ValueError:
            return
        key = (live.get("id"), state)
        if key == self.live_info_for and now < self.next_live_info:
            return
        self.live_info_for, self.next_live_info = key, now + 30
        threading.Thread(target=self.guard, args=(self.fill_live_info, live, state), daemon=True).start()

    def fill_live_info(self, live, state):
        import plugin_text
        progs = xtream.Account().short_epg(live["id"], 3, timeout=4)
        now = time.time()
        cur = next((p for p in progs if p["start"] <= now < p["stop"]), None)
        nxt = next((p for p in progs if cur and p["start"] >= cur["stop"]), None)
        home = xbmcgui.Window(10000)
        clock = plugin_text.clock
        home.setProperty("MHX.Now.Title", cur["title"] if cur else "")
        home.setProperty("MHX.Now.Plot", cur["plot"] if cur else "")
        home.setProperty("MHX.Now.Time", "%s - %s" % (clock(cur["start"]), clock(cur["stop"])) if cur else "")
        home.setProperty("MHX.Now.Percent", str(int(100 * (now - cur["start"]) / max(1, cur["stop"] - cur["start"])))
                         if cur else "")
        home.setProperty("MHX.Next.Title", nxt["title"] if nxt else "")
        home.setProperty("MHX.Next.Time", "%s - %s" % (clock(nxt["start"]), clock(nxt["stop"])) if nxt else "")
        home.setProperty("MHX.ProgrammeEnd", str(int(cur["stop"])) if cur and state == "live" else "")

    def tick(self):
        home = xbmcgui.Window(10000)
        self.tracker.tick()
        self.reminders()
        self.live_info()
        if self.busy():
            return
        want = home.getProperty("MHX.Want")
        if want:
            home.clearProperty("MHX.Want")
            try:
                self.run_in_background(self.fetch_wanted, json.loads(want))
            except ValueError:
                pass
            return
        changed = home.getProperty("MHX.Changed")
        if changed != self.changed and not watching():
            self.changed = changed  # (progress, hidden categories: MediaHub's home rows)
            self.run_in_background(self.write_home)
            return
        if time.time() - self.home_written > CHANNELS_EVERY and store.favourites() and \
                not watching():
            self.run_in_background(self.write_home)  # (what's on your channels now)
            return
        asked = home.getProperty("MHX.Build")
        now = time.time()
        if asked or now >= self.next_build_check:
            home.clearProperty("MHX.Build")
            self.next_build_check = now + 3600
            if xtream.Account().ready() and not watching() and \
                    (asked or now - store.built() > EVERY_DAY):
                self.run_in_background(self.build)

    def run(self):
        while not self.waitForAbort(1):
            try:
                self.tick()
            except Exception as exc:
                xbmc.log("MediaHub IPTV: %r" % exc, xbmc.LOGERROR)
        self.tracker.finish()


if __name__ == "__main__":
    Service().run()
