"""MediaHub IPTV - small things the pages and the service both use."""
import time

import xbmc


def clock(stamp):
    """A time of day in Kodi's region format, without seconds ("9:30 PM", "21:30")."""
    return time.strftime(xbmc.getRegion("time").replace(":%S", ""), time.localtime(stamp)) if stamp else ""
