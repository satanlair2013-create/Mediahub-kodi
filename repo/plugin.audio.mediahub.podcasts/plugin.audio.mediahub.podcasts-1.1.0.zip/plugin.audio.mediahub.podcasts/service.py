"""MediaHub Podcasts - in the background while Kodi runs.

- Notes how far into an episode from the add-on you are while it plays (resume,
  the played tick, Continue listening).
- Every few hours, while nothing plays full screen, reads the feeds of the
  podcasts you follow, so Latest episodes and MediaHub's home rows are up to
  date, and says when a new episode comes out.
- Downloads the newest episode of the podcasts set to download automatically when
  it comes out (and lets go of their played downloads beyond the number to keep).
"""
import json
import os
import sys
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import pods  # noqa: E402

FIRST_CHECK = 60  # seconds after Kodi starts
CHECK_EVERY = 3 * 3600


class Tracker:
    def __init__(self):
        self.next = 0.0
        self.path = None
        self.entry = None
        self.pos = self.total = self.furthest = 0.0
        self.saved = 0.0

    def tick(self):
        now = time.time()
        if now < self.next:
            return
        self.next = now + 2.0
        path = xbmc.getInfoLabel("Player.Filenameandpath") if xbmc.getCondVisibility("Player.HasMedia") else ""
        if path != self.path:
            self.finish()
            self.path = path
            if path:
                try:
                    playing = json.loads(xbmcgui.Window(10000).getProperty(pods.NOW) or "{}")
                except ValueError:
                    playing = {}
                self.entry = playing.get(path)
        if not self.entry:
            return
        try:
            player = xbmc.Player()
            self.pos, self.total = player.getTime(), player.getTotalTime()
        except RuntimeError:
            return
        if self.total > 0:
            self.furthest = max(self.furthest, self.pos / self.total)
        if now - self.saved > 15:
            self.record()
            self.saved = now

    def record(self):
        if self.entry and self.total > 0 and self.pos >= 5:
            pods.record(self.entry, self.pos, self.total, self.furthest)

    def finish(self):
        if self.entry:
            self.record()
        self.entry = None
        self.pos = self.total = self.furthest = 0.0


class Service(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.tracker = Tracker()
        self.next_check = time.time() + FIRST_CHECK
        self.worker = None

    def check_feeds(self, max_age):
        """Read every followed podcast's feed; note (and tell of) new episodes."""
        fresh = []
        for s in pods.subscriptions():
            if self.abortRequested():
                return
            try:
                show = pods.feed(s["feed"], max_age=max_age, timeout=10)
            except pods.Error:
                continue
            new = pods.new_episodes(show, "heard")
            if new:
                fresh.append((show, new[0], len(new)))
            pods.mark_seen(s["feed"], show, "heard")
            if s.get("auto"):
                self.auto_download(s, show, new)
            if self.waitForAbort(0.5):
                return
        pods.write_home()
        addon = xbmcaddon.Addon()
        if fresh and addon.getSettingBool("notify_new"):
            show, e, count = fresh[0]
            message = addon.getLocalizedString(30033) % show.get("title", "") if count == 1 and len(fresh) == 1 \
                else addon.getLocalizedString(30034) % sum(c for _, _, c in fresh)
            xbmcgui.Dialog().notification(addon.getAddonInfo("name"), message,
                                          e.get("art") or show.get("art") or addon.getAddonInfo("icon"), 6000)

    def auto_download(self, s, show, new):
        """The newest episode, when it's new (or, just after turning it on, if nothing of this
        podcast's is downloaded yet)."""
        episodes = show.get("episodes") or []
        if not episodes:
            return
        newest = episodes[0]
        have = [d for d in pods.downloads().values() if d["feed"] == s["feed"]]
        if (new and newest["guid"] == new[0]["guid"]) or not have:
            if not pods.downloaded(s["feed"], newest["guid"]):
                pods.download(s["feed"], newest, show, lambda done, total: not self.abortRequested(), auto=True)
        keep = xbmcaddon.Addon().getSettingInt("keep_downloads") or 3
        pods.tidy_downloads(s["feed"], keep)

    def guard(self, max_age):
        try:
            self.check_feeds(max_age)
        except Exception as exc:  # (never take the service down)
            xbmc.log("MediaHub Podcasts: %r" % exc, xbmc.LOGERROR)

    def run(self):
        home = xbmcgui.Window(10000)
        while not self.waitForAbort(1):
            try:
                self.tracker.tick()
                now = time.time()
                asked = home.getProperty("MHP.Check")
                busy = self.worker is not None and self.worker.is_alive()
                if (asked or now >= self.next_check) and not busy and \
                        not xbmc.getCondVisibility("Player.HasVideo + Window.IsActive(fullscreenvideo)"):
                    home.clearProperty("MHP.Check")
                    self.next_check = now + CHECK_EVERY
                    # (asked: MediaHub or the add-on wants it now, so even a feed read a minute ago)
                    self.worker = threading.Thread(target=self.guard, args=(60 if asked else CHECK_EVERY - 600,),
                                                   daemon=True)
                    self.worker.start()
            except Exception as exc:
                xbmc.log("MediaHub Podcasts: %r" % exc, xbmc.LOGERROR)
        self.tracker.finish()


if __name__ == "__main__":
    Service().run()
