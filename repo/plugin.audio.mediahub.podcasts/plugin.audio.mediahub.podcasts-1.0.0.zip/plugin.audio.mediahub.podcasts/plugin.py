"""MediaHub Podcasts - find, follow and listen to podcasts.

Latest episodes of the podcasts you follow, Continue listening, Your podcasts,
the top podcasts in your country, search, and any podcast by its feed address.
Episodes resume where you stopped and get a tick once played.
"""
import json
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import pods  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name")
FANART = os.path.join(ADDON.getAddonInfo("path"), "resources", "fanart.jpg")


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def kodi(string_id):
    return xbmc.getLocalizedString(string_id)


def url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)


def notify(message, error=False):
    xbmcgui.Dialog().notification(NAME, message, xbmcgui.NOTIFICATION_WARNING if error else
                                  xbmcgui.NOTIFICATION_INFO, 4000, False)


def folder(label, target, icon="DefaultFolder.png", menu=None):
    item = xbmcgui.ListItem(label)
    item.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
    if menu:
        item.addContextMenuItems(menu)
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=True)


def action(label, target, icon="DefaultIconInfo.png"):
    item = xbmcgui.ListItem(label)
    item.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=False)


def end(content="", title=""):
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.setPluginCategory(HANDLE, title or NAME)
    # (label2 comes from the artist field: see episode_item)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED, labelMask="%L", label2Mask="%A")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def careful(work):
    try:
        work()
    except pods.Error as exc:
        xbmc.log("MediaHub Podcasts: %s" % exc, xbmc.LOGWARNING)
        notify(text(30020), True)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def time_label(seconds):
    seconds = int(seconds)
    return "%d:%02d:%02d" % (seconds // 3600, seconds // 60 % 60, seconds % 60) if seconds >= 3600 else \
        "%d:%02d" % (seconds // 60, seconds % 60)


# --------------------------------------------------------------------------- pages

def root():
    mine = pods.subscriptions()
    if mine:
        folder(text(30001), url(mode="latest"), "DefaultMusicRecentlyAdded.png")
    if pods.continue_listening(1):
        folder(text(30002), url(mode="continue"), "DefaultInProgressShows.png")
    if mine:
        folder(text(30003), url(mode="mine"), "DefaultMusicPlaylists.png")
    folder(text(30004), url(mode="top"), "DefaultMusicTop100.png")
    folder(kodi(137), url(mode="search"), "DefaultAddonsSearch.png")
    action(text(30005), url(mode="addfeed"), "DefaultAddSource.png")
    end()


def show_folder(s, mine=False):
    item = xbmcgui.ListItem(s.get("title", ""))
    art = s.get("art") or "DefaultMusicAlbums.png"
    item.setArt({"icon": art, "thumb": art, "poster": art, "fanart": FANART})
    tag = item.getMusicInfoTag()
    tag.setTitle(s.get("title", ""))
    tag.setArtist(s.get("author", ""))
    tag.setAlbum(s.get("title", ""))
    if s.get("genre"):
        tag.setGenres([s["genre"]])
    subscribed = mine or pods.is_subscribed(s["feed"])
    info = json.dumps({k: s.get(k, "") for k in ("feed", "title", "author", "art")})
    menu = [(text(30011), "RunPlugin(%s)" % url(mode="subscribe", on=0, show=info)) if subscribed else
            (text(30010), "RunPlugin(%s)" % url(mode="subscribe", on=1, show=info))]
    if subscribed:
        menu.append((text(30012), "RunPlugin(%s)" % url(mode="allplayed", feed=s["feed"])))
    item.addContextMenuItems(menu)
    xbmcplugin.addDirectoryItem(HANDLE, url(mode="show", feed=s["feed"]), item, isFolder=True)


def shows_page(found, title, mine=False):
    for s in found:
        show_folder(s, mine)
    end("albums", title)


def episode_item(e, show, with_show=False, new=False):
    pos, total, played = pods.state(show["feed"], e["guid"])
    total = total or e.get("duration") or 0
    label = ("[B]%s[/B]  %s" % (text(30030), e["title"])) if new and not played else e["title"]
    item = xbmcgui.ListItem(label)
    art = e.get("art") or show.get("art") or "DefaultAudio.png"
    item.setArt({"icon": art, "thumb": art, "fanart": FANART})
    tag = item.getMusicInfoTag()
    tag.setTitle(e["title"])
    parts = [show.get("title", "")] if with_show else []
    parts += [pods.ago(e.get("date")), pods.minutes(max(0, total - pos) if pos else total) if total else ""]
    if pos and not played:
        parts[-1] = text(30031) % pods.minutes(max(0, total - pos)) if total else text(30032) % time_label(pos)
    tag.setArtist("  •  ".join(p for p in parts if p))
    tag.setAlbum(show.get("title", ""))
    tag.setComment(e.get("plot", ""))
    if total:
        tag.setDuration(int(total))
    if played:
        tag.setPlayCount(1)
    menu = [(text(30014), "RunPlugin(%s)" % url(mode="played", feed=show["feed"], guid=e["guid"], on=0))
            if played else
            (text(30013), "RunPlugin(%s)" % url(mode="played", feed=show["feed"], guid=e["guid"], on=1))]
    if pos and not played:
        menu.append((kodi(12021), "RunPlugin(%s)" % pods.play_address(show["feed"], e, show, resume=False)))
    if with_show:
        menu.append((text(30015), "Container.Update(%s)" % url(mode="show", feed=show["feed"])))
    item.addContextMenuItems(menu)
    xbmcplugin.addDirectoryItem(HANDLE, pods.play_address(show["feed"], e, show), item, isFolder=False)


def show_page():
    feed_url = ARGS["feed"]
    show = pods.feed(feed_url, max_age=600 if pods.is_subscribed(feed_url) else pods.FEED_AGE)
    new = {e["guid"] for e in pods.new_episodes(show)}
    if pods.is_subscribed(feed_url):
        pods.mark_seen(feed_url, show)  # (seen now: not New next time)
    else:
        info = json.dumps({k: show.get(k, "") for k in ("feed", "title", "author", "art")})
        action(text(30010), url(mode="subscribe", on=1, show=info), "DefaultAddSource.png")
    for e in show.get("episodes", []):
        episode_item(e, show, new=e["guid"] in new)
    end("songs", show.get("title", ""))


def latest_page():
    new = {}
    for e, show, _ in pods.latest(60):
        if show["feed"] not in new:
            new[show["feed"]] = {x["guid"] for x in pods.new_episodes(show)}
        episode_item(e, show, with_show=True, new=e["guid"] in new[show["feed"]])
    end("songs", text(30001))


def continue_page():
    for p in pods.continue_listening():
        show = pods.cached_feed(p["feed"]) or {"feed": p["feed"], "title": p.get("show", "")}
        show.setdefault("feed", p["feed"])
        e = next((x for x in show.get("episodes", []) if x["guid"] == p["guid"]), p)
        episode_item(e, show, with_show=True)
    end("songs", text(30002))


def search():
    words = ARGS.get("q")
    if not words:
        words = xbmcgui.Dialog().input(text(30016))
        if not words:
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        xbmc.executebuiltin("Container.Update(%s,replace)" % url(mode="search", q=words))
        return end()
    shows_page(pods.search(words), '%s: "%s"' % (kodi(137), words))


def add_feed():
    address = xbmcgui.Dialog().input(text(30017), "https://")
    if not address or address == "https://":
        return
    try:
        show = pods.feed(address.strip(), max_age=0)
    except pods.Error:
        return notify(text(30018), True)
    pods.subscribe(show, True)
    notify(text(30021) % show.get("title", ""))
    xbmc.executebuiltin("Container.Refresh")


# --------------------------------------------------------------------------- playing

def play():
    feed_url, guid = ARGS.get("feed", ""), ARGS.get("guid", "")
    try:
        show = pods.feed(feed_url, max_age=24 * 3600)
    except pods.Error:
        return notify(text(30020), True)
    e = next((x for x in show.get("episodes", []) if x["guid"] == guid), None)
    if not e:  # (gone from the feed: what Continue listening remembers)
        e = pods.progress().get(pods.episode_key(feed_url, guid))
        if not e or not e.get("url"):
            return notify(text(30019), True)
    pos, _, played = pods.state(feed_url, guid)
    offset = 0
    if ARGS.get("resume") is not None:
        offset = pos if ARGS["resume"] == "1" and not played else 0
    elif pos > 30 and not played:
        pick = xbmcgui.Dialog().contextmenu([kodi(12022).format(time_label(pos)), kodi(12021)])
        if pick < 0:
            return
        offset = pos if pick == 0 else 0
    video = (e.get("type") or "").startswith("video")
    item = xbmcgui.ListItem(e["title"], path=e["url"])
    art = e.get("art") or show.get("art") or ""
    item.setArt({"thumb": art, "icon": art, "fanart": FANART})
    if video:
        tag = item.getVideoInfoTag()
        tag.setTitle(e["title"])
        tag.setTvShowTitle(show.get("title", ""))
        tag.setPlot(e.get("plot", ""))
    else:
        tag = item.getMusicInfoTag()
        tag.setTitle(e["title"])
        tag.setArtist(show.get("title", ""))
        tag.setComment(e.get("plot", ""))
        if e.get("duration"):
            tag.setDuration(int(e["duration"]))
    if offset:
        item.setProperty("StartOffset", str(int(offset)))
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO if video else xbmc.PLAYLIST_MUSIC)
    playlist.clear()
    playlist.add(e["url"], item)
    xbmcgui.Window(10000).setProperty(pods.NOW, json.dumps({e["url"]: pods.entry(feed_url, e, show)}))
    xbmc.Player().play(playlist)


def main():
    mode = ARGS.get("mode")
    if mode is None:
        root()
    elif mode == "latest":
        latest_page()
    elif mode == "continue":
        continue_page()
    elif mode == "mine":
        shows_page(pods.subscriptions(), text(30003), mine=True)
    elif mode == "top":
        careful(lambda: shows_page(pods.top(), text(30004)))
    elif mode == "search":
        careful(search)
    elif mode == "show":
        careful(show_page)
    elif mode == "refreshhome":  # (MediaHub Sync changed the lists)
        pods.write_home()
    elif mode == "addfeed":
        add_feed()
    elif mode == "play":
        play()
    elif mode == "subscribe":
        show = json.loads(ARGS.get("show") or "{}")
        if show.get("feed"):
            on = ARGS.get("on") == "1"
            pods.subscribe(show, on)
            notify(text(30021 if on else 30022) % show.get("title", ""))
            xbmc.executebuiltin("Container.Refresh")
    elif mode == "played":
        show = pods.cached_feed(ARGS["feed"])
        e = next((x for x in show.get("episodes", []) if x["guid"] == ARGS.get("guid")), None)
        if e:
            pods.set_played(ARGS["feed"], e, show, ARGS.get("on") == "1")
            xbmc.executebuiltin("Container.Refresh")
    elif mode == "allplayed":
        pods.set_all_played(ARGS["feed"], pods.cached_feed(ARGS["feed"]))
        xbmc.executebuiltin("Container.Refresh")


if __name__ == "__main__":
    main()
