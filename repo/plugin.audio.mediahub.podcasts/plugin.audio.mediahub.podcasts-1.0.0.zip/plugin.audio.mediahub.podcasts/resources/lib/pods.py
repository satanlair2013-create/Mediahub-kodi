"""MediaHub Podcasts - finding podcasts, reading their feeds, and what's kept.

Podcasts are found with Apple's free podcast search (no account or key), and the
top charts come from Apple's charts; every podcast is then read straight from
its own RSS feed, so any feed address works too.

Kept in the add-on's data folder:
- subscriptions.json: your podcasts [{feed, title, author, art, added}]
- progress.json: how far into each episode you are {key: {pos, total, played, t, ...}}
- seen.json, heard.json: the episodes each podcast had when you last opened it
  (the others are New) and when the service last checked it (for its message)
- feeds/: each feed as it was last read
- home.json: ready-made cards for MediaHub's home rows (the MediaHub Helper reads it)
"""
import email.utils
import gzip
import hashlib
import html
import json
import os
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.audio.mediahub.podcasts"
CERTS = "special://xbmc/system/certs/cacert.pem"
ITUNES = os.environ.get("MEDIAHUB_ITUNES", "https://itunes.apple.com").rstrip("/")  # (a test server can stand in)
CHARTS = os.environ.get("MEDIAHUB_PODCHARTS", "https://rss.applemarketingtools.com").rstrip("/")
ITUNES_NS = "{http://www.itunes.com/dtds/podcast-1.0.dtd}"
FEED_AGE = 3 * 3600  # a feed is read again after this long (the service does it in the background)
CHART_AGE = 12 * 3600
PLAYED = 0.95  # this far through counts as played
KEEP = 3000  # progress entries kept (the oldest go)
NOW = "MHP.Now"  # what the add-on started playing: {address: entry}
HOME_CARDS = 20


class Error(Exception):
    pass


def profile(name=""):
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)


def load_json(name, default):
    try:
        with open(profile(name), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(name, data):
    path = profile(name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def ssl_context():
    certs = xbmcvfs.translatePath(CERTS)
    try:
        return ssl.create_default_context(cafile=certs) if os.path.exists(certs) else ssl.create_default_context()
    except (OSError, ssl.SSLError):
        return ssl.create_default_context()


def fetch(url, timeout=15, limit=20 * 1024 * 1024):
    request = urllib.request.Request(url, headers={"User-Agent": xbmc.getUserAgent(), "Accept-Encoding": "gzip"})
    try:
        with urllib.request.urlopen(request, timeout=timeout, context=ssl_context()) as reply:
            body = reply.read(limit)
            if (reply.headers.get("Content-Encoding") or "").lower() == "gzip" or body[:2] == b"\x1f\x8b":
                body = gzip.decompress(body)
        return body
    except urllib.error.HTTPError as exc:
        raise Error("HTTP %d" % exc.code)
    except (OSError, ValueError, ssl.SSLError) as exc:
        raise Error(repr(exc))


def fetch_json(url, timeout=12):
    try:
        return json.loads(fetch(url, timeout).decode("utf-8", "replace") or "null")
    except ValueError:
        raise Error("not JSON")


def key(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()[:16]


def region():
    """Your country for the charts ("gb"), from Kodi's region."""
    code = (xbmc.getLanguage(xbmc.ISO_639_1, True) or "").split("-")[-1].lower()
    return code if len(code) == 2 and code.isalpha() else "us"


# --------------------------------------------------------------------------- finding podcasts

def show_from_itunes(r):
    return {"feed": r.get("feedUrl") or "", "title": r.get("collectionName") or r.get("trackName") or "",
            "author": r.get("artistName") or "", "art": r.get("artworkUrl600") or r.get("artworkUrl100") or "",
            "genre": r.get("primaryGenreName") or "", "count": int(r.get("trackCount") or 0)}


def search(words):
    reply = fetch_json("%s/search?%s" % (ITUNES, urllib.parse.urlencode(
        {"media": "podcast", "entity": "podcast", "term": words, "limit": 50, "country": region()})))
    return [s for s in (show_from_itunes(r) for r in (reply or {}).get("results") or []) if s["feed"]]


def top(limit=50):
    """Apple's top podcasts in your country (kept for half a day)."""
    cached = load_json("chart.json", {})
    if cached.get("region") == region() and time.time() - cached.get("t", 0) < CHART_AGE and cached.get("shows"):
        return cached["shows"]
    chart = fetch_json("%s/api/v2/%s/podcasts/top/%d/podcasts.json" % (CHARTS, region(), limit))
    ids = [str(r.get("id")) for r in ((chart or {}).get("feed") or {}).get("results") or [] if r.get("id")]
    if not ids:
        return []
    found = {}
    for n in range(0, len(ids), 50):  # (the charts don't have the feed addresses: look them up)
        reply = fetch_json("%s/lookup?%s" % (ITUNES, urllib.parse.urlencode({"id": ",".join(ids[n:n + 50]),
                                                                             "entity": "podcast"})))
        for r in (reply or {}).get("results") or []:
            found[str(r.get("collectionId"))] = show_from_itunes(r)
    shows = [found[i] for i in ids if i in found and found[i]["feed"]]
    save_json("chart.json", {"region": region(), "t": time.time(), "shows": shows})
    return shows


# --------------------------------------------------------------------------- feeds

def plain(text):
    """Show notes as plain text: no tags, no entities, tidy spaces."""
    text = re.sub(r"<(br|p|/p|li)[^>]*>", "\n", text or "", flags=re.I)
    text = html.unescape(re.sub(r"<[^>]+>", "", text))
    return re.sub(r"\n\s*\n+", "\n\n", re.sub(r"[ \t]+", " ", text)).strip()


def seconds(value):
    """itunes:duration: "3600", "1:02:03" or "62:03"."""
    try:
        parts = [float(p) for p in (value or "").strip().split(":")]
    except ValueError:
        return 0
    total = 0
    for p in parts:
        total = total * 60 + p
    return int(total)


def stamp(value):
    try:
        return int(email.utils.parsedate_to_datetime(value).timestamp())
    except (TypeError, ValueError, IndexError):
        return 0


def child(node, name):
    found = node.find(name)
    return (found.text or "").strip() if found is not None and found.text else ""


def parse(body, feed_url):
    try:
        root = ET.fromstring(body)
    except ET.ParseError:
        raise Error("not a feed")
    channel = root.find("channel")
    if channel is None:
        raise Error("not a podcast feed")
    image = channel.find(ITUNES_NS + "image")
    art = image.get("href") if image is not None and image.get("href") else ""
    if not art:
        art = child(channel.find("image") if channel.find("image") is not None else channel, "url")
    show = {"feed": feed_url, "title": child(channel, "title"), "author": child(channel, ITUNES_NS + "author"),
            "art": art, "plot": plain(child(channel, "description") or child(channel, ITUNES_NS + "summary")),
            "genre": (channel.find(ITUNES_NS + "category").get("text") or "")
            if channel.find(ITUNES_NS + "category") is not None else ""}
    episodes = []
    for item in channel.findall("item"):
        enclosure = item.find("enclosure")
        if enclosure is None or not enclosure.get("url"):
            continue
        eimage = item.find(ITUNES_NS + "image")
        guid = child(item, "guid") or enclosure.get("url")
        number = child(item, ITUNES_NS + "episode")
        episodes.append({
            "guid": guid, "title": child(item, "title") or child(item, ITUNES_NS + "title"),
            "url": enclosure.get("url"), "type": enclosure.get("type") or "audio/mpeg",
            "date": stamp(child(item, "pubDate")), "duration": seconds(child(item, ITUNES_NS + "duration")),
            "plot": plain(child(item, "description") or child(item, ITUNES_NS + "summary"))[:3000],
            "art": eimage.get("href") if eimage is not None and eimage.get("href") else "",
            "number": int(number) if number.isdigit() else 0})
    episodes.sort(key=lambda e: -e["date"])
    show["episodes"] = episodes
    return show


def feed(feed_url, max_age=FEED_AGE, timeout=15):
    """A podcast and its episodes, newest first (read again once max_age has passed;
    the last copy is used when the feed can't be reached)."""
    path = "feeds/%s.json" % key(feed_url)
    cached = load_json(path, {})
    if cached.get("episodes") is not None and time.time() - cached.get("t", 0) < max_age:
        return cached
    try:
        show = parse(fetch(feed_url, timeout), feed_url)
    except Error:
        if cached.get("episodes") is not None:
            return cached
        raise
    show["t"] = time.time()
    save_json(path, show)
    return show


def cached_feed(feed_url):
    return load_json("feeds/%s.json" % key(feed_url), {})


# --------------------------------------------------------------------------- your podcasts

def subscriptions():
    return [s for s in load_json("subscriptions.json", []) if isinstance(s, dict) and s.get("feed")]


def is_subscribed(feed_url):
    return any(s["feed"] == feed_url for s in subscriptions())


def subscribe(show, on):
    found = [s for s in subscriptions() if s["feed"] != show["feed"]]
    if on:
        found.append({"feed": show["feed"], "title": show.get("title", ""), "author": show.get("author", ""),
                      "art": show.get("art", ""), "added": time.time()})
        try:  # (what it has now isn't New)
            now = feed(show["feed"], max_age=600)
            mark_seen(show["feed"], now)
            mark_seen(show["feed"], now, "heard")
        except Error:
            pass
    save_json("subscriptions.json", found)
    write_home()


def mark_seen(feed_url, show, book="seen"):
    """book "seen": the episodes on the podcast's page when you last opened it (the
    rest are New); "heard": the ones the service has already told you about."""
    seen = load_json(book + ".json", {})
    seen[key(feed_url)] = [e["guid"] for e in show.get("episodes", [])[:300]]
    save_json(book + ".json", seen)


def new_episodes(show, book="seen"):
    """Episodes that arrived after the podcast was last looked at."""
    seen = set(load_json(book + ".json", {}).get(key(show["feed"]), []))
    return [e for e in show.get("episodes", []) if e["guid"] not in seen] if seen else []


# --------------------------------------------------------------------------- progress

def episode_key(feed_url, guid):
    return key(feed_url, guid)


def progress():
    return load_json("progress.json", {})


def state(feed_url, guid):
    """(position, total, played) of an episode."""
    p = progress().get(episode_key(feed_url, guid)) or {}
    return p.get("pos", 0), p.get("total", 0), bool(p.get("played"))


def set_played(feed_url, episode, show, played):
    data = progress()
    k = episode_key(feed_url, episode["guid"])
    data[k] = dict(entry(feed_url, episode, show), pos=0, total=episode.get("duration") or 0, played=played,
                   t=time.time())
    save_json("progress.json", data)
    write_home()


def set_all_played(feed_url, show):
    data = progress()
    for e in show.get("episodes", []):
        data[episode_key(feed_url, e["guid"])] = dict(entry(feed_url, e, show), pos=0, total=e.get("duration") or 0,
                                                      played=True, t=time.time())
    save_json("progress.json", data)
    write_home()


def entry(feed_url, e, show):
    """What's kept about an episode while it plays (and for Continue listening)."""
    return {"feed": feed_url, "guid": e["guid"], "title": e.get("title", ""), "show": show.get("title", ""),
            "art": e.get("art") or show.get("art", ""), "url": e.get("url", ""), "type": e.get("type", ""),
            "date": e.get("date", 0), "duration": e.get("duration", 0)}


def record(e, pos, total, furthest):
    data = progress()
    played = total > 0 and furthest >= PLAYED
    data[episode_key(e["feed"], e["guid"])] = dict(e, pos=0 if played else int(pos), total=int(total),
                                                   played=played, t=time.time())
    if len(data) > KEEP:
        for k, _ in sorted(data.items(), key=lambda kv: kv[1].get("t", 0))[:len(data) - KEEP]:
            del data[k]
    save_json("progress.json", data)
    write_home()


def continue_listening(limit=30):
    return [p for p in sorted(progress().values(), key=lambda p: -p.get("t", 0))
            if p.get("pos", 0) > 30 and not p.get("played")][:limit]


def latest(limit=50, days=30):
    """The newest episodes of your podcasts (from the feeds as last read), unplayed first."""
    found = []
    cutoff = time.time() - days * 86400
    done = {k for k, p in progress().items() if p.get("played")}
    for s in subscriptions():
        show = cached_feed(s["feed"])
        for e in show.get("episodes", [])[:10]:
            if e.get("date", 0) >= cutoff:
                found.append((e, show, episode_key(s["feed"], e["guid"]) in done))
    found.sort(key=lambda x: (x[2], -x[0].get("date", 0)))
    return found[:limit]


def play_address(feed_url, e, show, resume=None):
    params = {"mode": "play", "feed": feed_url, "guid": e["guid"]}
    if resume is not None:
        params["resume"] = int(bool(resume))
    return "plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode(params))


def ago(t):
    """"Today", "Yesterday", "3 days ago" or the date."""
    if not t:
        return ""
    days = int((time.time() - t) // 86400)
    addon = xbmcaddon.Addon(ADDON_ID)
    if days <= 0:
        return addon.getLocalizedString(30040)
    if days == 1:
        return addon.getLocalizedString(30041)
    if days < 7:
        return addon.getLocalizedString(30042) % days
    return time.strftime(xbmc.getRegion("dateshort"), time.localtime(t))


def minutes(secs):
    return xbmcaddon.Addon(ADDON_ID).getLocalizedString(30043) % max(1, round(secs / 60)) if secs else ""


def write_home():
    """home.json: MediaHub's Podcasts: New Episodes and Continue Listening rows."""
    cards = {"podlatest": [], "podcontinue": []}
    one_each = set()
    for e, show, played in latest(60):
        if played or show["feed"] in one_each:
            continue
        one_each.add(show["feed"])
        pos, total, _ = state(show["feed"], e["guid"])
        cards["podlatest"].append({
            "Label": e["title"], "Label2": "  •  ".join(p for p in (show.get("title", ""), ago(e.get("date"))) if p),
            "Title": e["title"], "Square": e.get("art") or show.get("art", ""),
            "Percent": str(int(100 * pos / total)) if pos and total else "",
            "Action": "podcast|run|" + play_address(show["feed"], e, show), "Kind": "podcast", "kids": True})
    for p in continue_listening(HOME_CARDS):
        left = max(0, (p.get("total") or 0) - (p.get("pos") or 0))
        cards["podcontinue"].append({
            "Label": p.get("title", ""), "Label2": "  •  ".join(x for x in (p.get("show", ""), minutes(left)) if x),
            "Title": p.get("title", ""), "Square": p.get("art", ""),
            "Percent": str(int(100 * p["pos"] / p["total"])) if p.get("total") else "",
            "Action": "podcast|run|" + play_address(p["feed"], p, {}, resume=True), "Kind": "podcast",
            "kids": True})
    cards["podlatest"] = cards["podlatest"][:HOME_CARDS]
    save_json("home.json", cards)
    xbmcgui.Window(10000).setProperty("MHP.Home", str(time.time()))  # (the helper refreshes the rows)
