"""MediaHub Space - NASA's Astronomy Picture of the Day, and where the space station is.

- NASA's APOD (api.nasa.gov): a picture of space each day with an astronomer's
  explanation. DEMO_KEY works without signing up (a few dozen requests an hour);
  a free key from api.nasa.gov can go in the add-on's settings.
- Where the ISS is now: wheretheiss.at (no key).

Kept in the add-on's data folder:
- pictures.json: the last few weeks' pictures [{date, title, explanation, url, hd,
  video, copyright}], newest first (the plugin, the home row, the screensaver)
- home.json: MediaHub's Space: Picture of the Day row
Window(Home): MHA.Picture / MHA.Title (today's picture, for MediaHub's background
and screensaver), MHA.Home (set when the cards change).
"""
import datetime
import gzip
import json
import os
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.image.mediahub.space"
NASA = os.environ.get("MEDIAHUB_NASA", "https://api.nasa.gov").rstrip("/")  # (a test server can stand in)
ISS = os.environ.get("MEDIAHUB_ISS", "https://api.wheretheiss.at").rstrip("/")
CERTS = "special://xbmc/system/certs/cacert.pem"
KEEP_DAYS = 30
HOME_CARDS = 14
YOUTUBE = "plugin.video.youtube"
YOUTUBE_ID = re.compile(r"(?:youtube(?:-nocookie)?\.com/(?:embed/|watch\?v=)|youtu\.be/)([A-Za-z0-9_-]{11})")


class Error(Exception):
    pass


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def text(string_id):
    return addon().getLocalizedString(string_id)


def profile(name=""):
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)


def load_json(name, default):
    try:
        with open(profile(name), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(name, data):
    path = profile(name)
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def ssl_context():
    certs = xbmcvfs.translatePath(CERTS)
    try:
        return ssl.create_default_context(cafile=certs) if os.path.exists(certs) else ssl.create_default_context()
    except (OSError, ssl.SSLError):
        return ssl.create_default_context()


def fetch_json(address, timeout=15):
    request = urllib.request.Request(address, headers={"User-Agent": xbmc.getUserAgent(), "Accept-Encoding": "gzip"})
    try:
        with urllib.request.urlopen(request, timeout=timeout, context=ssl_context()) as reply:
            body = reply.read(4 * 1024 * 1024)
        if body[:2] == b"\x1f\x8b":
            body = gzip.decompress(body)
        return json.loads(body.decode("utf-8", "replace") or "null")
    except urllib.error.HTTPError as exc:
        raise Error("HTTP %d" % exc.code)
    except (OSError, ValueError, ssl.SSLError) as exc:
        raise Error(repr(exc))


# --------------------------------------------------------------------------- NASA's picture of the day

def api_key():
    return addon().getSetting("nasa_key").strip() or "DEMO_KEY"


def tidy(p):
    """One of NASA's entries as it's kept: a picture (url, hd) or a video (its thumbnail)."""
    video = p.get("media_type") == "video"
    url = p.get("thumbnail_url", "") if video else p.get("url", "")
    return {"date": p.get("date", ""), "title": (p.get("title") or "").strip(), "url": url,
            "hd": p.get("hdurl") or url if not video else url, "video": p.get("url", "") if video else "",
            "explanation": (p.get("explanation") or "").strip(), "copyright": re.sub(r"\s+", " ", p.get("copyright") or "").strip()}


def fetch_days(days=KEEP_DAYS):
    """The last few weeks' pictures, newest first."""
    today = datetime.date.today()
    start = today - datetime.timedelta(days=days - 1)
    query = urllib.parse.urlencode({"api_key": api_key(), "start_date": start.isoformat(), "thumbs": "true"})
    found = fetch_json("%s/planetary/apod?%s" % (NASA, query))
    if isinstance(found, dict) and found.get("error"):
        raise Error(str(found["error"]))
    pictures = [tidy(p) for p in found or [] if isinstance(p, dict) and p.get("date")]
    pictures = [p for p in pictures if p["url"]]
    pictures.sort(key=lambda p: p["date"], reverse=True)
    return pictures


def random_picture():
    query = urllib.parse.urlencode({"api_key": api_key(), "count": 1, "thumbs": "true"})
    found = fetch_json("%s/planetary/apod?%s" % (NASA, query))
    for p in found or []:
        if isinstance(p, dict) and (p.get("url") or p.get("thumbnail_url")):
            return tidy(p)
    raise Error("nothing")


def pictures():
    return load_json("pictures.json", [])


def picture(date):
    return next((p for p in pictures() if p["date"] == date), None)


def refresh():
    """Fetch the last few weeks (kept), then the home row and today's picture for the skin."""
    try:
        found = fetch_days()
    except Error as exc:
        xbmc.log("MediaHub Space: %s" % exc, xbmc.LOGWARNING)
        found = []
    if found:
        save_json("pictures.json", found)
    write_home()


def show_address(date):
    return "plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode({"mode": "show", "date": date}))


def write_home():
    kept = pictures()
    cards = [{"Label": p["title"], "Label2": day_label(p["date"]), "Title": p["title"], "Landscape": p["url"],
              "Poster": p["url"], "Plot": p["explanation"][:400], "Action": "space|run|" + show_address(p["date"]),
              "Kind": "space", "kids": True} for p in kept[:HOME_CARDS]]
    save_json("home.json", {"spacepics": cards})
    home = xbmcgui.Window(10000)
    newest = next((p for p in kept if not p["video"]), None)
    home.setProperty("MHA.Picture", newest["hd"] if newest else "")
    home.setProperty("MHA.Title", newest["title"] if newest else "")
    home.setProperty("MHA.Home", str(time.time()))  # (the MediaHub Helper refreshes the rows)


def day_label(date):
    try:
        d = datetime.date.fromisoformat(date)
    except ValueError:
        return date
    if d == datetime.date.today():
        return xbmc.getLocalizedString(33006)  # Today
    return d.strftime(xbmc.getRegion("dateshort"))


def youtube_id(address):
    found = YOUTUBE_ID.search(address or "")
    return found.group(1) if found else ""


# --------------------------------------------------------------------------- the space station

def iss_now():
    """{lat, lon, km, kmh, daylight, where} - where is a country code, or "" over the sea."""
    here = fetch_json("%s/v1/satellites/25544" % ISS, 10)
    if not isinstance(here, dict) or "latitude" not in here:
        raise Error("iss")
    out = {"lat": float(here["latitude"]), "lon": float(here["longitude"]), "km": float(here.get("altitude") or 0),
           "kmh": float(here.get("velocity") or 0), "daylight": here.get("visibility") == "daylight", "where": ""}
    try:
        place = fetch_json("%s/v1/coordinates/%.4f,%.4f" % (ISS, out["lat"], out["lon"]), 10)
        code = (place or {}).get("country_code", "")
        out["where"] = code if code and code != "??" else ""
    except Error:
        pass
    return out
