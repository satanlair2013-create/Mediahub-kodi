"""MediaHub Space - NASA's Astronomy Picture of the Day, NASA's live video and
where the International Space Station is right now.

Today's picture, the last few weeks, a surprise one from the archive (since 1995),
NASA live (NASA's YouTube channel, with the YouTube add-on) and "Where is the ISS?".
A picture opens full screen with its explanation (OK shows or hides it).
"""
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import space  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name")
FANART = os.path.join(ADDON.getAddonInfo("path"), "resources", "fanart.jpg")
NASA_CHANNEL = "UCLA_DiR1FfKNvjuUpBHmylQ"  # (NASA's YouTube channel: its live stream)
ACTION_CLOSE = (9, 10, 92, 13)          # back, previous menu, nav back, stop
ACTION_TOGGLE = (7, 100, 11, 122)       # select, click, info, the info button


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)


def notify(message, error=False):
    xbmcgui.Dialog().notification(NAME, message, xbmcgui.NOTIFICATION_WARNING if error else
                                  xbmcgui.NOTIFICATION_INFO, 4000, False)


def entry(label, target, icon, label2="", folder=False, fanart=""):
    item = xbmcgui.ListItem(label, label2)
    item.setArt({"icon": icon, "thumb": icon, "fanart": fanart or FANART})
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=folder)


def end(content="", title=""):
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.setPluginCategory(HANDLE, title or NAME)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def ensure_pictures():
    if not space.pictures():
        try:
            space.refresh()
        except space.Error:
            pass
    return space.pictures()


# --------------------------------------------------------------------------- pages

def root():
    kept = ensure_pictures()
    today = kept[0] if kept else None
    if today:
        entry("%s: %s" % (text(30001), today["title"]), url(mode="show", date=today["date"]), today["url"],
              space.day_label(today["date"]), fanart=today["url"])
    entry(text(30002), url(mode="recent"), "DefaultPicture.png", folder=True)
    entry(text(30003), url(mode="random"), "DefaultAddonPicture.png")
    entry(text(30004), url(mode="live"), "DefaultAddonVideo.png")
    entry(text(30005), url(mode="iss"), "DefaultIconInfo.png")
    if not kept:
        notify(text(30020), True)
    end()


def picture_item(p):
    item = xbmcgui.ListItem(p["title"], space.day_label(p["date"]))
    item.setArt({"thumb": p["url"], "icon": p["url"], "fanart": p["url"], "poster": p["url"]})
    tag = item.getVideoInfoTag()
    tag.setTitle(p["title"])
    tag.setPlot(p["explanation"])
    tag.setPremiered(p["date"])
    item.addContextMenuItems([(text(30006), "RunPlugin(%s)" % url(mode="about", date=p["date"]))])
    xbmcplugin.addDirectoryItem(HANDLE, url(mode="show", date=p["date"]), item, isFolder=False)


def recent():
    for p in ensure_pictures():
        picture_item(p)
    end("images", text(30002))


# --------------------------------------------------------------------------- a picture, full screen

class Viewer(xbmcgui.WindowDialog):
    """The picture filling the screen, and its explanation over the bottom (OK hides it)."""

    def __init__(self, p):
        super().__init__()
        temp = os.path.join(ADDON.getAddonInfo("path"), "resources")
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, os.path.join(temp, "black.png")))
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, p["hd"] or p["url"], aspectRatio=2))
        self.panel = xbmcgui.ControlImage(0, 470, 1280, 250, os.path.join(temp, "shade.png"))
        self.addControl(self.panel)
        credit = "  •  © %s" % p["copyright"] if p.get("copyright") else ""
        self.title = xbmcgui.ControlLabel(60, 490, 1160, 40, "[B]%s[/B]" % p["title"], font="font30",
                                          textColor="FFFFFFFF")
        self.meta = xbmcgui.ControlLabel(60, 530, 1160, 30, space.day_label(p["date"]) + credit, font="font12",
                                         textColor="FFB0B8C8")
        self.words = xbmcgui.ControlTextBox(60, 565, 1160, 140, font="font12", textColor="FFE6E9F0")
        for c in (self.title, self.meta, self.words):
            self.addControl(c)
        self.words.setText(p["explanation"])
        self.words.autoScroll(6000, 2500, 4000)
        self.shown = True

    def onAction(self, action):
        if action.getId() in ACTION_CLOSE:
            self.close()
        elif action.getId() in ACTION_TOGGLE:
            self.shown = not self.shown
            for c in (self.panel, self.title, self.meta, self.words):
                c.setVisible(self.shown)


def show(p):
    if p is None:
        return notify(text(30020), True)
    if p["video"]:  # (some days it's a video: on YouTube, or a file)
        found = space.youtube_id(p["video"])
        if found:
            return play_youtube("plugin://%s/play/?video_id=%s" % (space.YOUTUBE, found), p["title"])
        if p["video"].lower().split("?")[0].endswith((".mp4", ".m4v", ".webm", ".mov")):
            return xbmc.Player().play(p["video"], xbmcgui.ListItem(p["title"]))
        return about(p)
    viewer = Viewer(p)
    viewer.doModal()
    del viewer


def about(p):
    if p:
        xbmcgui.Dialog().textviewer("%s  (%s)" % (p["title"], space.day_label(p["date"])),
                                    p["explanation"] + ("\n\n© %s" % p["copyright"] if p.get("copyright") else ""))


def play_youtube(address, title):
    if not xbmc.getCondVisibility("System.HasAddon(%s)" % space.YOUTUBE):
        if xbmcgui.Dialog().yesno(NAME, text(30008)):
            xbmc.executebuiltin("InstallAddon(%s)" % space.YOUTUBE)
        return
    xbmc.Player().play(address, xbmcgui.ListItem(title))


def iss():
    try:
        here = space.iss_now()
    except space.Error:
        return notify(text(30021), True)
    lat = "%.1f°%s" % (abs(here["lat"]), "N" if here["lat"] >= 0 else "S")
    lon = "%.1f°%s" % (abs(here["lon"]), "E" if here["lon"] >= 0 else "W")
    lines = [text(30010) % (int(round(here["km"])), lat, lon)]
    lines.append(text(30011) % here["where"] if here["where"] else text(30012))
    lines.append(text(30013) % "{:,}".format(int(round(here["kmh"]))))
    lines.append(text(30014 if here["daylight"] else 30015))
    xbmcgui.Dialog().ok(text(30005), "\n".join(lines))


def main():
    mode = ARGS.get("mode")
    if mode is None:
        root()
    elif mode == "recent":
        recent()
    elif mode == "show":
        show(space.picture(ARGS.get("date", "")))
    elif mode == "about":
        about(space.picture(ARGS.get("date", "")))
    elif mode == "random":
        try:
            show(space.random_picture())
        except space.Error:
            notify(text(30020), True)
    elif mode == "live":
        play_youtube("plugin://%s/play/?channel_id=%s&live=1" % (space.YOUTUBE, NASA_CHANNEL), text(30004))
    elif mode == "iss":
        iss()
    elif mode == "refresh":
        space.refresh()


if __name__ == "__main__":
    main()
