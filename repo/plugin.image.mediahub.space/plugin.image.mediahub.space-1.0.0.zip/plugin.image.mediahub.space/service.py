"""MediaHub Space - in the background: fetch NASA's pictures a little after Kodi
starts and then every few hours (a new one comes each day), for the home row and
MediaHub's background and screensaver."""
import os
import sys
import threading
import time

import xbmc

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import space  # noqa: E402

FIRST = 45            # seconds after Kodi starts
EVERY = 4 * 3600


class Service(xbmc.Monitor):
    def run(self):
        space.write_home()  # (what was kept, straight away)
        due = time.time() + FIRST
        while not self.waitForAbort(5):
            if time.time() >= due and not xbmc.getCondVisibility("Player.HasVideo"):
                due = time.time() + EVERY
                threading.Thread(target=self.refresh, daemon=True).start()

    def refresh(self):
        try:
            space.refresh()
        except Exception as exc:  # (never take the service down)
            xbmc.log("MediaHub Space: %r" % exc, xbmc.LOGWARNING)


if __name__ == "__main__":
    Service().run()
