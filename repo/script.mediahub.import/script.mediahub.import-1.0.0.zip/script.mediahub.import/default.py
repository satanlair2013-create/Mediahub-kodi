"""MediaHub Import - bring your IMDb and Letterboxd lists and ratings into Kodi.

Pick an export file (IMDb's .csv of your ratings, your watchlist or a list;
Letterboxd's .zip, or one of its .csv files), and the titles you have in your
library get:
- your watchlist or list: added to My List (MediaHub's "My List" tag, in the
  list's order)
- your ratings: MediaHub's thumbs (Kodi's user rating: 9-10 love, 6-8 up,
  1-4 down; out of ten, a Letterboxd 4.5 is a 9), and Letterboxd's liked films: love
- what you've rated or watched: films marked as watched
Titles are matched by IMDb id (IMDb) or title and year (Letterboxd), and it ends
with what was found and what isn't in your library.
"""
import json
import os
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import importer  # noqa: E402

ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name")
MYLIST_TAG = "My List"
MYLIST_FILE = "special://profile/addon_data/script.mediahub.helper/mylist.json"
MISSING_SHOWN = 300


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                       "params": params})))
    return reply.get("result") or {}


def library():
    movies = rpc("VideoLibrary.GetMovies", properties=["title", "originaltitle", "year", "uniqueid", "tag",
                                                        "userrating", "playcount"]).get("movies") or []
    shows = rpc("VideoLibrary.GetTVShows", properties=["title", "originaltitle", "year", "uniqueid", "tag",
                                                        "userrating"]).get("tvshows") or []
    return importer.Library(movies, shows)


def read_file(path):
    f = xbmcvfs.File(path)
    try:
        return bytes(f.readBytes())
    finally:
        f.close()


def load_mylist():
    try:
        with open(xbmcvfs.translatePath(MYLIST_FILE), encoding="utf-8") as f:
            found = json.load(f)
        return found if isinstance(found, list) else []
    except (OSError, ValueError):
        return []


def save_mylist(entries):
    path = xbmcvfs.translatePath(MYLIST_FILE)
    xbmcvfs.mkdirs(os.path.dirname(path))
    with open(path, "w", encoding="utf-8") as f:
        json.dump(entries, f)


def plan(found, lib, replace_thumbs):
    """What would change: {"mylist": [(kind, d)], "thumbs": [(kind, d, value)],
    "watched": [(d, date)]} and the titles not in the library."""
    todo = {"mylist": [], "thumbs": [], "watched": []}
    missing, seen = [], set()

    def match(e):
        hit = lib.find(e)
        if not hit:
            key = (e["title"], e["year"])
            if key not in seen:
                seen.add(key)
                missing.append("%s (%s)" % (e["title"], e["year"]) if e["year"] else e["title"])
        return hit

    added = set()
    for e in found["mylist"]:
        hit = match(e)
        if hit and MYLIST_TAG not in (hit[1].get("tag") or []) and (hit[0], id(hit[1])) not in added:
            added.add((hit[0], id(hit[1])))
            todo["mylist"].append(hit)
    rated = {}
    for e in found["rated"]:
        hit = match(e)
        if hit and importer.thumb(e["rating"]):
            rated[(hit[0], id(hit[1]))] = (hit[0], hit[1], importer.thumb(e["rating"]))
    for e in found["loved"]:
        hit = match(e)
        if hit:
            rated[(hit[0], id(hit[1]))] = (hit[0], hit[1], 10)
    for kind, d, value in rated.values():
        if (replace_thumbs or not d.get("userrating")) and d.get("userrating") != value:
            todo["thumbs"].append((kind, d, value))
    marked = set()
    for e in found["watched"]:
        hit = match(e)
        if hit and hit[0] == "movie" and not hit[1].get("playcount") and id(hit[1]) not in marked:
            marked.add(id(hit[1]))
            todo["watched"].append((hit[1], e.get("date") or ""))
    return todo, missing


def apply(todo):
    progress = xbmcgui.DialogProgress()
    progress.create(NAME, text(30010))
    steps = max(1, sum(len(v) for v in todo.values()))
    done = 0
    entries = load_mylist()
    now = int(time.time())
    for n, (kind, d) in enumerate(todo["mylist"]):
        method = "VideoLibrary.SetMovieDetails" if kind == "movie" else "VideoLibrary.SetTVShowDetails"
        rpc(method, **{kind + "id": d[kind + "id"], "tag": (d.get("tag") or []) + [MYLIST_TAG]})
        entries = [e for e in entries if not (e[0] == kind and e[1] == d[kind + "id"])]
        entries.append([kind, d[kind + "id"], now - n])  # (the list's order: its first comes first)
        done += 1
        progress.update(int(100 * done / steps), d.get("title", ""))
        if progress.iscanceled():
            break
    if todo["mylist"]:
        save_mylist(entries)
    for kind, d, value in todo["thumbs"]:
        method = "VideoLibrary.SetMovieDetails" if kind == "movie" else "VideoLibrary.SetTVShowDetails"
        rpc(method, **{kind + "id": d[kind + "id"], "userrating": value})
        done += 1
        progress.update(int(100 * done / steps), d.get("title", ""))
        if progress.iscanceled():
            break
    for d, date in todo["watched"]:
        details = {"movieid": d["movieid"], "playcount": 1}
        if len(date) >= 10 and date[4] == "-":
            details["lastplayed"] = date[:10] + " 20:00:00"
        rpc("VideoLibrary.SetMovieDetails", **details)
        done += 1
        progress.update(int(100 * done / steps), d.get("title", ""))
        if progress.iscanceled():
            break
    progress.close()
    xbmcgui.Window(10000).setProperty("MH.Req.Rows", "import")  # (MediaHub's home rows)
    xbmc.executebuiltin("Container.Refresh")


def run_import(path=None):
    path = path or xbmcgui.Dialog().browseSingle(1, text(30002), "files", ".csv|.zip")
    if not path:
        return
    try:
        found = importer.read(os.path.basename(path), read_file(path))
    except Exception as exc:  # (a file that isn't an export)
        xbmc.log("MediaHub Import: %r" % exc, xbmc.LOGWARNING)
        found = importer.empty()
    total = sum(len(v) for v in found.values())
    if not total:
        return xbmcgui.Dialog().ok(NAME, text(30003))
    lib = library()
    todo, missing = plan(found, lib, False)
    choices = [("mylist", text(30004) % len(todo["mylist"])), ("thumbs", text(30005) % len(todo["thumbs"])),
               ("watched", text(30006) % len(todo["watched"])), ("replace", text(30007))]
    shown = [(key, label) for key, label in choices if key == "replace" and (found["rated"] or found["loved"])
             or key != "replace" and todo[key]]
    if not any(key != "replace" for key, _label in shown):
        return report(found, todo, missing, nothing=True)
    picked = xbmcgui.Dialog().multiselect(text(30008), [label for _key, label in shown],
                                          preselect=[n for n, (key, _l) in enumerate(shown) if key != "replace"])
    if not picked:
        return
    keys = {shown[n][0] for n in picked}
    if "replace" in keys:
        todo, missing = plan(found, lib, True)
    for key in ("mylist", "thumbs", "watched"):
        if key not in keys:
            todo[key] = []
    apply(todo)
    report(found, todo, missing)


def report(found, todo, missing, nothing=False):
    lines = []
    if nothing:
        lines.append(text(30011))
    else:
        lines += [text(30014) % len(todo["mylist"]), text(30015) % len(todo["thumbs"]),
                  text(30016) % len(todo["watched"])]
    if missing:
        lines += ["", "[B]%s[/B]" % (text(30012) % len(missing))]
        lines += missing[:MISSING_SHOWN]
        if len(missing) > MISSING_SHOWN:
            lines.append("…")
    xbmcgui.Dialog().textviewer(NAME, "\n".join(lines))


def main():
    while True:
        pick = xbmcgui.Dialog().select(NAME, [text(30001), text(30009)])
        if pick == 0:
            return run_import()
        if pick == 1:
            xbmcgui.Dialog().textviewer(text(30009), text(30013))
            continue
        return


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1]:  # RunScript(script.mediahub.import,<file>)
        run_import(sys.argv[1])
    else:
        main()
