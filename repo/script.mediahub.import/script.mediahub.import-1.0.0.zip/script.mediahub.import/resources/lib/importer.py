"""MediaHub Import - reading IMDb and Letterboxd exports, and finding the titles in
the library. (No Kodi calls here: default.py does those.)

IMDb (imdb.com > Your ratings / Your watchlist / a list > Export) gives a .csv:
  ratings:   Const, Your Rating, Date Rated, Title, ..., Title Type, ..., Year, ...
  watchlist or a list: Position, Const, Created, ..., Title, ..., Title Type, ..., Year, ...
Letterboxd (Settings > Data > Export your data) gives a .zip holding watched.csv,
ratings.csv (Rating out of 5, in halves), watchlist.csv and likes/films.csv; each
has Date, Name, Year, Letterboxd URI. Letterboxd has no IMDb ids, so its films are
matched by title and year.

read(name, data) -> {"mylist": [...], "rated": [...], "watched": [...], "loved": [...]},
each a list of {"title", "year", "imdb", "show", "rating" (1-10), "date"}.
"""
import csv
import io
import re
import unicodedata
import zipfile

SHOW_TYPES = ("tv series", "tvseries", "tv mini series", "tvminiseries", "tv mini-series")


def rows(text):
    return list(csv.DictReader(io.StringIO(text)))


def decode(data):
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", "replace")


def number(value, default=0.0):
    try:
        return float(str(value).strip())
    except (TypeError, ValueError):
        return default


def year_of(value):
    found = re.search(r"\d{4}", str(value or ""))
    return int(found.group(0)) if found else 0


def imdb_entry(row):
    kind = (row.get("Title Type") or "").strip().lower()
    return {"title": (row.get("Title") or "").strip(), "year": year_of(row.get("Year")),
            "imdb": (row.get("Const") or "").strip(), "show": kind in SHOW_TYPES,
            "rating": int(number(row.get("Your Rating"))), "date": (row.get("Date Rated") or row.get("Created") or "")}


def letterboxd_entry(row):
    # Letterboxd rates out of five in halves: out of ten here, like IMDb
    return {"title": (row.get("Name") or "").strip(), "year": year_of(row.get("Year")), "imdb": "",
            "show": False, "rating": int(round(number(row.get("Rating")) * 2)), "date": row.get("Date") or ""}


def empty():
    return {"mylist": [], "rated": [], "watched": [], "loved": []}


def read_imdb(text, name, found):
    table = rows(text)
    if not table:
        return
    header = set(table[0].keys())
    entries = [imdb_entry(r) for r in table if (r.get("Const") or "").startswith("tt")]
    is_list = "Position" in header or "watchlist" in name.lower()
    if is_list:
        found["mylist"] += entries
    rated = [e for e in entries if e["rating"]]
    found["rated"] += rated
    found["watched"] += [e for e in rated if not e["show"]]  # (you rated it: you've seen it)


def read_letterboxd(text, name, found):
    table = rows(text)
    if not table:
        return
    entries = [letterboxd_entry(r) for r in table if r.get("Name")]
    low = name.lower().replace("\\", "/")
    if low.endswith("watchlist.csv"):
        found["mylist"] += entries
    elif low.endswith("likes/films.csv"):
        found["loved"] += entries
    elif low.endswith("ratings.csv") or "Rating" in table[0]:
        found["rated"] += [e for e in entries if e["rating"]]
        found["watched"] += entries
    elif low.endswith(("watched.csv", "diary.csv")):
        found["watched"] += entries


def read_csv(name, data, found):
    text = decode(data)
    first = text.split("\n", 1)[0]
    if "Const" in first:
        read_imdb(text, name, found)
    elif "Letterboxd URI" in first or "Name" in first:
        read_letterboxd(text, name, found)


def read(name, data):
    """What an export holds (a .csv, or Letterboxd's .zip)."""
    found = empty()
    if name.lower().endswith(".zip") or data[:2] == b"PK":
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for inner in z.namelist():
                low = inner.lower()
                if not low.endswith(".csv") or "/deleted/" in low or "orphaned" in low:
                    continue
                if low.endswith(("watched.csv", "ratings.csv", "watchlist.csv", "likes/films.csv")):
                    read_csv(inner, z.read(inner), found)
    else:
        read_csv(name, data, found)
    for key in found:  # one of each title per kind
        seen, unique = set(), []
        for e in found[key]:
            k = (e["imdb"] or norm(e["title"]), e["year"], e["show"])
            if k not in seen:
                seen.add(k)
                unique.append(e)
        found[key] = unique
    return found


# --------------------------------------------------------------------------- matching

def norm(title):
    title = unicodedata.normalize("NFKD", title or "").encode("ascii", "ignore").decode("ascii").lower()
    title = title.replace("&", " and ")
    title = re.sub(r"[^a-z0-9 ]+", " ", title)
    title = re.sub(r"^(the|a|an) ", "", title.strip())
    return re.sub(r"\s+", " ", title).strip()


class Library:
    """The films and shows in the library, looked up by IMDb id or title and year."""

    def __init__(self, movies, shows):
        self.by_id, self.by_title = {}, {}
        for kind, items in (("movie", movies), ("tvshow", shows)):
            for d in items:
                entry = (kind, d)
                imdb = ((d.get("uniqueid") or {}).get("imdb") or "") if isinstance(d.get("uniqueid"), dict) else ""
                if imdb.startswith("tt"):
                    self.by_id[imdb] = entry
                for t in {d.get("title") or "", d.get("originaltitle") or ""}:
                    if t:
                        self.by_title.setdefault((norm(t), kind == "tvshow"), []).append(entry)

    def find(self, e):
        if e.get("imdb") and e["imdb"] in self.by_id:
            return self.by_id[e["imdb"]]
        candidates = self.by_title.get((norm(e["title"]), bool(e.get("show"))), [])
        if not candidates:
            return None
        if not e.get("year"):
            return candidates[0] if len(candidates) == 1 else None
        best = sorted(candidates, key=lambda c: abs((c[1].get("year") or 0) - e["year"]))[0]
        return best if abs((best[1].get("year") or 0) - e["year"]) <= 1 else None


def thumb(rating):
    """Out of ten -> MediaHub's thumbs (Kodi's user rating): 10 love, 8 up, 2 down;
    a middling 5 is left alone."""
    if rating >= 9:
        return 10
    if rating >= 6:
        return 8
    if 0 < rating <= 4:
        return 2
    return 0
