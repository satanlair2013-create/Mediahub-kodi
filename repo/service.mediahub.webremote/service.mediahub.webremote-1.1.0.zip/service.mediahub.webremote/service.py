"""MediaHub Web Remote - use a phone's web browser as Kodi's remote.

A small web server on the home network (port 8585 by default) serves the remote
page and answers it. Nothing is installed on the phone: open the address (or
scan the QR code from Connect a phone) and enter the code the TV shows once.
"""
import http.server
import json
import os
import socketserver
import sys
import threading
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import remote  # noqa: E402

WEB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "web")
PAGE_TYPES = {".html": "text/html; charset=utf-8", ".js": "application/javascript", ".css": "text/css",
              ".png": "image/png", ".json": "application/manifest+json", ".svg": "image/svg+xml"}
ASK_EVERY = 20  # seconds between codes a phone can ask the TV to show


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "MediaHubRemote"
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def reply(self, code, body=b"", kind="application/json", cache=False):
        if not isinstance(body, bytes):
            body = json.dumps(body).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", kind)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "max-age=86400" if cache else "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(body)

    def body(self):
        size = min(int(self.headers.get("Content-Length") or 0), 64 * 1024)
        try:
            return json.loads(self.rfile.read(size).decode("utf-8") or "{}") if size else {}
        except ValueError:
            return {}

    def allowed(self):
        return remote.valid(self.headers.get("X-Remote-Key", ""))

    def do_GET(self):
        path, _, query = self.path.partition("?")
        q = dict(urllib.parse.parse_qsl(query))
        if path in ("/", "/index.html"):
            return self.static("index.html")
        if path in ("/manifest.json", "/icon.png"):
            return self.static(path[1:])
        if path == "/api/strings":  # (the page's words, in Kodi's language)
            addon = xbmcaddon.Addon()
            return self.reply(200, {str(n): addon.getLocalizedString(n) for n in range(30100, 30160)
                                    if addon.getLocalizedString(n)})
        # (a picture's <img> can't send the header: its address carries the key)
        if not self.allowed() and not (path == "/art" and remote.valid(q.get("k", ""))):
            return self.reply(401, {"error": "pair"})
        try:
            if path == "/api/state":
                return self.reply(200, remote.state())
            if path == "/api/search":
                return self.reply(200, remote.search(q.get("q", "")))
            if path == "/api/channels":
                return self.reply(200, remote.channels())
            if path == "/api/inbox":
                return self.reply(200, remote.inbox_info())
            if path == "/api/quiz":
                return self.reply(200, remote.quiz_state(self.headers.get("X-Remote-Key", "")))
            if path == "/art":
                body, kind = remote.picture(q.get("u", ""))
                return self.reply(200, body, kind, cache=True) if body else self.reply(404, {})
        except Exception as exc:  # (a bad request never stops the remote)
            xbmc.log("MediaHub Web Remote: %r" % exc, xbmc.LOGWARNING)
            return self.reply(500, {"error": "failed"})
        self.reply(404, {"error": "not found"})

    def do_POST(self):
        path, _, query = self.path.partition("?")
        if path == "/api/upload":  # (a picture or video from the phone, as the raw body)
            return self.upload(dict(urllib.parse.parse_qsl(query)))
        data = self.body()
        if path == "/api/pair/ask":
            return self.reply(200, self.server.ask_for_code())
        if path == "/api/pair":
            token = remote.pair(str(data.get("code", "")), str(data.get("name", "")))
            return self.reply(200 if token else 403, {"key": token} if token else {"error": "code"})
        if not self.allowed():
            return self.reply(401, {"error": "pair"})
        try:
            if path == "/api/do":
                remote.do(str(data.get("action", "")))
            elif path == "/api/seek":
                remote.seek(data.get("percent"), data.get("seconds"))
            elif path == "/api/volume":
                remote.volume(data.get("level"), data.get("step"), data.get("mute"))
            elif path == "/api/text":
                remote.send_text(str(data.get("text", ""))[:500], bool(data.get("done", True)))
            elif path == "/api/open":
                remote.open_item(data if isinstance(data, dict) else {})
            elif path == "/api/link":
                return self.reply(200, remote.play_link(str(data.get("url", ""))[:2000]))
            elif path == "/api/youtube":
                remote.install_youtube()
            elif path == "/api/show":
                remote.show_batch(data.get("batch"))
            elif path == "/api/inbox/clear":
                remote.clear_inbox()
            elif path == "/api/quiz/join":
                slot = remote.quiz_join(self.headers.get("X-Remote-Key", ""), data.get("name"))
                return self.reply(200 if slot else 409, {"slot": slot})
            elif path == "/api/quiz/answer":
                ok = remote.quiz_answer(self.headers.get("X-Remote-Key", ""), data.get("qid"), data.get("choice"))
                return self.reply(200 if ok else 409, {"ok": ok})
            else:
                return self.reply(404, {"error": "not found"})
        except Exception as exc:
            xbmc.log("MediaHub Web Remote: %r" % exc, xbmc.LOGWARNING)
            return self.reply(500, {"error": "failed"})
        self.reply(200, {"ok": True})

    def upload(self, q):
        size = int(self.headers.get("Content-Length") or 0)
        if not self.allowed():
            self.close_connection = True
            return self.reply(401, {"error": "pair"})
        try:
            saved = remote.save_upload(self.rfile, size, q.get("batch"), q.get("name"))
        except OSError as exc:
            xbmc.log("MediaHub Web Remote: upload: %r" % exc, xbmc.LOGWARNING)
            saved = None
        if not saved:
            self.close_connection = True  # (what's left of the body isn't read)
            return self.reply(400, {"error": "file"})
        self.reply(200, {"ok": True})

    def static(self, name):
        path = os.path.join(WEB, name) if name != "icon.png" else \
            os.path.join(os.path.dirname(WEB), "icon.png")
        try:
            with open(path, "rb") as f:
                body = f.read()
        except OSError:
            return self.reply(404, {})
        self.reply(200, body, PAGE_TYPES.get(os.path.splitext(name)[1], "application/octet-stream"),
                   cache=name != "index.html")


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, port):
        super().__init__(("", port), Handler)
        self.last_ask = 0.0

    def ask_for_code(self):
        """A phone wants to pair: show a code on the TV (at most every ASK_EVERY seconds)."""
        now = time.time()
        if remote.current_code() or now - self.last_ask < ASK_EVERY:
            return {"shown": True}
        self.last_ask = now
        code = remote.new_code()
        addon = xbmcaddon.Addon()
        threading.Thread(target=xbmcgui.Dialog().ok, args=(addon.getAddonInfo("name"),
                                                          addon.getLocalizedString(30011) % " ".join(code)),
                         daemon=True).start()
        return {"shown": True}


class Service(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.server = None
        self.port = None

    def start(self):
        addon = xbmcaddon.Addon()
        if not addon.getSettingBool("enabled"):
            return
        self.port = remote.port_setting()
        try:
            self.server = Server(self.port)
        except OSError as exc:
            xbmc.log("MediaHub Web Remote: port %d: %r" % (self.port, exc), xbmc.LOGWARNING)
            xbmcgui.Dialog().notification(addon.getAddonInfo("name"), addon.getLocalizedString(30013) % self.port,
                                          xbmcgui.NOTIFICATION_WARNING, 6000)
            self.server = None
            return
        threading.Thread(target=self.server.serve_forever, kwargs={"poll_interval": 0.5}, daemon=True).start()
        xbmcgui.Window(10000).setProperty("MHW.Address", remote.address())

    def stop(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            self.server = None
        xbmcgui.Window(10000).clearProperty("MHW.Address")

    def onSettingsChanged(self):
        addon = xbmcaddon.Addon()
        if bool(self.server) != addon.getSettingBool("enabled") or remote.port_setting() != self.port:
            self.stop()
            self.start()

    def run(self):
        self.start()
        while not self.waitForAbort(5):
            if self.server:  # (the address changes when the network does)
                xbmcgui.Window(10000).setProperty("MHW.Address", remote.address())
        self.stop()


if __name__ == "__main__":
    Service().run()
