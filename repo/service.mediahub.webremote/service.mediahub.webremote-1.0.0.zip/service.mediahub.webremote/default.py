"""MediaHub Web Remote - Connect a phone.

Shows the remote's address and a QR code that opens it on the phone and pairs it
in one go (the QR code carries a pairing code that works for three minutes).
RunScript(service.mediahub.webremote,forget) forgets every paired phone.
"""
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import remote  # noqa: E402

ADDON = xbmcaddon.Addon()
ACTION_CLOSE = (9, 10, 92, 7, 100, 101, 13)  # back, previous menu, nav back, select, clicks, stop


def solid(path, rgba):
    """A one-pixel PNG of one colour (the panel behind the QR code)."""
    import struct
    import zlib

    def chunk(kind, body):
        return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body) & 0xffffffff)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0)) + \
        chunk(b"IDAT", zlib.compress(b"\x00" + bytes(rgba))) + chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(png)
    return path


class Connect(xbmcgui.WindowDialog):
    def __init__(self, qr, lines):
        super().__init__()
        temp = xbmcvfs.translatePath("special://temp/")
        panel = solid(os.path.join(temp, "mhremote-panel.png"), (20, 24, 36, 245))
        white = solid(os.path.join(temp, "mhremote-white.png"), (255, 255, 255, 255))
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, panel))
        self.addControl(xbmcgui.ControlImage(100, 150, 420, 420, white))
        self.addControl(xbmcgui.ControlImage(110, 160, 400, 400, qr))
        self.addControl(xbmcgui.ControlLabel(580, 120, 620, 60, "[B]%s[/B]" % ADDON.getAddonInfo("name"),
                                             font="font30", textColor="FFFFFFFF"))
        y = 200
        for text, colour, height in lines:
            box = xbmcgui.ControlTextBox(580, y, 620, height, font="font13", textColor=colour)
            self.addControl(box)
            box.setText(text)  # (a text box, so a long line wraps)
            y += height + 10

    def onAction(self, action):
        if action.getId() in ACTION_CLOSE:
            self.close()


def connect():
    if not ADDON.getSettingBool("enabled"):
        if not xbmcgui.Dialog().yesno(ADDON.getAddonInfo("name"), ADDON.getLocalizedString(30014)):
            return
        ADDON.setSettingBool("enabled", True)
        xbmc.sleep(1500)  # (the service starts the remote)
    code = remote.new_code()
    where = remote.address()
    qr = remote.qr_png("%s/#code=%s" % (where, code),
                       os.path.join(xbmcvfs.translatePath("special://temp/"), "mhremote-qr-%s.png" % code))
    phones = len(remote.tokens())
    lines = [(ADDON.getLocalizedString(30015), "FFB0B8C8", 60),
             ("[B]%s[/B]" % where, "FFFFFFFF", 40),
             (ADDON.getLocalizedString(30016) % " ".join(code), "FFB0B8C8", 40),
             (ADDON.getLocalizedString(30017), "FF8890A0", 60)]
    if phones:
        lines.append((ADDON.getLocalizedString(30018) % phones, "FF8890A0", 40))
    dialog = Connect(qr, lines)
    dialog.doModal()
    del dialog


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "forget":
        if xbmcgui.Dialog().yesno(ADDON.getAddonInfo("name"), ADDON.getLocalizedString(30019)):
            remote.forget_phones()
    else:
        connect()
