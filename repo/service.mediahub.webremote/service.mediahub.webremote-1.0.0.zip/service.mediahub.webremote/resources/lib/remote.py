"""MediaHub Web Remote - what the phone page asks Kodi for.

Everything goes through Kodi's own JSON-RPC (xbmc.executeJSONRPC), so Kodi's web
server doesn't have to be on. A phone has to be paired once: it gets a key that
it sends with every request (a header, so another web page can't send it).
"""
import json
import os
import re
import secrets
import struct
import time
import urllib.parse
import zlib

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "service.mediahub.webremote"
XTREAM = "plugin.video.mediahub.xtream"
RADIO = "plugin.audio.mediahub.radio"
PAIR = "MHW.Pair"  # Window(Home) property: {"code": "4821", "until": epoch} while a code is on the TV
PAIR_TIME = 180
MAX_TRIES = 8
# Input.ExecuteAction names the page may send
ACTIONS = {"up", "down", "left", "right", "select", "back", "info", "contextmenu", "osd", "playpause", "stop",
           "skipnext", "skipprevious", "stepforward", "stepback", "bigstepforward", "bigstepback", "volumeup",
           "volumedown", "mute", "fullscreen", "nextsubtitle", "showsubtitles", "audionextlanguage",
           "pageup", "pagedown", "channelup", "channeldown"}


def profile(name=""):
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)


def load_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(path, data):
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                       "params": params})))
    return reply.get("result")


def has_addon(addon_id):
    return xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id)


def text(string_id):
    return xbmcaddon.Addon(ADDON_ID).getLocalizedString(string_id)


# --------------------------------------------------------------------------- pairing

def tokens():
    return load_json(profile("phones.json"), {})


def valid(token):
    return bool(token) and token in tokens()


def new_code():
    """A pairing code for the TV to show (and the QR code to carry)."""
    code = "%04d" % secrets.randbelow(10000)
    xbmcgui.Window(10000).setProperty(PAIR, json.dumps({"code": code, "until": time.time() + PAIR_TIME,
                                                        "tries": 0}))
    return code


def current_code():
    try:
        pair = json.loads(xbmcgui.Window(10000).getProperty(PAIR) or "{}")
    except ValueError:
        return None
    return pair if pair.get("until", 0) > time.time() and pair.get("tries", 0) < MAX_TRIES else None


def pair(code, name):
    """The phone's key when the code is the one on the TV (None otherwise)."""
    pending = current_code()
    if not pending:
        return None
    if not secrets.compare_digest(str(code), pending["code"]):
        pending["tries"] = pending.get("tries", 0) + 1
        xbmcgui.Window(10000).setProperty(PAIR, json.dumps(pending))
        return None
    xbmcgui.Window(10000).clearProperty(PAIR)
    token = secrets.token_urlsafe(24)
    phones = tokens()
    phones[token] = {"name": (name or "Phone")[:60], "added": time.time()}
    save_json(profile("phones.json"), phones)
    xbmc.executebuiltin("Dialog.Close(okdialog)")  # (the code on the TV isn't needed now)
    xbmcgui.Dialog().notification(xbmcaddon.Addon(ADDON_ID).getAddonInfo("name"), text(30012) % phones[token]["name"],
                                  xbmcaddon.Addon(ADDON_ID).getAddonInfo("icon"), 4000, False)
    return token


def forget_phones():
    save_json(profile("phones.json"), {})


def address():
    """This Kodi's address on the home network, for the phone."""
    port = port_setting()
    ip = xbmc.getIPAddress() or "127.0.0.1"
    return "http://%s:%d" % (ip, port)


def port_setting():
    try:
        return int(xbmcaddon.Addon(ADDON_ID).getSetting("port") or 8585)
    except ValueError:
        return 8585


# --------------------------------------------------------------------------- QR code

def qr_png(data, path, scale=10, border=3):
    """Write data as a QR code, black on white, to a PNG file."""
    import qrcodegen
    qr = qrcodegen.QrCode.encode_text(data, qrcodegen.QrCode.Ecc.MEDIUM)
    size = qr.get_size() + 2 * border
    rows = []
    for y in range(size):
        line = bytearray()
        for x in range(size):
            dark = qr.get_module(x - border, y - border)
            line += (b"\x00" if dark else b"\xff") * scale
        rows += [bytes(line)] * scale
    width = size * scale
    raw = b"".join(b"\x00" + r for r in rows)

    def chunk(kind, body):
        return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body) & 0xffffffff)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, width, 8, 0, 0, 0, 0)) + \
        chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(png)
    return path


# --------------------------------------------------------------------------- what's playing

def art_url(image):
    """An address the phone can load a Kodi picture from (through this service)."""
    if not image or not ("://" in image or image.startswith("/")):
        return ""  # (Kodi's own icons, like DefaultAudio.png, only exist inside the skin)
    return "/art?u=" + urllib.parse.quote(image, safe="")


def state():
    players = rpc("Player.GetActivePlayers") or []
    app = rpc("Application.GetProperties", properties=["volume", "muted"]) or {}
    home = xbmcgui.Window(10000)
    out = {"volume": app.get("volume", 0), "muted": app.get("muted", False), "playing": None,
           "iptv": has_addon(XTREAM), "radio": has_addon(RADIO),
           "live": bool(home.getProperty("MHX.OSD")), "window": xbmc.getInfoLabel("System.CurrentWindow")}
    if not players:
        return out
    player = players[0]
    pid = player["playerid"]
    item = (rpc("Player.GetItem", playerid=pid, properties=["title", "artist", "album", "showtitle", "season",
                                                              "episode", "art", "thumbnail", "file", "year"]) or {}
            ).get("item") or {}
    props = rpc("Player.GetProperties", playerid=pid, properties=["time", "totaltime", "speed", "percentage",
                                                                  "live"]) or {}
    art = item.get("art") or {}
    title = item.get("title") or item.get("label") or ""
    if item.get("showtitle"):
        sub = "%s  •  S%d E%d" % (item["showtitle"], item.get("season") or 0, item.get("episode") or 0)
    elif item.get("artist"):
        sub = ", ".join(item["artist"]) + ("  •  %s" % item["album"] if item.get("album") else "")
    else:
        sub = str(item.get("year") or "") if item.get("year") else ""
    live_name = home.getProperty("MHX.Live.Name")
    if home.getProperty("MHX.OSD") and live_name:  # (a MediaHub IPTV channel: what's on it)
        title, sub = home.getProperty("MHX.Now.Title") or live_name, live_name
    picture = art.get("poster") or art.get("thumb") or art.get("tvshow.poster") or art.get("album.thumb") or \
        item.get("thumbnail") or art.get("fanart") or ""

    def secs(t):
        return (t or {}).get("hours", 0) * 3600 + (t or {}).get("minutes", 0) * 60 + (t or {}).get("seconds", 0)
    out["playing"] = {"type": player.get("type"), "title": title, "sub": sub, "art": art_url(picture),
                      "fanart": art_url(art.get("fanart") or ""), "time": secs(props.get("time")),
                      "total": secs(props.get("totaltime")), "paused": props.get("speed") == 0,
                      "live": bool(props.get("live"))}
    return out


def player_id():
    players = rpc("Player.GetActivePlayers") or []
    return players[0]["playerid"] if players else None


def do(action):
    if action == "home":
        rpc("GUI.ActivateWindow", window="home")
    elif action in ("channelup", "channeldown") and xbmcgui.Window(10000).getProperty("MHX.OSD"):
        # (a MediaHub IPTV channel: the next one in the list it came from)
        xbmc.executebuiltin("RunPlugin(plugin://%s/?mode=channelstep&step=%d)" % (XTREAM, 1 if action == "channelup"
                                                                                  else -1))
    elif action == "lastchannel":
        xbmc.executebuiltin("RunPlugin(plugin://%s/?mode=lastchannel)" % XTREAM)
    elif action in ACTIONS:
        rpc("Input.ExecuteAction", action=action)


def seek(percent=None, seconds=None):
    pid = player_id()
    if pid is None:
        return
    if percent is not None:
        rpc("Player.Seek", playerid=pid, value={"percentage": max(0.0, min(100.0, float(percent)))})
    elif seconds is not None:
        rpc("Player.Seek", playerid=pid, value={"seconds": int(seconds)})


def volume(level=None, step=None, mute=None):
    if mute is not None:
        rpc("Application.SetMute", mute="toggle")
    elif step is not None:
        rpc("Application.SetVolume", volume="increment" if step > 0 else "decrement")
    elif level is not None:
        rpc("Application.SetVolume", volume=max(0, min(100, int(level))))


def send_text(words, done=True):
    rpc("Input.SendText", text=words, done=done)


# --------------------------------------------------------------------------- finding things

def directory(path, limit=40):
    reply = rpc("Files.GetDirectory", directory=path, media="files", properties=["thumbnail", "art"],
                limits={"start": 0, "end": limit}) or {}
    found = []
    for f in reply.get("files") or []:
        art = f.get("art") or {}
        found.append({"label": re.sub(r"\[/?[A-Z]+[^\]]*\]", "", f.get("label") or ""),
                      "art": art_url(art.get("thumb") or art.get("icon") or f.get("thumbnail") or ""),
                      "open": {"file": f.get("file"), "folder": f.get("filetype") == "directory"}})
    return found


def search(words):
    words = (words or "").strip()
    if not words:
        return []
    groups = []
    rule = {"field": "title", "operator": "contains", "value": words}
    movies = (rpc("VideoLibrary.GetMovies", filter=rule, properties=["year", "art"],
                  limits={"start": 0, "end": 12}) or {}).get("movies") or []
    if movies:
        groups.append({"title": xbmc.getLocalizedString(342), "items": [
            {"label": m["label"], "sub": str(m.get("year") or ""),
             "art": art_url((m.get("art") or {}).get("poster", "")), "open": {"movieid": m["movieid"]}}
            for m in movies]})
    shows = (rpc("VideoLibrary.GetTVShows", filter=rule, properties=["year", "art"],
                 limits={"start": 0, "end": 12}) or {}).get("tvshows") or []
    if shows:
        groups.append({"title": xbmc.getLocalizedString(20343), "items": [
            {"label": s["label"], "sub": str(s.get("year") or ""),
             "art": art_url((s.get("art") or {}).get("poster", "")), "open": {"tvshowid": s["tvshowid"]}}
            for s in shows]})
    if has_addon(XTREAM):
        found = directory("plugin://%s/?mode=search&q=%s" % (XTREAM, urllib.parse.quote(words)), 30)
        if found:
            groups.append({"title": "IPTV", "items": found})
    return groups


def channels():
    """MediaHub IPTV's My channels and Recent channels, and MediaHub Radio's stations."""
    groups = []
    if has_addon(XTREAM):
        for mode, title in (("favourites", text(30020)), ("recentchannels", text(30021))):
            found = directory("plugin://%s/?mode=%s" % (XTREAM, mode))
            if found:
                groups.append({"title": title, "items": found})
    if has_addon(RADIO):
        mine = load_json(xbmcvfs.translatePath("special://profile/addon_data/%s/favourites.json" % RADIO), [])
        items = []
        for s in mine:
            if isinstance(s, dict) and s.get("id"):
                target = "plugin://%s/?%s" % (RADIO, urllib.parse.urlencode(
                    {"mode": "play", "id": s["id"], "name": s.get("name", ""), "url": s.get("url", ""),
                     "icon": s.get("icon", "")}))
                items.append({"label": s.get("name", ""), "art": art_url(s.get("icon", "")),
                              "open": {"file": target, "folder": False}})
        if items:
            groups.append({"title": text(30022), "items": items})
    return groups


def open_item(what):
    if what.get("movieid"):
        rpc("Player.Open", item={"movieid": int(what["movieid"])}, options={"resume": True})
    elif what.get("tvshowid"):
        rpc("GUI.ActivateWindow", window="videos", parameters=["videodb://tvshows/titles/%d/" % int(what["tvshowid"])])
    elif what.get("file"):
        target = str(what["file"])
        if not re.match(r"^(plugin|videodb|musicdb|special|https?|smb|nfs)://", target):
            return
        if what.get("folder"):
            window = "Music" if target.startswith("plugin://plugin.audio.") else "Videos"
            xbmc.executebuiltin("ActivateWindow(%s,%s,return)" % (window, target))
        elif target.startswith("plugin://"):
            xbmc.executebuiltin("RunPlugin(%s)" % target)
        else:
            rpc("Player.Open", item={"file": target})


# --------------------------------------------------------------------------- pictures

def picture(image):
    """(bytes, type) of a Kodi picture: image://<address>/ or an address Kodi can read."""
    inner = image
    if image.startswith("image://"):
        inner = urllib.parse.unquote(image[len("image://"):].rstrip("/"))
    if not re.match(r"^(https?|special|smb|nfs|/)", inner) and not re.match(r"^[A-Za-z]:\\", inner):
        return None, None
    if re.search(r"\.(py|xml|json|db|txt|log)$", inner.split("?")[0], re.I):
        return None, None  # (pictures only)
    f = xbmcvfs.File(inner)
    try:
        body = f.readBytes(8 * 1024 * 1024)
    finally:
        f.close()
    if not body:
        return None, None
    kind = "image/png" if body[:4] == b"\x89PNG" else "image/gif" if body[:3] == b"GIF" else \
        "image/webp" if body[8:12] == b"WEBP" else "image/jpeg"
    if not kind.startswith("image/") or (kind == "image/jpeg" and body[:2] != b"\xff\xd8"):
        return None, None
    return bytes(body), kind

