"""MediaHub Helper - audio and subtitle tracks for the player's Audio & Subtitles panel.

The skin's panel (Custom_1110_Streams.xml) asks with MH.Req.Streams and shows

  MH.Audio.<n>.Label / .Label2 / .Selected    n = 1.. (track n-1)
  MH.Sub.<n>.Label / .Label2 / .Selected      n = 1 is "Off", n = 2.. (subtitle n-2)

Picking one sends MH.Req.Action = audiostream|<n> or substream|<n>.
"""
import json

import xbmc
import xbmcgui

MAX_AUDIO = 10
MAX_SUBS = 12  # including "Off"
PANEL = 1110
AUDIO_LIST, SUB_LIST = 111, 112

CODECS = {
    "ac3": "Dolby Digital", "eac3": "Dolby Digital+", "truehd": "Dolby TrueHD",
    "dca": "DTS", "dts": "DTS", "dtshd_ma": "DTS-HD MA", "dtshd_hra": "DTS-HD",
    "aac": "AAC", "flac": "FLAC", "mp3": "MP3", "opus": "Opus", "vorbis": "Vorbis",
    "pcm_s16le": "PCM", "pcm_s24le": "PCM", "lpcm": "PCM",
}
CHANNELS = {1: "Mono", 2: "Stereo", 6: "5.1", 7: "6.1", 8: "7.1"}


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return reply.get("result", {})


def text(string_id):
    import xbmcaddon
    return xbmcaddon.Addon().getLocalizedString(string_id)


def video_player():
    for player in rpc("Player.GetActivePlayers") or []:
        if player.get("type") == "video":
            return player["playerid"]
    return None


def language(code, name=""):
    """'eng' -> 'English'; falls back to the track's own name or the code."""
    if code and code not in ("und", "unk"):
        try:
            full = xbmc.convertLanguage(code, xbmc.ENGLISH_NAME)
        except Exception:
            full = ""
        if full:
            return full
    return name or (code or "").upper()


def codec(stream):
    raw = (stream.get("codec") or "").lower()
    if "atmos" in raw:
        label = "Dolby Atmos"
    elif raw.startswith("dtshd_ma_x"):
        label = "DTS:X"
    else:
        label = CODECS.get(raw, raw.upper())
    channels = CHANNELS.get(stream.get("channels") or 0, "")
    return "  ".join(x for x in (label, channels) if x)


def audio_entry(stream, n):
    tags = []
    if stream.get("isimpaired"):
        tags.append("AD")
    if stream.get("isoriginal"):
        tags.append(text(32040))
    name = language(stream.get("language"), stream.get("name")) or "%s %d" % (text(32041), n)
    return name, "  •  ".join(x for x in [codec(stream)] + tags if x)


def sub_entry(stream, n):
    tags = []
    if stream.get("isforced"):
        tags.append(text(32042))
    if stream.get("isimpaired"):
        tags.append("SDH")
    name = language(stream.get("language"), stream.get("name")) or "%s %d" % (text(32043), n)
    return name, "  •  ".join(tags)


def refresh(focus=False):
    home = xbmcgui.Window(10000)
    playerid = video_player()
    info = {}
    if playerid is not None:
        info = rpc("Player.GetProperties", playerid=playerid, properties=[
            "audiostreams", "currentaudiostream", "subtitles", "currentsubtitle", "subtitleenabled"])
    audio = info.get("audiostreams") or []
    current_audio = (info.get("currentaudiostream") or {}).get("index", -1)
    subs = info.get("subtitles") or []
    current_sub = (info.get("currentsubtitle") or {}).get("index", -1) if info.get("subtitleenabled") else -1

    selected_audio = selected_sub = 1
    for n in range(1, MAX_AUDIO + 1):
        stream = audio[n - 1] if n <= len(audio) else None
        label, label2 = audio_entry(stream, n) if stream else ("", "")
        is_current = bool(stream) and stream.get("index") == current_audio
        if is_current:
            selected_audio = n
        home.setProperty("MH.Audio.%d.Label" % n, label)
        home.setProperty("MH.Audio.%d.Label2" % n, label2)
        home.setProperty("MH.Audio.%d.Selected" % n, "1" if is_current else "")

    home.setProperty("MH.Sub.1.Label", text(32044))
    home.setProperty("MH.Sub.1.Label2", "")
    home.setProperty("MH.Sub.1.Selected", "1" if current_sub == -1 else "")
    for n in range(2, MAX_SUBS + 1):
        stream = subs[n - 2] if n - 2 < len(subs) else None
        label, label2 = sub_entry(stream, n - 1) if stream else ("", "")
        is_current = bool(stream) and stream.get("index") == current_sub
        if is_current:
            selected_sub = n
        home.setProperty("MH.Sub.%d.Label" % n, label)
        home.setProperty("MH.Sub.%d.Label2" % n, label2)
        home.setProperty("MH.Sub.%d.Selected" % n, "1" if is_current else "")
    home.setProperty("MH.Audio.Count", str(len(audio)))
    home.setProperty("MH.Sub.Count", str(len(subs)))

    if focus and xbmc.getCondVisibility("Window.IsActive(%d)" % PANEL):
        # start on the track that's playing
        xbmc.executebuiltin("Control.SetFocus(%d,%d,absolute)" % (SUB_LIST, selected_sub - 1))
        xbmc.executebuiltin("Control.SetFocus(%d,%d,absolute)" % (AUDIO_LIST, selected_audio - 1))


def select(kind, n, monitor):
    playerid = video_player()
    if playerid is None:
        return
    if kind == "audiostream":
        info = rpc("Player.GetProperties", playerid=playerid, properties=["audiostreams"])
        audio = info.get("audiostreams") or []
        if 1 <= n <= len(audio):
            rpc("Player.SetAudioStream", playerid=playerid, stream=audio[n - 1]["index"])
    elif kind == "substream":
        if n <= 1:
            rpc("Player.SetSubtitle", playerid=playerid, subtitle="off")
        else:
            info = rpc("Player.GetProperties", playerid=playerid, properties=["subtitles"])
            subs = info.get("subtitles") or []
            if n - 2 < len(subs):
                rpc("Player.SetSubtitle", playerid=playerid, subtitle=subs[n - 2]["index"], enable=True)
    # the player switches a moment later
    monitor.waitForAbort(0.3)
    refresh()


def handle(action, monitor):
    """Answer audiostream|<n> / substream|<n>. Returns True when it was one of ours."""
    name, _, arg = action.partition("|")
    if name in ("audiostream", "substream") and arg.isdigit():
        select(name, int(arg), monitor)
        return True
    return False
