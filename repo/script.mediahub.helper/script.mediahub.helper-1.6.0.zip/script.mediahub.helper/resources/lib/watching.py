"""MediaHub Helper - things that happen while you watch.

* Finish by: pick a time ("I'll finish at 11pm") and the next episode only plays
  if it will end before then; Up Next leaves out episodes that don't fit.
  MH.FinishBy (epoch seconds), MH.FinishBy.Label ("11:00 PM").
* Intro memory: once you've pressed Skip Intro in a show, its later episodes
  skip the intro by themselves (Skin setting MH.NoAutoSkip turns this off).
  The shows are kept in addon_data/.../autoskip.json. MH.AutoSkip = 1 while
  playing one of them, so the skin doesn't offer the button as well.
* Sound mode: Normal, Night (quieter, with Kodi's volume amplification lifting
  quiet speech) or Dialogue (amplification only). MH.SoundMode.
* Timer: the player bar's timer button offers Stop after this one, Sleep in
  15-90 minutes and Finish by. Over the last minute of a sleep timer the sound
  fades and the picture dims (MH.Sleep.Fading); any button cancels it.
  MH.Sleep (epoch, or "end"), MH.Sleep.Label ("Sleep in 28 min").
* Are you still watching? After three videos in a row started with no button
  pressed, the next one pauses and asks (MH.StillWatching = the title).
  Skin.HasSetting(MH.NoStillWatching) turns it off.
* After a movie: when a library movie ends (or is stopped in its last tenth),
  the after-movie page (Custom_1114_PostPlay.xml) opens with thumbs and More
  Like This. MH.PostPlay.*; Skin.HasSetting(MH.NoPostPlay) turns it off.
* Subtitle style: presets for Kodi's subtitle settings (Skin.String(MH.SubStyle)).
"""
import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

AUTOSKIP = "special://profile/addon_data/script.mediahub.helper/autoskip.json"
# Night mode's saved volume, kept on disk too: Kodi keeps the lowered volume
# through a restart, the Window(Home) properties don't survive it
SOUND_STATE = "special://profile/addon_data/script.mediahub.helper/soundmode.json"
AMP_STEPS = 6  # volume amplification steps a sound mode adds (about 6 dB)


def home():
    return xbmcgui.Window(10000)


def text(string_id):
    return xbmcaddon.Addon().getLocalizedString(string_id)


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return reply.get("result", {})


def notify(message, ms=4000):
    xbmcgui.Dialog().notification("MediaHub", message, xbmcgui.NOTIFICATION_INFO, ms, False)


# --------------------------------------------------------------------------- finish by

def finish_by_choices():
    """Now rounded up to the next half hour, then every half hour for 5 hours."""
    t = time.localtime()
    start = time.mktime(time.struct_time((t.tm_year, t.tm_mon, t.tm_mday, t.tm_hour,
                                          30 if t.tm_min < 30 else 0, 0, 0, 0, -1)))
    if t.tm_min >= 30:
        start += 3600
    return [start + i * 1800 for i in range(10)]


def clock(epoch):
    fmt = xbmc.getRegion("time").replace(":%S", "")
    return time.strftime(fmt, time.localtime(epoch)).lstrip("0")


SLEEP_MINUTES = (15, 30, 45, 60, 90)
FADE = 60  # seconds the sound fades and the picture dims before a sleep timer stops


def clear_timers():
    for name in ("MH.FinishBy", "MH.FinishBy.Label", "MH.Sleep", "MH.Sleep.Label"):
        home().clearProperty(name)


def choose_timer():
    """The player bar's timer: stop after this one, sleep in N minutes, or finish by."""
    choices = finish_by_choices()
    labels = [text(32060), text(32090)] + [text(32091) % m for m in SLEEP_MINUTES] + \
        [text(32092) % clock(c) for c in choices]
    pick = xbmcgui.Dialog().select(text(32093), labels)
    if pick < 0:
        return
    if pick == 0:
        clear_timers()
        return
    if pick == 1:
        home().setProperty("MH.Sleep", "end")
        trim_playlist()
        notify(text(32090))
        return
    if pick < 2 + len(SLEEP_MINUTES):
        minutes = SLEEP_MINUTES[pick - 2]
        home().setProperty("MH.Sleep", str(int(time.time() + minutes * 60)))
        notify(text(32091) % minutes)
        return
    at = choices[pick - 2 - len(SLEEP_MINUTES)]
    home().setProperty("MH.FinishBy", str(int(at)))
    home().setProperty("MH.FinishBy.Label", clock(at))
    notify(text(32063) % home().getProperty("MH.FinishBy.Label"))


def trim_playlist():
    """Take everything after the playing item out of the video queue."""
    items = rpc("Playlist.GetItems", playlistid=1).get("items") or []
    position = rpc("Player.GetProperties", playerid=1, properties=["position"]).get("position", -1)
    if position < 0:
        return False
    for i in range(len(items) - 1, position, -1):
        rpc("Playlist.Remove", playlistid=1, position=i)
    return len(items) > position + 1


def sleep_target(now):
    value = home().getProperty("MH.Sleep")
    if value == "end":
        remaining = xbmc.getInfoLabel("Player.TimeRemaining(secs)")
        return now + int(remaining) if remaining.isdigit() else None
    return float(value) if value else None


# --------------------------------------------------------------------------- subtitle style

# Kodi's subtitle settings for each preset (backgroundtype: 0 none, 2 box)
SUB_STYLES = [
    ("standard", 32097, {"fontsize": 42, "colorpick": "FFFFFFFF", "bordersize": 25, "backgroundtype": 0, "style": 0}),
    ("large", 32098, {"fontsize": 54, "colorpick": "FFFFFFFF", "bordersize": 25, "backgroundtype": 0, "style": 1}),
    ("xlarge", 32099, {"fontsize": 64, "colorpick": "FFFFFFFF", "bordersize": 30, "backgroundtype": 0, "style": 1}),
    ("yellow", 32100, {"fontsize": 46, "colorpick": "FFFFEB3B", "bordersize": 25, "backgroundtype": 0, "style": 1}),
    ("boxed", 32101, {"fontsize": 46, "colorpick": "FFFFFFFF", "bordersize": 0, "backgroundtype": 2,
                      "bgcolorpick": "FF000000", "bgopacity": 80, "style": 0}),
]


def choose_sub_style():
    now = xbmc.getInfoLabel("Skin.String(MH.SubStyle)") or "standard"
    labels = [text(sid) for _, sid, _ in SUB_STYLES]
    current = next((i for i, (key, _, _) in enumerate(SUB_STYLES) if key == now), 0)
    pick = xbmcgui.Dialog().select(text(32096), labels, preselect=current)
    if pick < 0:
        return
    key, _, values = SUB_STYLES[pick]
    for name, value in values.items():
        rpc("Settings.SetSettingValue", setting="subtitles." + name, value=value)
    xbmc.executebuiltin("Skin.SetString(MH.SubStyle,%s)" % key)


def finish_by():
    value = home().getProperty("MH.FinishBy")
    return float(value) if value else None


def fits(runtime_secs):
    """Would something this long finish in time? (True when no time is set)"""
    limit = finish_by()
    return limit is None or time.time() + (runtime_secs or 0) <= limit


# --------------------------------------------------------------------------- intro memory

def load_autoskip():
    try:
        with open(xbmcvfs.translatePath(AUTOSKIP)) as f:
            return set(json.load(f))
    except (OSError, ValueError):
        return set()


def save_autoskip(shows):
    path = xbmcvfs.translatePath(AUTOSKIP)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(sorted(shows), f)


def remember_skip(show):
    if show:
        shows = load_autoskip()
        shows.add(show)
        save_autoskip(shows)


def forget_skips():
    save_autoskip(set())
    notify(text(32064))


# --------------------------------------------------------------------------- sound mode

def set_sound_mode(mode):
    """normal / night / dialogue. Night lowers the volume and adds amplification;
    both are undone when going back to normal."""
    old = home().getProperty("MH.SoundMode") or "normal"
    if mode == old:
        return
    app = rpc("Application.GetProperties", properties=["volume"])
    if old == "night":
        saved = home().getProperty("MH.SoundMode.Volume")
        if saved.isdigit():
            rpc("Application.SetVolume", volume=int(saved))
    if old in ("night", "dialogue"):
        for _ in range(AMP_STEPS):
            xbmc.executebuiltin("Action(volampdown)")
    if mode == "night":
        volume = app.get("volume", 100)
        home().setProperty("MH.SoundMode.Volume", str(volume))
        save_sound_state({"volume": volume})
        rpc("Application.SetVolume", volume=max(10, int(volume * 0.6)))
    else:
        save_sound_state(None)
    if mode in ("night", "dialogue"):
        for _ in range(AMP_STEPS):
            xbmc.executebuiltin("Action(volampup)")
    home().setProperty("MH.SoundMode", "" if mode == "normal" else mode)
    notify(text({"normal": 32065, "night": 32066, "dialogue": 32067}[mode]))


def save_sound_state(state):
    path = xbmcvfs.translatePath(SOUND_STATE)
    try:
        if state is None:
            if os.path.exists(path):
                os.remove(path)
            return
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            json.dump(state, f)
    except OSError:
        pass


def restore_sound_mode():
    """At start-up: if Kodi stopped while Night mode was on, put the volume back."""
    try:
        with open(xbmcvfs.translatePath(SOUND_STATE)) as f:
            volume = int(json.load(f).get("volume", 0))
    except (OSError, ValueError, TypeError):
        return
    if volume and not home().getProperty("MH.SoundMode"):
        rpc("Application.SetVolume", volume=volume)
    save_sound_state(None)


def next_sound_mode():
    order = ["normal", "night", "dialogue"]
    now = home().getProperty("MH.SoundMode") or "normal"
    set_sound_mode(order[(order.index(now) + 1) % len(order)])


# --------------------------------------------------------------------------- the watcher

class Watching:
    def __init__(self):
        self.next_check = 0.0
        self.file = None
        self.skipped = set()   # (file, chapter) already auto-skipped
        self.trimmed = None    # file whose playlist we cut short
        self.started = 0.0     # when the playing file started
        self.ended = 0.0       # when the last file stopped (the queue moves on within seconds)
        self.unattended = 0    # videos in a row started with no button pressed
        self.fading = None     # (volume before, when the fade began) during a sleep fade
        self.movie = None      # (movieid, percent played) of a library movie playing
        self.asked_stop = False  # stopped by the sleep timer or "still watching": no after-movie page

    def tick(self):
        now = time.time()
        if now < self.next_check:
            return
        self.next_check = now + 0.5
        playing = xbmc.getCondVisibility("Player.HasVideo")
        if not playing:
            if self.fading:
                self.end_fade(stopped=True)
            if self.file:
                self.file = None
                self.trimmed = None
                self.ended = now
                home().clearProperty("MH.AutoSkip")
                home().clearProperty("MH.StillWatching")
                limit = finish_by()
                if limit and now > limit:
                    home().clearProperty("MH.FinishBy")
                    home().clearProperty("MH.FinishBy.Label")
                if home().getProperty("MH.Sleep") == "end":
                    clear_timers()
            return
        path = xbmc.getInfoLabel("Player.Filenameandpath")
        show = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
        if path != self.file:
            self.new_file(path, show, now)
        if self.movie:
            try:
                self.movie = (self.movie[0], float(xbmc.getInfoLabel("Player.Progress") or 0))
            except ValueError:
                pass
        if home().getProperty("MH.StillWatching") and not xbmc.getCondVisibility("Player.Paused"):
            home().clearProperty("MH.StillWatching")  # play was pressed on the remote
            self.unattended = 0
        self.auto_skip(path)
        self.enforce_finish_by(path)
        self.sleep_timer(now)

    def new_file(self, path, show, now):
        # (between two queued videos Kodi plays nothing for a moment: that's not a new start)
        first = self.file is None and now - self.ended > 15
        self.file = path
        self.trimmed = None
        # a library movie? (Kodi 20 has no VideoPlayer.DBID, so ask the player)
        item = rpc("Player.GetItem", playerid=1).get("item") or {}
        self.movie = (item["id"], 0.0) if item.get("type") == "movie" and item.get("id") else None
        auto = bool(show) and show in load_autoskip() and \
            not xbmc.getCondVisibility("Skin.HasSetting(MH.NoAutoSkip)")
        home().setProperty("MH.AutoSkip", "1" if auto else "")
        # started with no button pressed since the last one started?
        if first or xbmc.getGlobalIdleTime() < now - self.started - 5:
            self.unattended = 0
        else:
            self.unattended += 1
        self.started = now
        if self.unattended >= 3 and not xbmc.getCondVisibility("Skin.HasSetting(MH.NoStillWatching)"):
            rpc("Player.PlayPause", playerid=1, play=False)
            home().setProperty("MH.StillWatching", show or xbmc.getInfoLabel("VideoPlayer.Title"))

    def sleep_timer(self, now):
        target = sleep_target(now)
        if target is None:
            if self.fading:
                self.end_fade()
            return
        remaining = target - now
        home().setProperty("MH.Sleep.Label", text(32094) % max(1, int(remaining // 60) + 1)
                           if home().getProperty("MH.Sleep") != "end" else text(32090))
        if remaining > FADE:
            return
        if not self.fading:
            volume = rpc("Application.GetProperties", properties=["volume"]).get("volume", 100)
            self.fading = (volume, now)
            save_sound_state({"volume": volume})  # (put back after a restart, see restore_sound_mode)
            home().setProperty("MH.Sleep.Fading", "1")
        volume, began = self.fading
        if xbmc.getGlobalIdleTime() < now - began - 1:
            # a button was pressed: keep watching
            self.end_fade()
            clear_timers()
            notify(text(32102))
            return
        if remaining <= 1:
            self.asked_stop = True
            xbmc.executebuiltin("PlayerControl(Stop)")
            xbmc.sleep(500)
            self.end_fade(stopped=True)
            return
        rpc("Application.SetVolume", volume=int(volume * max(0.0, remaining) / FADE))

    def end_fade(self, stopped=False):
        volume, _ = self.fading
        self.fading = None
        rpc("Application.SetVolume", volume=volume)
        save_sound_state(None)
        home().clearProperty("MH.Sleep.Fading")
        if stopped:
            clear_timers()
            notify(text(32095))

    def on_stop(self, data):
        """Player.OnStop: open the after-movie page when a movie was watched to the end."""
        movie, self.movie = self.movie, None
        asked, self.asked_stop = self.asked_stop, False
        try:
            info = json.loads(data) if data else {}
        except ValueError:
            info = {}
        item = info.get("item") or {}
        if asked or item.get("type") != "movie" or not movie or \
                xbmc.getCondVisibility("Skin.HasSetting(MH.NoPostPlay)"):
            return None
        if info.get("end") or movie[1] >= 90:
            return movie[0]
        return None

    def auto_skip(self, path):
        if home().getProperty("MH.AutoSkip") != "1" or xbmc.getCondVisibility("Player.Paused"):
            return
        name = xbmc.getInfoLabel("Player.ChapterName").lower()
        chapter = xbmc.getInfoLabel("Player.Chapter")
        if ("intro" in name or "opening" in name) and (path, chapter) not in self.skipped:
            self.skipped.add((path, chapter))
            xbmc.executebuiltin("Action(chapterorbigstepforward)")
            notify(text(32068), 2500)

    def still_watching(self, answer):
        home().clearProperty("MH.StillWatching")
        self.unattended = 0
        if answer == "yes":
            rpc("Player.PlayPause", playerid=1, play=True)
        else:
            self.asked_stop = True
            xbmc.executebuiltin("PlayerControl(Stop)")

    def enforce_finish_by(self, path):
        limit = finish_by()
        if limit is None or self.trimmed == path:
            return
        remaining = xbmc.getInfoLabel("Player.TimeRemaining(secs)")
        if not remaining.isdigit() or int(remaining) > 45:
            return
        items = rpc("Playlist.GetItems", playlistid=1, properties=["runtime"]).get("items") or []
        position = rpc("Player.GetProperties", playerid=1, properties=["position"]).get("position", -1)
        if position < 0 or position + 1 >= len(items):
            return
        ends = time.time() + int(remaining)
        if ends + (items[position + 1].get("runtime") or 0) <= limit:
            return
        # the next one wouldn't finish in time: stop after this one
        self.trimmed = path
        for i in range(len(items) - 1, position, -1):
            rpc("Playlist.Remove", playlistid=1, position=i)
        notify(text(32069) % home().getProperty("MH.FinishBy.Label"), 6000)


def handle(action):
    """Answer finishby (the timer) / introskipped|<show> / forgetskips /
    soundmode[|mode] / substyle."""
    name, _, arg = action.partition("|")
    if name == "finishby":
        return "thread", choose_timer
    if name == "substyle":
        return "thread", choose_sub_style
    if name == "introskipped":
        remember_skip(arg)
        return "done", None
    if name == "forgetskips":
        forget_skips()
        return "done", None
    if name == "soundmode":
        if arg:
            set_sound_mode(arg)
        else:
            next_sound_mode()
        return "done", None
    return None, None
