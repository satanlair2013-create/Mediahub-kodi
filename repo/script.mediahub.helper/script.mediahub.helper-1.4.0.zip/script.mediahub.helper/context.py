"""MediaHub Helper - context menu items: My List and thumbs for library titles,
and Remove download in the downloads folder. They hand the request to the
service (see resources/lib/mediahub.py and personal.py)."""
import sys

import xbmcaddon
import xbmcgui


def main():
    if sys.argv[1] == "deletedownload":
        xbmcgui.Window(10000).setProperty("MH.Req.Action", "deletedownload|" + sys.listitem.getPath())
        return
    tag = sys.listitem.getVideoInfoTag()
    kind, dbid = tag.getMediaType(), tag.getDbId()
    if kind not in ("movie", "tvshow", "episode") or dbid <= 0:
        return
    home = xbmcgui.Window(10000)
    if sys.argv[1] == "mylist":
        home.setProperty("MH.Req.Action", "mylist|%s|%d" % (kind, dbid))
    elif sys.argv[1] == "rate":
        addon = xbmcaddon.Addon()
        choices = [(10, 32006), (8, 32005), (2, 32004), (0, 32003)]
        pick = xbmcgui.Dialog().select(addon.getLocalizedString(32012),
                                       [addon.getLocalizedString(sid) for _, sid in choices])
        if pick >= 0:
            # "Remove rating" sends the current value again, which clears it
            value = choices[pick][0] or tag.getUserRating()
            if value:
                home.setProperty("MH.Req.Action", "rate|%s|%d|%d" % (kind, dbid, value))


if __name__ == "__main__":
    main()
