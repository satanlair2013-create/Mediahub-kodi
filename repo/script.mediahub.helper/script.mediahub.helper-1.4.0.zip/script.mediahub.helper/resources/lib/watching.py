"""MediaHub Helper - things that happen while you watch.

* Finish by: pick a time ("I'll finish at 11pm") and the next episode only plays
  if it will end before then; Up Next leaves out episodes that don't fit.
  MH.FinishBy (epoch seconds), MH.FinishBy.Label ("11:00 PM").
* Intro memory: once you've pressed Skip Intro in a show, its later episodes
  skip the intro by themselves (Skin setting MH.NoAutoSkip turns this off).
  The shows are kept in addon_data/.../autoskip.json. MH.AutoSkip = 1 while
  playing one of them, so the skin doesn't offer the button as well.
* Sound mode: Normal, Night (quieter, with Kodi's volume amplification lifting
  quiet speech) or Dialogue (amplification only). MH.SoundMode.
"""
import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

AUTOSKIP = "special://profile/addon_data/script.mediahub.helper/autoskip.json"
# Night mode's saved volume, kept on disk too: Kodi keeps the lowered volume
# through a restart, the Window(Home) properties don't survive it
SOUND_STATE = "special://profile/addon_data/script.mediahub.helper/soundmode.json"
AMP_STEPS = 6  # volume amplification steps a sound mode adds (about 6 dB)


def home():
    return xbmcgui.Window(10000)


def text(string_id):
    return xbmcaddon.Addon().getLocalizedString(string_id)


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return reply.get("result", {})


def notify(message, ms=4000):
    xbmcgui.Dialog().notification("MediaHub", message, xbmcgui.NOTIFICATION_INFO, ms, False)


# --------------------------------------------------------------------------- finish by

def finish_by_choices():
    """Now rounded up to the next half hour, then every half hour for 5 hours."""
    t = time.localtime()
    start = time.mktime(time.struct_time((t.tm_year, t.tm_mon, t.tm_mday, t.tm_hour,
                                          30 if t.tm_min < 30 else 0, 0, 0, 0, -1)))
    if t.tm_min >= 30:
        start += 3600
    return [start + i * 1800 for i in range(10)]


def clock(epoch):
    fmt = xbmc.getRegion("time").replace(":%S", "")
    return time.strftime(fmt, time.localtime(epoch)).lstrip("0")


def choose_finish_by():
    choices = finish_by_choices()
    labels = [text(32060), text(32061)] + [clock(c) for c in choices]
    pick = xbmcgui.Dialog().select(text(32062), labels)
    if pick < 0:
        return
    if pick == 0:
        home().clearProperty("MH.FinishBy")
        home().clearProperty("MH.FinishBy.Label")
        return
    if pick == 1:
        # after this episode: now, so nothing more fits
        home().setProperty("MH.FinishBy", str(int(time.time())))
        home().setProperty("MH.FinishBy.Label", text(32061))
    else:
        home().setProperty("MH.FinishBy", str(int(choices[pick - 2])))
        home().setProperty("MH.FinishBy.Label", clock(choices[pick - 2]))
    notify(text(32063) % home().getProperty("MH.FinishBy.Label"))


def finish_by():
    value = home().getProperty("MH.FinishBy")
    return float(value) if value else None


def fits(runtime_secs):
    """Would something this long finish in time? (True when no time is set)"""
    limit = finish_by()
    return limit is None or time.time() + (runtime_secs or 0) <= limit


# --------------------------------------------------------------------------- intro memory

def load_autoskip():
    try:
        with open(xbmcvfs.translatePath(AUTOSKIP)) as f:
            return set(json.load(f))
    except (OSError, ValueError):
        return set()


def save_autoskip(shows):
    path = xbmcvfs.translatePath(AUTOSKIP)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(sorted(shows), f)


def remember_skip(show):
    if show:
        shows = load_autoskip()
        shows.add(show)
        save_autoskip(shows)


def forget_skips():
    save_autoskip(set())
    notify(text(32064))


# --------------------------------------------------------------------------- sound mode

def set_sound_mode(mode):
    """normal / night / dialogue. Night lowers the volume and adds amplification;
    both are undone when going back to normal."""
    old = home().getProperty("MH.SoundMode") or "normal"
    if mode == old:
        return
    app = rpc("Application.GetProperties", properties=["volume"])
    if old == "night":
        saved = home().getProperty("MH.SoundMode.Volume")
        if saved.isdigit():
            rpc("Application.SetVolume", volume=int(saved))
    if old in ("night", "dialogue"):
        for _ in range(AMP_STEPS):
            xbmc.executebuiltin("Action(volampdown)")
    if mode == "night":
        volume = app.get("volume", 100)
        home().setProperty("MH.SoundMode.Volume", str(volume))
        save_sound_state({"volume": volume})
        rpc("Application.SetVolume", volume=max(10, int(volume * 0.6)))
    else:
        save_sound_state(None)
    if mode in ("night", "dialogue"):
        for _ in range(AMP_STEPS):
            xbmc.executebuiltin("Action(volampup)")
    home().setProperty("MH.SoundMode", "" if mode == "normal" else mode)
    notify(text({"normal": 32065, "night": 32066, "dialogue": 32067}[mode]))


def save_sound_state(state):
    path = xbmcvfs.translatePath(SOUND_STATE)
    try:
        if state is None:
            if os.path.exists(path):
                os.remove(path)
            return
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            json.dump(state, f)
    except OSError:
        pass


def restore_sound_mode():
    """At start-up: if Kodi stopped while Night mode was on, put the volume back."""
    try:
        with open(xbmcvfs.translatePath(SOUND_STATE)) as f:
            volume = int(json.load(f).get("volume", 0))
    except (OSError, ValueError, TypeError):
        return
    if volume and not home().getProperty("MH.SoundMode"):
        rpc("Application.SetVolume", volume=volume)
    save_sound_state(None)


def next_sound_mode():
    order = ["normal", "night", "dialogue"]
    now = home().getProperty("MH.SoundMode") or "normal"
    set_sound_mode(order[(order.index(now) + 1) % len(order)])


# --------------------------------------------------------------------------- the watcher

class Watching:
    def __init__(self):
        self.next_check = 0.0
        self.file = None
        self.skipped = set()   # (file, chapter) already auto-skipped
        self.trimmed = None    # file whose playlist we cut short

    def tick(self):
        now = time.time()
        if now < self.next_check:
            return
        self.next_check = now + 0.5
        playing = xbmc.getCondVisibility("Player.HasVideo")
        if not playing:
            if self.file:
                self.file = None
                self.trimmed = None
                home().clearProperty("MH.AutoSkip")
                limit = finish_by()
                if limit and now > limit:
                    home().clearProperty("MH.FinishBy")
                    home().clearProperty("MH.FinishBy.Label")
            return
        path = xbmc.getInfoLabel("Player.Filenameandpath")
        show = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
        if path != self.file:
            self.file = path
            self.trimmed = None
            auto = bool(show) and show in load_autoskip() and \
                not xbmc.getCondVisibility("Skin.HasSetting(MH.NoAutoSkip)")
            home().setProperty("MH.AutoSkip", "1" if auto else "")
        self.auto_skip(path)
        self.enforce_finish_by(path)

    def auto_skip(self, path):
        if home().getProperty("MH.AutoSkip") != "1" or xbmc.getCondVisibility("Player.Paused"):
            return
        name = xbmc.getInfoLabel("Player.ChapterName").lower()
        chapter = xbmc.getInfoLabel("Player.Chapter")
        if ("intro" in name or "opening" in name) and (path, chapter) not in self.skipped:
            self.skipped.add((path, chapter))
            xbmc.executebuiltin("Action(chapterorbigstepforward)")
            notify(text(32068), 2500)

    def enforce_finish_by(self, path):
        limit = finish_by()
        if limit is None or self.trimmed == path:
            return
        remaining = xbmc.getInfoLabel("Player.TimeRemaining(secs)")
        if not remaining.isdigit() or int(remaining) > 45:
            return
        items = rpc("Playlist.GetItems", playlistid=1, properties=["runtime"]).get("items") or []
        position = rpc("Player.GetProperties", playerid=1, properties=["position"]).get("position", -1)
        if position < 0 or position + 1 >= len(items):
            return
        ends = time.time() + int(remaining)
        if ends + (items[position + 1].get("runtime") or 0) <= limit:
            return
        # the next one wouldn't finish in time: stop after this one
        self.trimmed = path
        for i in range(len(items) - 1, position, -1):
            rpc("Playlist.Remove", playlistid=1, position=i)
        notify(text(32069) % home().getProperty("MH.FinishBy.Label"), 6000)


def handle(action):
    """Answer finishby / introskipped|<show> / forgetskips / soundmode[|mode]."""
    name, _, arg = action.partition("|")
    if name == "finishby":
        return "thread", choose_finish_by
    if name == "introskipped":
        remember_skip(arg)
        return "done", None
    if name == "forgetskips":
        forget_skips()
        return "done", None
    if name == "soundmode":
        if arg:
            set_sound_mode(arg)
        else:
            next_sound_mode()
        return "done", None
    return None, None
