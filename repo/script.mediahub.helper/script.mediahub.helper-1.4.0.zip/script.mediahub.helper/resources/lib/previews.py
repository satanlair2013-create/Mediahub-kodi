"""MediaHub Helper - trailer previews in the home rows.

When a card in a home row keeps the focus for a few seconds, its trailer plays
in a small panel at the top of the home screen (Includes_Home.xml, RowPreview),
like the previews on Disney+ and Netflix. Moving on stops it.

Skin.String(MH.RowPreviews): "" = local trailers only (the default: a trailer from
the YouTube add-on shows Kodi's busy spinner while it loads, which blocks the
remote), "all" = any trailer, "off" = none.
"""
import time

import xbmc
import xbmcgui

DELAY = 4  # seconds on one card before its trailer starts
ROW_LISTS = range(9301, 9400)  # the home row lists (gen_rows.py LIST_BASE)


def home():
    return xbmcgui.Window(10000)


class Previews:
    def __init__(self):
        self.key = None
        self.since = 0.0
        self.playing = False
        self.done_key = None  # the card whose trailer already played to the end
        self.started = 0.0
        self.next_check = 0.0

    def stop(self):
        if self.playing:
            self.playing = False
            # (Player.HasMedia, not HasVideo: the trailer may still be opening)
            if xbmc.getCondVisibility("Player.HasMedia") and \
                    home().getProperty("MH.Preview") == "1":
                xbmc.executebuiltin("PlayerControl(Stop)")
            for name in ("MH.Preview", "MH.Preview.Title", "MH.Preview.Logo"):
                home().clearProperty(name)

    def allowed(self, trailer):
        mode = xbmc.getInfoLabel("Skin.String(MH.RowPreviews)")
        if mode == "off" or not trailer:
            return False
        remote = trailer.startswith(("plugin://", "http://", "https://"))
        return mode == "all" or not remote

    def tick(self):
        now = time.time()
        if now < self.next_check:
            return
        self.next_check = now + 0.25
        # Kodi's "busy" spinner while the trailer opens takes the focus for a
        # moment: that isn't leaving the card. (Any other dialog is.)
        if xbmc.getCondVisibility("Window.IsActive(busydialog) | Window.IsActive(busydialognocancel)"):
            return
        on_row = xbmc.getCondVisibility("Window.IsActive(home) + !Window.IsVisible(1112)")
        control = xbmc.getInfoLabel("System.CurrentControlID")
        if not on_row or not control.isdigit() or int(control) not in ROW_LISTS:
            key = None
        else:
            key = (control, xbmc.getInfoLabel("ListItem.DBType"), xbmc.getInfoLabel("ListItem.DBID"),
                   xbmc.getInfoLabel("ListItem.Trailer"))
        if key != self.key:
            self.stop()
            self.key, self.since = key, now
            return
        if self.playing:
            # (give it a few seconds to start before deciding it has ended)
            if now - self.started > 6 and not xbmc.getCondVisibility("Player.HasVideo"):
                # the trailer ended; don't start it again for the same card
                self.playing = False
                for name in ("MH.Preview", "MH.Preview.Title", "MH.Preview.Logo"):
                    home().clearProperty(name)
                self.done_key = key
            return
        if key and key != self.done_key and now - self.since >= DELAY and self.allowed(key[3]) \
                and not xbmc.getCondVisibility("Player.HasMedia"):
            logo = xbmc.getInfoLabel("ListItem.Art(clearlogo)") or xbmc.getInfoLabel("ListItem.Art(tvshow.clearlogo)")
            home().setProperty("MH.Preview.Title", xbmc.getInfoLabel("ListItem.Label"))
            home().setProperty("MH.Preview.Logo", logo)
            home().setProperty("MH.Preview", "1")
            self.playing = True
            self.started = now
            xbmc.executebuiltin('PlayMedia("%s",1)' % key[3].replace('"', '\\"'))
