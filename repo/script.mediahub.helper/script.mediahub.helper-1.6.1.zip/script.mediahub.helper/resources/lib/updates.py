"""MediaHub Helper - "update available" check for the skin and this add-on.

Reads the MediaHub repository's addons.xml (the address comes from the installed
repository.mediahub add-on, or the public site if that isn't installed) and
compares it with what's installed. When something is newer it sets:

  MH.Update.Available = 1
  MH.Update.Version   = the new skin version (or the helper's, if only it changed)
  MH.Update.News      = the <news> text of that version

and the skin shows a banner with an Update button, which sends MH.Req.Action = update.
"""
import re
import time
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDONS = ("skin.mediahub", "script.mediahub.helper")
REPO_ID = "repository.mediahub"
PUBLIC_INDEX = "https://satanlair2013-create.github.io/Mediahub-kodi/repo/addons.xml"
CHECK_EVERY = 6 * 3600


def version_tuple(v):
    return tuple(int(p) for p in re.findall(r"\d+", v or "0")[:4])


def installed_version(addon_id):
    try:
        return xbmcaddon.Addon(addon_id).getAddonInfo("version")
    except Exception:  # not installed, or being replaced right now
        return ""


def index_url():
    """The addons.xml the MediaHub repository add-on reads."""
    try:
        path = xbmcvfs.translatePath(xbmcaddon.Addon(REPO_ID).getAddonInfo("path"))
        root = ET.parse(path.rstrip("/\\") + "/addon.xml").getroot()
        info = root.find(".//info")
        if info is not None and info.text:
            return info.text.strip()
    except (RuntimeError, OSError, ET.ParseError):
        pass
    return PUBLIC_INDEX


def read(url):
    # Kodi's own file layer, so https works with Kodi's certificates on every platform
    f = xbmcvfs.File(url)
    try:
        return f.read()
    finally:
        f.close()


def available():
    """{addon id: (version, news)} from the repository."""
    found = {}
    root = ET.fromstring(read(index_url()))
    for addon in root.findall("addon"):
        if addon.get("id") in ADDONS:
            news = addon.find(".//news")
            found[addon.get("id")] = (addon.get("version"), (news.text or "").strip() if news is not None else "")
    return found


def outdated():
    """[(addon id, new version, news)] for our add-ons that have a newer version."""
    result = []
    for addon_id, (version, news) in available().items():
        have = installed_version(addon_id)
        if have and version_tuple(version) > version_tuple(have):
            result.append((addon_id, version, news))
    return result


def prop(name, value):
    xbmcgui.Window(10000).setProperty(name, value)


def check(notify=True, manual=False):
    """Look for updates and tell the skin. Returns the outdated list."""
    try:
        found = outdated()
    except Exception as exc:  # offline, site down, bad XML...
        xbmc.log("MediaHub Helper: update check failed: %r" % exc, xbmc.LOGWARNING)
        prop("MH.Update.Checked", "error")
        return []
    prop("MH.Update.Checked", time.strftime("%H:%M"))
    if not found:
        prop("MH.Update.Available", "")
        prop("MH.Update.Version", "")
        prop("MH.Update.News", "")
        if manual:
            xbmcgui.Dialog().notification("MediaHub", text(32030) % installed_version("skin.mediahub"),
                                          xbmcgui.NOTIFICATION_INFO, 3000, False)
        return []
    skin = [f for f in found if f[0] == "skin.mediahub"]
    addon_id, version, news = (skin or found)[0]
    already_told = xbmcgui.Window(10000).getProperty("MH.Update.Version") == version
    prop("MH.Update.Version", version)
    prop("MH.Update.News", news)
    prop("MH.Update.Available", "1")
    if notify and not already_told:
        xbmcgui.Dialog().notification("MediaHub", text(32031) % version, xbmcgui.NOTIFICATION_INFO, 5000, False)
    return found


def text(string_id):
    return xbmcaddon.Addon().getLocalizedString(string_id)


def rpc_setting(setting, value=None):
    import json
    if value is None:
        request = {"jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue", "params": {"setting": setting}}
    else:
        request = {"jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
                   "params": {"setting": setting, "value": value}}
    if xbmc.Monitor().abortRequested():  # (see mediahub.rpc)
        return {}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get("result", {})


PENDING = "special://profile/addon_data/script.mediahub.helper/pending_update.json"
PENDING_TIMEOUT = 15 * 60  # give up (and put the setting back) after this long


def pending_path():
    return xbmcvfs.translatePath(PENDING)


def load_pending():
    import json
    try:
        with open(pending_path()) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def save_pending(data):
    import json
    import os
    path = pending_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f)


def clear_pending():
    import os
    try:
        os.remove(pending_path())
    except OSError:
        pass


def update(monitor):
    """Install the MediaHub updates through Kodi's own add-on installer.

    This only starts the update and returns. Kodi replaces this add-on while it
    installs, so nothing of ours may still be running then: an earlier version
    waited here with a progress bar, Kodi had to kill it, and the update failed
    or Kodi crashed. The service finishes up afterwards (finish_update), in the
    new version once Kodi has restarted it.
    """
    found = check(notify=False)
    if not found or load_pending():
        return
    mode = rpc_setting("general.addonupdates").get("value", 0)
    if mode != 0:
        # Refresh Kodi's repository list (this installs nothing in "notify" mode) and
        # see whether other add-ons are waiting too
        xbmc.executebuiltin("UpdateAddonRepos(true)")
        for _ in range(40):
            if monitor.waitForAbort(0.5):
                return
            if int(xbmc.getInfoLabel("System.AddonUpdateCount") or 0) >= len(found):
                break
        if int(xbmc.getInfoLabel("System.AddonUpdateCount") or 0) > len(found):
            # Other add-ons have updates too: let the user choose in Kodi's list
            # rather than updating those as well
            xbmc.executebuiltin("ActivateWindow(addonbrowser,addons://outdated/,return)")
            return
    save_pending({"mode": mode, "time": time.time(),
                  "versions": {addon_id: installed_version(addon_id) for addon_id, _, _ in found}})
    xbmcgui.Dialog().notification("MediaHub", text(32032), xbmcgui.NOTIFICATION_INFO, 4000, False)
    if mode != 0:
        # install updates automatically, just for this; finish_update puts it back
        rpc_setting("general.addonupdates", 0)
    xbmc.executebuiltin("UpdateAddonRepos(true)")


def finish_update():
    """Called by the service now and then: once the update is in (or has taken too
    long), put the user's update setting back and say so."""
    pending = load_pending()
    if not pending:
        return
    versions = pending.get("versions") or {}
    done = all(installed_version(a) not in ("", v) for a, v in versions.items())
    if not done and time.time() - pending.get("time", 0) < PENDING_TIMEOUT:
        return
    clear_pending()
    if pending.get("mode", 0) != 0:
        rpc_setting("general.addonupdates", pending["mode"])
    if done:
        prop("MH.Update.Available", "")
        prop("MH.Update.Version", "")
        xbmcgui.Dialog().notification("MediaHub", text(32033) % installed_version("skin.mediahub"),
                                      xbmcgui.NOTIFICATION_INFO, 5000, False)
    else:
        # it didn't go through: show Kodi's list so it can be finished by hand
        xbmc.executebuiltin("ActivateWindow(addonbrowser,addons://outdated/,return)")
