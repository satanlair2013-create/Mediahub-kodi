"""MediaHub Helper - things about you.

* Avatars: "Who's watching?" shows every profile with an avatar. Skin Settings >
  Profile avatar picks one of the skin's avatars (media/avatars/avatar-NN.png).
  The login screen runs with the master profile's skin settings, so the pick is
  kept there as MH.Avatar.<position in the profile list>; this profile gets
  MH.MyAvatar too. MH.ProfileAvatar (Window(Home)) is this profile's avatar,
  picked or not, for the skin to show.
* Your year: MH.Year.* for the year-in-review page (Custom_1113_YourYear.xml),
  from the library's "last played" dates: hours watched, movies and episodes,
  top genres, the show you watched most, your longest binge and your busiest
  month. (Kodi keeps when you last watched each thing, not every time, so
  rewatches only count once.)
* Downloads (not on Apple TV): copy a movie or episode to the downloads folder
  (Skin.String(MH.DownloadFolder), or special://profile/addon_data/<this add-on>/downloads/)
  to watch without the network. Skin.HasSetting(MH.HasDownloads) is set once
  there is something in it.
"""
import collections
import os
import re
import time
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import mediahub

AVATARS = 12
PROFILES = "special://masterprofile/profiles.xml"
MASTER_SKIN_SETTINGS = "special://masterprofile/addon_data/skin.mediahub/settings.xml"
DEFAULT_DOWNLOADS = "special://profile/addon_data/script.mediahub.helper/downloads/"
CHUNK = 1024 * 1024


def home():
    return xbmcgui.Window(10000)


def text(string_id):
    return xbmcaddon.Addon().getLocalizedString(string_id)


# --------------------------------------------------------------------------- avatars

def profile_position():
    """This profile's place (1, 2, ...) in the profile list, as the login screen shows it."""
    try:
        root = ET.parse(xbmcvfs.translatePath(PROFILES)).getroot()
    except (OSError, ET.ParseError):
        return 1
    me = xbmc.getInfoLabel("System.ProfileName")
    for i, profile in enumerate(root.findall("profile"), 1):
        if profile.findtext("name") == me:
            return i
    return 1


def is_master():
    return xbmcvfs.translatePath("special://profile/") == xbmcvfs.translatePath("special://masterprofile/")


def avatar_path(number):
    return "special://skin/media/avatars/avatar-%s.png" % number


def show_avatar():
    """MH.ProfileAvatar: the picked avatar, else the one "Who's watching?" gives this position."""
    picked = xbmc.getInfoLabel("Skin.String(MH.MyAvatar)")
    number = picked or "%02d" % ((profile_position() - 1) % AVATARS + 1)
    home().setProperty("MH.ProfileAvatar", avatar_path(number))


def save_for_login_screen(position, number):
    """Write MH.Avatar.<position> into the master profile's skin settings."""
    key = "mh.avatar.%d" % position
    if is_master():
        # the master profile's settings are the live ones: Kodi saves them itself
        if number:
            xbmc.executebuiltin("Skin.SetString(MH.Avatar.%d,%s)" % (position, number))
        else:
            xbmc.executebuiltin("Skin.Reset(MH.Avatar.%d)" % position)
        return
    path = xbmcvfs.translatePath(MASTER_SKIN_SETTINGS)
    try:
        tree = ET.parse(path)
        root = tree.getroot()
    except (OSError, ET.ParseError):
        root = ET.Element("settings")
        tree = ET.ElementTree(root)
    setting = next((s for s in root.findall("setting") if s.get("id") == key), None)
    if not number:
        if setting is not None:
            root.remove(setting)
    else:
        if setting is None:
            setting = ET.SubElement(root, "setting", {"id": key, "type": "string"})
        setting.text = number
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tree.write(path, encoding="utf-8", xml_declaration=False)


def choose_avatar():
    items = []
    auto = xbmcgui.ListItem(text(32080), offscreen=True)
    auto.setArt({"icon": avatar_path("%02d" % ((profile_position() - 1) % AVATARS + 1))})
    items.append(auto)
    for n in range(1, AVATARS + 1):
        li = xbmcgui.ListItem("%s %d" % (text(32081), n), offscreen=True)
        li.setArt({"icon": avatar_path("%02d" % n)})
        items.append(li)
    pick = xbmcgui.Dialog().select(text(32082), items, useDetails=True)
    if pick < 0:
        return
    number = "" if pick == 0 else "%02d" % pick
    if number:
        xbmc.executebuiltin("Skin.SetString(MH.MyAvatar,%s)" % number)
    else:
        xbmc.executebuiltin("Skin.Reset(MH.MyAvatar)")
    save_for_login_screen(profile_position(), number)
    xbmc.sleep(200)
    show_avatar()


# --------------------------------------------------------------------------- your year

def this_year(date):
    return bool(date) and date.startswith(time.strftime("%Y"))


def fmt_day(date):
    """The day in the region's long format, without the weekday or year ("24 September")."""
    t = time.strptime(date[:10], "%Y-%m-%d")
    fmt = re.sub(r"%A[,.\s]*|[,.\s]*%Y", "", xbmc.getRegion("datelong")).strip(" ,.")
    return time.strftime(fmt or "%d %B", t).lstrip("0")


def year_in_review():
    kids = mediahub.kids_mode()
    movies = [m for m in mediahub.all_items("movie", mediahub.MOVIE_PROPS + ["lastplayed", "runtime"])
              if m.get("playcount") and this_year(m.get("lastplayed"))
              and (not kids or mediahub.kids_ok(m.get("mpaa")))]
    eps = [e for e in mediahub.rpc("VideoLibrary.GetEpisodes", properties=mediahub.EPISODE_PROPS).get("episodes", [])
           if e.get("playcount") and this_year(e.get("lastplayed"))]
    shows = {s["tvshowid"]: s for s in mediahub.all_items("tvshow", mediahub.SHOW_PROPS)}
    if kids:
        eps = [e for e in eps if mediahub.kids_ok((shows.get(e["tvshowid"]) or {}).get("mpaa"))]

    seconds = sum(m.get("runtime") or 0 for m in movies) + sum(e.get("runtime") or 0 for e in eps)
    def split(names):  # some scrapers leave "A | B" or "A / B" as one genre
        return [g.strip() for n in names or [] for g in re.split(r"\s*[|/]\s*", n) if g.strip()]

    genres = collections.Counter()
    for m in movies:
        genres.update(split(m.get("genre")))
    per_show = collections.Counter(e["tvshowid"] for e in eps)
    for showid, count in per_show.items():
        # an episode counts for a third of a movie
        genres.update({g: count / 3 for g in split((shows.get(showid) or {}).get("genre"))})
    months = collections.Counter(d["lastplayed"][5:7] for d in movies + eps)
    binges = collections.Counter((e["tvshowid"], e["lastplayed"][:10]) for e in eps)

    p = "MH.Year."
    home().setProperty(p + "Year", time.strftime("%Y"))
    home().setProperty(p + "Hours", str(int(round(seconds / 3600))))
    home().setProperty(p + "Movies", str(len(movies)))
    home().setProperty(p + "Episodes", str(len(eps)))
    home().setProperty(p + "Shows", str(len(per_show)))
    top = [g for g, _ in genres.most_common(3)]
    for i in range(3):
        home().setProperty(p + "Genre.%d" % (i + 1), top[i] if i < len(top) else "")
    for name in ("Show", "Show.Episodes", "Show.Poster", "Show.Fanart", "Show.Logo",
                 "Binge", "Binge.Show", "Binge.Day", "Month", "Movie", "Movie.Poster"):
        home().clearProperty(p + name)
    if per_show:
        showid, count = per_show.most_common(1)[0]
        show = shows.get(showid) or {}
        art = show.get("art") or {}
        home().setProperty(p + "Show", show.get("title", ""))
        home().setProperty(p + "Show.Episodes", str(count))
        home().setProperty(p + "Show.Poster", art.get("poster", ""))
        home().setProperty(p + "Show.Fanart", art.get("fanart", ""))
        home().setProperty(p + "Show.Logo", art.get("clearlogo", ""))
    if binges:
        (showid, day), count = binges.most_common(1)[0]
        if count > 1:
            home().setProperty(p + "Binge", str(count))
            home().setProperty(p + "Binge.Show", (shows.get(showid) or {}).get("title", ""))
            home().setProperty(p + "Binge.Day", fmt_day(day))
    if months:
        month = months.most_common(1)[0][0]
        home().setProperty(p + "Month", time.strftime("%B", time.strptime(month, "%m")))
    if movies:
        # your favourite: the best rated by you, then the most recently watched
        best = max(movies, key=lambda m: ((m.get("userrating") or 0), m.get("lastplayed") or ""))
        home().setProperty(p + "Movie", best.get("title", ""))
        home().setProperty(p + "Movie.Poster", (best.get("art") or {}).get("poster", ""))
    home().setProperty(p + "Ready", "1")


# --------------------------------------------------------------------------- downloads

def download_folder():
    folder = xbmc.getInfoLabel("Skin.String(MH.DownloadFolder)") or DEFAULT_DOWNLOADS
    return folder if folder.endswith(("/", "\\")) else folder + "/"


def safe_name(name):
    return re.sub(r'[\\/:*?"<>|]+', "", name).strip() or "video"


def download(kind, dbid):
    if xbmc.getCondVisibility("System.Platform.TVOS"):
        return  # Apple TV apps can't keep big files: tvOS may delete them at any time
    if kind == "movie":
        d = mediahub.details("movie", dbid, ["title", "year", "file"]) or {}
        name = "%s (%s)" % (d.get("title"), d.get("year")) if d.get("year") else d.get("title", "")
    else:
        d = mediahub.details("episode", dbid, ["title", "showtitle", "season", "episode", "file"]) or {}
        name = "%s S%02dE%02d %s" % (d.get("showtitle"), d.get("season") or 0, d.get("episode") or 0, d.get("title"))
    source = d.get("file", "")
    if not source or source.startswith(("plugin://", "stack://")):
        xbmcgui.Dialog().notification("MediaHub", text(32086), xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    folder = download_folder()
    xbmcvfs.mkdirs(folder)
    target = folder + safe_name(name) + os.path.splitext(source)[1]
    if xbmcvfs.exists(target):
        xbmcgui.Dialog().notification("MediaHub", text(32087), xbmcgui.NOTIFICATION_INFO, 3000, False)
        return
    size = xbmcvfs.Stat(source).st_size() or 0
    partial = target + ".part"
    progress = xbmcgui.DialogProgressBG()
    progress.create(text(32083), d.get("title", ""))
    done = 0
    ok = True
    src = xbmcvfs.File(source)
    dst = xbmcvfs.File(partial, "w")
    monitor = xbmc.Monitor()
    try:
        while True:
            chunk = src.readBytes(CHUNK)
            if not chunk:
                break
            if not dst.write(chunk) or monitor.abortRequested():
                ok = False
                break
            done += len(chunk)
            if size:
                progress.update(int(100 * done / size), text(32083), "%s - %d%%" % (d.get("title", ""), 100 * done / size))
    finally:
        src.close()
        dst.close()
        progress.close()
    if ok and (not size or done >= size):
        xbmcvfs.rename(partial, target)
        xbmc.executebuiltin("Skin.SetBool(MH.HasDownloads)")
        xbmcgui.Dialog().notification("MediaHub", text(32084) % d.get("title", ""), xbmcgui.NOTIFICATION_INFO, 4000, False)
    else:
        xbmcvfs.delete(partial)
        xbmcgui.Dialog().notification("MediaHub", text(32085), xbmcgui.NOTIFICATION_WARNING, 4000)


def delete_download(path):
    folder = xbmcvfs.translatePath(download_folder())
    if not xbmcvfs.translatePath(path).startswith(folder):
        return  # only ever delete from the downloads folder
    if xbmcgui.Dialog().yesno("MediaHub", text(32088) % os.path.basename(path)):
        xbmcvfs.delete(path)
        xbmc.executebuiltin("Container.Refresh")
        if not xbmcvfs.listdir(download_folder())[1]:
            xbmc.executebuiltin("Skin.Reset(MH.HasDownloads)")


class Downloads:
    """MH.InDownloads = 1 while the downloads folder is open, for the page title
    and the "Remove download" context menu item."""

    def __init__(self):
        self.next_check = 0.0

    def tick(self):
        now = time.time()
        if now < self.next_check:
            return
        self.next_check = now + 0.5
        inside = False
        if xbmc.getCondVisibility("Skin.HasSetting(MH.HasDownloads) + Window.IsActive(videos)"):
            here = xbmcvfs.translatePath(xbmc.getInfoLabel("Container.FolderPath")).rstrip("/\\")
            inside = here == xbmcvfs.translatePath(download_folder()).rstrip("/\\")
        if inside != (home().getProperty("MH.InDownloads") == "1"):
            home().setProperty("MH.InDownloads", "1" if inside else "")


def handle(action):
    """Answer avatar / yourYear / download|<type>|<dbid> / deletedownload|<path>."""
    name, _, arg = action.partition("|")
    if name == "avatar":
        return "thread", choose_avatar
    if name == "youryear":
        return "thread", year_in_review
    if name == "download":
        kind, _, dbid = arg.partition("|")
        if dbid.isdigit():
            return "thread", lambda: download(kind, int(dbid))
        return "done", None
    if name == "deletedownload":
        return "thread", lambda: delete_download(arg)
    return None, None
