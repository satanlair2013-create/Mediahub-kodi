"""MediaHub Helper - more on the details page and the show page.

* Ratings badges: when a movie's or show's details page opens, its scraped
  ratings are put in MH.Rating.* for the badges next to the title - IMDb (7.8),
  Rotten Tomatoes (92%, fresh or rotten), Metacritic (76, coloured by score)
  and TMDB (78%). Kodi keeps every rating out of 10; the percentages are
  worked out here. Only the ratings your scraper fetched are shown (the
  TMDb scraper gets Rotten Tomatoes and Metacritic with its OMDb setting on).
* Extras: videos in an "extras" (or "featurettes", "behind the scenes"...)
  folder next to the movie, or in the show's folder, are listed in
  MH.Extras.<i>.* for the Extras row. A picture with the same name as the
  video (or name-thumb.jpg) is its thumbnail.
* Mark season watched / unwatched on the show page: markseason|<tvshowid>|<season>.
"""
import os
import re

import xbmc
import xbmcgui
import xbmcvfs

import mediahub

EXTRAS_FOLDERS = ("extras", "featurettes", "behind the scenes", "deleted scenes", "interviews",
                  "scenes", "shorts", "other", "trailers")
VIDEO = (".mkv", ".mp4", ".m4v", ".avi", ".mov", ".ts", ".m2ts", ".webm", ".wmv", ".mpg", ".strm")
PICTURE = (".jpg", ".png", "-thumb.jpg", "-thumb.png", "-landscape.jpg")
# Metacritic's own colours
META_GREEN, META_YELLOW, META_RED = "FF66CC33", "FFFFCC33", "FFFF0000"

extras = []  # the paths in the Extras row, for extra|<n>


def home():
    return xbmcgui.Window(10000)


# --------------------------------------------------------------------------- ratings

def rating(ratings, *names):
    for name in names:
        value = (ratings.get(name) or {}).get("rating")
        if value:
            return value
    return None


def fill_ratings(kind, dbid, d):
    ratings = d.get("ratings") or {}
    imdb = rating(ratings, "imdb")
    tomato = rating(ratings, "tomatometerallcritics", "tomatometeravgcritics")
    meta = rating(ratings, "metacritic")
    tmdb = rating(ratings, "themoviedb", "tmdb")
    w = home()
    w.setProperty("MH.Rating.IMDb", "%.1f" % imdb if imdb else "")
    w.setProperty("MH.Rating.RT", "%d%%" % round(tomato * 10) if tomato else "")
    w.setProperty("MH.Rating.RT.Fresh", "1" if tomato and tomato >= 6 else "")
    w.setProperty("MH.Rating.Meta", str(round(meta * 10)) if meta else "")
    w.setProperty("MH.Rating.MetaColor", "" if not meta else
                  META_GREEN if meta >= 6.1 else META_YELLOW if meta >= 4 else META_RED)
    w.setProperty("MH.Rating.TMDB", "%d%%" % round(tmdb * 10) if tmdb else "")
    w.setProperty("MH.Rating.Type", kind)
    w.setProperty("MH.Rating.DBID", str(dbid))


# --------------------------------------------------------------------------- extras

def parent(path):
    """The folder a file is in (works for smb://, nfs:// and local paths)."""
    path = path.replace("\\", "/")
    return path[:path.rstrip("/").rfind("/") + 1]


def folder_items(folder):
    try:
        dirs, files = xbmcvfs.listdir(folder)
    except Exception:  # noqa: BLE001 - an unreadable share
        return [], []
    return dirs, files


def label_for(name):
    name = os.path.splitext(name)[0]
    name = re.sub(r"[-_.](behindthescenes|deleted|featurette|interview|scene|short|trailer|other|extra)$",
                  "", name, flags=re.I)
    return re.sub(r"[._]+", " ", name).strip()


def find_extras(base, fanart):
    """Videos in the extras folders under `base` (a folder path ending in /)."""
    found = []
    dirs, _ = folder_items(base)
    for d in sorted(dirs, key=str.lower):
        if d.lower() not in EXTRAS_FOLDERS:
            continue
        folder = base + d + "/"
        _, files = folder_items(folder)
        names = set(files)
        for f in sorted(files, key=str.lower):
            stem, ext = os.path.splitext(f)
            if ext.lower() not in VIDEO:
                continue
            thumb = next((folder + stem + p for p in PICTURE if stem + p in names), "")
            found.append({"Label": label_for(f), "Label2": d, "Landscape": thumb or fanart,
                          "ArtHasTitle": "", "Title": label_for(f),
                          "Action": "extra|%d" % len(found), "Path": folder + f})
            if len(found) >= mediahub.MAX_ITEMS:
                return found
    return found


def fill_extras(kind, dbid, d):
    global extras
    path = d.get("file", "")  # a show's is its folder
    fanart = (d.get("art") or {}).get("fanart", "")
    found = []
    if path and not path.startswith(("stack://", "plugin://", "videodb://")):
        base = path if kind == "tvshow" else parent(path)
        found = find_extras(base, fanart)
    extras = [f.pop("Path") for f in found]
    mediahub.fill("MH.Extras", found)
    home().setProperty("MH.Extras.Type", kind)
    home().setProperty("MH.Extras.DBID", str(dbid))


def play_extra(index):
    if 0 <= index < len(extras):
        xbmc.executebuiltin("Dialog.Close(all,true)")
        xbmc.Player().play(extras[index])


# --------------------------------------------------------------------------- the page opened

def refresh(request):
    """MH.Req.Similar = <type>|<dbid>: the details page of a movie or show opened."""
    kind, _, dbid = request.partition("|")
    if kind not in ("movie", "tvshow") or not dbid.isdigit():
        return
    d = mediahub.details(kind, int(dbid), ["ratings", "file", "art"])
    if d:
        fill_ratings(kind, int(dbid), d)
        fill_extras(kind, int(dbid), d)


# --------------------------------------------------------------------------- seasons

def mark_season(tvshowid, season):
    """Mark every episode of a season watched - or, if they all are, unwatched."""
    eps = mediahub.rpc("VideoLibrary.GetEpisodes", tvshowid=tvshowid, season=season,
                       properties=["playcount"]).get("episodes", [])
    if not eps:
        return
    watched = 0 if all(e["playcount"] for e in eps) else 1
    for e in eps:
        if bool(e["playcount"]) != bool(watched):
            params = {"episodeid": e["episodeid"], "playcount": watched}
            if watched:
                params["resume"] = {"position": 0, "total": 0}
            mediahub.rpc("VideoLibrary.SetEpisodeDetails", **params)
    # Kodi refreshes the page itself on each change; refresh once more after the last
    xbmc.sleep(600)
    xbmc.executebuiltin("Container.Refresh")
    mediahub.refresh_show(str(tvshowid))


def handle(action):
    """Answer extra|<n> / markseason|<tvshowid>|<season>."""
    parts = action.split("|")
    if parts[0] == "extra" and len(parts) == 2 and parts[1].isdigit():
        return "thread", lambda: play_extra(int(parts[1]))
    if parts[0] == "markseason" and len(parts) == 3 and parts[1].isdigit() and \
            re.match(r"^-?\d+$", parts[2]) and int(parts[2]) >= 0:
        return "thread", lambda: mark_season(int(parts[1]), int(parts[2]))
    return None, None
