"""MediaHub Helper - finding something to watch.

* People search: while the search page (Custom_1106_Search.xml) is open, the
  names of actors and directors that contain what you've typed are listed in
  MH.People.<i>.Label / .Thumb / .Role (MH.People.Count), from movies and TV
  shows together, each person once.
* Surprise me: picks something unwatched for you - weighted towards what you
  like, but still a surprise - and opens it.
* Voice search: the search page's mic key opens the keyboard with a hint to
  talk. On Apple TV, Kodi's keyboard takes dictation from the Siri Remote.
"""
import json
import random
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui

import mediahub

MAX_PEOPLE = 20
SEARCH_WINDOW = 1106
# where Kodi keeps people: (node, content type, role string id)
PEOPLE_NODES = (("movies/actors", "movies", 32070), ("tvshows/actors", "tvshows", 32070),
                ("movies/directors", "movies", 32071), ("tvshows/directors", "tvshows", 32071))


def home():
    return xbmcgui.Window(10000)


def text(string_id):
    return xbmcaddon.Addon().getLocalizedString(string_id)


# --------------------------------------------------------------------------- people search

def people_path(node, content, field, words):
    rules = {"rules": {"and": [{"field": field, "operator": "contains", "value": [words]}]},
             "type": content}
    return "videodb://%s/?xsp=%s" % (node, urllib.parse.quote(json.dumps(rules, separators=(",", ":"))))


def find_people(words):
    found = {}
    for node, content, role in PEOPLE_NODES:
        field = "director" if "directors" in node else "actor"
        files = mediahub.rpc("Files.GetDirectory", directory=people_path(node, content, field, words),
                             media="video", properties=["thumbnail"]).get("files") or []
        for f in files:
            # (the filter picks the titles with a matching name in them, and
            # Kodi then lists everyone in those titles)
            name = f.get("label") or ""
            if words.lower() not in name.lower():
                continue
            person = found.setdefault(name.lower(), {"Label": name, "Thumb": "", "roles": []})
            person["Thumb"] = person["Thumb"] or f.get("thumbnail") or ""
            if role not in person["roles"]:
                person["roles"].append(role)
    words = words.lower()
    people = sorted(found.values(), key=lambda p: (not p["Label"].lower().startswith(words),
                                                   not p["Thumb"], p["Label"].lower()))
    return people[:MAX_PEOPLE]


def fill_people(people):
    for i in range(1, MAX_PEOPLE + 1):
        p = people[i - 1] if i <= len(people) else {}
        home().setProperty("MH.People.%d.Label" % i, p.get("Label", ""))
        home().setProperty("MH.People.%d.Thumb" % i, p.get("Thumb", ""))
        home().setProperty("MH.People.%d.Role" % i, " & ".join(text(r) for r in p.get("roles", [])))
    home().setProperty("MH.People.Count", str(len(people)))


class People:
    """Keeps MH.People.* in step with what's typed on the search page."""

    def __init__(self):
        self.words = None
        self.changed = 0.0
        self.next_check = 0.0

    def tick(self):
        now = time.time()
        if now < self.next_check:
            return
        self.next_check = now + 0.2
        if not xbmc.getCondVisibility("Window.IsActive(%d)" % SEARCH_WINDOW):
            return
        words = xbmc.getInfoLabel("Skin.String(MH.Search)").strip()
        if words == self.words:
            return
        if self.changed == 0.0:
            self.changed = now  # wait until the typing pauses
        if now - self.changed < 0.4:
            return
        self.changed = 0.0
        self.words = words
        fill_people(find_people(words) if len(words) >= 2 else [])


# --------------------------------------------------------------------------- surprise me

def surprise(kind=""):
    """Open something unwatched: a movie, or a show with episodes left to see."""
    kids = mediahub.kids_mode()
    movies = mediahub.all_items("movie", mediahub.MOVIE_PROPS) if kind != "tvshow" else []
    shows = mediahub.all_items("tvshow", mediahub.SHOW_PROPS) if kind != "movie" else []
    weights = mediahub.taste(movies + shows)
    pool = []
    for k, items in (("movie", movies), ("tvshow", shows)):
        for d in items:
            r = d.get("userrating") or 0
            unwatched = not d.get("playcount") if k == "movie" else \
                (d.get("watchedepisodes") or 0) < (d.get("episode") or 0)
            if not unwatched or 1 <= r <= 4 or (kids and not mediahub.kids_ok(d.get("mpaa"))):
                continue
            # taste tilts the odds; the random part keeps it a surprise
            pool.append((max(0.5, 1 + mediahub.score(d, weights)) * random.random(), k, d))
    if not pool:
        xbmcgui.Dialog().notification("MediaHub", text(32073), xbmcgui.NOTIFICATION_INFO, 3000, False)
        return
    _, k, d = max(pool, key=lambda row: row[0])
    xbmcgui.Dialog().notification(text(32072), d["title"], xbmcgui.NOTIFICATION_INFO, 3000, False)
    mediahub.open_item(k, d["movieid"] if k == "movie" else d["tvshowid"])


# --------------------------------------------------------------------------- voice search

def voice_search():
    # (empty, so what you say replaces what was there)
    words = xbmcgui.Dialog().input(text(32074))
    if words:
        xbmc.executebuiltin('Skin.SetString(MH.Search,"%s")' % words.replace('"', "").strip())


def handle(action):
    """Answer surprise[|movie|tvshow] / voicesearch."""
    name, _, arg = action.partition("|")
    if name == "surprise":
        return "thread", lambda: surprise(arg)
    if name == "voicesearch":
        return "thread", voice_search
    return None, None
