"""MediaHub Helper - which days count as "new" for the NEW / NEW EPISODES badges.

Kodi can't compare dates in a skin, so this writes the last NEW_DAYS days, formatted
exactly like ListItem.DateAdded (the short date of the user's region), to
MH.NewDate.1 .. MH.NewDate.<NEW_DAYS>, and the skin checks ListItem.DateAdded
against them. A day when a big part of the library was added at once (the first
scan of a library) is left out, so a fresh library isn't all marked NEW.
"""
import datetime
import json

import xbmc
import xbmcgui

NEW_DAYS = 14
BULK_MIN = 20  # a day with more additions than this, and at least half the library, is an import


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return reply.get("result", {})


def kodi_date(fmt, day):
    """Format a date with the pattern xbmc.getRegion('dateshort') returns
    (it is %m/%d/%Y-style, with %-d / %#d for no leading zero)."""
    out = fmt
    for token, value in (("%-d", str(day.day)), ("%#d", str(day.day)), ("%d", "%02d" % day.day),
                         ("%-m", str(day.month)), ("%#m", str(day.month)), ("%m", "%02d" % day.month),
                         ("%Y", "%04d" % day.year), ("%y", "%02d" % (day.year % 100))):
        out = out.replace(token, value)
    return out


class Recent:
    def __init__(self):
        self.days = set()  # "YYYY-MM-DD" of the days that count as new
        self.today = None

    def refresh(self):
        counts = {}
        total = 0
        for method, key in (("VideoLibrary.GetMovies", "movies"), ("VideoLibrary.GetEpisodes", "episodes")):
            for item in rpc(method, properties=["dateadded"]).get(key, []):
                total += 1
                day = (item.get("dateadded") or "")[:10]
                if day:
                    counts[day] = counts.get(day, 0) + 1
        today = datetime.date.today()
        fmt = xbmc.getRegion("dateshort")
        home = xbmcgui.Window(10000)
        self.days = set()
        for i in range(NEW_DAYS):
            day = today - datetime.timedelta(days=i)
            n = counts.get(day.isoformat(), 0)
            bulk = n > BULK_MIN and n * 2 >= total
            if n and not bulk:
                self.days.add(day.isoformat())
                home.setProperty("MH.NewDate.%d" % (i + 1), kodi_date(fmt, day))
            else:
                home.setProperty("MH.NewDate.%d" % (i + 1), "")
        self.today = today

    def due(self):
        """A new day started since the last refresh."""
        return self.today != datetime.date.today()

    def is_new(self, dateadded):
        return bool(dateadded) and dateadded[:10] in self.days


RECENT = Recent()
