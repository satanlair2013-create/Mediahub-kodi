"""MediaHub Helper - for the whole family.

* Bedtime (Kids mode): Skin.String(MH.Bedtime) and MH.WakeTime ("HH:MM") make a
  night. Ten minutes before bedtime a note says so; at bedtime what is playing
  gets ten more minutes (or stops at its end, if sooner) and then the bedtime
  screen (Custom_1118_Bedtime.xml) covers everything until the morning. A
  grown-up can unlock it for the night with the Kids mode PIN. Leaving Kids
  mode ends it too.
* Family List: a "watch together" list every profile shares. It lives in the
  master profile's add-on data (special://masterprofile/...), and titles are
  matched to each profile's library by their IMDb / TMDB / TVDB id, or title and
  year. familylist|<type>|<dbid> adds or removes; the "family" home row shows it.
* Backup and restore: your skin settings (rows, network cards, colours, every
  switch), My List and thumbs to one .json file anywhere Kodi can write, and
  back. My List and thumbs are matched by id or title and year, so a backup
  moves to another device with the same films. The helper's own files (the
  order of My List, hidden Up Next shows, remembered intros) go back only to
  the same library.
"""
import datetime
import hashlib
import json
import os
import time
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import mediahub

FAMILY_FILE = "special://masterprofile/addon_data/script.mediahub.helper/family.json"
SKIN_SETTINGS = "special://profile/addon_data/skin.mediahub/settings.xml"
HELPER_DATA = "special://profile/addon_data/script.mediahub.helper/"
HELPER_FILES = ("mylist.json", "upnext_hidden.json", "autoskip.json")
BEDTIME_WINDOW = 1118
WARN = 10 * 60        # the note before bedtime, and the grace for what is playing
BACKUP_KIND = "mediahub-backup"


def home():
    return xbmcgui.Window(10000)


def text(string_id):
    return xbmcaddon.Addon().getLocalizedString(string_id)


def notify(string_id, heading=""):
    xbmcgui.Dialog().notification(heading or "MediaHub", text(string_id), xbmcgui.NOTIFICATION_INFO, 4000, False)


# --------------------------------------------------------------------------- matching titles

def ids_of(d):
    return {k: str(v) for k, v in (d.get("uniqueid") or {}).items() if v}


def same_title(entry, d):
    ids = ids_of(d)
    if any(ids.get(k) == v for k, v in (entry.get("ids") or {}).items()):
        return True
    return entry.get("title", "").lower() == d.get("title", "").lower() and \
        (not entry.get("year") or not d.get("year") or int(entry["year"]) == int(d["year"]))


def library(kind, props):
    return mediahub.all_items(kind, props + ["uniqueid"] if "uniqueid" not in props else props)


def find(kind, entry, items):
    return next((d for d in items if same_title(entry, d)), None)


def entry_for(kind, d):
    return {"type": kind, "title": d.get("title", ""), "year": d.get("year") or 0, "ids": ids_of(d)}


# --------------------------------------------------------------------------- Family List

def load_family():
    try:
        with open(xbmcvfs.translatePath(FAMILY_FILE), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def save_family(entries):
    path = xbmcvfs.translatePath(FAMILY_FILE)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(entries, f)


def in_family(kind, d, entries=None):
    return any(e["type"] == kind and same_title(e, d) for e in (entries if entries is not None else load_family()))


def set_state(kind, dbid, state):
    home().setProperty("MH.Family.Type", kind)
    home().setProperty("MH.Family.DBID", str(dbid))
    home().setProperty("MH.Family.In", "1" if state else "")


def toggle_family(kind, dbid):
    d = mediahub.details(kind, dbid, ["title", "year", "uniqueid"])
    if not d:
        return
    entries = load_family()
    kept = [e for e in entries if not (e["type"] == kind and same_title(e, d))]
    added = len(kept) == len(entries)
    if added:
        entry = entry_for(kind, d)
        entry["by"] = xbmc.getInfoLabel("System.ProfileName")
        entry["added"] = int(time.time())
        kept.insert(0, entry)
    save_family(kept)
    set_state(kind, dbid, added)
    notify(32105 if added else 32106, d.get("title", ""))
    home().setProperty("MH.Req.Rows", "family%d" % time.time())


def family_row(kids):
    """The home row: the Family List titles this profile's library has, newest first."""
    entries = load_family()
    if not entries:
        return []
    found = []
    for kind in ("movie", "tvshow"):
        want = [e for e in entries if e["type"] == kind]
        if not want:
            continue
        items = library(kind, mediahub.MOVIE_PROPS if kind == "movie" else mediahub.SHOW_PROPS)
        for e in want:
            d = find(kind, e, items)
            if d and (not kids or mediahub.kids_ok(d.get("mpaa"))):
                found.append((e.get("added", 0), mediahub.title_fields(kind, d)))
    found.sort(key=lambda row: row[0], reverse=True)
    return [fields for _, fields in found[:mediahub.MAX_ITEMS]]


def refresh(request):
    """The details page opened (MH.Req.Similar = <type>|<dbid>): is it on the Family List?"""
    kind, _, dbid = request.partition("|")
    if kind in ("movie", "tvshow") and dbid.isdigit():
        d = mediahub.details(kind, int(dbid), ["title", "year", "uniqueid"])
        if d:
            set_state(kind, int(dbid), in_family(kind, d))


# --------------------------------------------------------------------------- bedtime

def minutes(hhmm):
    try:
        h, m = hhmm.split(":")
        return int(h) * 60 + int(m)
    except ValueError:
        return None


class Bedtime:
    """Checked by the service every loop; does its work every couple of seconds."""

    def __init__(self):
        self.next_check = 0
        self.warned = None     # the night we gave the ten-minute note for
        self.stop_at = None    # when what is playing at bedtime stops

    def night(self, now, bed, wake):
        """The date the current night started, or None outside bedtime."""
        mins = now.hour * 60 + now.minute
        if bed == wake:
            return None
        if bed < wake:
            return now.date().isoformat() if bed <= mins < wake else None
        if mins >= bed:
            return now.date().isoformat()
        if mins < wake:
            return (now.date() - datetime.timedelta(days=1)).isoformat()
        return None

    def tick(self, kids_mode):
        if time.time() < self.next_check:
            return
        self.next_check = time.time() + 2
        bed = minutes(xbmc.getInfoLabel("Skin.String(MH.Bedtime)"))
        wake = minutes(xbmc.getInfoLabel("Skin.String(MH.WakeTime)") or "07:00")
        locked = home().getProperty("MH.Bedtime.Locked")
        if not kids_mode() or bed is None or wake is None:
            if locked:
                self.unlock()
            return
        now = datetime.datetime.now()
        night = self.night(now, bed, wake)
        if night is None:
            if locked:
                self.unlock()
            soon = (bed - (now.hour * 60 + now.minute)) % (24 * 60)
            if 0 < soon <= WARN // 60 and self.warned != now.date().isoformat():
                self.warned = now.date().isoformat()
                notify(32111)
            return
        if home().getProperty("MH.Bedtime.Unlocked") == night:
            return
        player = xbmc.Player()
        if player.isPlaying() and not locked:
            if self.stop_at is None:
                self.stop_at = time.time() + WARN
                notify(32110)
            if time.time() < self.stop_at:
                return
            player.stop()
            xbmc.sleep(500)
        self.stop_at = None
        home().setProperty("MH.Bedtime.Locked", night)
        home().setProperty("MH.Bedtime.Wake", xbmc.getInfoLabel("Skin.String(MH.WakeTime)") or "07:00")
        if player.isPlaying():
            player.stop()
        if not xbmc.getCondVisibility("Window.IsActive(%d)" % BEDTIME_WINDOW):
            xbmc.executebuiltin("Dialog.Close(all,true)")
            xbmc.executebuiltin("ActivateWindow(%d)" % BEDTIME_WINDOW)

    def unlock(self, night=""):
        if night:
            home().setProperty("MH.Bedtime.Unlocked", night)
        home().clearProperty("MH.Bedtime.Locked")
        self.stop_at = None
        if xbmc.getCondVisibility("Window.IsActive(%d)" % BEDTIME_WINDOW):
            xbmc.executebuiltin("ReplaceWindow(home)")

    def grown_up(self):
        """The bedtime screen's button: the Kids mode PIN unlocks it until the morning."""
        pin = xbmc.getInfoLabel("Skin.String(MH.KidsPin)")
        if pin:
            tried = xbmcgui.Dialog().numeric(0, text(32112), "", True)
            if tried != pin:
                if tried:
                    notify(32113)
                return
        self.unlock(home().getProperty("MH.Bedtime.Locked") or "unlocked")


def choose_bedtime():
    """Skin Settings > Bedtime: set bedtime and wake-up time, or turn it off."""
    dialog = xbmcgui.Dialog()
    while True:
        bed = xbmc.getInfoLabel("Skin.String(MH.Bedtime)")
        wake = xbmc.getInfoLabel("Skin.String(MH.WakeTime)") or "07:00"
        options = ["%s: %s" % (text(32107), bed or "-"), "%s: %s" % (text(32108), wake)]
        if bed:
            options.append(text(32109))
        pick = dialog.select(text(32107), options)
        if pick < 0:
            return
        if pick == 2:
            xbmc.executebuiltin("Skin.Reset(MH.Bedtime)")
            return
        name, current = ("MH.Bedtime", bed or "20:00") if pick == 0 else ("MH.WakeTime", wake)
        value = dialog.numeric(2, text(32107 if pick == 0 else 32108), current)
        if value and minutes(value) is not None:
            h, m = value.split(":")
            xbmc.executebuiltin("Skin.SetString(%s,%02d:%02d)" % (name, int(h), int(m)))
            xbmc.sleep(200)


# --------------------------------------------------------------------------- backup and restore

def skin_settings():
    """{id: (type, value)} for every skin setting that is on or has a value."""
    try:
        root = ET.parse(xbmcvfs.translatePath(SKIN_SETTINGS)).getroot()
    except (OSError, ET.ParseError):
        return {}
    found = {}
    for s in root.iter("setting"):
        sid, kind, value = s.get("id", ""), s.get("type", "string"), s.text or ""
        if sid and ((kind == "bool" and value == "true") or (kind == "string" and value)):
            found[sid] = (kind, value)
    return found


def fingerprint():
    """Tells whether a backup was made from this same library (the ids match)."""
    h = hashlib.md5()
    for kind in ("movie", "tvshow"):
        for d in mediahub.all_items(kind, ["title"]):
            h.update(("%s%d%s" % (kind, d[kind + "id"], d["title"])).encode("utf-8"))
    return h.hexdigest()


def backup():
    dialog = xbmcgui.Dialog()
    folder = dialog.browse(3, text(32114), "files")
    if not folder:
        return
    items = []
    for kind in ("movie", "tvshow"):
        for d in mediahub.all_items(kind, ["title", "year", "uniqueid", "tag", "userrating"]):
            mine = mediahub.MYLIST_TAG in (d.get("tag") or [])
            if mine or d.get("userrating"):
                e = entry_for(kind, d)
                e.update({"mylist": mine, "rating": d.get("userrating") or 0})
                items.append(e)
    files = {}
    for name in HELPER_FILES:
        try:
            with open(xbmcvfs.translatePath(HELPER_DATA + name), encoding="utf-8") as f:
                files[name] = json.load(f)
        except (OSError, ValueError):
            pass
    data = {"kind": BACKUP_KIND, "version": 1, "made": time.strftime("%Y-%m-%d %H:%M"),
            "profile": xbmc.getInfoLabel("System.ProfileName"),
            "skin": {k: list(v) for k, v in skin_settings().items()},
            "library": items, "files": files, "fingerprint": fingerprint()}
    name = "MediaHub backup %s.json" % time.strftime("%Y-%m-%d")
    path = folder + ("" if folder.endswith(("/", "\\")) else "/") + name
    f = xbmcvfs.File(path, "w")
    ok = f.write(json.dumps(data, indent=1).encode("utf-8"))
    f.close()
    dialog.notification("MediaHub", text(32115 if ok else 32120) + ("\n" + name if ok else ""),
                        xbmcgui.NOTIFICATION_INFO, 5000, False)


def quote(value):
    return '"%s"' % value.replace("\\", "\\\\").replace('"', '\\"')


def restore():
    dialog = xbmcgui.Dialog()
    path = dialog.browse(1, text(32116), "files", ".json")
    if not path:
        return
    f = xbmcvfs.File(path)
    try:
        data = json.loads(f.readBytes().decode("utf-8"))
    except ValueError:
        data = {}
    finally:
        f.close()
    if data.get("kind") != BACKUP_KIND:
        notify(32119)
        return
    if not dialog.yesno("MediaHub", "%s\n%s  •  %s" % (text(32117), data.get("profile", ""), data.get("made", ""))):
        return
    # skin settings: what the backup has, and nothing else
    wanted = {k: tuple(v) for k, v in (data.get("skin") or {}).items()}
    for sid, (kind, _) in skin_settings().items():
        if sid not in wanted:
            xbmc.executebuiltin("Skin.Reset(%s)" % sid)
    for sid, (kind, value) in wanted.items():
        if kind == "bool":
            xbmc.executebuiltin("Skin.SetBool(%s)" % sid)
        else:
            xbmc.executebuiltin("Skin.SetString(%s,%s)" % (sid, quote(value)))
    # My List and thumbs
    for kind in ("movie", "tvshow"):
        want = [e for e in data.get("library") or [] if e.get("type") == kind]
        if not want:
            continue
        method = "VideoLibrary.SetMovieDetails" if kind == "movie" else "VideoLibrary.SetTVShowDetails"
        items = mediahub.all_items(kind, ["title", "year", "uniqueid", "tag", "userrating"])
        for e in want:
            d = find(kind, e, items)
            if not d:
                continue
            params = {kind + "id": d[kind + "id"]}
            tags = d.get("tag") or []
            if e.get("mylist") and mediahub.MYLIST_TAG not in tags:
                params["tag"] = tags + [mediahub.MYLIST_TAG]
            if e.get("rating") and e["rating"] != d.get("userrating"):
                params["userrating"] = int(e["rating"])
            if len(params) > 1:
                mediahub.rpc(method, **params)
    if data.get("fingerprint") == fingerprint():
        folder = xbmcvfs.translatePath(HELPER_DATA)
        os.makedirs(folder, exist_ok=True)
        for name, content in (data.get("files") or {}).items():
            if name in HELPER_FILES:
                with open(os.path.join(folder, name), "w", encoding="utf-8") as out:
                    json.dump(content, out)
    notify(32118)
    xbmc.sleep(500)
    xbmc.executebuiltin("ReloadSkin()")


def handle(action, bedtime):
    """Answer familylist|<type>|<dbid> / bedtime / bedtimeunlock / backup / restore."""
    parts = action.split("|")
    if parts[0] == "familylist" and len(parts) == 3 and parts[2].isdigit():
        return "thread", lambda: toggle_family(parts[1], int(parts[2]))
    if parts[0] == "bedtime":
        return "thread", choose_bedtime
    if parts[0] == "bedtimeunlock":
        return "thread", bedtime.grown_up
    if parts[0] == "backup":
        return "thread", backup
    if parts[0] == "restore":
        return "thread", restore
    return None, None
