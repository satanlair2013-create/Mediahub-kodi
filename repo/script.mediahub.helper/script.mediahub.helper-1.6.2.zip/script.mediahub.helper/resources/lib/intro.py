"""MediaHub Helper - the start-up intro (the skin's Startup.xml).

When Kodi starts, the skin shows its intro window and waits. The helper plays
the intro sound (special://skin/sounds/intro.wav, through Kodi's interface
sounds so nothing shows as "now playing") and sets MH.Intro.Play in the same
moment, which starts the pictures, so the logo lands on the beat. After the
intro it opens the home screen.

Skin.HasSetting(MH.NoIntro) skips the intro, MH.NoIntroSound keeps it silent.
Kodi's own Settings > Interface > Sounds set to Off also silences it.

The splash: while Kodi itself loads (before any skin), it shows
special://home/media/splash.png if there is one. The helper puts the skin's
media/splash.png there - the same picture the intro starts from - and takes it
away again if you change skin or turn the intro off. A splash of your own
(splash.jpg, or a splash.png that isn't ours) is left alone.
"""
import hashlib
import os
import shutil

import xbmc
import xbmcgui
import xbmcvfs

SOUND = "special://skin/sounds/intro.wav"
LENGTH = 3.7  # seconds from the sound starting to the home screen
STARTUP = 12999  # Kodi's start-up window (Startup.xml)
SPLASH_SOURCE = "special://skin/media/splash.png"
SPLASH = "special://home/media/splash.png"
USER_SPLASH = "special://home/media/splash.jpg"  # Kodi prefers this one
SPLASH_MARK = "special://home/media/mediahub-splash.md5"  # says the splash.png is ours


def md5(path):
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()


def sync_splash():
    """Put our splash in place, or take it away (see above)."""
    dest = xbmcvfs.translatePath(SPLASH)
    mark = xbmcvfs.translatePath(SPLASH_MARK)
    try:
        with open(mark) as f:
            mine = os.path.exists(dest) and f.read().strip() == md5(dest)
    except OSError:
        mine = False
    wanted = xbmc.getSkinDir() == "skin.mediahub" and \
        not xbmc.getCondVisibility("Skin.HasSetting(MH.NoIntro)")
    try:
        if not wanted:
            if mine:
                os.remove(dest)
                os.remove(mark)
            return
        if os.path.exists(xbmcvfs.translatePath(USER_SPLASH)) or (os.path.exists(dest) and not mine):
            return
        source = xbmcvfs.translatePath(SPLASH_SOURCE)
        if os.path.exists(source) and (not mine or md5(source) != md5(dest)):
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copyfile(source, dest)
            with open(mark, "w") as f:
                f.write(md5(dest))
    except OSError as exc:
        xbmc.log("MediaHub Helper: splash: %r" % exc, xbmc.LOGWARNING)


def startup_showing():
    return xbmc.getCondVisibility("Window.IsActive(%d)" % STARTUP)


def play(monitor):
    """Called once when the service starts (in its own thread)."""
    if not startup_showing() or xbmc.getCondVisibility("Skin.HasSetting(MH.NoIntro)"):
        return
    home = xbmcgui.Window(10000)
    xbmc.executebuiltin("CancelAlarm(mhintro_nohelper,true)")
    if home.getProperty("MH.Intro.Play"):
        return  # the skin already started it on its own
    if not xbmc.getCondVisibility("Skin.HasSetting(MH.NoIntroSound)"):
        xbmc.playSFX(SOUND, False)
    home.setProperty("MH.Intro.Play", "1")
    if monitor.waitForAbort(LENGTH):
        return
    if startup_showing():  # (unless a button already skipped it)
        xbmc.executebuiltin("CancelAlarm(mhintro,true)")
        xbmc.executebuiltin("ReplaceWindow(%s)" % xbmc.getInfoLabel("System.StartupWindow"))
