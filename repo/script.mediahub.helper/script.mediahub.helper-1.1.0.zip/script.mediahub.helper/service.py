"""MediaHub Helper - background service.

The one place the add-on's Python runs: the skin sets request properties on
Window(Home) and this loop answers them (see resources/lib/mediahub.py). Keeping
it all in one long-running script means the skin never starts several add-on
scripts at once, which Kodi builds on Python 3.12 can crash on.
"""
import os
import sys

import xbmc
import xbmcgui

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import mediahub  # noqa: E402

REFRESH_ON = ("VideoLibrary.OnUpdate", "VideoLibrary.OnScanFinished", "VideoLibrary.OnRemove",
              "VideoLibrary.OnCleanFinished", "Player.OnStop")


class Service(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.rows_due = False

    def onNotification(self, sender, method, data):
        if method in REFRESH_ON:
            self.rows_due = True

    def take(self, name):
        home = xbmcgui.Window(10000)
        value = home.getProperty(name)
        if value:
            home.clearProperty(name)
        return value

    def run(self):
        mediahub.prop("MH.HelperRunning", "1")
        while not self.waitForAbort(0.1):
            try:
                action = self.take("MH.Req.Action")
                if action and mediahub.do_action(action):
                    self.rows_due = True
                similar = self.take("MH.Req.Similar")
                if similar:
                    mediahub.refresh_similar(similar)
                show = self.take("MH.Req.Show")
                if show.isdigit():
                    mediahub.refresh_show(show)
                if self.take("MH.Req.Rows") or self.rows_due:
                    self.rows_due = False
                    mediahub.refresh_rows()
            except Exception as exc:  # keep serving whatever one request did
                xbmc.log("MediaHub Helper: %r" % exc, xbmc.LOGERROR)
        mediahub.prop("MH.HelperRunning", "")


if __name__ == "__main__":
    Service().run()
