"""MediaHub Helper - context menu items: My List and thumbs for library titles,
My channels for Live TV channels, moving or hiding a home row, and Remove
download in the downloads folder. They hand the request to the
service (see resources/lib/mediahub.py and personal.py)."""
import sys
import time

import xbmcaddon
import xbmcgui


def my_channel():
    """Add the channel to My channels, or take it off."""
    import os
    import xbmc
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
    import channels
    item = sys.listitem
    channelid = item.getProperty("channelid") or xbmc.getInfoLabel("ListItem.Property(channelid)")
    if not channelid.isdigit():
        return
    name = xbmc.getInfoLabel("ListItem.ChannelName") or item.getLabel()
    added = channels.toggle({"id": int(channelid), "name": name, "icon": item.getArt("icon") or
                             xbmc.getInfoLabel("ListItem.Icon"), "path": item.getPath()})
    addon = xbmcaddon.Addon()
    xbmcgui.Dialog().notification("MediaHub", addon.getLocalizedString(32142 if added else 32143) % name,
                                  xbmcgui.NOTIFICATION_INFO, 3000, False)


ROW_LISTS = range(9301, 9337)  # the home row lists: 12 positions x 3 layouts (gen_rows.py LIST_BASE)
ROW_GROUPS = 9400  # their groups: 9400 + 3n - 2 .. 9400 + 3n


def row_shown(n):
    import xbmc
    return any(xbmc.getCondVisibility("Control.IsVisible(%d)" % (ROW_GROUPS + 3 * n - k)) for k in (0, 1, 2))


def row_menu():
    """Move the focused home row up or down (past rows that aren't showing), or hide it."""
    import xbmc
    control = xbmc.getInfoLabel("System.CurrentControlID")
    if not control.isdigit() or int(control) not in ROW_LISTS:
        return
    home, addon = xbmcgui.Window(10000), xbmcaddon.Addon()
    n, layout = (int(control) - ROW_LISTS[0]) // 3 + 1, (int(control) - ROW_LISTS[0]) % 3
    keys = {i: home.getProperty("MH.RowKey.%d" % i) for i in range(1, 13)}
    up = next((m for m in range(n - 1, 0, -1) if row_shown(m)), None)
    down = next((m for m in range(n + 1, 13) if row_shown(m)), None)
    choices = [(k, sid) for k, sid in (("up", 32147), ("down", 32148)) if (up if k == "up" else down)]
    choices += [("hide", 32149), ("edit", 32150)]
    pick = xbmcgui.Dialog().contextmenu([addon.getLocalizedString(sid) for _, sid in choices])
    if pick < 0:
        return
    what = choices[pick][0]
    if what == "edit":
        xbmc.executebuiltin("ActivateWindow(1103)")
        return
    if what == "hide":
        xbmc.executebuiltin("Skin.SetString(MH.Row%d,none)" % n)
        home.setProperty("MH.RowKey.%d" % n, "none")
        near = down or up
        if near:  # (focus the row that takes its place)
            xbmc.sleep(300)
            shown = [k for k in (0, 1, 2) if xbmc.getCondVisibility("Control.IsVisible(%d)" % (ROW_GROUPS + 3 * near - 2 + k))]
            xbmc.executebuiltin("SetFocus(%d)" % (ROW_LISTS[0] + 3 * (near - 1) + (shown[0] if shown else 0)))
        xbmcgui.Dialog().notification("MediaHub", addon.getLocalizedString(32151), xbmcgui.NOTIFICATION_INFO, 5000, False)
    else:
        m = up if what == "up" else down
        xbmc.executebuiltin("Skin.SetString(MH.Row%d,%s)" % (n, keys[m]))
        xbmc.executebuiltin("Skin.SetString(MH.Row%d,%s)" % (m, keys[n]))
        home.setProperty("MH.RowKey.%d" % n, keys[m])
        home.setProperty("MH.RowKey.%d" % m, keys[n])
        xbmc.sleep(300)  # (let the rows swap before following yours)
        xbmc.executebuiltin("SetFocus(%d)" % (ROW_LISTS[0] + 3 * (m - 1) + layout))
    home.setProperty("MH.Req.Rows", str(time.time()))  # the helper rows refill


def main():
    if sys.argv[1] == "trailer":
        import xbmc
        trailer = sys.listitem.getVideoInfoTag().getTrailer() or xbmc.getInfoLabel("ListItem.Trailer")
        if trailer.startswith("plugin://plugin.video.youtube") and \
                not xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            xbmcgui.Window(10000).setProperty("MH.Req.Action", "needyoutube")
            return
        if trailer:
            xbmc.executebuiltin('PlayMedia("%s")' % trailer.replace('"', '\\"'))
        return
    if sys.argv[1] == "mix":  # (a song, an artist, an album or a genre in the music library)
        tag = sys.listitem.getMusicInfoTag()
        kind, dbid = tag.getMediaType(), tag.getDbId()
        if kind in ("song", "artist", "album", "genre") and dbid > 0:
            xbmcgui.Window(10000).setProperty("MH.Req.Action", "mix|%s|%d" % (kind, dbid))
        return
    if sys.argv[1] == "rowmenu":
        return row_menu()
    if sys.argv[1] == "mychannel":
        return my_channel()
    if sys.argv[1] == "deletedownload":
        xbmcgui.Window(10000).setProperty("MH.Req.Action", "deletedownload|" + sys.listitem.getPath())
        return
    if sys.argv[1] == "hidecontinue":
        # a library item, or one of the helper's own home row cards (DBType / DBID properties)
        tag = sys.listitem.getVideoInfoTag()
        kind = tag.getMediaType() or sys.listitem.getProperty("DBType")
        dbid = tag.getDbId() if tag.getDbId() > 0 else int(sys.listitem.getProperty("DBID") or 0)
        if kind in ("movie", "episode", "tvshow") and dbid > 0:
            xbmcgui.Window(10000).setProperty("MH.Req.Action", "hidecontinue|%s|%d" % (kind, dbid))
        return
    tag = sys.listitem.getVideoInfoTag()
    kind, dbid = tag.getMediaType(), tag.getDbId()
    if kind not in ("movie", "tvshow", "episode") or dbid <= 0:
        return
    home = xbmcgui.Window(10000)
    if sys.argv[1] == "mylist":
        home.setProperty("MH.Req.Action", "mylist|%s|%d" % (kind, dbid))
    elif sys.argv[1] == "rate":
        addon = xbmcaddon.Addon()
        choices = [(10, 32006), (8, 32005), (2, 32004), (0, 32003)]
        pick = xbmcgui.Dialog().select(addon.getLocalizedString(32012),
                                       [addon.getLocalizedString(sid) for _, sid in choices])
        if pick >= 0:
            # "Remove rating" sends the current value again, which clears it
            value = choices[pick][0] or tag.getUserRating()
            if value:
                home.setProperty("MH.Req.Action", "rate|%s|%d|%d" % (kind, dbid, value))


if __name__ == "__main__":
    main()
