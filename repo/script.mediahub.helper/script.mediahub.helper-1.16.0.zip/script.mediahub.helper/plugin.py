"""MediaHub Helper - the On demand pages (plugin://script.mediahub.helper/), and
the add-on folder picker for custom home rows (?mode=pickrow&n=<1-3>).

The pages read the list resources/lib/ondemand.py builds from the IPTV playlist:
TV Shows > A-Z > show > season > episodes, Movies > A-Z, and Search. Everything
is paged, so a catalogue of hundreds of thousands of entries stays light.
"""
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import ondemand  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
PAGE = 200
MAX_GROUP = 1000  # channels in a group for a home row (see pick_tv_group)
LETTERS = ["#"] + [chr(c) for c in range(ord("A"), ord("Z") + 1)]
ADDON = xbmcaddon.Addon()
ONDEMAND = ADDON.getLocalizedString(32140)


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)


def folder(label, target, icon="DefaultFolder.png", label2="", art=None):
    item = xbmcgui.ListItem(label, label2)
    item.setArt(dict({"icon": icon, "thumb": icon}, **(art or {})))
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=True)


def playable(row, kind, info=None):
    """A list item for an entry: selecting it plays it through ?mode=play (resume
    offered, and an episode's next ones queued for Up Next). info: its show's (or
    the film's) poster, backdrop and plot, when known (odart.py)."""
    import odprogress
    info = info or {}
    _id, show, season, episode, title, year, logo, grp, address = row
    if kind == "episode":
        title = title or "%s %d" % (xbmc.getLocalizedString(20359), episode)  # "Episode 3"
        label = "%dx%02d. %s" % (season, episode, title)
    else:
        label = "%s (%d)" % (title, year) if year else title
    item = xbmcgui.ListItem(label)
    tag = item.getVideoInfoTag()
    tag.setTitle(title or label)
    tag.setMediaType(kind)
    if kind == "episode":
        tag.setTvShowTitle(show)
        tag.setSeason(season)
        tag.setEpisode(episode)
    elif year:
        tag.setYear(year)
    if grp:
        tag.setGenres([grp])
    poster = info.get("poster") if kind == "movie" else logo or info.get("poster")
    poster = poster or logo
    art = {"thumb": poster, "poster": poster, "icon": poster} if poster else {}
    if info.get("fanart"):
        art["fanart"] = info["fanart"]
    if kind == "episode" and info.get("poster"):
        art["tvshow.poster"] = info["poster"]
    if art:
        item.setArt(art)
    if kind == "movie" and info.get("plot"):
        tag.setPlot(info["plot"])
    if kind == "movie" and not year and info.get("year"):
        tag.setYear(int(info["year"]))
    position, total, watched = odprogress.resume_point(address)
    if watched:
        tag.setPlaycount(1)
    elif position and total:
        tag.setResumePoint(float(position), float(total))
    xbmcplugin.addDirectoryItem(HANDLE, url(mode="play", id=_id), item, isFolder=False)


def end(content="", title=""):
    """Finish the page: in the order given (A-Z already), titled On demand / the show."""
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.setPluginCategory(HANDLE, title or ONDEMAND)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED, labelMask="%L")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)


# --------------------------------------------------------------------------- pages

def root():
    info = ondemand.built()
    if info:
        _, shows, episodes, movies = info
        folder(text(32131), url(mode="letters", kind="episode"), "DefaultTVShows.png", "%d" % shows)
        folder(text(32132), url(mode="letters", kind="movie"), "DefaultMovies.png", "%d" % movies)
        folder(xbmc.getLocalizedString(137), url(mode="search"), "DefaultAddonsSearch.png")
        folder(text(32133), url(mode="build"), "DefaultAddonsUpdates.png")
        hidden = len(ondemand.hidden_groups())
        item = xbmcgui.ListItem(text(32162), text(32163) % hidden if hidden else "")
        item.setArt({"icon": "DefaultAddonsRepo.png", "thumb": "DefaultAddonsRepo.png"})
        xbmcplugin.addDirectoryItem(HANDLE, url(mode="groups"), item, isFolder=False)
    elif ondemand.playlists():
        folder(text(32134), url(mode="build"), "DefaultAddonsUpdates.png")
    else:
        folder(text(32135), url(mode="none"), "DefaultIconInfo.png")
    end()


def letters(kind):
    where, params = ondemand.group_filter()
    con = ondemand.connect()
    try:
        col = "COUNT(DISTINCT showkey)" if kind == "episode" else "COUNT(*)"
        counts = dict(con.execute("SELECT letter, %s FROM items WHERE kind=?%s GROUP BY letter" % (col, where),
                                  [kind] + params))
    finally:
        con.close()
    for letter in LETTERS:
        if counts.get(letter):
            folder(letter, url(mode="shows" if kind == "episode" else "movies", letter=letter),
                   "DefaultFolder.png", str(counts[letter]))
    end(title=text(32131 if kind == "episode" else 32132))


def next_page(mode, page, **params):
    folder("[B]%s >[/B]" % xbmc.getLocalizedString(33078), url(mode=mode, page=page + 1, **params),
           "DefaultFolder.png")


def show_folder(key, name, count, logo, info):
    """A show: its poster, backdrop and plot from TVmaze when known (odart.py)."""
    info = info or {}
    item = xbmcgui.ListItem(name, "%d" % count)
    poster = info.get("poster") or logo
    art = {"icon": poster or "DefaultTVShows.png", "thumb": poster or "DefaultTVShows.png"}
    if poster:
        art["poster"] = poster
    if info.get("fanart"):
        art["fanart"] = info["fanart"]
    item.setArt(art)
    tag = item.getVideoInfoTag()
    tag.setTitle(name)
    tag.setMediaType("tvshow")
    if info.get("plot"):
        tag.setPlot(info["plot"])
    if info.get("year"):
        tag.setYear(int(info["year"]))
    if info.get("genres"):
        tag.setGenres(info["genres"].split(" / "))
    xbmcplugin.addDirectoryItem(HANDLE, url(mode="seasons", show=key), item, isFolder=True)


def show_list(rows):
    """Shows (showkey, name, count, logo), with what's known of them; the rest are
    asked for in the background."""
    import odart
    known = odart.lookup([odart.show_key(r[0]) for r in rows])
    missing = []
    for key, name, count, logo in rows:
        info = known.get(odart.show_key(key))
        show_folder(key, name, count, logo, info)
        if odart.due(info):
            missing.append(["s", key, name])
    odart.wanted(missing)


def shows(letter, page):
    where, params = ondemand.group_filter()
    con = ondemand.connect()
    try:
        rows = con.execute("SELECT showkey, MIN(show), COUNT(*), MAX(logo) FROM items WHERE kind='episode' AND letter=?"
                           "%s GROUP BY showkey ORDER BY showkey LIMIT ? OFFSET ?" % where,
                           [letter] + params + [PAGE + 1, page * PAGE]).fetchall()
    finally:
        con.close()
    show_list(rows[:PAGE])
    if len(rows) > PAGE:
        next_page("shows", page, letter=letter)
    end("tvshows", "%s: %s" % (text(32131), letter))


def show_info(key, name):
    """A show's TVmaze details, looked up now if they aren't known yet."""
    import odart
    info = odart.lookup([odart.show_key(key)]).get(odart.show_key(key))
    if odart.due(info):
        info = odart.fetch(["s", key, name], xbmc.Monitor()) or info
    return info or {}


def seasons(key):
    where, params = ondemand.group_filter()
    con = ondemand.connect()
    try:
        rows = con.execute("SELECT season, COUNT(*), MAX(logo), MIN(show) FROM items WHERE showkey=?"
                           " AND kind='episode'%s GROUP BY season ORDER BY season" % where, [key] + params).fetchall()
    finally:
        con.close()
    if not rows:
        return end()
    if len(rows) == 1:
        return episodes(key, rows[0][0])
    info = show_info(key, rows[0][3])
    for season, count, logo, name in rows:
        item = xbmcgui.ListItem("%s %d" % (xbmc.getLocalizedString(20373), season), "%d" % count)
        poster = info.get("poster") or logo
        art = {"icon": poster or "DefaultTVShows.png", "thumb": poster or "DefaultTVShows.png"}
        if poster:
            art["poster"] = poster
        if info.get("fanart"):
            art["fanart"] = info["fanart"]
        item.setArt(art)
        tag = item.getVideoInfoTag()
        tag.setTvShowTitle(name)
        tag.setSeason(season)
        tag.setMediaType("season")
        if info.get("plot"):
            tag.setPlot(info["plot"])
        xbmcplugin.addDirectoryItem(HANDLE, url(mode="episodes", show=key, season=season), item, isFolder=True)
    end("seasons", rows[0][3])


def episodes(key, season):
    where, params = ondemand.group_filter()
    con = ondemand.connect()
    try:
        rows = con.execute("SELECT id, show, season, episode, title, year, logo, grp, url FROM items"
                           " WHERE showkey=? AND season=? AND kind='episode'%s ORDER BY episode, id" % where,
                           [key, int(season)] + params).fetchall()
    finally:
        con.close()
    info = show_info(key, rows[0][1]) if rows else {}
    for row in rows:
        playable(row, "episode", info)
    end("episodes", "%s - %s %d" % (rows[0][1], xbmc.getLocalizedString(20373), int(season)) if rows else "")


def movie_list(rows):
    import odart
    keys = {r[0]: odart.movie_key(ondemand.sort_key(r[4] or r[1]), r[5]) for r in rows}
    known = odart.lookup(keys.values())
    missing = []
    for row in rows:
        info = known.get(keys[row[0]])
        playable(row, "movie", info)
        if odart.tmdb_key() and odart.due(info):
            missing.append(["m", ondemand.sort_key(row[4] or row[1]), row[4] or row[1], row[5]])
    odart.wanted(missing)


def movies(letter, page):
    where, params = ondemand.group_filter()
    con = ondemand.connect()
    try:
        rows = con.execute("SELECT id, show, season, episode, title, year, logo, grp, url FROM items"
                           " WHERE kind='movie' AND letter=?%s ORDER BY showkey, year LIMIT ? OFFSET ?" % where,
                           [letter] + params + [PAGE + 1, page * PAGE]).fetchall()
    finally:
        con.close()
    movie_list(rows[:PAGE])
    if len(rows) > PAGE:
        next_page("movies", page, letter=letter)
    end("movies", "%s: %s" % (text(32132), letter))


def search():
    words = ARGS.get("q") or xbmcgui.Dialog().input(xbmc.getLocalizedString(137))
    if not words:
        return end()
    like = "%" + ondemand.sort_key(words) + "%"
    where, params = ondemand.group_filter()
    con = ondemand.connect()
    try:
        found_shows = con.execute("SELECT showkey, MIN(show), COUNT(*), MAX(logo) FROM items WHERE kind='episode'"
                                  " AND showkey LIKE ?%s GROUP BY showkey ORDER BY showkey LIMIT 100" % where,
                                  [like] + params).fetchall()
        found_movies = con.execute("SELECT id, show, season, episode, title, year, logo, grp, url FROM items"
                                   " WHERE kind='movie' AND showkey LIKE ?%s ORDER BY showkey LIMIT 200" % where,
                                   [like] + params).fetchall()
    finally:
        con.close()
    show_list(found_shows)
    movie_list(found_movies)
    end("videos", "%s: %s" % (xbmc.getLocalizedString(137), words))


def choose_groups():
    """Hide playlist groups (group-title) from the pages. When a Kids mode PIN is set,
    it's asked for first, so the choice stays with the grown-ups."""
    pin = xbmc.getInfoLabel("Skin.String(MH.KidsPin)")
    if pin and xbmcgui.Dialog().numeric(0, text(32164), "", True) != pin:
        xbmcgui.Dialog().notification("MediaHub", xbmc.getLocalizedString(12342), xbmcgui.NOTIFICATION_WARNING,
                                      3000, False)  # "Incorrect password"
        return
    con = ondemand.connect()
    try:
        groups = con.execute("SELECT grp, COUNT(*) FROM items WHERE grp != '' GROUP BY grp ORDER BY grp").fetchall()
    finally:
        con.close()
    if not groups:
        return
    hidden = set(ondemand.hidden_groups())
    pick = xbmcgui.Dialog().multiselect(text(32162), ["%s  (%d)" % g for g in groups],
                                        preselect=[i for i, g in enumerate(groups) if g[0] in hidden])
    if pick is None:
        return
    ondemand.set_hidden([groups[i][0] for i in pick])
    xbmc.executebuiltin("Container.Refresh")


def play(rowid):
    """Play an entry, offering to resume where you stopped."""
    import odprogress
    entry = odprogress.find(rowid=rowid)
    if not entry:
        return
    position, _, _ = odprogress.resume_point(entry["url"])
    resume = False
    if position > 30:
        pick = xbmcgui.Dialog().contextmenu([
            xbmc.getLocalizedString(12022).format(time_label(position)),  # "Resume from {0:s}"
            xbmc.getLocalizedString(12021)])  # "Play from beginning"
        if pick < 0:
            return
        resume = pick == 0
    odprogress.play(rowid, resume)


def time_label(seconds):
    seconds = int(seconds)
    return "%d:%02d:%02d" % (seconds // 3600, seconds // 60 % 60, seconds % 60) if seconds >= 3600 else \
        "%d:%02d" % (seconds // 60, seconds % 60)


def build():
    xbmcgui.Window(10000).setProperty("MH.Req.Action", "ondemandbuild")
    end()


# --------------------------------------------------------------------------- custom rows from add-ons

def rpc(method, **params):
    import json
    reply = json.loads(xbmc.executeJSONRPC(json.dumps(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return reply.get("result", {})


def pick_row(n):
    """Choose a folder of any video add-on for custom row n (Skin.String(MH.CustomRow<n>.Path))."""
    addons = rpc("Addons.GetAddons", type="xbmc.addon.video", enabled=True,
                 properties=["name"]).get("addons", [])
    addons = sorted((a for a in addons if a["addonid"] != "script.mediahub.helper"), key=lambda a: a["name"].lower())
    if not addons:
        xbmcgui.Dialog().notification("MediaHub", text(32136), xbmcgui.NOTIFICATION_INFO, 4000, False)
        return
    pick = xbmcgui.Dialog().select(text(32137), [a["name"] for a in addons])
    if pick < 0:
        return
    path, name = "plugin://%s/" % addons[pick]["addonid"], addons[pick]["name"]
    trail = []
    while True:
        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
        try:
            items = rpc("Files.GetDirectory", directory=path, media="video").get("files", [])
        finally:
            xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
        folders = [f for f in items if f.get("filetype") == "directory"]
        if not folders and trail:  # (nothing further down: this is the one)
            break
        choices = ["[B]%s[/B]" % (text(32138) % name)] + [f["label"] for f in folders]
        pick = xbmcgui.Dialog().select(name, choices)
        if pick < 0:
            if not trail:
                return
            path, name = trail.pop()
            continue
        if pick == 0:
            break
        trail.append((path, name))
        path, name = folders[pick - 1]["file"], folders[pick - 1]["label"]
    xbmc.executebuiltin('Skin.SetString(MH.CustomRow%d.Path,"%s")' % (n, path.replace('"', '\\"')))
    if not xbmc.getInfoLabel("Skin.String(MH.CustomRow%d.Name)" % n):
        xbmc.executebuiltin('Skin.SetString(MH.CustomRow%d.Name,"%s")' % (n, name.replace('"', "'")))
    xbmcgui.Dialog().notification("MediaHub", text(32139) % name, xbmcgui.NOTIFICATION_INFO, 3000, False)


def pick_tv_group(n):
    """Home row n (1-2): a Live TV channel group, or none."""
    # (never "All channels": with a big IPTV list, Kodi building it can use up the
    # memory - that's what closed Kodi on Apple TV in 1.9.1)
    everything = xbmc.getLocalizedString(19287)
    groups = [g for g in rpc("PVR.GetChannelGroups", channeltype="tv").get("channelgroups", [])
              if g.get("label") != everything]
    choices = [text(32165)] + [g["label"] for g in groups]
    pick = xbmcgui.Dialog().select(text(32166), choices)
    if pick < 0:
        return
    if pick == 0:
        xbmc.executebuiltin("Skin.Reset(MH.TvGroup%d.Id)" % n)
        xbmc.executebuiltin("Skin.Reset(MH.TvGroup%d.Name)" % n)
    else:
        group = groups[pick - 1]
        size = rpc("PVR.GetChannels", channelgroupid=group["channelgroupid"],
                   limits={"start": 0, "end": 1}).get("limits", {}).get("total", 0)
        if size > MAX_GROUP:
            xbmcgui.Dialog().ok(group["label"], text(32167) % (size, MAX_GROUP))
            return
        xbmc.executebuiltin("Skin.SetString(MH.TvGroup%d.Id,%d)" % (n, group["channelgroupid"]))
        xbmc.executebuiltin('Skin.SetString(MH.TvGroup%d.Name,"%s")' % (n, group["label"].replace('"', "'")))
    xbmc.sleep(200)
    xbmcgui.Window(10000).setProperty("MH.Req.Action", "tvgroups")


def main():
    mode = ARGS.get("mode", "root")
    if mode == "tvgroup":
        return pick_tv_group(int(ARGS.get("n", "1")))
    if mode == "pickrow":
        return pick_row(int(ARGS.get("n", "1")))
    if mode == "root":
        return root()
    if mode == "build":
        return build()
    if mode == "play":
        return play(int(ARGS.get("id", "0")))
    if mode == "groups":
        return choose_groups()
    if mode == "none":
        return end()
    if not ondemand.built():
        return root()
    if mode == "letters":
        return letters(ARGS.get("kind", "episode"))
    if mode == "shows":
        return shows(ARGS.get("letter", "#"), int(ARGS.get("page", "0")))
    if mode == "seasons":
        return seasons(ARGS.get("show", ""))
    if mode == "episodes":
        return episodes(ARGS.get("show", ""), ARGS.get("season", "1"))
    if mode == "movies":
        return movies(ARGS.get("letter", "#"), int(ARGS.get("page", "0")))
    if mode == "search":
        return search()
    return root()


if __name__ == "__main__":
    main()
