"""MediaHub Helper - posters, backdrops and plots for On demand (ondemand.py).

IPTV playlists rarely say more than a name. Shows are looked up on TVmaze (free,
no account); films on TMDB when Skin Settings has a TMDB API key (free from
themoviedb.org). What's found is kept in odart.db (not rebuilt with the list),
and a title that wasn't found is asked about again after a month.

The pages (plugin.py) show what's there and put what's missing in
MH.OD.WantArt; the service looks those up in the background (a request every
half second, stoppable) and refreshes the page when done. A show's own page looks
it up straight away.
"""
import json
import os
import re
import sqlite3
import threading
import time
import urllib.parse

import xbmc
import xbmcgui
import xbmcvfs

DB = "special://profile/addon_data/script.mediahub.helper/odart.db"
TEMP = "special://temp/mediahub-odart-%s.json"
TVMAZE = os.environ.get("MEDIAHUB_TVMAZE", "https://api.tvmaze.com")
TMDB = os.environ.get("MEDIAHUB_TMDB", "https://api.themoviedb.org/3")
TMDB_IMAGES = "https://image.tmdb.org/t/p/"
RETRY = 30 * 24 * 3600
GAP = 0.5
WANT = "MH.OD.WantArt"
LOCK = threading.Lock()


def connect():
    path = xbmcvfs.translatePath(DB)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    con = sqlite3.connect(path, timeout=10)
    con.execute("CREATE TABLE IF NOT EXISTS art (key TEXT PRIMARY KEY, poster TEXT, fanart TEXT, plot TEXT,"
                " year INTEGER, genres TEXT, t REAL)")
    return con


def show_key(showkey):
    return "s:" + showkey


def movie_key(key, year):
    return "m:%s:%s" % (key, year or "")


def tmdb_key():
    return xbmc.getInfoLabel("Skin.String(MH.OD.TmdbKey)").strip()


def lookup(keys):
    """{key: {poster, fanart, plot, year, genres}} for the keys known (found or not)."""
    if not keys or not os.path.exists(xbmcvfs.translatePath(DB)):
        return {}
    con = connect()
    try:
        found = {}
        keys = list(keys)
        for i in range(0, len(keys), 500):
            part = keys[i:i + 500]
            for row in con.execute("SELECT key, poster, fanart, plot, year, genres, t FROM art WHERE key IN (%s)"
                                   % ",".join("?" * len(part)), part):
                found[row[0]] = {"poster": row[1] or "", "fanart": row[2] or "", "plot": row[3] or "",
                                 "year": row[4] or 0, "genres": row[5] or "", "t": row[6] or 0}
        return found
    finally:
        con.close()


def store(key, info):
    con = connect()
    try:
        con.execute("INSERT OR REPLACE INTO art VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (key, info.get("poster", ""), info.get("fanart", ""), info.get("plot", ""),
                     info.get("year") or 0, info.get("genres", ""), time.time()))
        con.commit()
    finally:
        con.close()


def get_json(url, monitor):
    import net
    local = xbmcvfs.translatePath(TEMP % threading.get_ident())
    try:
        if not net.fetch(url, local, monitor):
            return None
        with open(local, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None
    finally:
        try:
            os.remove(local)
        except OSError:
            pass


def same_name(a, b):
    """TVmaze answers with its best guess: only take it when the names match (not
    counting a year or country in brackets, or "The")."""
    import ondemand

    def norm(n):
        return ondemand.sort_key(re.sub(r"\(.*?\)|\[.*?\]", " ", n or ""))
    return norm(a) == norm(b)


def clean(html):
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", html or "")).strip()


def fetch_show(name, monitor):
    show = get_json("%s/singlesearch/shows?q=%s" % (TVMAZE, urllib.parse.quote(name)), monitor)
    if not isinstance(show, dict) or not show.get("id") or same_name(show.get("name"), name) is False:
        return {}
    image = show.get("image") or {}
    info = {"poster": image.get("original") or image.get("medium") or "", "plot": clean(show.get("summary")),
            "year": int((show.get("premiered") or "0")[:4] or 0), "genres": " / ".join(show.get("genres") or [])}
    monitor.waitForAbort(GAP)
    images = get_json("%s/shows/%d/images" % (TVMAZE, show["id"]), monitor)
    if isinstance(images, list):
        backdrop = next((i for i in images if i.get("type") == "background"), None)
        if backdrop:
            info["fanart"] = ((backdrop.get("resolutions") or {}).get("original") or {}).get("url", "")
    return info


def fetch_movie(title, year, monitor):
    key = tmdb_key()
    if not key:
        return None  # (no key: don't remember as "not found")
    query = {"api_key": key, "query": title}
    if year:
        query["year"] = year
    reply = get_json("%s/search/movie?%s" % (TMDB, urllib.parse.urlencode(query)), monitor)
    results = (reply or {}).get("results") or []
    if not results:
        return {} if reply is not None else None
    m = results[0]
    return {"poster": TMDB_IMAGES + "w500" + m["poster_path"] if m.get("poster_path") else "",
            "fanart": TMDB_IMAGES + "w1280" + m["backdrop_path"] if m.get("backdrop_path") else "",
            "plot": m.get("overview") or "", "year": int((m.get("release_date") or "0")[:4] or 0)}


def fetch(item, monitor):
    """item: ["s", showkey, name] or ["m", key, title, year]. Stores and returns what was found."""
    if item[0] == "s":
        info, key = fetch_show(item[2], monitor), show_key(item[1])
    else:
        info, key = fetch_movie(item[2], item[3], monitor), movie_key(item[1], item[3])
    if info is None or monitor.abortRequested():
        return None
    store(key, info)
    return info


def wanted(items):
    """The pages: ask the service to look these up (the page's missing ones)."""
    if items:
        xbmcgui.Window(10000).setProperty(WANT, json.dumps({"path": xbmc.getInfoLabel("Container.FolderPath"),
                                                            "items": items[:200]}))


def due(info):
    """Look it up (again)? Not known, or not found a month ago."""
    return not info or (not info.get("poster") and not info.get("plot") and time.time() - info.get("t", 0) > RETRY)


class Fetcher:
    """Looks up what the pages asked for, in the background."""

    def __init__(self):
        self.busy = False

    def tick(self, monitor):
        home = xbmcgui.Window(10000)
        want = home.getProperty(WANT)
        if not want or self.busy:
            return
        home.clearProperty(WANT)
        try:
            request = json.loads(want)
        except ValueError:
            return
        self.busy = True

        def run():
            try:
                found = 0
                with LOCK:
                    for item in request.get("items") or []:
                        if monitor.abortRequested():
                            return
                        if fetch(item, monitor):
                            found += 1
                        monitor.waitForAbort(GAP)
                # still on that page: show them
                if found and xbmc.getInfoLabel("Container.FolderPath") == request.get("path"):
                    xbmc.executebuiltin("Container.Refresh")
            finally:
                self.busy = False
        import mediahub
        mediahub.in_thread(run)
