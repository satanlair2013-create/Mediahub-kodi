"""MediaHub Helper - Ask a grown-up: the Kids mode screens ask the grown-ups' phones.

On the Time for bed and That's all the TV for today screens, "Ask a grown-up" puts
a request on the phones paired with MediaHub Web Remote (Window(Home) MH.Ask:
{"id", "kind": bedtime | screentime, "t"}); a grown-up answers there (the first
time with the Kids mode PIN, typed on the phone) and the Web Remote sets
MH.Ask.Answer: {"id", "answer": yes | no | 15 | 30 | 60 | day, "who"}. Here the
answer unlocks the night, or adds the time, as the Grown-ups button would with the
PIN. MH.Ask.Waiting is set while the question is out (for the screen's words).
"""
import json
import time

import xbmc
import xbmcgui

import mediahub

ASK = "MH.Ask"
ANSWER = "MH.Ask.Answer"
LASTS = 15 * 60   # a question nobody answers goes after a quarter of an hour
TIME = {"15": 0, "30": 1, "60": 2, "day": 3}  # (ScreenTime.MORE's order)


def home():
    return xbmcgui.Window(10000)


class Asking:
    def __init__(self):
        self.asked = None  # {"id", "kind", "t"}

    def ask(self, kind):
        if kind not in ("bedtime", "screentime"):
            return
        if not home().getProperty("MHW.Address"):  # (no Web Remote running: nobody to ask)
            return mediahub.notify(mediahub.text(32238), 32241)
        self.asked = {"id": "%d" % (time.time() * 1000), "kind": kind, "t": time.time()}
        home().setProperty(ASK, json.dumps(self.asked))
        home().setProperty("MH.Ask.Waiting", "1")
        mediahub.notify(mediahub.text(32238), 32239)

    def done(self):
        self.asked = None
        home().clearProperty(ASK)
        home().clearProperty("MH.Ask.Waiting")

    def tick(self, bedtime, screentime):
        if not self.asked:
            return
        if time.time() - self.asked["t"] > LASTS:
            return self.done()
        raw = home().getProperty(ANSWER)
        if not raw:
            return
        home().clearProperty(ANSWER)
        try:
            answer = json.loads(raw)
        except ValueError:
            return
        if not isinstance(answer, dict) or answer.get("id") != self.asked["id"]:
            return
        kind, said, who = self.asked["kind"], str(answer.get("answer")), str(answer.get("who") or "")[:30]
        self.done()
        if said == "no":
            xbmcgui.Dialog().notification(mediahub.text(32238), mediahub.text(32240) % who,
                                          xbmcgui.NOTIFICATION_INFO, 5000, False)
            return
        if kind == "bedtime" and said == "yes":
            bedtime.unlock(home().getProperty("MH.Bedtime.Locked") or "unlocked")
        elif kind == "screentime" and said in TIME:
            screentime.add(TIME[said])
        else:
            return
        xbmcgui.Dialog().notification(mediahub.text(32238), mediahub.text(32242) % who,
                                      xbmcgui.NOTIFICATION_INFO, 5000, False)
        xbmc.log("MediaHub Helper: %s allowed %s from a phone" % (who, kind), xbmc.LOGINFO)
