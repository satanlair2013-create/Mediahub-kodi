"""MediaHub Helper - My channels: the Live TV channels you pick, as a home row.

"My channels: add / remove" in the context menu of a channel (context.py) keeps
the channel in mychannels.json. The service fills the home row (skin:
MyChannelsRow) from it, with what's on now and next, and keeps that current -
properties, like the other helper rows, so showing Home runs no add-on script.
Selecting a card sends MH.Req.Action = playchannel|<channel id>.
"""
import calendar
import json
import os
import time

import xbmc
import xbmcgui
import xbmcvfs

FILE = "special://profile/addon_data/script.mediahub.helper/mychannels.json"
PREFIX = "MH.MyChan"
FIELDS = ("Label", "Label2", "Title", "Icon", "Next", "Percent", "ID", "NoGuide")
REFRESH = 60  # seconds between refreshes of what's on
MAX = 20  # cards in the row (MyChannelsRow has this many items)


def path():
    return xbmcvfs.translatePath(FILE)


def load():
    try:
        with open(path()) as f:
            data = json.load(f)
        return [c for c in data if isinstance(c, dict) and c.get("id")]
    except (OSError, ValueError):
        return []


def save(chans):
    p = path()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p + ".tmp", "w") as f:
        json.dump(chans[:MAX], f)
    os.replace(p + ".tmp", p)
    ids(chans)


def ids(chans=None):
    """MH.MyChannels.Ids: ",1,5," - which channels are in (the service refills the row
    when it changes), empty when none (the row hides)."""
    chans = load() if chans is None else chans
    value = "," + ",".join(str(c["id"]) for c in chans) + "," if chans else ""
    xbmcgui.Window(10000).setProperty("MH.MyChannels.Ids", value)
    return value


def toggle(entry):
    """Add the channel, or remove it if it is there. True = added."""
    chans = load()
    if any(c["id"] == entry["id"] for c in chans):
        save([c for c in chans if c["id"] != entry["id"]])
        return False
    save(chans + [entry])
    return True


def clock(stamp):
    """A broadcast's UTC "2026-09-25 18:00:00" as the local time "18:00"."""
    try:
        return time.strftime("%H:%M", time.localtime(calendar.timegm(time.strptime(stamp, "%Y-%m-%d %H:%M:%S"))))
    except (TypeError, ValueError):
        return ""


def card(d, fallback=None):
    """A channel's card fields from its PVR details."""
    fallback = fallback or {}
    now, nxt = d.get("broadcastnow") or {}, d.get("broadcastnext") or {}
    name = d.get("channel") or d.get("label") or fallback.get("name", "")
    return {
        "Label": name,
        "Label2": "%s - %s" % (clock(now.get("starttime")), clock(now.get("endtime"))) if now else "",
        "Title": now.get("title") or name,
        "Icon": d.get("icon") or fallback.get("icon", ""),
        "Next": "%s  %s" % (clock(nxt.get("starttime")), nxt.get("title", "")) if nxt else "",
        "Percent": str(int(now.get("progresspercentage") or 0)) if now else "",
        "ID": str(d.get("channelid") or fallback.get("id", "")),
        "NoGuide": "" if now else "1",
    }


PROPS = ["channel", "icon", "broadcastnow", "broadcastnext", "hidden"]


def cards():
    import mediahub
    found = []
    for chan in load()[:MAX]:
        d = mediahub.rpc("PVR.GetChannelDetails", channelid=int(chan["id"]), properties=PROPS).get("channeldetails")
        if d and d.get("hidden"):
            continue
        found.append(card(d or {}, chan))
    return found


def group_cards(n):
    """Home row n (1-2) of a Live TV channel group chosen in Skin Settings: its first
    channels with what's on. (Only that group is asked for, never the whole list.)"""
    import mediahub
    group = xbmc.getInfoLabel("Skin.String(MH.TvGroup%d.Id)" % n)
    if not group.isdigit():
        return []
    chans = mediahub.rpc("PVR.GetChannels", channelgroupid=int(group), properties=PROPS,
                         limits={"start": 0, "end": MAX}).get("channels", [])
    return [card(d) for d in chans if not d.get("hidden")]


def fill_props(prefix, found):
    home = xbmcgui.Window(10000)
    for i in range(1, MAX + 1):
        fields = found[i - 1] if i <= len(found) else {}
        for key in FIELDS:
            home.setProperty("%s.%d.%s" % (prefix, i, key), fields.get(key, ""))
    home.setProperty(prefix + ".Count", str(len(found)))


def fill():
    fill_props(PREFIX, cards())


def fill_groups():
    for n in (1, 2):
        fill_props("MH.TvGroup%d" % n, group_cards(n))


def play(channelid):
    """playchannel|<id>: switch to the channel (by its address if the id is gone -
    the channel list was made again)."""
    import mediahub
    if mediahub.rpc("Player.Open", item={"channelid": channelid}) != "OK":
        where = next((c.get("path") for c in load() if c["id"] == channelid), "")
        if where:
            xbmc.executebuiltin('PlayMedia("%s")' % where)


def handle(action):
    if action.startswith("playchannel|") and action[12:].isdigit():
        play(int(action[12:]))
        return True
    if action == "lastchannel":
        last = xbmcgui.Window(10000).getProperty("MH.LastChannel.Id")
        if last.isdigit():
            play(int(last))
        return True
    if action == "tvgroups":  # (a group was chosen in Skin Settings)
        fill_groups()
        return True
    return False


class History:
    """The channel watched before this one, for "Last channel" (MH.LastChannel.*)."""

    def __init__(self):
        self.next = 0.0
        self.current = None

    def tick(self):
        now = time.time()
        if now < self.next:
            return
        self.next = now + 2
        if not xbmc.getCondVisibility("VideoPlayer.Content(livetv)"):
            return
        import mediahub
        item = mediahub.rpc("Player.GetItem", playerid=1).get("item") or {}
        if item.get("type") != "channel" or not item.get("id") or item["id"] == (self.current or {}).get("id"):
            return
        if self.current:
            home = xbmcgui.Window(10000)
            home.setProperty("MH.LastChannel.Id", str(self.current["id"]))
            home.setProperty("MH.LastChannel.Name", self.current.get("label", ""))
        self.current = {"id": item["id"], "label": item.get("label", "")}


class Keeper:
    """Fill the row when the channels change, and every minute (what's on moves on)."""

    def __init__(self):
        self.next = 0
        self.next_groups = 0
        self.filled = None

    def tick(self):
        now = time.time()
        if now >= self.next_groups:
            self.next_groups = now + REFRESH
            if xbmc.getCondVisibility("Window.IsVisible(home) + [!String.IsEmpty(Skin.String(MH.TvGroup1.Id)) | "
                                      "!String.IsEmpty(Skin.String(MH.TvGroup2.Id))]"):
                fill_groups()
        current = xbmcgui.Window(10000).getProperty("MH.MyChannels.Ids")
        if current == self.filled and now < self.next:
            return
        self.next = now + REFRESH
        if not current:
            if self.filled:  # (the last one was removed)
                fill()
            self.filled = current
            return
        if current != self.filled or xbmc.getCondVisibility("Window.IsVisible(home)"):
            fill()
            self.filled = current
