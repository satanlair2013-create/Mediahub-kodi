"""MediaHub Helper - reactions from phones, floating up over the picture.

MediaHub Web Remote's reaction buttons (and, during Watch together, MediaHub Sync
passing on the other room's) add {"k": kind, "n": who, "r": 1 if from the other room}
to Window(Home) MH.React.In (a JSON list); this shows each in the next of eight slots
of Custom_1139_Reactions.xml for a few seconds. While watching together, this room's
reactions go on to MHS.React.Out for MediaHub Sync to send.
"""
import json
import random
import time

import xbmcgui

KINDS = ("laugh", "wow", "love", "clap", "scared", "like", "popcorn", "sad")
SLOTS = 8
SHOW = 3.6       # seconds a reaction is up (its animation is 3.3)
IN = "MH.React.In"
OUT = "MHS.React.Out"


def take_list(home, name):
    raw = home.getProperty(name)
    if not raw:
        return []
    home.clearProperty(name)
    try:
        found = json.loads(raw)
    except ValueError:
        return []
    return [x for x in found if isinstance(x, dict)] if isinstance(found, list) else []


def add_to_list(home, name, entry, keep=20):
    try:
        found = json.loads(home.getProperty(name) or "[]")
    except ValueError:
        found = []
    home.setProperty(name, json.dumps((found if isinstance(found, list) else [])[-keep:] + [entry]))


class Reactions:
    def __init__(self):
        self.until = [0.0] * SLOTS
        self.pending = []  # slots to show on the next tick (their old one has just gone)

    def tick(self):
        home = xbmcgui.Window(10000)
        now = time.time()
        for n in self.pending:
            home.setProperty("MH.React.%d.On" % n, "1")
        self.pending = []
        for r in take_list(home, IN):
            self.show(home, str(r.get("k", "")), str(r.get("n", ""))[:20], bool(r.get("r")), now)
        for n, t in enumerate(self.until):
            if t and now >= t:
                self.until[n] = 0.0
                home.clearProperty("MH.React.%d.On" % n)
        if not any(self.until) and not self.pending and home.getProperty("MH.React.Active"):
            home.clearProperty("MH.React.Active")

    def show(self, home, kind, who, remote, now):
        if kind not in KINDS:
            return
        free = [n for n, t in enumerate(self.until) if not t]
        n = random.choice(free) if free else min(range(SLOTS), key=lambda i: self.until[i])
        home.setProperty("MH.React.%d.Icon" % n, "reactions/%s.png" % kind)
        home.setProperty("MH.React.%d.Name" % n, who)
        home.setProperty("MH.React.Active", "1")
        if self.until[n]:  # (reused: hidden now, shown next tick, so it floats up again)
            home.clearProperty("MH.React.%d.On" % n)
            self.pending.append(n)
        else:
            home.setProperty("MH.React.%d.On" % n, "1")
        self.until[n] = now + SHOW
        if not remote and home.getProperty("MHS.Together"):
            add_to_list(home, OUT, {"k": kind, "n": who})
