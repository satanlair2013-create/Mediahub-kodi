"""MediaHub Helper - a show's theme music on its page.

When the TV show page (view 53 of the Videos window) is open and nothing is
playing, the show's theme.mp3 (in its folder, as the TV Tunes add-on uses) plays
quietly in the background; leaving the page stops it. Skin Settings can turn it
off (MH.NoThemeMusic).
"""
import time

import xbmc
import xbmcgui
import xbmcvfs

import mediahub

NAMES = ("theme.mp3", "theme.flac", "theme.m4a")
SHOW_PAGE = "Window.IsActive(videos) + Control.IsVisible(53) + !Skin.HasSetting(MH.NoThemeMusic)"


def show_id():
    for label in ("Container(53).ListItem.TvShowDBID", "Container(53).ListItemAbsolute(1).TvShowDBID",
                  "Container(53).ListItemAbsolute(2).TvShowDBID"):
        value = xbmc.getInfoLabel(label)
        if value.isdigit():
            return int(value)
    return None


def theme_of(dbid):
    folder = (mediahub.rpc("VideoLibrary.GetTVShowDetails", tvshowid=dbid, properties=["file"])
              .get("tvshowdetails") or {}).get("file", "")
    if not folder or folder.startswith(("plugin://", "videodb://")):
        return None
    folder = folder if folder.endswith(("/", "\\")) else folder + "/"
    return next((folder + n for n in NAMES if xbmcvfs.exists(folder + n)), None)


class ThemeMusic:
    def __init__(self):
        self.next = 0.0
        self.show = None
        self.playing = None
        self.away = 0  # checks in a row the page wasn't there

    def tick(self):
        now = time.time()
        if now < self.next:
            return
        self.next = now + 1.0
        if xbmc.getCondVisibility("Window.IsVisible(busydialog) | Window.IsVisible(busydialognocancel)"):
            return  # (while Kodi opens something, the page reads as hidden)
        dbid = show_id() if xbmc.getCondVisibility(SHOW_PAGE) else None
        if dbid is None:
            self.away += 1
            if self.away >= 2:  # (gone for two seconds: not a blink while it redraws)
                self.stop()
                self.show = None
            return
        self.away = 0
        if dbid == self.show:
            return
        self.stop()
        self.show = dbid
        if xbmc.getCondVisibility("Player.HasMedia"):
            return  # (something you chose is playing: leave it)
        theme = theme_of(dbid)
        if theme:
            item = xbmcgui.ListItem(xbmc.getInfoLabel("Container(53).ListItem.TVShowTitle"))
            xbmc.Player().play(theme, item, windowed=True)
            self.playing = theme

    def stop(self):
        """Stop the theme if it's still what's playing (not an episode you started)."""
        if self.playing and xbmc.getInfoLabel("Player.Filenameandpath") == self.playing:
            xbmc.Player().stop()
        self.playing = None
