"""MediaHub Helper - Skin Settings > Storage: how big Kodi's picture cache is, and
clearing the pictures not used for a month.

Kodi keeps a copy of every poster, backdrop and logo it has shown
(Thumbnails), and never lets go of them; on a box with little storage (Apple
TV) that adds up. Clearing goes through Kodi itself (Textures.RemoveTexture,
which drops the picture and its entry), so anything still wanted is simply
fetched again the next time it's shown. Old add-on download zips (addons/
packages) go too; Kodi downloads them again if it ever needs one.
"""
import os
import time

import xbmc
import xbmcgui
import xbmcvfs

import mediahub

THUMBNAILS = "special://profile/Thumbnails"
PACKAGES = "special://home/addons/packages"
UNUSED_DAYS = 30


def folder_size(path):
    total, count = 0, 0
    for root, _, files in os.walk(xbmcvfs.translatePath(path)):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
                count += 1
            except OSError:
                pass
    return total, count


def human(size):
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return ("%d %s" if unit in ("B", "KB") else "%.1f %s") % (size, unit)
        size /= 1024.0


def measure():
    """MH.Cache.Size: "1.2 GB (34,210 pictures)" - pictures and old add-on zips."""
    pictures, count = folder_size(THUMBNAILS)
    packages, _ = folder_size(PACKAGES)
    mediahub.prop("MH.Cache.Size", mediahub.text(32168) % (human(pictures + packages), "{:,}".format(count)))
    return pictures + packages


def clean(monitor):
    before = measure()
    since = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() - UNUSED_DAYS * 86400))
    old = mediahub.rpc("Textures.GetTextures", properties=[],
                       filter={"field": "lastused", "operator": "lessthan", "value": since}).get("textures", [])
    bar = xbmcgui.DialogProgressBG()
    bar.create("MediaHub", mediahub.text(32169))
    try:
        for n, t in enumerate(old):
            if monitor.abortRequested():
                return
            mediahub.rpc("Textures.RemoveTexture", textureid=t["textureid"])
            if n % 50 == 0:
                bar.update(int(100 * n / max(1, len(old))))
        packages = xbmcvfs.translatePath(PACKAGES)
        for f in os.listdir(packages) if os.path.isdir(packages) else []:
            if f.endswith(".zip"):
                try:
                    os.remove(os.path.join(packages, f))
                except OSError:
                    pass
    finally:
        bar.close()
    after = measure()
    xbmcgui.Dialog().notification("MediaHub", mediahub.text(32170) % human(max(0, before - after)),
                                  xbmcgui.NOTIFICATION_INFO, 5000, False)


def handle(action, monitor):
    """cachesize (Skin Settings opened), cacheclean."""
    if action == "cachesize":
        return "thread", measure
    if action == "cacheclean":
        return "thread", lambda: clean(monitor)
    return None, None
