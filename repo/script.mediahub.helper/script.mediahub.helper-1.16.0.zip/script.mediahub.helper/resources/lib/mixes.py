"""MediaHub Helper - Instant mixes: music like a song, an artist, an album or a genre.

"Instant mix" (the context menu of a song, artist, album or genre in the music
library, or the button on the music player) fills Kodi's music playlist with the
library's songs that go with it: the same genres and moods first, from around the
same years, with the artists taking turns, and the song itself first. While the
mix plays, more are added before it runs out; playing something else ends it.

  MH.Req.Action mix|song|<id>, mix|artist|<id>, mix|album|<id>, mix|genre|<id>
  Window(Home) MH.Mix: what the mix is from, while it plays
"""
import random
import time

import xbmc
import xbmcgui

import mediahub

PROPS = ["title", "artist", "artistid", "genre", "mood", "year", "albumid", "duration", "playcount"]
FIRST = 20      # songs to start with
MORE = 10       # added when only a few are left
LOW = 4         # "a few"
CHECK_EVERY = 5


def songs(rule=None):
    params = {"properties": PROPS}
    if rule:
        params["filter"] = rule
    return mediahub.rpc("AudioLibrary.GetSongs", **params).get("songs") or []


def seed_of(kind, dbid):
    """(name, genres, moods, years, artist ids, first song or None, the seed's own songs)."""
    if kind == "song":
        s = mediahub.rpc("AudioLibrary.GetSongDetails", songid=dbid, properties=PROPS).get("songdetails")
        if not s:
            return None
        return (s.get("title") or s.get("label"), set(s.get("genre") or []), set(s.get("mood") or []),
                [s["year"]] if s.get("year") else [], set(s.get("artistid") or []), s, [s])
    if kind == "artist":
        a = mediahub.rpc("AudioLibrary.GetArtistDetails", artistid=dbid, properties=["genre", "mood"]
                         ).get("artistdetails")
        own = songs({"field": "artist", "operator": "is", "value": (a or {}).get("artist") or (a or {}).get("label", "")})
        if not a:
            return None
        name = a.get("artist") or a.get("label")
    elif kind == "album":
        a = mediahub.rpc("AudioLibrary.GetAlbumDetails", albumid=dbid, properties=["title", "genre", "mood", "year"]
                         ).get("albumdetails")
        if not a:
            return None
        name = a.get("title") or a.get("label")
        own = [s for s in songs({"field": "album", "operator": "is", "value": name}) if s.get("albumid") == dbid]
    elif kind == "genre":
        g = next((g for g in mediahub.rpc("AudioLibrary.GetGenres").get("genres") or [] if g["genreid"] == dbid), None)
        if not g:
            return None
        name, a = g["label"], {"genre": [g["label"]]}
        own = songs({"field": "genre", "operator": "is", "value": name})
    else:
        return None
    genres = set(a.get("genre") or []) | {x for s in own for x in s.get("genre") or []}
    moods = set(a.get("mood") or []) | {x for s in own for x in s.get("mood") or []}
    years = [s["year"] for s in own if s.get("year")]
    artists = {x for s in own for x in s.get("artistid") or []} if kind != "genre" else set()
    return name, genres, moods, years, artists, None, own


class Mixes:
    def __init__(self):
        self.seed = None
        self.used = set()
        self.last_artists = []
        self.next = 0

    def start(self, kind, dbid):
        seed = seed_of(kind, int(dbid))
        if not seed:
            return
        name, genres, moods, years, artists, first, _own = seed
        self.seed = {"genres": genres, "moods": moods, "years": years, "artists": artists}
        self.used = {first["songid"]} if first else set()
        self.last_artists = list(first.get("artistid") or []) if first else []
        picks = self.pick(FIRST - (1 if first else 0))
        if first:
            picks.insert(0, first)
        if len(picks) < 2:
            self.seed = None
            return mediahub.notify(mediahub.text(32234), 32236)
        mediahub.rpc("Playlist.Clear", playlistid=0)
        mediahub.rpc("Playlist.Add", playlistid=0, item=[{"songid": s["songid"]} for s in picks])
        mediahub.rpc("Player.Open", item={"playlistid": 0, "position": 0})
        mediahub.prop("MH.Mix", name)
        xbmcgui.Dialog().notification(mediahub.text(32234), mediahub.text(32235) % name,
                                      "special://skin/media/icons/mh/mix.png", 3000, False)
        self.next = time.time() + CHECK_EVERY

    def score(self, s):
        seed = self.seed
        points = 3 * len(seed["genres"] & set(s.get("genre") or [])) + 2 * len(seed["moods"] & set(s.get("mood") or []))
        if seed["years"] and s.get("year"):
            near = min(abs(s["year"] - y) for y in seed["years"])
            points += 2 if near <= 3 else 1 if near <= 8 else 0
        if seed["artists"] & set(s.get("artistid") or []):
            points += 2  # (the artist's own songs belong in their mix)
        return points + random.random() * 2.5

    def pick(self, count):
        if self.seed["genres"]:
            pool = songs({"or": [{"field": "genre", "operator": "is", "value": g} for g in self.seed["genres"]]})
            if len(pool) < count * 2:  # (a small genre: the rest of the library can fill in)
                pool += songs()
        else:
            pool = songs()
        seen, fresh = set(), []
        for s in pool:
            if s["songid"] not in self.used and s["songid"] not in seen:
                seen.add(s["songid"])
                fresh.append(s)
        ranked = sorted(fresh, key=self.score, reverse=True)
        picks = []
        while ranked and len(picks) < count:
            # the best one whose artist hasn't just played (or else simply the best)
            s = next((x for x in ranked[:12] if not set(x.get("artistid") or []) & set(self.last_artists[-2:])),
                     ranked[0])
            ranked.remove(s)
            picks.append(s)
            self.used.add(s["songid"])
            self.last_artists = (self.last_artists + list(s.get("artistid") or []))[-4:]
        return picks

    def stop(self):
        self.seed = None
        mediahub.prop("MH.Mix", "")

    def tick(self):
        if not self.seed or time.time() < self.next:
            return
        self.next = time.time() + CHECK_EVERY
        playing = xbmc.getInfoLabel("MusicPlayer.DBID")
        if not xbmc.getCondVisibility("Player.HasAudio") or not playing.isdigit() or int(playing) not in self.used:
            return self.stop()  # (something else is on now)
        props = mediahub.rpc("Player.GetProperties", playerid=0, properties=["playlistid", "position"])
        if props.get("playlistid") != 0:
            return self.stop()
        size = (mediahub.rpc("Playlist.GetItems", playlistid=0, limits={"start": 0, "end": 1}).get("limits") or {}
                ).get("total", 0)
        if size - props.get("position", 0) - 1 < LOW:
            more = self.pick(MORE)
            if more:
                mediahub.rpc("Playlist.Add", playlistid=0, item=[{"songid": s["songid"]} for s in more])


def handle(action, mixes):
    """mix|<song|artist|album|genre>|<id>"""
    parts = action.split("|")
    if len(parts) == 3 and parts[0] == "mix" and parts[2].isdigit():
        return "thread", lambda: mixes.start(parts[1], int(parts[2]))
    return None, None
