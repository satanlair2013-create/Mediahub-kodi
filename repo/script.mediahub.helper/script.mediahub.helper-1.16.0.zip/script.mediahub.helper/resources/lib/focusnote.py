"""MediaHub Helper - the focused Home card, for the context menu's header.

In a dialog, Kodi fills ListItem.* only from windows with media lists, and Home
isn't one: over Home the context menu (DialogContextMenu.xml) couldn't say what
it's for. So while Home shows with no dialog open, the card in focus is noted
here as MH.Focus.Title / .Art / .Meta.
"""
import time

import xbmc
import xbmcgui

EVERY = 0.25


def info(label):
    return xbmc.getInfoLabel(label)


class FocusNote:
    def __init__(self):
        self.next = 0.0
        self.last = None

    def tick(self):
        now = time.time()
        if now < self.next:
            return
        self.next = now + EVERY
        if not xbmc.getCondVisibility("Window.IsActive(home) + !System.HasActiveModalDialog + !System.HasModalDialog"):
            return  # (keep what was in focus when the menu opened)
        title = info("ListItem.Title") or info("ListItem.Label")
        dbtype = info("ListItem.DBType") or info("ListItem.Property(DBType)")
        art = (info("ListItem.Art(poster)") or info("ListItem.Art(tvshow.poster)") or info("ListItem.Icon")
               or info("ListItem.Thumb"))
        if dbtype == "episode":
            season, episode = info("ListItem.Season"), info("ListItem.Episode")
            meta = info("ListItem.TVShowTitle") + ("  •  S%s E%s" % (season, episode) if season and episode else "")
        else:
            parts = [info("ListItem.Year"), info("ListItem.Duration(mins)")]
            meta = "  •  ".join(p + (" min" if i and p else "") for i, p in enumerate(parts) if p)
        note = (title, art, meta)
        if note != self.last:
            self.last = note
            home = xbmcgui.Window(10000)
            home.setProperty("MH.Focus.Title", title)
            home.setProperty("MH.Focus.Art", art)
            home.setProperty("MH.Focus.Meta", meta)
