"""MediaHub Helper - On demand: an IPTV video-on-demand playlist as TV shows and movies.

Some IPTV playlists are really catalogues: every episode and every film is an entry,
hundreds of thousands of them. Loaded into Kodi's Live TV as "channels" they use up
the memory of a small box like Apple TV. This reads the playlist itself instead and
keeps it in a small database (ondemand.db), so the On demand pages (plugin.py) show
it as TV shows > seasons > episodes and movies, a page at a time.

The playlist: Skin.String(MH.OD.Playlist) (an address or a file, set in Skin
Settings), or else the playlists of the IPTV Simple Client add-on - whether or not
that add-on is turned on, so it can be switched off to free the memory.

What counts as what: "Name S01 E02" (or S01E02, 1x02) is an episode of "Name";
an entry whose address is a video file (.mp4, .mkv...) or an Xtream /movie/ address
is a movie; everything else is a live channel and is left to Live TV.
"""
import glob
import json
import os
import re
import sqlite3
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

DB = "special://profile/addon_data/script.mediahub.helper/ondemand.db"
IPTV_SETTINGS = ("special://profile/addon_data/pvr.iptvsimple/instance-settings-*.xml",
                 "special://profile/addon_data/pvr.iptvsimple/settings.xml")  # (Kodi 19 and older)
REFRESH_EVERY = 24 * 3600
VIDEO_EXT = (".mp4", ".mkv", ".avi", ".m4v", ".mov", ".wmv", ".mpg", ".mpeg", ".flv", ".webm")
EPISODE = re.compile(r"^(?P<show>.*?\S)[\s._-]*(?:S(?P<s>\d{1,3})[\s._-]*E(?P<e>\d{1,4})|(?P<s2>\d{1,2})x(?P<e2>\d{1,3}))\b"
                     r"[\s._:-]*(?P<rest>.*)$", re.I)
YEAR = re.compile(r"^(?P<title>.*?)(?:[\s._-]+(?P<open>[(\[]?)|(?P<open2>[(\[]))(?P<year>(?:19|20)\d\d)[)\]]?\s*$")
# a language tag in front: "EN - Name", "|EN| Name", "[EN] Name"
TAG = re.compile(r"^\s*(?:\|[A-Z]{2,4}\||\[[A-Z]{2,4}\]|[A-Z]{2,4}\s+-\s+|[A-Z]{2,4}\s*\|)\s*")
ATTR = re.compile(r'([\w-]+)="([^"]*)"')
BATCH = 5000
BUILDING = threading.Lock()  # one build at a time (the daily one, or Update the list)


def db_path():
    return xbmcvfs.translatePath(DB)


def connect():
    path = db_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    con = sqlite3.connect(path, timeout=10)
    con.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)")
    return con


def meta(con, key, default=""):
    row = con.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    return row[0] if row else default


def built():
    """(time, shows, episodes, movies) of the index, or None."""
    if not os.path.exists(db_path()):
        return None
    try:
        con = connect()
        try:
            when = float(meta(con, "built", "0") or 0)
            if not when:
                return None
            return (when, int(meta(con, "shows", "0")), int(meta(con, "episodes", "0")),
                    int(meta(con, "movies", "0")))
        finally:
            con.close()
    except sqlite3.Error:
        return None


# --------------------------------------------------------------------------- hidden groups

HIDDEN = "special://profile/addon_data/script.mediahub.helper/odhidden.json"
ADULT = re.compile(r"adult|xxx|porn|\+18|18\+|for adults|erotic", re.I)


def hidden_groups():
    """The playlist groups (group-title) left out of the pages. Until you choose,
    groups that look adult are."""
    try:
        with open(xbmcvfs.translatePath(HIDDEN)) as f:
            return list(json.load(f))
    except (OSError, ValueError, TypeError):
        pass
    if not os.path.exists(db_path()):
        return []
    try:
        con = connect()
        try:
            return [g for (g,) in con.execute("SELECT DISTINCT grp FROM items") if g and ADULT.search(g)]
        finally:
            con.close()
    except sqlite3.Error:
        return []


def set_hidden(groups):
    path = xbmcvfs.translatePath(HIDDEN)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(sorted(groups), f)


def group_filter():
    """(" AND grp NOT IN (?, ...)", [groups]) for the queries, or ("", [])."""
    groups = hidden_groups()
    if not groups:
        return "", []
    return " AND grp NOT IN (%s)" % ",".join("?" * len(groups)), groups


# --------------------------------------------------------------------------- the playlists

def iptv_playlists():
    """The playlist addresses in the IPTV Simple Client's settings (every instance)."""
    found = []
    paths = sorted(glob.glob(xbmcvfs.translatePath(IPTV_SETTINGS[0]))) or \
        glob.glob(xbmcvfs.translatePath(IPTV_SETTINGS[1]))
    for path in paths:
        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                text = f.read()
        except OSError:
            continue
        values = dict(re.findall(r'<setting id="([^"]+)"[^>]*>([^<]*)</setting>', text))
        kind = values.get("m3uPathType", "0")
        where = values.get("m3uUrl" if kind == "1" else "m3uPath", "").strip()
        if where:
            found.append(where.replace("&amp;", "&"))
    return found


def playlists():
    own = xbmc.getInfoLabel("Skin.String(MH.OD.Playlist)").strip()
    return [own] if own else iptv_playlists()


# --------------------------------------------------------------------------- reading one

def sort_key(name):
    name = re.sub(r"^(the|a|an)\s+", "", name.strip().lower())
    return re.sub(r"[^\w]+", " ", name).strip()


def letter(key):
    first = key[:1].upper()
    return first if "A" <= first <= "Z" else "#"


def this_year():
    return time.localtime().tm_year


def classify(name, url):
    """('episode', show, season, episode, title) / ('movie', title, year) / None (live)."""
    name = TAG.sub("", name, count=1)
    m = EPISODE.match(name)
    if m:
        season = int(m.group("s") or m.group("s2"))
        episode = int(m.group("e") or m.group("e2"))
        return ("episode", m.group("show").strip(" -._:|"), season, episode, (m.group("rest") or "").strip())
    lower = url.lower().split("?")[0]
    if "/movie/" in lower or lower.endswith(VIDEO_EXT):
        y = YEAR.match(name)
        # (an unbracketed year that hasn't happened is part of the title: Blade Runner 2049)
        if y and y.group("title").strip() and (y.group("open") or y.group("open2") or int(y.group("year")) <= this_year() + 1):
            return ("movie", y.group("title").strip(" -._:|"), int(y.group("year")))
        return ("movie", name.strip(), 0)
    return None


def entries(path):
    """(name, attributes, url) for each entry of an M3U file."""
    name, attrs = None, {}
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith("#EXTINF"):
                head, _, title = line.partition(",")
                attrs = dict(ATTR.findall(head))
                name = title.strip() or attrs.get("tvg-name", "")
            elif line.startswith("#"):
                continue
            elif name is not None:
                yield name, attrs, line
                name, attrs = None, {}


def fetch(where, dest, monitor):
    """A local copy of the playlist (read in pieces, so the helper can still stop
    in time during a long download)."""
    if "://" not in where and os.path.exists(where):
        return where
    import net
    local = xbmcvfs.translatePath(dest)
    return local if net.fetch(where, local, monitor or xbmc.Monitor()) else None


# --------------------------------------------------------------------------- building the index

def build(monitor=None, progress=True):
    """Read the playlists into ondemand.db. Returns (shows, episodes, movies), or None;
    "busy" if a build is already running."""
    if not BUILDING.acquire(blocking=False):
        return "busy"
    try:
        return _build(monitor, progress)
    finally:
        BUILDING.release()


def _build(monitor, progress):
    sources = playlists()
    if not sources:
        return None
    bar = None
    if progress:
        bar = xbmcgui.DialogProgressBG()
        bar.create("MediaHub", xbmc.getLocalizedString(20186))  # "Please wait..."
    tmp_db = db_path() + ".new"
    try:
        if os.path.exists(tmp_db):
            os.remove(tmp_db)
        con = sqlite3.connect(tmp_db)
        con.execute("CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT)")
        con.execute("CREATE TABLE items (id INTEGER PRIMARY KEY, kind TEXT, show TEXT, showkey TEXT,"
                    " letter TEXT, season INTEGER, episode INTEGER, title TEXT, year INTEGER,"
                    " logo TEXT, grp TEXT, url TEXT)")
        batch, seen, read = [], 0, 0
        for n, where in enumerate(sources):
            local = fetch(where, "special://temp/mediahub-ondemand-%d.m3u" % n, monitor)
            if monitor and monitor.abortRequested():
                con.close()
                return None
            if not local:
                xbmc.log("MediaHub Helper: on demand: couldn't read %s" % where, xbmc.LOGWARNING)
                continue
            read += 1
            try:
                for name, attrs, url in entries(local):
                    seen += 1
                    kind = classify(name, url)
                    logo, grp = attrs.get("tvg-logo", ""), attrs.get("group-title", "")
                    if kind is None:  # a live channel: kept only for search (odprogress.search)
                        key = sort_key(TAG.sub("", name, count=1))
                        batch.append(("live", name.strip(), key, letter(key), 0, 0, name.strip(), 0, logo, grp, url))
                    elif kind[0] == "episode":
                        key = sort_key(kind[1])
                        batch.append(("episode", kind[1], key, letter(key), kind[2], kind[3], kind[4], 0, logo, grp, url))
                    else:
                        key = sort_key(kind[1])
                        batch.append(("movie", kind[1], key, letter(key), 0, 0, kind[1], kind[2], logo, grp, url))
                    if len(batch) >= BATCH:
                        con.executemany("INSERT INTO items (kind, show, showkey, letter, season, episode, title,"
                                        " year, logo, grp, url) VALUES (?,?,?,?,?,?,?,?,?,?,?)", batch)
                        batch = []
                        if bar:
                            bar.update(0, "MediaHub", "%s: %d" % (xbmc.getLocalizedString(20186), seen))
                        if monitor and monitor.abortRequested():
                            con.close()
                            return None
            finally:
                if local.startswith(xbmcvfs.translatePath("special://temp")):
                    try:
                        os.remove(local)
                    except OSError:
                        pass
        if not read:  # (none could be read: keep the list there is)
            con.close()
            return None
        if batch:
            con.executemany("INSERT INTO items (kind, show, showkey, letter, season, episode, title,"
                            " year, logo, grp, url) VALUES (?,?,?,?,?,?,?,?,?,?,?)", batch)
        con.execute("CREATE INDEX shows ON items (kind, letter, showkey)")
        con.execute("CREATE INDEX eps ON items (showkey, season, episode)")
        con.execute("CREATE INDEX urls ON items (url)")  # (odprogress.py: what's playing)
        shows = con.execute("SELECT COUNT(DISTINCT showkey) FROM items WHERE kind='episode'").fetchone()[0]
        episodes = con.execute("SELECT COUNT(*) FROM items WHERE kind='episode'").fetchone()[0]
        movies = con.execute("SELECT COUNT(*) FROM items WHERE kind='movie'").fetchone()[0]
        for key, value in (("built", str(time.time())), ("shows", str(shows)), ("episodes", str(episodes)),
                           ("movies", str(movies)), ("sources", "\n".join(sources))):
            con.execute("INSERT INTO meta VALUES (?, ?)", (key, value))
        con.commit()
        con.close()
        os.replace(tmp_db, db_path())
        status()
        return shows, episodes, movies
    except (OSError, sqlite3.Error) as exc:
        xbmc.log("MediaHub Helper: on demand: %r" % exc, xbmc.LOGERROR)
        return None
    finally:
        if bar:
            bar.close()


def status():
    """MH.OD.Status for Skin Settings; MH.OD.Ready (the list is made) and MH.OD.Source
    (there is a list or a playlist to make it from) for the side menu."""
    home = xbmcgui.Window(10000)
    info = built()
    home.setProperty("MH.OD.Source", "1" if info or playlists() else "")
    if not info:
        home.setProperty("MH.OD.Ready", "")
        home.setProperty("MH.OD.Status", "")
        return
    when, shows, episodes, movies = info
    home.setProperty("MH.OD.Ready", "1")
    import mediahub
    home.setProperty("MH.OD.Status", "%s  -  %s" % (mediahub.text(32141) % (shows, episodes, movies),
                                                    time.strftime("%d %b %H:%M", time.localtime(when))))


class Keeper:
    """The service keeps the list fresh: once a day, while nothing is playing."""

    def __init__(self):
        self.next_check = time.time() + 120
        self.next_status = time.time() + 60
        self.busy = False

    def tick(self, monitor):
        now = time.time()
        if now >= self.next_status and not self.busy:  # (a playlist set in Skin Settings since)
            self.next_status = now + 60
            status()
        if now < self.next_check or self.busy:
            return
        self.next_check = now + 3600
        info = built()
        if not info or now - info[0] < REFRESH_EVERY or xbmc.getCondVisibility("Player.HasMedia"):
            return
        self.busy = True

        def run():
            try:
                build(monitor, progress=False)
            finally:
                self.busy = False
        import mediahub
        mediahub.in_thread(run)


def handle(action, monitor):
    """ondemandbuild: (re)build the list now, with a progress bar."""
    if action == "ondemandbuild":
        def run():
            result = build(monitor)
            import mediahub
            if result == "busy":
                return
            if result:
                xbmcgui.Dialog().notification("MediaHub", mediahub.text(32129) % result,
                                              xbmcgui.NOTIFICATION_INFO, 5000, False)
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().notification("MediaHub", mediahub.text(32130),
                                              xbmcgui.NOTIFICATION_WARNING, 5000, False)
        return "thread", run
    return None, None
