"""MediaHub Helper - What's missing (Library health): episodes that have been on TV
but aren't in the library, and films of a collection you have part of.

- TV shows: TVmaze's list of episodes (the ones already shown, not the specials)
  against the library's
- Films: TMDB says which collection a film is in (with the TMDB key from On
  demand's settings); the collection's films that are out and aren't in the
  library are the gaps

Choosing a collection's gap lists its missing films with where each can be
watched in your country (TMDB's watch providers, from JustWatch).

It takes a while (a question per show and per film, spaced out so the sites don't
mind), so it runs when asked (the page's "What's missing" button), with a progress
bar, and the answer is kept (missing.json) for the page to show next time.
"""
import datetime
import json
import os
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import mediahub

CACHE = "special://profile/addon_data/script.mediahub.helper/missing.json"
GAP = 0.3           # seconds between TMDB requests
COLLECTION_RELOOK = 60 * 24 * 3600
SHOW_MAX = 12       # episode names in a line ("S02E05, S02E07 ...")


def load():
    try:
        with open(xbmcvfs.translatePath(CACHE), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save(data):
    path = xbmcvfs.translatePath(CACHE)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def tmdb_key():
    key = xbmc.getInfoLabel("Skin.String(MH.OD.TmdbKey)").strip()
    if not key and xbmc.getCondVisibility("System.HasAddon(plugin.video.mediahub.cinema)"):
        try:
            key = xbmcaddon.Addon("plugin.video.mediahub.cinema").getSetting("tmdb_key").strip()
        except RuntimeError:
            key = ""
    return key


def episode_line(missing):
    """S01 (all 10) · S03E02, S03E05 - shortest way to say which episodes."""
    by_season = {}
    for season, number in missing:
        by_season.setdefault(season, []).append(number)
    parts, named = [], 0
    for season in sorted(by_season):
        numbers = sorted(by_season[season])
        if len(numbers) > 3 and numbers == list(range(1, len(numbers) + 1)):
            parts.append(mediahub.text(32220) % (season, len(numbers)))
            continue
        for number in numbers:
            if named < SHOW_MAX:
                parts.append("S%02dE%02d" % (season, number))
            named += 1
    if named > SHOW_MAX:
        parts.append("…")
    return "  ·  ".join(parts)


def show_gaps(monitor, bar, maze_ids):
    import upcoming
    today = datetime.date.today().isoformat()
    shows = mediahub.rpc("VideoLibrary.GetTVShows", properties=["title", "uniqueid", "art", "year"]).get("tvshows") or []
    found = []
    for n, show in enumerate(shows):
        if monitor.abortRequested():
            break
        bar.update(int(50 * n / max(1, len(shows))), mediahub.text(32219), show["title"])
        key = str(show["tvshowid"])
        maze_id = maze_ids.get(key)
        if maze_id is None:
            maze_id = maze_ids[key] = upcoming.lookup(show.get("uniqueid") or {}, show.get("title", ""), monitor)
        if not maze_id:
            continue
        episodes = upcoming.get("/shows/%d/episodes" % maze_id, monitor)
        monitor.waitForAbort(upcoming.GAP)
        if not isinstance(episodes, list):
            continue
        have = {(e.get("season"), e.get("episode")) for e in mediahub.rpc(
            "VideoLibrary.GetEpisodes", tvshowid=show["tvshowid"], properties=["season", "episode"]).get("episodes") or []}
        missing = sorted({(e["season"], e["number"]) for e in episodes
                          if e.get("season") and e.get("number") and e.get("airdate") and e["airdate"] < today} - have)
        if missing:
            art = show.get("art") or {}
            found.append({"Label": show["title"], "Label2": mediahub.text(32221) % (len(missing), episode_line(missing)),
                          "Poster": art.get("poster") or art.get("thumb") or "",
                          "Action": "info|tvshow|%d" % show["tvshowid"], "Kind": "tvshow", "n": len(missing)})
    return found


def tmdb(path, key, monitor, **query):
    import odart
    query["api_key"] = key
    reply = odart.get_json("%s%s?%s" % (odart.TMDB, path, urllib.parse.urlencode(query)), monitor)
    monitor.waitForAbort(GAP)
    return reply if isinstance(reply, dict) and "status_code" not in reply else None


def tmdb_id(movie, key, monitor):
    ids = movie.get("uniqueid") or {}
    if str(ids.get("tmdb") or "").isdigit():
        return int(ids["tmdb"])
    if ids.get("imdb"):
        reply = tmdb("/find/%s" % ids["imdb"], key, monitor, external_source="imdb_id") or {}
        results = reply.get("movie_results") or []
        if results:
            return int(results[0]["id"])
    reply = tmdb("/search/movie", key, monitor, query=movie["title"], year=movie.get("year") or "") or {}
    for r in reply.get("results") or []:
        if (r.get("title") or "").lower() == movie["title"].lower() and \
                (r.get("release_date") or "")[:4] == str(movie.get("year") or ""):
            return int(r["id"])
    return 0


def collection_gaps(monitor, bar, known):
    import odart
    key = tmdb_key()
    if not key:
        return None
    today = datetime.date.today().isoformat()
    now = time.time()
    movies = mediahub.rpc("VideoLibrary.GetMovies", properties=["title", "year", "uniqueid", "art"]).get("movies") or []
    owned, collections = {}, {}
    for n, movie in enumerate(movies):
        if monitor.abortRequested():
            break
        bar.update(50 + int(40 * n / max(1, len(movies))), mediahub.text(32219), movie["title"])
        mark = known.get(str(movie["movieid"]))
        if not mark or now - mark.get("t", 0) > COLLECTION_RELOOK:
            tid = tmdb_id(movie, key, monitor)
            collection = 0
            if tid:
                details = tmdb("/movie/%d" % tid, key, monitor)
                if details is None:
                    continue  # (not reachable now: ask again next time)
                collection = (details.get("belongs_to_collection") or {}).get("id") or 0
            mark = known[str(movie["movieid"])] = {"tmdb": tid, "c": collection, "t": now}
        if mark.get("tmdb"):
            owned[mark["tmdb"]] = movie
        if mark.get("c"):
            collections.setdefault(mark["c"], []).append(movie)
    found = []
    for n, (cid, mine) in enumerate(collections.items()):
        if monitor.abortRequested():
            break
        bar.update(90 + int(10 * n / max(1, len(collections))), mediahub.text(32219), mine[0]["title"])
        info = tmdb("/collection/%d" % cid, key, monitor)
        if not info:
            continue
        gone = [p for p in info.get("parts") or []
                if p.get("id") not in owned and p.get("release_date") and p["release_date"] <= today]
        if not gone:
            continue
        gone.sort(key=lambda p: p["release_date"])
        names = ", ".join("%s (%s)" % (p.get("title", ""), p["release_date"][:4]) for p in gone)
        poster = info.get("poster_path")
        found.append({"Label": info.get("name") or "", "Label2": mediahub.text(32222) % names,
                      "Poster": odart.TMDB_IMAGES + "w342" + poster if poster else
                      ((mine[0].get("art") or {}).get("poster") or ""),
                      "Action": "missingfilms|%d" % cid, "Kind": "movie", "n": len(gone),
                      "films": [{"id": p["id"], "title": p.get("title", ""), "year": p["release_date"][:4],
                                 "poster": odart.TMDB_IMAGES + "w342" + p["poster_path"] if p.get("poster_path") else ""}
                                for p in gone]})
    return found


def check(monitor):
    data = load()
    bar = xbmcgui.DialogProgressBG()
    bar.create(mediahub.text(32219), "")
    try:
        shows = show_gaps(monitor, bar, data.setdefault("maze", {}))
        films = collection_gaps(monitor, bar, data.setdefault("films", {}))
    finally:
        bar.close()
    data["gaps"] = shows + (films or [])
    data["checked"] = time.time()
    data["nokey"] = films is None
    save(data)
    if films is None:
        mediahub.notify(mediahub.text(32219), 32223)


def country():
    """Where you watch: MediaHub Cinema's country when it's set, or else Kodi's language's."""
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.mediahub.cinema)"):
        try:
            chosen = xbmcaddon.Addon("plugin.video.mediahub.cinema").getSetting("region").strip().upper()
            if len(chosen) == 2 and chosen.isalpha():
                return chosen
        except RuntimeError:
            pass
    value = str(mediahub.rpc("Settings.GetSettingValue", setting="locale.language").get("value") or "")
    parts = value.rsplit(".", 1)[-1].split("_")
    return parts[1].upper() if len(parts) == 2 and len(parts[1]) == 2 else "GB"


WAYS = (("flatrate", 32228), ("free", 32229), ("ads", 32230), ("rent", 32231), ("buy", 32232))


def where_line(providers):
    """"Netflix, Disney Plus  ·  Rent: Apple TV" from TMDB's watch providers for one country."""
    parts = []
    for way, label in WAYS:
        names = [p["provider_name"] for p in sorted(providers.get(way) or [], key=lambda p: p.get("display_priority", 99))
                 if p.get("provider_name")][:4]
        if names:
            parts.append("%s: %s" % (mediahub.text(label), ", ".join(names)))
    return "  ·  ".join(parts)


def missing_films(cid, monitor):
    """A collection's missing films, each with where to watch it; choosing one opens it in
    MediaHub Cinema (its trailer, tell me when it's out, about)."""
    entry = next((g for g in load().get("gaps") or [] if g.get("Action") == "missingfilms|%s" % cid), None)
    key = tmdb_key()
    if not entry or not key:
        return
    here = country()
    items = []
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        for f in entry.get("films") or []:
            reply = tmdb("/movie/%d/watch/providers" % int(f["id"]), key, monitor) or {}
            line = where_line((reply.get("results") or {}).get(here) or {}) or mediahub.text(32233) % here
            item = xbmcgui.ListItem("%s (%s)" % (f["title"], f["year"]), line)
            item.setArt({"icon": f.get("poster") or "DefaultMovies.png", "thumb": f.get("poster") or "DefaultMovies.png"})
            items.append(item)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    pick = xbmcgui.Dialog().select("%s: %s  [COLOR FF8890A0](JustWatch)[/COLOR]" % (mediahub.text(32227), entry["Label"]),
                                   items, useDetails=True)
    if pick >= 0 and xbmc.getCondVisibility("System.HasAddon(plugin.video.mediahub.cinema)"):
        xbmc.executebuiltin("RunPlugin(plugin://plugin.video.mediahub.cinema/?mode=film&id=%d)"
                            % int(entry["films"][pick]["id"]))


def gaps():
    """What the last look found: ([entries], when, no TMDB key)."""
    data = load()
    return data.get("gaps") or [], data.get("checked") or 0, bool(data.get("nokey"))
