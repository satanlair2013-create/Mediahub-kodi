"""MediaHub Helper - "Previously on": back to a show after a while, a reminder first.

When an episode starts from the beginning and you last watched the episode before it
two weeks ago or more, the episode waits (paused) behind a card with that episode's
still, title and story (Custom_1140_PreviouslyOn.xml), then carries on by itself after
20 seconds, or at once with Play. Skin settings > "Previously on" turns it off
(MH.NoPreviouslyOn). Spoiler-free mode doesn't matter here: you've seen that one.

  Window(Home) MH.Prev.Active / .Show / .Title / .Plot / .Art / .Fanart / .Left
"""
import time

import xbmc
import xbmcgui

import mediahub

AWAY = 14 * 86400   # a break this long gets a reminder
WAIT = 20           # seconds the card stays
FIELDS = ("Active", "Show", "Title", "Plot", "Art", "Fanart", "Left")


def prop(name, value=None):
    home = xbmcgui.Window(10000)
    if value is None:
        return home.getProperty("MH.Prev." + name)
    home.setProperty("MH.Prev." + name, str(value))


def epoch(lastplayed):
    try:
        return time.mktime(time.strptime(lastplayed, "%Y-%m-%d %H:%M:%S"))
    except (TypeError, ValueError, OverflowError):
        return 0


def before(ep):
    """The episode just before this one (the last of the season before, for a first episode)."""
    eps = mediahub.rpc("VideoLibrary.GetEpisodes", tvshowid=ep["tvshowid"],
                       properties=["title", "season", "episode", "plot", "art", "lastplayed", "playcount"],
                       sort={"method": "episode"}).get("episodes") or []
    here = (ep.get("season") or 0, ep.get("episode") or 0)
    earlier = [e for e in eps if e.get("season") and (e["season"], e.get("episode") or 0) < here]
    return earlier[-1] if earlier else None


class PreviouslyOn:
    def __init__(self):
        self.until = 0.0

    def started(self, data):
        """Player.OnAVStart (in a thread): a library episode from its start after a long break?"""
        if xbmc.getCondVisibility("Skin.HasSetting(MH.NoPreviouslyOn)") or self.until:
            return
        item = (data or {}).get("item") or {}
        if item.get("type") != "episode" or not isinstance(item.get("id"), int):
            return
        ep = mediahub.rpc("VideoLibrary.GetEpisodeDetails", episodeid=item["id"],
                          properties=["tvshowid", "season", "episode", "showtitle", "art"]).get("episodedetails")
        if not ep or (ep.get("tvshowid") or -1) < 0:
            return
        xbmc.sleep(400)
        try:
            if xbmc.Player().getTime() > 60:  # (carrying on in the middle: no)
                return
        except RuntimeError:
            return
        prev = before(ep)
        last = epoch((prev or {}).get("lastplayed"))
        if not prev or not prev.get("playcount") or not last or time.time() - last < AWAY:
            return
        art = prev.get("art") or {}
        mediahub.rpc("Player.PlayPause", playerid=1, play=False)
        prop("Show", ep.get("showtitle") or "")
        prop("Title", "S%d E%d  %s" % (prev.get("season") or 0, prev.get("episode") or 0, prev.get("title") or ""))
        prop("Plot", prev.get("plot") or "")
        prop("Art", art.get("thumb") or art.get("tvshow.fanart") or "")
        prop("Fanart", (ep.get("art") or {}).get("tvshow.fanart") or art.get("tvshow.fanart") or "")
        prop("Left", WAIT)
        self.until = time.time() + WAIT
        prop("Active", "1")

    def go(self, stop=False):
        """Play (or Stop): the card goes and the episode carries on (or stops)."""
        if not self.until:
            return
        self.until = 0.0
        for name in FIELDS:
            xbmcgui.Window(10000).clearProperty("MH.Prev." + name)
        if stop:
            xbmc.executebuiltin("PlayerControl(Stop)")
        elif xbmc.getCondVisibility("Player.Paused"):
            mediahub.rpc("Player.PlayPause", playerid=1, play=True)

    def tick(self):
        if not self.until:
            return
        if not xbmc.getCondVisibility("Player.HasVideo"):
            return self.go(stop=True)
        left = max(0, int(self.until - time.time() + 0.99))
        if str(left) != prop("Left"):
            prop("Left", left)
        if not left:
            self.go()


def handle(action, previously):
    """prevon|go, prevon|stop"""
    if action == "prevon|go":
        return "now", previously.go
    if action == "prevon|stop":
        return "now", lambda: previously.go(stop=True)
    return None, None
