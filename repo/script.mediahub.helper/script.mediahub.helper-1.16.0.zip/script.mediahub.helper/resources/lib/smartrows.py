"""MediaHub Helper - smart collections for the home rows (gen_rows.py types
"director" and "mcu").

Director Spotlight: a director with three or more movies in your library - one
whose films you've watched or liked, if there is one - and their movies. Another
director each day.

Marvel in Story Order: the Marvel Cinematic Universe films you have, in the order
the story happens (not the order they came out), starting from the first one you
haven't watched - so the row is where your marathon is up to.
"""
import re
import time

import mediahub

MIN_FILMS = 3

# The Marvel Cinematic Universe in story order (with other titles they go by)
MCU = [
    ("Captain America: The First Avenger",),
    ("Captain Marvel",),
    ("Iron Man",),
    ("Iron Man 2",),
    ("The Incredible Hulk",),
    ("Thor",),
    ("The Avengers", "Marvel's The Avengers", "Avengers Assemble"),
    ("Thor: The Dark World",),
    ("Iron Man 3",),
    ("Captain America: The Winter Soldier",),
    ("Guardians of the Galaxy",),
    ("Guardians of the Galaxy Vol. 2", "Guardians of the Galaxy Volume 2"),
    ("Avengers: Age of Ultron",),
    ("Ant-Man",),
    ("Captain America: Civil War",),
    ("Black Widow",),
    ("Black Panther",),
    ("Spider-Man: Homecoming",),
    ("Doctor Strange",),
    ("Thor: Ragnarok",),
    ("Ant-Man and the Wasp",),
    ("Avengers: Infinity War",),
    ("Avengers: Endgame",),
    ("Spider-Man: Far From Home",),
    ("Shang-Chi and the Legend of the Ten Rings",),
    ("Eternals",),
    ("Spider-Man: No Way Home",),
    ("Doctor Strange in the Multiverse of Madness",),
    ("Black Panther: Wakanda Forever",),
    ("Thor: Love and Thunder",),
    ("Guardians of the Galaxy Vol. 3", "Guardians of the Galaxy Volume 3"),
    ("Ant-Man and the Wasp: Quantumania",),
    ("The Marvels",),
    ("Deadpool & Wolverine",),
    ("Captain America: Brave New World",),
    ("Thunderbolts*", "Thunderbolts"),
    ("The Fantastic Four: First Steps",),
]


def norm(title):
    title = title.lower().replace("&", " and ").replace("volume", "vol")
    return re.sub(r"[^a-z0-9]+", " ", title).strip()


MCU_INDEX = {norm(name): i for i, names in enumerate(MCU) for name in names}


def movies(kids):
    found = mediahub.all_items("movie", mediahub.MOVIE_PROPS)
    return [d for d in found if not kids or mediahub.kids_ok(d.get("mpaa"))]


def card(d):
    f = mediahub.title_fields("movie", d)
    f["Action"] = "info|movie|%d" % d["movieid"]
    return f


def mcu_row(kids):
    """The MCU films you have, in story order, from the first one not watched."""
    ordered = {}
    for d in movies(kids):
        i = MCU_INDEX.get(norm(d.get("title") or ""))
        if i is not None and i not in ordered:
            ordered[i] = d
    if len(ordered) < MIN_FILMS:
        return []
    films = [ordered[i] for i in sorted(ordered)]
    start = next((n for n, d in enumerate(films) if not d.get("playcount")), 0)
    fields = []
    for n, d in enumerate(films[start:] + films[:start]):
        f = card(d)
        f["Label2"] = "%d / %d" % ((start + n) % len(films) + 1, len(films))
        fields.append(f)
    return fields[:mediahub.MAX_ITEMS]


def director_row(kids):
    """Another director each day: one with MIN_FILMS or more of your movies, the
    ones whose films you've watched or given a thumbs up coming first."""
    by = {}
    for d in movies(kids):
        for name in d.get("director") or []:
            by.setdefault(name, []).append(d)
    names = [n for n, films in by.items() if len(films) >= MIN_FILMS]
    if not names:
        mediahub.prop("MH.Director.Name", "")
        return []

    def liking(name):
        films = by[name]
        return sum(1 for d in films if d.get("playcount")) + sum(2 for d in films if (d.get("userrating") or 0) >= 8)
    liked = sorted(names, key=lambda n: (-liking(n), n))
    pool = [n for n in liked if liking(n)] or liked
    name = pool[int(time.time() // 86400) % len(pool)]  # (a different one each day)
    mediahub.prop("MH.Director.Name", name)
    films = sorted(by[name], key=lambda d: (bool(d.get("playcount")), -(d.get("year") or 0)))
    return [card(d) for d in films[:mediahub.MAX_ITEMS]]
