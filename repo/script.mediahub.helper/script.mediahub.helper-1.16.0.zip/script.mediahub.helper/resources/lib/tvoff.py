"""MediaHub Helper - the TV goes off too, not just the film.

When the sleep timer or Kids mode bedtime stops what's playing (with "Turn the TV
off too" in Skin settings > Playback), or with the timer's "TV off after this one",
the TV is switched off: over HDMI-CEC (Kodi's CECStandby, when the box is plugged
into the TV and CEC is on), or through Home Assistant when a TV entity is set
(MH.HA.Tv: media_player.living_room_tv, switch.tv or remote.tv).
"""
import xbmc

import cinema

DOMAINS = ("media_player", "switch", "remote")


def wanted():
    return xbmc.getCondVisibility("Skin.HasSetting(MH.TvOff)")


def off():
    entity = cinema.setting("MH.HA.Tv")
    domain = entity.split(".", 1)[0] if "." in entity else ""
    if domain in DOMAINS and cinema.setting("MH.HA.Url") and cinema.setting("MH.HA.Token"):
        cinema.post("/api/services/%s/turn_off" % domain, {"entity_id": entity}, what=entity)
    else:
        xbmc.executebuiltin("CECStandby")
    xbmc.log("MediaHub Helper: TV off", xbmc.LOGINFO)
