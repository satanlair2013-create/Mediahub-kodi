"""MediaHub Helper - today's weather for the screensaver.

When Kodi has a weather add-on set up, the screensaver shows Kodi's own weather
and this does nothing. Otherwise Skin Settings takes a town (MH.Weather.City) and
this asks Open-Meteo (free, no account) about it: the temperature now, what it's
like, and today's high and low, in the unit of Kodi's region settings. It asks
only while the screensaver is showing (and when the town is changed), at most
every half hour.

Properties: MH.Weather.Temp, .Text, .Icon (one of Kodi's own weather icons),
.HiLo and .Place.
"""
import json
import os
import threading
import time
import urllib.parse

import xbmc
import xbmcgui
import xbmcvfs

import mediahub

BASE = os.environ.get("MEDIAHUB_OPENMETEO")
GEOCODE = (BASE or "https://geocoding-api.open-meteo.com") + "/v1/search"
FORECAST = (BASE or "https://api.open-meteo.com") + "/v1/forecast"
TEMP = "special://temp/mediahub-weather.json"
ICONS = "resource://resource.images.weathericons.default/%s.png"
EVERY = 30 * 60
RETRY = 5 * 60

# WMO weather codes -> (Kodi's icon by day, by night, text)
KINDS = [
    ((0,), 32, 31, 32171),
    ((1, 2), 30, 29, 32172),
    ((3,), 26, 26, 32173),
    ((45, 48), 20, 20, 32174),
    ((51, 53, 55, 56, 57), 9, 9, 32175),
    ((61, 63, 65), 12, 12, 32176),
    ((66, 67), 10, 10, 32176),
    ((71, 73, 75, 77, 85, 86), 16, 16, 32177),
    ((80, 81, 82), 11, 11, 32178),
    ((95, 96, 99), 4, 4, 32179),
]
PROPS = ("Temp", "Text", "Icon", "HiLo", "Place")


def city():
    return xbmc.getInfoLabel("Skin.String(MH.Weather.City)").strip()


def kodi_has_weather():
    return bool(xbmc.getInfoLabel("Weather.Plugin"))


def fahrenheit():
    return "F" in (xbmc.getRegion("tempunit") or "").upper()


def get_json(url, monitor):
    import net
    local = xbmcvfs.translatePath(TEMP)
    try:
        if not net.fetch(url, local, monitor):
            return None
        with open(local, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None
    finally:
        net.remove(local)


def place(name, monitor):
    """(latitude, longitude, "Town, Country") for "Town" or "Town, Country"; None
    when not found; False when Open-Meteo couldn't be asked."""
    town, _, where = (p.strip() for p in name.partition(","))
    reply = get_json("%s?%s" % (GEOCODE, urllib.parse.urlencode({"name": town, "count": 10, "format": "json"})),
                     monitor)
    if reply is None:
        return False
    results = reply.get("results") or []
    if where:  # (the country, its code, or the region / state)
        w = {"uk": "gb", "usa": "us", "america": "us"}.get(where.lower(), where.lower())

        def matches(r):
            names = [str(r.get(k) or "").lower() for k in ("country", "admin1", "admin2")]
            return w == str(r.get("country_code") or "").lower() or any(n and n.startswith(w) for n in names)
        results = [r for r in results if matches(r)] or results
    if not results:
        return None
    r = results[0]
    return r["latitude"], r["longitude"], ", ".join(x for x in (r.get("name"), r.get("country")) if x)


def clear():
    home = xbmcgui.Window(10000)
    for p in PROPS:
        home.clearProperty("MH.Weather." + p)


class Weather:
    def __init__(self):
        self.lock = threading.Lock()
        self.places = {}  # town as typed -> place()
        self.due = 0.0
        self.city = None

    def fetch(self, monitor, tell=False):
        """Look it up now (in a thread). tell: say when the town isn't found."""
        name = city()
        if not name:
            clear()
            return
        with self.lock:
            if name not in self.places or self.places[name] is False:
                self.places[name] = place(name, monitor)
            found = self.places[name]
            if not found:
                self.due = time.time() + RETRY
                if found is None:
                    clear()
                    if tell:
                        xbmcgui.Dialog().notification("MediaHub", mediahub.text(32181) % name,
                                                      xbmcgui.NOTIFICATION_WARNING, 5000, False)
                return
            lat, lon, where = found
            query = {"latitude": lat, "longitude": lon, "timezone": "auto", "forecast_days": 1,
                     "current": "temperature_2m,weather_code,is_day",
                     "daily": "temperature_2m_max,temperature_2m_min"}
            if fahrenheit():
                query["temperature_unit"] = "fahrenheit"
            reply = get_json("%s?%s" % (FORECAST, urllib.parse.urlencode(query)), monitor)
            current = (reply or {}).get("current") or {}
            if current.get("temperature_2m") is None:
                self.due = time.time() + RETRY
                return
            code = current.get("weather_code")
            kind = next((k for k in KINDS if code in k[0]), None)
            home = xbmcgui.Window(10000)
            home.setProperty("MH.Weather.Temp", "%d°" % round(current["temperature_2m"]))
            home.setProperty("MH.Weather.Text", mediahub.text(kind[3]) if kind else "")
            home.setProperty("MH.Weather.Icon", ICONS % (kind[1] if current.get("is_day", 1) else kind[2])
                             if kind else "")
            daily = (reply or {}).get("daily") or {}
            high, low = (daily.get("temperature_2m_max") or [None])[0], (daily.get("temperature_2m_min") or [None])[0]
            home.setProperty("MH.Weather.HiLo", mediahub.text(32180) % ("%d°" % round(high), "%d°" % round(low))
                             if high is not None and low is not None else "")
            home.setProperty("MH.Weather.Place", where)
            self.due = time.time() + EVERY

    def tick(self, monitor):
        """Service loop: keep it fresh while the screensaver shows."""
        if not mediahub.prop("MH.SS.Active") or kodi_has_weather():
            return
        name = city()
        if name != self.city:
            self.city, self.due = name, 0.0
        if name and time.time() >= self.due and not self.lock.locked():
            self.due = time.time() + RETRY  # (not again while this one is on its way)
            mediahub.in_thread(self.fetch, monitor)

    def handle(self, action, monitor):
        """weathercity: the town was changed in Skin Settings."""
        if action != "weathercity":
            return None, None
        self.city, self.due = city(), time.time() + RETRY
        return "thread", lambda: self.fetch(monitor, tell=True)


def use_mediahub_weather():
    """Skin settings > MediaHub Weather: make it Kodi's weather (Settings > Services > Weather),
    asking for a town first if it has none yet (Kodi asks the add-on for the weather as soon
    as it's chosen)."""
    import updates
    import xbmcaddon
    if not xbmcaddon.Addon("weather.mediahub").getSetting("Location1"):
        xbmc.executebuiltin("RunScript(weather.mediahub,Location1)")
        monitor = xbmc.Monitor()
        for n in range(600):  # (while the town is being chosen)
            if monitor.waitForAbort(0.5) or xbmcaddon.Addon("weather.mediahub").getSetting("Location1"):
                break
            if n > 6 and search_given_up():
                break
    if updates.rpc_setting("weather.addon").get("value") == "weather.mediahub":
        updates.rpc_setting("weather.addon", "")
    updates.rpc_setting("weather.addon", "weather.mediahub")


def search_given_up():
    """The town search was given up (no keyboard or list on screen any more)."""
    return not xbmc.getCondVisibility("Window.IsVisible(virtualkeyboard) | Window.IsVisible(selectdialog) | "
                                      "Window.IsVisible(okdialog) | Window.IsVisible(busydialog)") and \
        not xbmc.getCondVisibility("System.HasModalDialog")
