"""MediaHub Helper - Lite mode, for boxes short of memory (Apple TV above all).

Lite mode (Skin.HasSetting(MH.Lite)) shows six home rows instead of twelve and
turns off what uses the most memory: trailer previews, the hero trailer, moving
effects, backdrops and the artwork colour glow. What those settings were is kept
(lite.json), so turning Lite mode off puts them back as they were.

When the free memory stays very low for a while (and nothing is playing), Lite
mode turns itself on, once - Skin Settings > Lite mode can turn it off again, and
"Turn on by itself" off stops it from doing that.
"""
import json
import os
import re
import time

import xbmc
import xbmcgui
import xbmcvfs

import mediahub

SAVED = "special://profile/addon_data/script.mediahub.helper/lite.json"
BOOLS_ON = ("MH.NoHeroPreview", "MH.ReduceMotion", "MH.NoMediaBackdrop")  # Lite turns these on
BOOLS_OFF = ("MH.ShowBackdrop", "MH.ArtColour")  # and these off
LOW_MB = 250  # free memory below this ...
LOW_LOOKS = 3  # ... this many looks in a row (EVERY seconds apart) turns Lite mode on
EVERY = 30


def is_on():
    return xbmc.getCondVisibility("Skin.HasSetting(MH.Lite)")


def has(name):
    return xbmc.getCondVisibility("Skin.HasSetting(%s)" % name)


def set_bool(name, on):
    xbmc.executebuiltin(("Skin.SetBool(%s)" if on else "Skin.Reset(%s)") % name)


def turn_on():
    if is_on():
        return
    saved = {name: has(name) for name in BOOLS_ON + BOOLS_OFF}
    saved["MH.RowPreviews"] = xbmc.getInfoLabel("Skin.String(MH.RowPreviews)")
    try:
        path = xbmcvfs.translatePath(SAVED)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            json.dump(saved, f)
    except OSError:
        pass
    for name in BOOLS_ON:
        set_bool(name, True)
    for name in BOOLS_OFF:
        set_bool(name, False)
    xbmc.executebuiltin("Skin.SetString(MH.RowPreviews,off)")
    set_bool("MH.Lite", True)


def turn_off():
    if not is_on():
        return
    try:
        with open(xbmcvfs.translatePath(SAVED)) as f:
            saved = json.load(f)
    except (OSError, ValueError):
        saved = {}
    for name in BOOLS_ON + BOOLS_OFF:
        if name in saved:
            set_bool(name, bool(saved[name]))
    if "MH.RowPreviews" in saved:
        xbmc.executebuiltin("Skin.SetString(MH.RowPreviews,%s)" % saved["MH.RowPreviews"])
    set_bool("MH.Lite", False)


def free_mb():
    """System.Memory(free), e.g. "812MB", in MB (None if Kodi can't say)."""
    m = re.match(r"\s*([\d.]+)\s*([KMG]?)B", xbmc.getInfoLabel("System.Memory(free)") or "", re.I)
    if not m:
        return None
    return float(m.group(1)) * {"K": 1 / 1024.0, "M": 1, "G": 1024, "": 1 / 1048576.0}[m.group(2).upper()]


class Watcher:
    def __init__(self):
        self.next_look = time.time() + 120  # (memory is busy just after start-up)
        self.low = 0
        self.done = False

    def tick(self):
        now = time.time()
        if self.done or now < self.next_look:
            return
        self.next_look = now + EVERY
        if is_on() or has("MH.LiteNoAuto") or xbmc.getInfoLabel("Skin.String(MH.LiteAuto)"):
            self.done = True  # (on already, not wanted, or it turned itself on once before)
            return
        if xbmc.getCondVisibility("Player.HasVideo"):  # (the video buffer comes and goes)
            self.low = 0
            return
        free = free_mb()
        self.low = self.low + 1 if free is not None and free < LOW_MB else 0
        if self.low < LOW_LOOKS:
            return
        self.done = True
        xbmc.log("MediaHub Helper: only %d MB of memory free - turning Lite mode on" % free, xbmc.LOGWARNING)
        turn_on()
        mediahub.prop("MH.Req.Rows", str(now))  # (rows 7-12 are left out now)
        xbmc.executebuiltin("Skin.SetString(MH.LiteAuto,%s)" % time.strftime("%Y-%m-%d"))
        xbmcgui.Dialog().notification("MediaHub", mediahub.text(32145), xbmcgui.NOTIFICATION_INFO, 8000, False)


def handle(action):
    """lite|on, lite|off."""
    if action == "lite|on":
        turn_on()
        return True
    if action == "lite|off":
        turn_off()
        return True
    return False
