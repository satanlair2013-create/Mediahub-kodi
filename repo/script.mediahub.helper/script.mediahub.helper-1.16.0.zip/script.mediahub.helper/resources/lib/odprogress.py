"""MediaHub Helper - where you are in On demand (ondemand.py) films and episodes.

While an On demand address plays, the service notes how far in you are
(odprogress.json, by address, so it survives the daily rebuild of the list). The
pages show the resume point and the watched tick; playing an episode queues the
next few of its season, so Kodi's Up Next card offers the next one; and the home
row "Continue Watching: On demand" has what you're part-way through, and the
next episode of a show whose last one you finished.
"""
import json
import os
import time

import xbmc
import xbmcgui
import xbmcvfs

import mediahub
import ondemand

FILE = "special://profile/addon_data/script.mediahub.helper/odprogress.json"
KEEP = 300  # entries kept (the oldest go)
WATCHED = 0.9  # this far through counts as watched
QUEUE = 5  # episodes queued after the one you play
EVERY = 2.0
SAVE_EVERY = 15.0
COLUMNS = "id, kind, show, showkey, season, episode, title, year, logo, grp, url"


def load():
    try:
        with open(xbmcvfs.translatePath(FILE)) as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save(data):
    if len(data) > KEEP:
        data = dict(sorted(data.items(), key=lambda kv: kv[1].get("t", 0))[-KEEP:])
    path = xbmcvfs.translatePath(FILE)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path + ".tmp", "w") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def as_dict(row):
    return dict(zip([c.strip() for c in COLUMNS.split(",")], row)) if row else None


def find(url=None, rowid=None):
    """The On demand entry for an address (or a list id), or None."""
    if not ondemand.built():
        return None
    con = ondemand.connect()
    try:
        if rowid is not None:
            row = con.execute("SELECT %s FROM items WHERE id=?" % COLUMNS, (rowid,)).fetchone()
        else:
            row = con.execute("SELECT %s FROM items WHERE url=? LIMIT 1" % COLUMNS, (url,)).fetchone()
        return as_dict(row)
    finally:
        con.close()


def following(entry, count):
    """The episodes after this one in its show (this season, then the next)."""
    con = ondemand.connect()
    try:
        rows = con.execute("SELECT %s FROM items WHERE kind='episode' AND showkey=? AND (season>? OR "
                           "(season=? AND episode>?)) ORDER BY season, episode, id LIMIT ?" % COLUMNS,
                           (entry["showkey"], entry["season"], entry["season"], entry["episode"],
                            count * 2)).fetchall()
    finally:
        con.close()
    found, seen = [], set()
    for row in rows:  # (a playlist can list an episode twice: keep the first)
        e = as_dict(row)
        if (e["season"], e["episode"]) not in seen:
            seen.add((e["season"], e["episode"]))
            found.append(e)
    return found[:count]


def bare(url):
    return url.split("?", 1)[0].split("|", 1)[0]


def playing_url():
    """The address playing, as the list has it."""
    path = xbmc.getInfoLabel("Player.Filenameandpath")
    try:
        queue = json.loads(mediahub.prop("MH.OD.Queue") or "[]")
    except ValueError:
        queue = []
    if queue:
        at = mediahub.rpc("Player.GetProperties", playerid=1, properties=["position"]).get("position", -1)
        if 0 <= at < len(queue) and bare(queue[at]) == bare(path):
            return queue[at]
    return path


def list_item(e):
    if e["kind"] == "episode":
        label = "%s  S%d E%d%s" % (e["show"], e["season"], e["episode"], "  " + e["title"] if e["title"] else "")
    else:
        label = e["title"]
    item = xbmcgui.ListItem(label, path=e["url"])
    tag = item.getVideoInfoTag()
    tag.setTitle(e["title"] or ("%s %d" % (xbmc.getLocalizedString(20359), e["episode"])
                                if e["kind"] == "episode" else e["show"]))
    tag.setMediaType(e["kind"])
    if e["kind"] == "episode":
        tag.setTvShowTitle(e["show"])
        tag.setSeason(e["season"])
        tag.setEpisode(e["episode"])
    elif e.get("year"):
        tag.setYear(e["year"])
    if e.get("logo"):
        item.setArt({"thumb": e["logo"], "poster": e["logo"], "icon": e["logo"]})
    return item


def play(rowid, resume):
    """Play an On demand entry (from where you stopped if resume), with the next
    episodes of its season queued so Up Next offers them."""
    e = find(rowid=rowid)
    if not e:
        return
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    first = list_item(e)
    position = (load().get(e["url"]) or {}).get("pos", 0)
    if resume and position > 30:
        first.setProperty("StartOffset", str(int(position)))
    playlist.add(e["url"], first)
    queue = [e["url"]]
    if e["kind"] == "episode":
        for nxt in following(e, QUEUE):
            playlist.add(nxt["url"], list_item(nxt))
            queue.append(nxt["url"])
    # (Kodi reports the playing address without its ?query, so the tracker goes by
    # the playlist position in this)
    mediahub.prop("MH.OD.Queue", json.dumps(queue))
    xbmc.Player().play(playlist)


def resume_point(url):
    """(position, total, watched) for an address."""
    p = load().get(url) or {}
    return p.get("pos", 0), p.get("total", 0), bool(p.get("watched"))


class Tracker:
    """Notes how far into an On demand address you are while it plays."""

    def __init__(self):
        self.next = 0.0
        self.url = None
        self.entry = None
        self.pos = self.total = 0.0
        self.furthest = 0.0  # the furthest it got this time (reaching the end counts, whatever follows)
        self.saved = 0.0

    def tick(self):
        now = time.time()
        if now < self.next:
            return
        self.next = now + EVERY
        playing = xbmc.getCondVisibility("Player.HasVideo")
        url = playing_url() if playing else ""
        if url != self.url:
            self.finish()
            self.url, self.entry = url, None
            if url.lower().startswith(("http://", "https://")):
                self.entry = find(url=url)
        if not self.entry:
            return
        try:
            player = xbmc.Player()
            self.pos, self.total = player.getTime(), player.getTotalTime()
        except RuntimeError:
            return
        if self.total > 0:
            self.furthest = max(self.furthest, self.pos / self.total)
        if now - self.saved > SAVE_EVERY:
            self.record(False)
            self.saved = now

    def record(self, final):
        if not self.entry or self.entry["kind"] == "live" or self.total <= 0 or self.pos < 5:
            return
        data = load()
        e = self.entry
        watched = self.furthest >= WATCHED
        data[e["url"]] = {"kind": e["kind"], "show": e["show"], "showkey": e["showkey"], "season": e["season"],
                          "episode": e["episode"], "title": e["title"], "logo": e["logo"],
                          "pos": 0 if watched else int(self.pos), "total": int(self.total),
                          "watched": watched, "t": time.time()}
        save(data)
        if final:
            mediahub.prop("MH.Req.Rows", str(time.time()))  # (the Continue row)

    def finish(self):
        """The address stopped (or another started)."""
        if self.entry:
            self.record(True)
        self.entry = None
        self.pos = self.total = self.furthest = 0.0


def continue_row(kids):
    """Home row: what you're part-way through, and the next episode of a show whose
    last episode you finished - most recent first."""
    if kids or not ondemand.built():
        return []
    data = load()
    cards, shows = [], set()
    for url, p in sorted(data.items(), key=lambda kv: -kv[1].get("t", 0)):
        if p.get("kind") == "episode":
            if p.get("showkey") in shows:
                continue
            shows.add(p.get("showkey"))
        entry = find(url=url)
        if not entry:
            continue
        if p.get("watched"):
            if entry["kind"] != "episode":
                continue
            nxt = next((n for n in following(entry, 3) if not (data.get(n["url"]) or {}).get("watched")), None)
            if not nxt:
                continue
            entry, pos, total = nxt, 0, 0
        else:
            pos, total = p.get("pos", 0), p.get("total", 0)
        name = entry["show"] if entry["kind"] == "episode" else entry["title"]
        left = int((total - pos) / 60) if total and pos else 0
        cards.append({
            "Label": name,
            "Label2": ("S%d E%d" % (entry["season"], entry["episode"]) if entry["kind"] == "episode" else "")
            + (("  •  " if entry["kind"] == "episode" else "") + mediahub.text(32161) % left if left else ""),
            "Title": entry["title"] or name,
            "Landscape": entry["logo"] or "",
            "Poster": entry["logo"] or "",
            "Percent": str(int(100 * pos / total)) if total and pos else "",
            "Action": "odplay|%d|%d" % (entry["id"], 1 if pos else 0),
            "Kind": "ondemand",
            "T": int(p.get("t") or 0),  # (when: for the Continue anywhere row)
        })
        if len(cards) >= mediahub.MAX_ITEMS:
            break
    return cards


def search(words, kids):
    """Search page (finding.People): On demand shows and films, and live channels
    from the playlist, whose names contain the words - as card fields."""
    if kids or len(words) < 2 or not ondemand.built():
        return [], []
    import odart
    like = "%" + ondemand.sort_key(words) + "%"
    where, params = ondemand.group_filter()
    con = ondemand.connect()
    try:
        shows = con.execute("SELECT showkey, MIN(show), COUNT(*), MAX(logo) FROM items WHERE kind='episode' AND "
                            "showkey LIKE ?%s GROUP BY showkey ORDER BY showkey LIMIT 10" % where,
                            [like] + params).fetchall()
        films = con.execute("SELECT %s FROM items WHERE kind='movie' AND showkey LIKE ?%s ORDER BY showkey LIMIT 10"
                            % (COLUMNS, where), [like] + params).fetchall()
        live = con.execute("SELECT %s FROM items WHERE kind='live' AND showkey LIKE ?%s ORDER BY showkey LIMIT 20"
                           % (COLUMNS, where), [like] + params).fetchall()
    finally:
        con.close()
    art = odart.lookup([odart.show_key(k) for k, _, _, _ in shows])
    od = []
    for key, name, count, logo in shows:
        info = art.get(odart.show_key(key)) or {}
        picture = info.get("fanart") or info.get("poster") or logo or ""
        od.append({"Label": name, "Label2": "%s  •  %d" % (xbmc.getLocalizedString(20343), count),
                   "Title": name, "Landscape": picture, "Poster": info.get("poster") or logo or "",
                   "Action": "odshow|" + key, "Kind": "ondemand"})
    films = [as_dict(r) for r in films]
    film_art = odart.lookup([odart.movie_key(ondemand.sort_key(e["title"]), e["year"]) for e in films])
    for e in films:
        info = film_art.get(odart.movie_key(ondemand.sort_key(e["title"]), e["year"])) or {}
        od.append({"Label": e["title"], "Label2": str(e["year"] or ""), "Title": e["title"],
                   "Landscape": info.get("fanart") or info.get("poster") or e["logo"] or "",
                   "Poster": info.get("poster") or e["logo"] or "",
                   "Action": "odplay|%d|1" % e["id"], "Kind": "ondemand"})
    tv = [{"Label": e["show"], "Label2": e["grp"] or "", "Title": e["show"], "Landscape": e["logo"] or "",
           "Poster": e["logo"] or "", "Action": "odplay|%d|0" % e["id"], "Kind": "live"}
          for e in (as_dict(r) for r in live)]
    return od[:mediahub.MAX_ITEMS], tv[:mediahub.MAX_ITEMS]


def handle(action):
    """odplay|<id>|<1: resume>, odshow|<showkey>"""
    if action.startswith("odshow|"):
        import urllib.parse
        xbmc.executebuiltin("ActivateWindow(Videos,plugin://script.mediahub.helper/?%s,return)"
                            % urllib.parse.urlencode({"mode": "seasons", "show": action[7:]}))
        return True
    if action.startswith("odplay|"):
        parts = action.split("|")
        if len(parts) == 3 and parts[1].isdigit():
            play(int(parts[1]), parts[2] == "1")
        return True
    return False
