"""MediaHub Helper - Trailer night.

One trailer after another, for the films in your library you haven't watched yet,
like the trailers before a film at the cinema. OK on "Watch the film" plays the
film of the trailer that's on; right goes on to the next trailer.

The trailers play in the skin's own window (Custom_1137_TrailerNight.xml, a video
window behind the film's logo and plot), not in the full-screen player. Window(Home)
properties:

  MHN.Active   1 while it runs
  MHN.Title / .Logo / .Fanart / .Meta (year, genre, running time) / .Plot
  MHN.Pos / .Total, MHN.Next (the next film's title), MHN.InList (1: in My List)
"""
import json
import random
import time

import xbmc
import xbmcgui

import mediahub

WINDOW = 1137
MAX_TRAILERS = 60
START_GRACE = 6     # seconds a trailer gets to start before "not playing" means it ended
OPEN_GRACE = 3      # seconds the window gets to open


def home():
    return xbmcgui.Window(10000)


def prop(name, value=None):
    if value is None:
        return home().getProperty("MHN." + name)
    home().setProperty("MHN." + name, str(value))


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                       "params": params})))
    return reply.get("result") or {}


def playable(trailer):
    """A trailer Kodi can play here: a file, a web address, or a YouTube one with its add-on."""
    if not trailer:
        return False
    if trailer.startswith("plugin://"):
        addon = trailer.split("/")[2]
        return xbmc.getCondVisibility("System.HasAddon(%s)" % addon)
    return True


def reel(kids):
    found = rpc("VideoLibrary.GetMovies", filter={"field": "playcount", "operator": "is", "value": "0"},
                properties=["title", "year", "art", "plot", "genre", "runtime", "trailer", "mpaa", "tag"])
    films = [m for m in found.get("movies") or []
             if playable(m.get("trailer")) and (not kids or mediahub.kids_ok(m.get("mpaa")))]
    random.shuffle(films)
    return films[:MAX_TRAILERS]


def running_time(seconds):
    minutes = int(seconds or 0) // 60
    if not minutes:
        return ""
    return mediahub.text(32205) % (minutes // 60, minutes % 60) if minutes >= 60 else mediahub.text(32203) % minutes


class TrailerNight:
    def __init__(self):
        self.films, self.index = [], -1
        self.started = self.opened = 0
        self.active = False

    # the skin: MH.Req.Action trailernight / tnwatch / tnnext / tnprev / tnlist / tnclose
    def open(self):
        films = reel(mediahub.kids_mode())
        if not films:
            xbmcgui.Dialog().ok(mediahub.text(32214), mediahub.text(32215))
            return
        self.films, self.index = films, -1
        self.opened = self.started = time.time()
        self.active = True
        prop("Active", "1")
        prop("Total", len(films))
        xbmc.executebuiltin("ActivateWindow(%d)" % WINDOW)
        xbmc.sleep(500)  # (so the home screen's own trailer preview has stopped first)
        self.play(0)

    def play(self, index):
        if not self.films:
            return
        self.index = index % len(self.films)
        film = self.films[self.index]
        art = film.get("art") or {}
        prop("Title", film["title"])
        prop("Logo", art.get("clearlogo", ""))
        prop("Fanart", art.get("fanart", ""))
        prop("Meta", "  •  ".join(str(x) for x in (film.get("year") or "", " / ".join((film.get("genre") or [])[:2]),
                                                    running_time(film.get("runtime"))) if x))
        prop("Plot", film.get("plot", ""))
        prop("Pos", self.index + 1)
        prop("InList", "1" if mediahub.MYLIST_TAG in (film.get("tag") or []) else "")
        prop("Next", self.films[(self.index + 1) % len(self.films)]["title"] if len(self.films) > 1 else "")
        self.started = time.time()
        # (1: in the window, not full screen; noresume: never "Resume from ...?" for a trailer)
        xbmc.executebuiltin('PlayMedia("%s",1,noresume)' % film["trailer"].replace('"', '\\"'))

    def watch(self):
        if not self.active or self.index < 0:
            return
        film = self.films[self.index]
        self.close()
        xbmc.executebuiltin("ReplaceWindow(home)")
        xbmc.sleep(300)
        rpc("Player.Open", item={"movieid": film["movieid"]}, options={"resume": True})

    def toggle_list(self):
        if not self.active or self.index < 0:
            return
        film = self.films[self.index]
        mediahub.toggle_mylist("movie", film["movieid"])
        tags = [t for t in film.get("tag") or [] if t != mediahub.MYLIST_TAG]
        if prop("InList") != "1":
            tags.append(mediahub.MYLIST_TAG)
        film["tag"] = tags
        prop("InList", "1" if mediahub.MYLIST_TAG in tags else "")

    def close(self):
        """The window closed (or a film was chosen): stop the trailer and clear up."""
        if not self.active:
            return
        self.active = False
        if xbmc.getCondVisibility("Player.HasMedia") and not xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
            xbmc.executebuiltin("PlayerControl(Stop)")
        for name in ("Active", "Title", "Logo", "Fanart", "Meta", "Plot", "Pos", "Total", "Next", "InList"):
            home().clearProperty("MHN." + name)
        self.films, self.index = [], -1

    def tick(self):
        if not self.active:
            return
        now = time.time()
        if now - self.opened > OPEN_GRACE and not xbmc.getCondVisibility("Window.IsActive(%d)" % WINDOW):
            self.close()
            return
        # the trailer ended (or wouldn't play): on to the next one
        if now - self.started > START_GRACE and not xbmc.getCondVisibility("Player.HasMedia"):
            self.play(self.index + 1)


def handle(action, night):
    """(how, work) for the service's loop."""
    return {"trailernight": ("thread", night.open), "tnwatch": ("now", night.watch),
            "tnnext": ("now", lambda: night.play(night.index + 1)),
            "tnprev": ("now", lambda: night.play(night.index - 1)),
            "tnlist": ("now", night.toggle_list), "tnclose": ("now", night.close)}[action]
