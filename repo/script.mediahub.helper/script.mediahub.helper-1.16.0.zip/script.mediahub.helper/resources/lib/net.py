"""MediaHub Helper - downloads that can be stopped.

Kodi gives the helper 5 seconds to stop (when Kodi closes, or the helper is
updated or turned off) and then kills it, which can crash Kodi. xbmcvfs.copy()
can't be interrupted, and Kodi's File.read() gets nothing from a server that
doesn't say how long the file is, so a long download (a big IPTV playlist) or a
server that stalls would hold the helper up. Web addresses are read here in
pieces instead, with a time limit, checking between pieces whether the helper
should stop. Anything else (a file, smb://, or a web address this can't read)
goes through xbmcvfs.copy as before.
"""
import os
import ssl
import urllib.error
import urllib.request
import zlib

import xbmc
import xbmcvfs

CHUNK = 64 * 1024
TIMEOUT = 20  # seconds a server may keep us waiting for the next piece
CERTS = "special://xbmc/system/certs/cacert.pem"  # (Kodi ships one where the system has none: Apple TV, Android)


def context():
    certs = xbmcvfs.translatePath(CERTS)
    try:
        return ssl.create_default_context(cafile=certs) if os.path.exists(certs) else ssl.create_default_context()
    except (OSError, ssl.SSLError):
        return ssl.create_default_context()


def remove(path):
    try:
        os.remove(path)
    except OSError:
        pass


def fetch(url, dest, monitor):
    """Save url to the local file dest. True when something arrived; False when it
    failed or the helper is stopping (dest is then removed)."""
    if url.lower().startswith(("http://", "https://")) and "|" not in url:
        request = urllib.request.Request(url, headers={"User-Agent": xbmc.getUserAgent()})
        try:
            with urllib.request.urlopen(request, timeout=TIMEOUT, context=context()) as reply, open(dest, "wb") as out:
                # (some servers compress even when asked not to)
                coding = (reply.headers.get("Content-Encoding") or "").lower()
                unpack = zlib.decompressobj(zlib.MAX_WBITS | 32) if coding in ("gzip", "x-gzip", "deflate") else None
                while True:
                    if monitor.abortRequested():
                        break
                    data = reply.read(CHUNK)
                    if not data:
                        if unpack:
                            out.write(unpack.flush())
                        if out.tell() > 0:
                            return True
                        break
                    out.write(unpack.decompress(data) if unpack else data)
            remove(dest)
            return False
        except urllib.error.HTTPError as exc:  # (the server answered: no point asking again)
            xbmc.log("MediaHub Helper: %s: %s" % (url.split("?")[0], exc), xbmc.LOGWARNING)
            remove(dest)
            return False
        except (OSError, ValueError, ssl.SSLError, zlib.error) as exc:
            xbmc.log("MediaHub Helper: %s: %r - trying through Kodi" % (url.split("?")[0], exc), xbmc.LOGWARNING)
            remove(dest)
            if monitor.abortRequested():
                return False
    ok = bool(xbmcvfs.copy(url, dest)) and os.path.exists(dest) and os.path.getsize(dest) > 0
    if not ok:
        remove(dest)
    return ok
