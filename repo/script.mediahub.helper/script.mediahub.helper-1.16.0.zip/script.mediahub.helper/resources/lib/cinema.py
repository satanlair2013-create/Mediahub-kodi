"""MediaHub Helper - Cinema mode: Home Assistant sets the room for a film.

Skin settings > Cinema mode (Home Assistant): the Home Assistant address, a
long-lived access token (Home Assistant > your profile > Security), and a scene
or script for each moment:

- MH.HA.Start: a film (or, with MH.CinemaEpisodes, an episode) starts or carries on
  after a pause, full screen (not the trailers on the home screen)
- MH.HA.Pause: it's paused
- MH.HA.End: the end credits (the last few minutes), or it stops
- MH.HA.ArtLights: lights (light.tv_strip, light.lamp) that take the main colour of
  the film's poster whenever it starts or carries on

Each can be a scene (scene.*), a script (script.*) or an automation (automation.*,
which is triggered). Any left empty is skipped. The calls go out in the background,
so a slow or missing Home Assistant never holds up the player.
"""
import json
import threading
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcgui
import xbmcvfs

import artcolour
import mediahub

SERVICES = {"scene": ("scene", "turn_on"), "script": ("script", "turn_on"),
            "automation": ("automation", "trigger"), "light": ("light", "turn_on"),
            "switch": ("switch", "turn_on"), "input_boolean": ("input_boolean", "turn_on")}
CREDITS_MIN = 180  # seconds before the end that count as the credits (at least) ...
CREDITS_SHARE = 0.04  # ... or this share of the film, whichever is longer


def setting(name):
    return xbmc.getInfoLabel("Skin.String(%s)" % name).strip()


def post(path, data, done=None, what=""):
    """One Home Assistant service call (in the background)."""
    base, token = setting("MH.HA.Url").rstrip("/"), setting("MH.HA.Token")
    if not base or not token:
        return

    def send():
        request = urllib.request.Request(base + path, data=json.dumps(data).encode(), method="POST",
                                         headers={"Authorization": "Bearer " + token,
                                                  "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(request, timeout=5) as reply:
                ok, why = 200 <= reply.status < 300, str(reply.status)
        except urllib.error.HTTPError as exc:
            ok, why = False, "HTTP %d" % exc.code
        except (OSError, ValueError) as exc:
            ok, why = False, str(getattr(exc, "reason", exc))
        if not ok:
            xbmc.log("MediaHub cinema mode: %s: %s" % (what or path, why), xbmc.LOGWARNING)
        if done:
            done(ok, why)
    threading.Thread(target=send, daemon=True).start()


def call(entity, done=None):
    """Turn on / trigger one Home Assistant entity (in the background)."""
    domain = entity.split(".", 1)[0] if entity else ""
    if domain in SERVICES:
        post("/api/services/%s/%s" % SERVICES[domain], {"entity_id": entity}, done, entity)


def film_art():
    """The film's poster (or fanart), as Kodi has it."""
    for label in ("Player.Art(poster)", "Player.Art(tvshow.poster)", "Player.Art(fanart)"):
        url = xbmc.getInfoLabel(label)
        if url.startswith("image://"):
            url = urllib.parse.unquote(url[len("image://"):].rstrip("/"))
        if url:
            return url
    return ""


def picture_bytes(url):
    """The picture as a JPEG: Kodi's own cached copy (small), or else the file itself."""
    cached = mediahub.rpc("Textures.GetTextures", properties=["cachedurl"],
                          filter={"field": "url", "operator": "is", "value": url}).get("textures") or []
    paths = ["special://thumbnails/" + t["cachedurl"] for t in cached if t.get("cachedurl")]
    if not url.startswith(("http://", "https://", "image://")):
        paths.append(url)
    for path in paths:
        if not path.lower().endswith((".jpg", ".jpeg", ".tbn")):
            continue
        f = xbmcvfs.File(path)
        try:
            if f.size() > 12 * 1024 * 1024:
                continue
            data = bytes(f.readBytes())
        finally:
            f.close()
        if data:
            return data
    return b""


def colour_lights(done=None):
    """MH.HA.ArtLights (light.a, light.b): the main colour of the film's poster. The helper
    works it out itself; for a web picture it can't read, Home Assistant's Color
    Extractor integration is asked instead."""
    lights = [x.strip() for x in setting("MH.HA.ArtLights").split(",") if x.strip().startswith("light.")]
    url = film_art()
    if not lights or not url:
        return
    colour = artcolour.main_colour(picture_bytes(url))
    if colour:
        post("/api/services/light/turn_on", {"entity_id": lights, "rgb_color": list(colour)}, done, "light colour")
    elif url.startswith(("http://", "https://")):
        post("/api/services/color_extractor/turn_on", {"color_extract_url": url, "entity_id": lights}, done,
             "color_extractor")


class Cinema:
    """Watches the player and calls the scene for each moment, once."""

    def __init__(self):
        self.state = None  # None, "playing", "paused", "credits"

    def watched(self):
        if not xbmc.getCondVisibility("Skin.HasSetting(MH.Cinema)"):
            return False
        if not xbmc.getCondVisibility("Player.HasVideo + Window.IsActive(fullscreenvideo)"):
            return False
        return xbmc.getCondVisibility("VideoPlayer.Content(movies) | [VideoPlayer.Content(episodes) + "
                                      "Skin.HasSetting(MH.CinemaEpisodes)]")

    def tick(self):
        if self.state is None:
            if self.watched():
                self.enter("playing")
            return
        if not xbmc.getCondVisibility("Player.HasVideo"):
            if self.state != "credits":
                call(setting("MH.HA.End"))
            self.state = None
            return
        if self.state == "credits":
            return
        try:
            player = xbmc.Player()
            left, total = player.getTotalTime() - player.getTime(), player.getTotalTime()
        except RuntimeError:
            return
        if total > 600 and left <= max(CREDITS_MIN, total * CREDITS_SHARE):
            self.enter("credits")
        elif xbmc.getCondVisibility("Player.Paused"):
            if self.state != "paused":
                self.enter("paused")
        elif self.state == "paused":
            self.enter("playing")

    def enter(self, state):
        self.state = state
        call(setting({"playing": "MH.HA.Start", "paused": "MH.HA.Pause", "credits": "MH.HA.End"}[state]))
        if state == "playing":
            # (after the scene, which may set the lights' colours itself)
            threading.Timer(2, colour_lights).start()


def test():
    """Skin settings > Test cinema mode: the Film starts scene, then (after ten
    seconds) the end one, saying whether Home Assistant answered."""
    start, end = setting("MH.HA.Start"), setting("MH.HA.End")
    if not setting("MH.HA.Url") or not setting("MH.HA.Token") or not (start or end):
        return xbmcgui.Dialog().ok(mediahub.text(32190), mediahub.text(32191))

    def said(ok, why):
        xbmcgui.Dialog().notification(mediahub.text(32190), mediahub.text(32192) if ok else mediahub.text(32193) % why,
                                      xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_WARNING, 5000)
    call(start or end, said)
    if start and end:
        threading.Timer(10, call, args=(end,)).start()
