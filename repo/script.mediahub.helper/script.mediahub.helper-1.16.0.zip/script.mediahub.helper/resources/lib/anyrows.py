"""MediaHub Helper - two home rows that look everywhere.

- Continue anywhere: everything you're part-way through, newest first, whichever
  it's in: the library's films and episodes, On demand, MediaHub IPTV, Classics,
  Audiobooks, Podcasts and Concerts (their cards carry "T", when you last played them).
- Worth a rewatch: films and shows you gave a thumbs up (or love) and haven't
  watched for over a year, the best loved and longest ago first.
"""
import time

import mediahub

YEAR = 365 * 86400
ADDON_ROWS = ("odcontinue", "iptvcontinue", "clcontinue", "abcontinue", "podcontinue", "concontinue")
LOVED = 8  # (MediaHub's thumbs up is 8, love 10)


def epoch(lastplayed):
    try:
        return int(time.mktime(time.strptime(lastplayed, "%Y-%m-%d %H:%M:%S")))
    except (TypeError, ValueError, OverflowError):
        return 0


def library_started(kids):
    going = {"field": "inprogress", "operator": "true", "value": ""}
    found = []
    for m in mediahub.rpc("VideoLibrary.GetMovies", filter=going, properties=mediahub.MOVIE_PROPS + ["lastplayed"],
                          limits={"start": 0, "end": mediahub.MAX_ITEMS}).get("movies") or []:
        if not kids or mediahub.kids_ok(m.get("mpaa")):
            found.append(dict(mediahub.title_fields("movie", m), T=epoch(m.get("lastplayed"))))
    shows = {}
    if kids:
        shows = {s["tvshowid"]: s.get("mpaa") for s in
                 mediahub.rpc("VideoLibrary.GetTVShows", properties=["mpaa"]).get("tvshows") or []}
    for e in mediahub.rpc("VideoLibrary.GetEpisodes", filter=going, properties=mediahub.EPISODE_PROPS,
                          limits={"start": 0, "end": mediahub.MAX_ITEMS}).get("episodes") or []:
        if not kids or mediahub.kids_ok(shows.get(e.get("tvshowid"))):
            found.append(dict(mediahub.episode_fields(e), T=epoch(e.get("lastplayed"))))
    return found


def continue_anywhere(kids):
    cards = library_started(kids)
    for key in ADDON_ROWS:
        try:
            cards += [c for c in mediahub.helper_row(key)(kids) if c.get("T")]
        except Exception:  # (one add-on's cards never spoil the row)
            continue
    cards.sort(key=lambda c: -int(c.get("T") or 0))
    for c in cards:
        if not c.get("Landscape") and c.get("Square"):
            c["Landscape"] = c["Square"]  # (a book's or a podcast's cover)
    return cards[:mediahub.MAX_ITEMS]


def rewatch(kids):
    now = time.time()
    found = []
    for kind, method, key in (("movie", "VideoLibrary.GetMovies", "movies"),
                              ("tvshow", "VideoLibrary.GetTVShows", "tvshows")):
        props = (mediahub.MOVIE_PROPS if kind == "movie" else mediahub.SHOW_PROPS) + ["lastplayed"]
        rule = {"field": "userrating", "operator": "greaterthan", "value": str(LOVED - 1)}
        for d in mediahub.rpc(method, filter=rule, properties=props).get(key) or []:
            last = epoch(d.get("lastplayed"))
            if not d.get("playcount") and kind == "movie":
                continue
            if last and now - last < YEAR or (kids and not mediahub.kids_ok(d.get("mpaa"))):
                continue
            found.append(((d.get("userrating") or 0), -(last or 0), mediahub.title_fields(kind, d)))
    found.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return [fields for _r, _l, fields in found][:mediahub.MAX_ITEMS]
