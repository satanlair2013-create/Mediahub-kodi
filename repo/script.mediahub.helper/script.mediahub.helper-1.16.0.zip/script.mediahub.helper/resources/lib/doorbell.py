"""MediaHub Helper - Doorbell: Home Assistant says someone's at the door.

Skin settings > Cinema mode (Home Assistant): the same address and access token
as cinema mode, plus

- MH.HA.Doorbell: the doorbell, as Home Assistant has it: an event entity
  (event.front_door: every press is a new state), or a binary sensor, input
  boolean or switch (binary_sensor.doorbell: rings when it turns on)
- MH.HA.Camera: a camera to show (camera.front_door); optional

When it rings, what's playing pauses and a pop-up (Custom_1138_Doorbell.xml) shows
the camera's picture, fresh every few seconds, with Resume and Dismiss. Home
Assistant is asked every couple of seconds, in the background.

Window(Home): MH.Door.Name, MH.Door.Picture, MH.Door.Time, MH.Door.Resume (1 when
the doorbell paused something).
"""
import json
import threading
import time
import urllib.error
import urllib.request

import xbmc
import xbmcgui

import mediahub

WINDOW = 1138
POLL = 2           # seconds between asking Home Assistant
PICTURE_EVERY = 3  # seconds between camera pictures while the pop-up is up
OPEN_FOR = 120     # seconds before the pop-up closes by itself
RINGS_ON = ("binary_sensor", "input_boolean", "switch")


def home():
    return xbmcgui.Window(10000)


def setting(name):
    return xbmc.getInfoLabel("Skin.String(%s)" % name).strip()


def get_state(base, token, entity):
    request = urllib.request.Request("%s/api/states/%s" % (base, entity),
                                     headers={"Authorization": "Bearer " + token})
    with urllib.request.urlopen(request, timeout=4) as reply:
        return json.loads(reply.read().decode("utf-8"))


def picture(base, token, camera):
    """The camera's picture: an address Kodi can load as it is (Home Assistant puts a
    short-lived access token for that one camera in it)."""
    if not camera:
        return ""
    try:
        path = (get_state(base, token, camera).get("attributes") or {}).get("entity_picture") or ""
    except (OSError, ValueError):
        return ""
    if not path:
        return ""
    # (a new address every time, or Kodi would show the picture it already has)
    return "%s%s%smh=%d" % (base, path, "&" if "?" in path else "?", int(time.time() * 1000))


class Doorbell:
    def __init__(self):
        self.next_poll = self.next_picture = self.shown = 0
        self.last = None      # (entity, state) last seen
        self.busy = False
        self.paused = False   # the doorbell paused the player

    def config(self):
        if not xbmc.getCondVisibility("Skin.HasSetting(MH.Doorbell)"):
            return None
        base, token, entity = setting("MH.HA.Url").rstrip("/"), setting("MH.HA.Token"), setting("MH.HA.Doorbell")
        return (base, token, entity) if base and token and entity else None

    def tick(self):
        now = time.time()
        if self.shown:
            if not xbmc.getCondVisibility("Window.IsVisible(%d)" % WINDOW):
                if now - self.shown > 3:  # (closed with Back / Dismiss)
                    self.closed()
            elif now - self.shown > OPEN_FOR:
                xbmc.executebuiltin("Dialog.Close(%d)" % WINDOW)
            elif now >= self.next_picture and not self.busy:
                self.next_picture = now + PICTURE_EVERY
                self.background(self.refresh_picture)
        if now < self.next_poll or self.busy:
            return
        self.next_poll = now + POLL
        found = self.config()
        if not found:
            self.last = None
            return
        self.background(self.poll, *found)

    def background(self, work, *args):
        self.busy = True

        def run():
            try:
                work(*args)
            finally:
                self.busy = False
        threading.Thread(target=run, daemon=True).start()

    def poll(self, base, token, entity):
        try:
            state = get_state(base, token, entity)
        except urllib.error.HTTPError as exc:
            if self.last != (entity, "error"):
                xbmc.log("MediaHub doorbell: %s: HTTP %d" % (entity, exc.code), xbmc.LOGWARNING)
            self.last = (entity, "error")
            return
        except (OSError, ValueError):
            return  # (Home Assistant restarting, the network down: try again later)
        value = str(state.get("state", ""))
        before, self.last = self.last, (entity, value)
        if before is None or before[0] != entity or before[1] in ("error", value):
            return  # (the first look, after changing the setting, or nothing new)
        domain = entity.split(".", 1)[0]
        if value in ("unavailable", "unknown"):
            return
        # (an event or a button: any new state is a press; a sensor or switch: turning on)
        if domain not in RINGS_ON or value == "on":
            name = (state.get("attributes") or {}).get("friendly_name") or ""
            self.ring(base, token, name)

    def ring(self, base, token, name=""):
        if xbmc.getCondVisibility("Player.HasMedia + !Player.Paused + Player.PauseEnabled"):
            xbmc.executebuiltin("PlayerControl(Play)")  # (pauses it)
            self.paused = True
        else:
            self.paused = self.paused and xbmc.getCondVisibility("Player.Paused")
        home().setProperty("MH.Door.Name", name)
        home().setProperty("MH.Door.Time", xbmc.getInfoLabel("System.Time"))
        home().setProperty("MH.Door.Resume", "1" if self.paused else "")
        home().setProperty("MH.Door.Picture", picture(base, token, setting("MH.HA.Camera")))
        self.shown = self.next_picture = time.time()
        self.next_picture += PICTURE_EVERY
        xbmc.executebuiltin("ActivateWindow(%d)" % WINDOW)

    def refresh_picture(self):
        found = self.config() or (setting("MH.HA.Url").rstrip("/"), setting("MH.HA.Token"), "")
        fresh = picture(found[0], found[1], setting("MH.HA.Camera"))
        if fresh and self.shown:
            home().setProperty("MH.Door.Picture.Old", home().getProperty("MH.Door.Picture"))
            home().setProperty("MH.Door.Picture", fresh)

    def resume(self):
        """Resume: carry on with what the doorbell paused."""
        paused, self.paused = self.paused, False
        xbmc.executebuiltin("Dialog.Close(%d)" % WINDOW)
        if paused and xbmc.getCondVisibility("Player.Paused"):
            xbmc.executebuiltin("PlayerControl(Play)")
        self.closed()

    def closed(self):
        self.shown = 0
        self.paused = self.paused and xbmc.getCondVisibility("Player.Paused")
        for name in ("Name", "Picture", "Picture.Old", "Time", "Resume"):
            home().clearProperty("MH.Door." + name)

    def test(self):
        base, token = setting("MH.HA.Url").rstrip("/"), setting("MH.HA.Token")
        if not base or not token:
            xbmcgui.Dialog().ok(mediahub.text(32216), mediahub.text(32217))
            return
        self.ring(base, token, mediahub.text(32218))


def handle(action, bell):
    return {"doortest": ("thread", bell.test), "doorresume": ("now", bell.resume),
            "doorclosed": ("now", bell.closed)}[action]
