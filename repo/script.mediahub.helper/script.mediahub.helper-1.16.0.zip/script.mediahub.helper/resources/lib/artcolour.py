"""MediaHub Helper - the main colour of a picture, for lights (cinema mode).

Kodi's Python has no picture library, so this reads a JPEG's "DC" values: in a
JPEG each 8 x 8 block of pixels starts with its average colour, which can be read
without decoding the rest. From those block colours, the most common vivid hue
wins (a plain average of a poster is nearly always brown or grey).

Only plain ("baseline") JPEGs, which is what Kodi writes to its thumbnail cache.
"""
import colorsys
import struct

MAX_MCUS = 12000  # enough to see a whole cached poster; a huge original is read only in part


class Unsupported(Exception):
    pass


def _huffman(counts, symbols):
    """(maxcode, valptr, mincode, symbols) per code length, as in the JPEG standard."""
    maxcode, valptr, mincode = [-1] * 17, [0] * 17, [0] * 17
    code = k = 0
    for length in range(1, 17):
        if counts[length - 1]:
            valptr[length], mincode[length] = k, code
            code += counts[length - 1]
            k += counts[length - 1]
            maxcode[length] = code - 1
        code <<= 1
    return maxcode, valptr, mincode, symbols


class Bits:
    def __init__(self, data, pos):
        self.data, self.pos, self.buf, self.left = data, pos, 0, 0

    def bit(self):
        if not self.left:
            byte = self.data[self.pos] if self.pos < len(self.data) else 0
            self.pos += 1
            if byte == 0xFF:
                marker = self.data[self.pos] if self.pos < len(self.data) else 0
                if marker == 0:
                    self.pos += 1          # (a stuffed 0xFF)
                elif 0xD0 <= marker <= 0xD7:
                    raise Unsupported("restart in the middle")  # (handled by restart())
            self.buf, self.left = byte, 8
        self.left -= 1
        return (self.buf >> self.left) & 1

    def bits(self, n):
        value = 0
        for _ in range(n):
            value = (value << 1) | self.bit()
        return value

    def decode(self, table):
        maxcode, valptr, mincode, symbols = table
        code = self.bit()
        for length in range(1, 17):
            if code <= maxcode[length]:
                return symbols[valptr[length] + code - mincode[length]]
            code = (code << 1) | self.bit()
        raise Unsupported("bad code")

    def restart(self):
        """Skip to just after the next RSTn marker."""
        self.left = 0
        while self.pos + 1 < len(self.data):
            if self.data[self.pos] == 0xFF and 0xD0 <= self.data[self.pos + 1] <= 0xD7:
                self.pos += 2
                return
            self.pos += 1


def extend(value, size):
    return value - (1 << size) + 1 if size and value < (1 << (size - 1)) else value


def block_colours(data):
    """The average (r, g, b) of each MCU (a 8x8 to 16x16 area) of a baseline JPEG."""
    if data[:2] != b"\xff\xd8":
        raise Unsupported("not a JPEG")
    pos, quant, dc_tables, ac_tables, frame, restart_every = 2, {}, {}, {}, None, 0
    while pos < len(data):
        if data[pos] != 0xFF:
            raise Unsupported("lost")
        marker = data[pos + 1]
        pos += 2
        if marker in (0xD8, 0x01) or 0xD0 <= marker <= 0xD7:
            continue
        size = struct.unpack(">H", data[pos:pos + 2])[0]
        body = data[pos + 2:pos + size]
        if marker == 0xDB:  # quantisation tables
            i = 0
            while i < len(body):
                precision, tid = body[i] >> 4, body[i] & 15
                quant[tid] = struct.unpack(">H", body[i + 1:i + 3])[0] if precision else body[i + 1]
                i += 1 + (128 if precision else 64)
        elif marker in (0xC0, 0xC1):  # baseline frame
            height, width, n = struct.unpack(">HHB", body[1:6])
            comps = [(body[6 + 3 * c], body[7 + 3 * c] >> 4, body[7 + 3 * c] & 15, body[8 + 3 * c]) for c in range(n)]
            frame = (width, height, comps)
        elif 0xC2 <= marker <= 0xCF and marker not in (0xC4, 0xC8, 0xCC):
            raise Unsupported("progressive or other kind")
        elif marker == 0xC4:  # Huffman tables
            i = 0
            while i < len(body):
                kind, tid = body[i] >> 4, body[i] & 15
                counts = list(body[i + 1:i + 17])
                total = sum(counts)
                table = _huffman(counts, list(body[i + 17:i + 17 + total]))
                (ac_tables if kind else dc_tables)[tid] = table
                i += 17 + total
        elif marker == 0xDD:
            restart_every = struct.unpack(">H", body[:2])[0]
        elif marker == 0xDA:  # the picture itself
            if not frame:
                raise Unsupported("no frame")
            n = body[0]
            tables = {body[1 + 2 * c]: (body[2 + 2 * c] >> 4, body[2 + 2 * c] & 15) for c in range(n)}
            return _scan(data, pos + size, frame, tables, quant, dc_tables, ac_tables, restart_every)
        pos += size
    raise Unsupported("no picture")


def _scan(data, pos, frame, tables, quant, dc_tables, ac_tables, restart_every):
    width, height, comps = frame
    hmax = max(c[1] for c in comps)
    vmax = max(c[2] for c in comps)
    mcus = ((width + 8 * hmax - 1) // (8 * hmax)) * ((height + 8 * vmax - 1) // (8 * vmax))
    bits = Bits(data, pos)
    previous = {c[0]: 0 for c in comps}
    out = []
    for m in range(min(mcus, MAX_MCUS)):
        if restart_every and m and m % restart_every == 0:
            bits.restart()
            previous = {c[0]: 0 for c in comps}
        means = []
        for cid, h, v, qid in comps:
            dc_id, ac_id = tables[cid]
            total = 0
            for _ in range(h * v):
                size = bits.decode(dc_tables[dc_id])
                previous[cid] += extend(bits.bits(size), size)
                total += previous[cid]
                k = 1
                while k < 64:  # (the rest of the block: read past it)
                    symbol = bits.decode(ac_tables[ac_id])
                    run, size = symbol >> 4, symbol & 15
                    if not size:
                        if run != 15:
                            break
                        k += 16
                        continue
                    bits.bits(size)
                    k += run + 1
            means.append(total / (h * v) * quant[qid] / 8 + 128)
        if len(means) == 3:
            y, cb, cr = means
            rgb = (y + 1.402 * (cr - 128), y - 0.344136 * (cb - 128) - 0.714136 * (cr - 128), y + 1.772 * (cb - 128))
        else:
            rgb = (means[0],) * 3
        out.append(tuple(max(0, min(255, int(c))) for c in rgb))
    return out


def main_colour(data):
    """The picture's main vivid colour as (r, g, b), for a light; None when it can't tell."""
    try:
        colours = block_colours(data)
    except (Unsupported, IndexError, KeyError, struct.error):
        return None
    buckets = {}
    for r, g, b in colours:
        hue, sat, val = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
        if sat < 0.25 or val < 0.2:
            continue  # (greys, black and white don't make a colour for a room)
        key = int(hue * 24) % 24
        weight = sat * val
        entry = buckets.setdefault(key, [0, 0, 0, 0])
        entry[0] += weight
        entry[1] += r * weight
        entry[2] += g * weight
        entry[3] += b * weight
    if not buckets:
        return None
    total, r, g, b = max(buckets.values(), key=lambda e: e[0])
    hue, sat, _ = colorsys.rgb_to_hsv(r / total / 255, g / total / 255, b / total / 255)
    # (the hue and a bit more colour; the brightness is the lights' own)
    return tuple(int(c * 255) for c in colorsys.hsv_to_rgb(hue, min(1, sat * 1.2), 1))
