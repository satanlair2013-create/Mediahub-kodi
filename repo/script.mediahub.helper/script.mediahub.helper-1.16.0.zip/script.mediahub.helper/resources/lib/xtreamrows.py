"""MediaHub Helper - home rows from the MediaHub IPTV add-on (plugin.video.mediahub.xtream).

That add-on keeps ready-made cards in its home.json: Continue Watching: IPTV,
IPTV: New Movies and IPTV: New Series. These rows show them (in Kids mode only
the ones from children's categories), and a card's action runs the add-on:
"xtream|run|<plugin address>" plays, "xtream|open|<plugin address>" opens a page.

It also has your favourite IPTV channels with their next few programmes: the
IPTV: My Channels row (MH.XChan, the same cards as My Channels) shows what's on
each now and next, worked out again every minute; a card sends
playchannel|x<stream id>.
"""
import json
import time

import xbmc
import xbmcvfs

import mediahub

FILE = "special://profile/addon_data/plugin.video.mediahub.xtream/home.json"
ROWS = ("iptvcontinue", "iptvmovies", "iptvseries")


def load():
    try:
        with open(xbmcvfs.translatePath(FILE), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def row(key):
    """The cards of one row (a function(kids) for mediahub.refresh_rows)."""
    def cards(kids):
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.mediahub.xtream)"):
            return []
        found = [c for c in load().get(key) or [] if isinstance(c, dict) and (not kids or c.get("kids"))]
        return [{k: v for k, v in c.items() if k != "kids"} for c in found][:mediahub.MAX_ITEMS]
    return cards


def clock(stamp):
    return time.strftime("%H:%M", time.localtime(stamp)) if stamp else ""  # (as the My Channels row)


def channel_cards():
    """IPTV: My Channels: each favourite channel with what's on now and next."""
    import channels
    now = time.time()
    found = []
    for c in load().get("iptvchannels") or []:
        if not isinstance(c, dict) or not c.get("id"):
            continue
        progs = sorted(c.get("programmes") or [], key=lambda p: p.get("start", 0))
        cur = next((p for p in progs if p.get("start", 0) <= now < p.get("stop", 0)), None)
        nxt = next((p for p in progs if cur and p.get("start", 0) >= cur.get("stop", 0)), None)
        found.append({
            "Label": c.get("name", ""),
            "Label2": "%s - %s" % (clock(cur["start"]), clock(cur["stop"])) if cur else "",
            "Title": cur.get("title") if cur else c.get("name", ""),
            "Icon": c.get("icon", ""),
            "Next": "%s  %s" % (clock(nxt["start"]), nxt.get("title", "")) if nxt else "",
            "Percent": str(int(100 * (now - cur["start"]) / max(1, cur["stop"] - cur["start"]))) if cur else "",
            "ID": "x" + str(c["id"]),
            "NoGuide": "" if cur else "1",
        })
    return found[:channels.MAX]


class Watcher:
    """Refresh the home rows when the add-on has written new cards, and what's on
    the IPTV channels every minute while the home screen shows."""

    def __init__(self):
        self.seen = None
        self.next_channels = 0.0

    def tick(self):
        """True when the helper rows should be filled again."""
        import channels
        stamp = mediahub.prop("MHX.Home")
        now = time.time()
        changed = stamp != self.seen
        first, self.seen = self.seen is None, stamp
        if changed or (now >= self.next_channels and xbmc.getCondVisibility("Window.IsVisible(home)")):
            self.next_channels = now + 60
            channels.fill_props("MH.XChan", channel_cards())
        return changed and not first


def handle(action):
    """xtream|run|<address>, xtream|open|<address>, playchannel|x<stream id>."""
    if action.startswith("playchannel|x"):
        card = next((c for c in load().get("iptvchannels") or [] if "x" + str(c.get("id")) == action[12:]), None)
        if card and card.get("action"):
            return handle(card["action"])
        return True
    if not action.startswith("xtream|"):
        return False
    parts = action.split("|", 2)
    if len(parts) == 3 and parts[2].startswith("plugin://plugin.video.mediahub.xtream/"):
        if parts[1] == "open":
            xbmc.executebuiltin("ActivateWindow(Videos,%s,return)" % parts[2])
        else:
            xbmc.executebuiltin("RunPlugin(%s)" % parts[2])
    return True


def offer_youtube():
    """A trailer needs the YouTube add-on, which isn't installed: offer to get it."""
    import xbmcgui
    if xbmcgui.Dialog().yesno("YouTube", mediahub.text(32182)):
        xbmc.executebuiltin("InstallAddon(plugin.video.youtube)")
