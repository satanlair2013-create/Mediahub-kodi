"""MediaHub Helper - what's coming up for your TV shows (TVmaze), for the Calendar
window (Custom_1121_Calendar.xml) and the Coming Soon row.

Once a day (in the background, a request a second or so) each show in the
library that is still running is looked up on TVmaze (tvmaze.com, free, no
account) by its TVDB or IMDb id, and its next episode noted (upcoming.json).
The Calendar lists the next two weeks, day by day; Coming Soon adds the next
seven days to the library's own future episodes.

A show TVmaze says has ended, or doesn't know, is only asked about again after
a month.
"""
import datetime
import json
import os
import threading
import time

import xbmc
import xbmcvfs

import mediahub

API = os.environ.get("MEDIAHUB_TVMAZE", "https://api.tvmaze.com")  # (a test server can stand in)
CACHE = "special://profile/addon_data/script.mediahub.helper/upcoming.json"
TEMP = "special://temp/mediahub-tvmaze.json"
REFRESH = 24 * 3600
RELOOK = 30 * 24 * 3600  # a show TVmaze didn't know, or says has ended, is asked about again after this
GAP = 0.7  # seconds between requests (TVmaze allows 20 in 10 seconds)
DAYS = 14  # the Calendar's span
CAL_MAX = 40  # entries in the Calendar window
LOCK = threading.Lock()


def load():
    try:
        with open(xbmcvfs.translatePath(CACHE)) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save(data):
    path = xbmcvfs.translatePath(CACHE)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path + ".tmp", "w") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def get(path, monitor):
    """JSON from TVmaze (net.fetch: Kodi's own file layer, and it can be stopped).
    None if it isn't there or can't be read."""
    import net
    local = xbmcvfs.translatePath(TEMP)
    try:
        if not net.fetch(API + path, local, monitor):
            return None
        with open(local, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None
    finally:
        xbmcvfs.delete(TEMP)


def lookup(ids, title, monitor):
    """TVmaze's id for a show, from its TVDB or IMDb id, or else its exact name
    (0: not known there)."""
    import urllib.parse
    for key, param in (("tvdb", "thetvdb"), ("imdb", "imdb")):
        value = str(ids.get(key) or "")
        if value:
            show = get("/lookup/shows?%s=%s" % (param, urllib.parse.quote(value)), monitor)
            monitor.waitForAbort(GAP)
            if isinstance(show, dict) and show.get("id"):
                return int(show["id"])
    if title:
        show = get("/singlesearch/shows?q=%s" % urllib.parse.quote(title), monitor)
        monitor.waitForAbort(GAP)
        if isinstance(show, dict) and show.get("id") and (show.get("name") or "").lower() == title.lower():
            return int(show["id"])
    return 0


def next_episode(maze_id, monitor):
    show = get("/shows/%d?embed=nextepisode" % maze_id, monitor)
    monitor.waitForAbort(GAP)
    if not isinstance(show, dict):
        return None, ""
    ep = (show.get("_embedded") or {}).get("nextepisode") or {}
    status = show.get("status") or ""
    if not ep.get("airstamp") and not ep.get("airdate"):
        return {}, status
    return {"season": ep.get("season") or 0, "number": ep.get("number") or 0, "name": ep.get("name") or "",
            "airdate": ep.get("airdate") or "", "airtime": ep.get("airtime") or "",
            "airstamp": ep.get("airstamp") or ""}, status


def refresh(monitor):
    """Look up what's next for every running show in the library (the ones not
    looked at today)."""
    if not LOCK.acquire(blocking=False):
        return
    try:
        data = load()
        maze, eps = data.setdefault("maze", {}), data.setdefault("eps", {})
        shows = mediahub.rpc("VideoLibrary.GetTVShows", properties=["title", "uniqueid"]).get("tvshows", [])
        now = time.time()
        changed = False
        for show in shows:
            if monitor.abortRequested():
                break
            key = str(show["tvshowid"])
            known = maze.get(key)
            if not known or (not known.get("id") and now - known.get("t", 0) > RELOOK):
                maze[key] = {"id": lookup(show.get("uniqueid") or {}, show.get("title", ""), monitor), "t": now}
                changed = True
            maze_id = maze[key]["id"]
            if not maze_id:
                continue
            had = eps.get(key) or {}
            ended = (had.get("status") or "").lower() == "ended"
            if now - had.get("t", 0) < (RELOOK if ended else REFRESH):
                continue
            ep, status = next_episode(maze_id, monitor)
            if ep is None:
                continue  # (not reachable now: try again next time)
            eps[key] = {"ep": ep, "status": status, "t": now}
            changed = True
        # shows that left the library
        present = {str(s["tvshowid"]) for s in shows}
        for table in (maze, eps):
            for key in [k for k in table if k not in present]:
                del table[key]
                changed = True
        if changed:
            save(data)
        publish()
        mediahub.prop("MH.Req.Rows", str(time.time()))  # (Coming Soon)
    finally:
        LOCK.release()


def local_time(ep):
    """When it airs, as a local datetime (the airstamp is UTC with an offset)."""
    stamp = ep.get("airstamp") or ""
    try:
        when = datetime.datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        return datetime.datetime.fromtimestamp(when.timestamp())
    except ValueError:
        pass
    try:
        return datetime.datetime.fromisoformat("%s %s" % (ep["airdate"], ep.get("airtime") or "00:00"))
    except (KeyError, ValueError):
        return None


def entries(days=DAYS):
    """[(local datetime, tvshowid, episode)] airing from today for `days` days, soonest first."""
    today = datetime.datetime.combine(datetime.date.today(), datetime.time())
    until = today + datetime.timedelta(days=days)
    found = []
    for key, value in (load().get("eps") or {}).items():
        ep = (value or {}).get("ep") or {}
        when = local_time(ep) if ep else None
        if when and today <= when < until:
            found.append((when, int(key), ep))
    return sorted(found, key=lambda e: e[0])


def shows_by_id():
    return {s["tvshowid"]: s for s in mediahub.rpc(
        "VideoLibrary.GetTVShows", properties=["title", "art", "mpaa"]).get("tvshows", [])}


def fields(when, show, ep):
    art = show.get("art") or {}
    day = mediahub.when(when.strftime("%Y-%m-%d"))
    hour = when.strftime("%H:%M") if (ep.get("airstamp") or ep.get("airtime")) else ""
    return {
        "Label": show.get("title", ""),
        "Label2": "S%d E%d  •  %s%s" % (ep["season"], ep["number"], day, "  " + hour if hour else ""),
        "Title": ep.get("name") or "",
        "Landscape": art.get("landscape") or art.get("fanart") or "",
        "ArtHasTitle": "1" if art.get("landscape") else "",
        "Poster": art.get("poster") or "",
        "Logo": art.get("clearlogo") or "",
        "DBType": "tvshow",
        "DBID": show["tvshowid"],
        "Action": "info|tvshow|%d" % show["tvshowid"],
    }


def coming(kids, days=7):
    """Coming Soon cards from TVmaze for the next `days` days (one per show)."""
    shows = shows_by_id()
    found, seen = [], set()
    for when, tvshowid, ep in entries(days):
        show = shows.get(tvshowid)
        if not show or tvshowid in seen or (kids and not mediahub.kids_ok(show.get("mpaa"))):
            continue
        seen.add(tvshowid)
        f = fields(when, show, ep)
        f["When"] = when.strftime("%Y-%m-%d %H:%M")
        found.append(f)
    return found


def day_label(day):
    """'Today  25 Sep', 'Tomorrow  26 Sep', 'Monday  28 Sep'."""
    days = (day - datetime.date.today()).days
    name = mediahub.text(32050) if days == 0 else mediahub.text(32051) if days == 1 else day.strftime("%A")
    return "%s  %d %s" % (name, day.day, day.strftime("%b"))


def publish():
    """The Calendar window's list: MH.Cal.<n>.* (Day is set on the first of each day)."""
    home_prop = mediahub.prop
    shows = shows_by_id()
    kids = mediahub.kids_mode()
    items, last_day = [], None
    for when, tvshowid, ep in entries():
        show = shows.get(tvshowid)
        if not show or (kids and not mediahub.kids_ok(show.get("mpaa"))):
            continue
        f = fields(when, show, ep)
        day = when.date()
        f["Day"] = "" if day == last_day else day_label(day)
        f["Time"] = when.strftime("%H:%M") if (ep.get("airstamp") or ep.get("airtime")) else ""
        f["Episode"] = "S%d E%d" % (ep["season"], ep["number"])
        last_day = day
        items.append(f)
        if len(items) >= CAL_MAX:
            break
    keys = ("Label", "Title", "Landscape", "Poster", "Logo", "DBID", "Action", "Day", "Time", "Episode")
    for i in range(1, CAL_MAX + 1):
        f = items[i - 1] if i <= len(items) else {}
        for k in keys:
            home_prop("MH.Cal.%d.%s" % (i, k), str(f.get(k, "")))
    home_prop("MH.Cal.Count", str(len(items)))
    home_prop("MH.Cal.Ready", "1")
    if xbmc.getCondVisibility("Window.IsActive(1121) + !Control.HasFocus(9001) + !Control.HasFocus(9000)"):
        # (the list was empty when the window opened; with nothing in it, the side menu)
        xbmc.executebuiltin("SetFocus(%d)" % (9001 if items else 9000))


class Keeper:
    def __init__(self):
        self.next = time.time() + 90  # (after start-up)

    def tick(self, monitor):
        now = time.time()
        if now < self.next:
            return
        self.next = now + 6 * 3600
        if not xbmc.getCondVisibility("Library.HasContent(TVShows)"):
            return
        mediahub.in_thread(refresh, monitor)


def handle(action, monitor):
    """calendar: the Calendar window opened - list what's known, and look again in
    the background if it's more than a day old."""
    if action == "calendar":
        publish()
        return "thread", lambda: refresh(monitor)
    return None, None
