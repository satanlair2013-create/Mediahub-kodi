"""MediaHub Helper - room-aware pause: nobody in the room, the film waits.

Skin settings > Cinema mode (Home Assistant) > "Pause when everyone leaves the room"
(MH.PresencePause), with a presence, occupancy or motion sensor (MH.HA.Presence:
binary_sensor.living_room_occupancy, or a person / device tracker). When it says
nobody's there for GRACE seconds while a video plays, the video pauses (a
notification says why); when someone's back, it carries on - unless you paused or
stopped it yourself in between. Home Assistant is asked every few seconds, in the
background, with cinema mode's address and token.
"""
import threading
import time
import urllib.error

import xbmc
import xbmcgui

import doorbell
import mediahub

POLL = 3
GRACE = 30                    # seconds of an empty room before pausing
HERE = ("on", "home", "occupied", "detected", "true")


class Presence:
    def __init__(self):
        self.next_poll = 0.0
        self.busy = False
        self.away_since = None
        self.paused = False  # this paused the film

    def config(self):
        if not xbmc.getCondVisibility("Skin.HasSetting(MH.PresencePause)"):
            return None
        base, token = doorbell.setting("MH.HA.Url").rstrip("/"), doorbell.setting("MH.HA.Token")
        entity = doorbell.setting("MH.HA.Presence")
        return (base, token, entity) if base and token and entity else None

    def tick(self):
        now = time.time()
        if now < self.next_poll or self.busy:
            return
        self.next_poll = now + POLL
        found = self.config()
        if not found or not (self.paused or xbmc.getCondVisibility("Player.HasVideo")):
            self.away_since = None
            return
        self.busy = True
        threading.Thread(target=self.poll, args=found, daemon=True).start()

    def poll(self, base, token, entity):
        try:
            try:
                state = str(doorbell.get_state(base, token, entity).get("state", "")).lower()
            except (urllib.error.HTTPError, OSError, ValueError):
                return  # (not reachable now: nothing changes)
            if state in ("unavailable", "unknown", ""):
                return
            self.seen(state in HERE)
        finally:
            self.busy = False

    def seen(self, someone):
        now = time.time()
        if someone:
            self.away_since = None
            if self.paused:
                self.paused = False
                if xbmc.getCondVisibility("Player.HasVideo + Player.Paused"):
                    mediahub.rpc("Player.PlayPause", playerid=1, play=True)
                    xbmcgui.Dialog().notification(mediahub.text(32243), mediahub.text(32245),
                                                  xbmcgui.NOTIFICATION_INFO, 3000, False)
            return
        if self.paused:
            if not xbmc.getCondVisibility("Player.HasVideo + Player.Paused"):
                self.paused = False  # (someone played or stopped it themselves)
            return
        if not xbmc.getCondVisibility("Player.HasVideo") or xbmc.getCondVisibility("Player.Paused"):
            self.away_since = None
            return
        if self.away_since is None:
            self.away_since = now
        elif now - self.away_since >= GRACE:
            self.away_since = None
            mediahub.rpc("Player.PlayPause", playerid=1, play=False)
            self.paused = True
            xbmcgui.Dialog().notification(mediahub.text(32243), mediahub.text(32244),
                                          xbmcgui.NOTIFICATION_INFO, 5000, False)
