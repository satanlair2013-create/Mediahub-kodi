"""MediaHub Helper - profile birthdays.

Skin Settings > Your birthday keeps a day and month in this profile's skin settings
(Skin.String(MH.Birthday), "MM-DD"; each Kodi profile has its own). On the day:

* Window(Home) MH.Birthday.Today is set, so the home greeting says happy birthday;
* the first time the home screen shows that day, confetti falls down it
  (MH.Confetti, for a few seconds; not with Reduce motion);
* the Birthday picks row (MH.Bday.<n>.*, above the network cards) has the
  birthday person's favourites: what they loved or gave a thumbs up, their
  My List, and what they've watched most.

A 29 February birthday is on the 28th in other years.

  MH.Req.Action birthday: set, change or remove it
"""
import time

import xbmc
import xbmcgui

import mediahub

CHECK_EVERY = 60
CONFETTI_TIME = 9


def today_key():
    return time.strftime("%m-%d")


def is_today(birthday):
    if not birthday:
        return False
    today = today_key()
    if birthday == today:
        return True
    leap = time.localtime().tm_year % 4 == 0 and (time.localtime().tm_year % 100 or time.localtime().tm_year % 400 == 0)
    return birthday == "02-29" and today == "02-28" and not leap


def picks(kids):
    """The favourites: loved and thumbs up first, then My List, then the most watched."""
    seen, found = set(), []

    def add(kind, d, rank):
        key = (kind, d[kind + "id"])
        if key in seen or (kids and not mediahub.kids_ok(d.get("mpaa"))):
            return
        seen.add(key)
        found.append((rank, mediahub.title_fields(kind, d)))

    for kind in ("movie", "tvshow"):
        props = mediahub.MOVIE_PROPS if kind == "movie" else mediahub.SHOW_PROPS
        liked = {"field": "userrating", "operator": "greaterthan", "value": "6"}
        for d in mediahub.all_items(kind, props, filter=liked):
            add(kind, d, (3, d.get("userrating") or 0))
        for d in mediahub.all_items(kind, props, filter={"field": "tag", "operator": "is", "value": mediahub.MYLIST_TAG}):
            add(kind, d, (2, 0))
        played = {"field": "playcount", "operator": "greaterthan", "value": "0"}
        most = mediahub.rpc("VideoLibrary.Get%s" % ("Movies" if kind == "movie" else "TVShows"), filter=played,
                            properties=props + (["lastplayed"] if kind == "movie" else []),
                            sort={"method": "playcount", "order": "descending"},
                            limits={"start": 0, "end": 10}).get("movies" if kind == "movie" else "tvshows") or []
        for d in most:
            add(kind, d, (1, d.get("playcount") or d.get("watchedepisodes") or 0))
    found.sort(key=lambda row: row[0], reverse=True)
    return [fields for _rank, fields in found][:mediahub.MAX_ITEMS]


def choose():
    """Skin Settings > Your birthday."""
    now = xbmc.getInfoLabel("Skin.String(MH.Birthday)")
    if now:
        pick = xbmcgui.Dialog().select(mediahub.text(32246), [mediahub.text(32247), mediahub.text(32248)])
        if pick < 0:
            return
        if pick == 1:
            xbmc.executebuiltin("Skin.Reset(MH.Birthday)")
            xbmc.executebuiltin("Skin.Reset(MH.Birthday.Shown)")
            return
    month, day = (now.split("-") + ["", ""])[:2] if now else ("", "")
    start = "%s/%s/%s" % (day, month, time.strftime("%Y")) if now else time.strftime("%d/%m/%Y")
    answer = xbmcgui.Dialog().numeric(1, mediahub.text(32246), start)
    try:
        d, m = [int(x) for x in answer.replace(" ", "").split("/")[:2]]
    except ValueError:
        return
    if not (1 <= m <= 12 and 1 <= d <= 31):
        return
    xbmc.executebuiltin("Skin.SetString(MH.Birthday,%02d-%02d)" % (m, d))
    # (the Label2 in Skin Settings: "14 March", in Kodi's language)
    xbmc.executebuiltin("Skin.SetString(MH.Birthday.Label,%d %s)" % (d, xbmc.getLocalizedString(20 + m)))
    xbmc.executebuiltin("Skin.Reset(MH.Birthday.Shown)")


class Birthday:
    def __init__(self):
        self.next = 0
        self.filled = ""       # the day (and profile) the picks were made for
        self.confetti_until = 0

    def tick(self):
        if self.confetti_until and time.time() >= self.confetti_until:
            self.confetti_until = 0
            mediahub.prop("MH.Confetti", "")
        if time.time() < self.next:
            return self.maybe_confetti()
        self.next = time.time() + CHECK_EVERY
        birthday = xbmc.getInfoLabel("Skin.String(MH.Birthday)")
        if not is_today(birthday):
            if mediahub.prop("MH.Birthday.Today"):
                mediahub.prop("MH.Birthday.Today", "")
                mediahub.fill("MH.Bday", [])
            self.filled = ""
            return
        mediahub.prop("MH.Birthday.Today", "1")
        stamp = "%s|%s|%s" % (today_key(), xbmc.getInfoLabel("System.ProfileName"), mediahub.kids_mode())
        if self.filled != stamp:
            self.filled = stamp
            mediahub.fill("MH.Bday", picks(mediahub.kids_mode()))
        self.maybe_confetti()

    def maybe_confetti(self):
        """Once on the day, the first time the home screen is up."""
        if not mediahub.prop("MH.Birthday.Today") or self.confetti_until:
            return
        shown = xbmc.getInfoLabel("Skin.String(MH.Birthday.Shown)")
        if shown == time.strftime("%Y-%m-%d") or not xbmc.getCondVisibility("Window.IsActive(home)"):
            return
        xbmc.executebuiltin("Skin.SetString(MH.Birthday.Shown,%s)" % time.strftime("%Y-%m-%d"))
        if xbmc.getCondVisibility("Skin.HasSetting(MH.ReduceMotion)"):
            return
        mediahub.prop("MH.Confetti", "1")
        self.confetti_until = time.time() + CONFETTI_TIME


def handle(action):
    if action == "birthday":
        return "thread", choose
    return None, None
