"""MediaHub Helper - "New since you were last here".

The service notes when you last used Kodi (whatsnew.json: the last time a button
was pressed, saved every few minutes and when Kodi closes). When you come back
after a while - Kodi started again, or picked up after six hours or more without
a button - the movies and episodes added to the library since then are counted,
and Home shows a banner (MH.WhatsNew.*) whose buttons open them.
"""
import json
import os
import time
import urllib.parse

import xbmc
import xbmcvfs

import mediahub

FILE = "special://profile/addon_data/script.mediahub.helper/whatsnew.json"
AWAY = 6 * 3600  # this long without a button is "a while"
SAVE_EVERY = 300
EVERY = 30
IDLE = 120  # a button pressed in the last 2 minutes = in use


def load():
    try:
        with open(xbmcvfs.translatePath(FILE)) as f:
            return float(json.load(f).get("active") or 0)
    except (OSError, ValueError, AttributeError):
        return 0.0


def save(active):
    path = xbmcvfs.translatePath(FILE)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path + ".tmp", "w") as f:
            json.dump({"active": active}, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def xsp_path(base, kind, since):
    spec = json.dumps({"rules": {"and": [{"field": "dateadded", "operator": "after", "value": [since]}]},
                       "type": kind, "order": {"direction": "descending", "method": "dateadded"}},
                      separators=(",", ":"))
    return base + "?xsp=" + urllib.parse.quote(spec, safe="")


def count(method, since):
    reply = mediahub.rpc(method, properties=[], limits={"start": 0, "end": 1},
                         filter={"field": "dateadded", "operator": "after", "value": since})
    return int((reply.get("limits") or {}).get("total") or 0)


def clear():
    for key in ("", ".Movies", ".Episodes", ".MoviesPath", ".EpisodesPath", ".Since"):
        mediahub.prop("MH.WhatsNew" + key, "")


def show(since_ts):
    """Count what was added since then; set the banner if there's anything."""
    if mediahub.kids_mode():
        return
    since = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(since_ts))
    movies = count("VideoLibrary.GetMovies", since)
    episodes = count("VideoLibrary.GetEpisodes", since)
    clear()
    if not movies and not episodes:
        return
    mediahub.prop("MH.WhatsNew.Movies", str(movies) if movies else "")
    mediahub.prop("MH.WhatsNew.Episodes", str(episodes) if episodes else "")
    mediahub.prop("MH.WhatsNew.MoviesPath", xsp_path("videodb://movies/titles/", "movies", since))
    mediahub.prop("MH.WhatsNew.EpisodesPath", xsp_path("videodb://tvshows/titles/-1/-1/", "episodes", since))
    mediahub.prop("MH.WhatsNew.Since", mediahub.when(time.strftime("%Y-%m-%d", time.localtime(since_ts)))
                  if time.time() - since_ts < 6 * 86400 else "")
    mediahub.prop("MH.WhatsNew", "1")
    xbmc.log("MediaHub Helper: new since %s: %d movies, %d episodes" % (since, movies, episodes), xbmc.LOGINFO)


class Watcher:
    def __init__(self):
        self.last = load()  # the last time Kodi was in use
        self.saved = self.last
        self.next = 0.0
        self.started = False

    def tick(self):
        now = time.time()
        if now < self.next:
            return
        self.next = now + EVERY
        if not self.started:  # Kodi just started: new since the last session?
            self.started = True
            if self.last and now - self.last > 60:
                show(self.last)
        if xbmc.getCondVisibility("System.IdleTime(%d)" % IDLE):
            return  # (not in use)
        if self.last and now - self.last > AWAY:  # back after a while
            show(self.last)
        self.last = now
        if now - self.saved > SAVE_EVERY:
            save(now)
            self.saved = now

    def stop(self):
        save(self.last or time.time())
