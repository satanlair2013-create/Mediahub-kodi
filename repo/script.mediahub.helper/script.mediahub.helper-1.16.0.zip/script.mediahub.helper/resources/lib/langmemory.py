"""MediaHub Helper - each show remembers its languages.

When you change the audio language or the subtitles while watching an episode
(with the Audio & Subtitles panel or Kodi's own), the choice is kept for that
show (langmemory.json): its next episodes start with the same audio language
and the same subtitles (or none). Only a change you make is kept, never what an
episode started with, so a show you never touch goes on following Kodi's own
language settings. Skin Settings can turn it off.
"""
import json
import os
import time

import xbmc
import xbmcvfs

import mediahub

FILE = "special://profile/addon_data/script.mediahub.helper/langmemory.json"
SETTLE = 4.0  # seconds into an episode before its streams are looked at
EVERY = 2.0
KEEP = 300


def load():
    try:
        with open(xbmcvfs.translatePath(FILE)) as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save(data):
    if len(data) > KEEP:
        data = dict(sorted(data.items(), key=lambda kv: kv[1].get("t", 0))[-KEEP:])
    path = xbmcvfs.translatePath(FILE)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path + ".tmp", "w") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def streams():
    return mediahub.rpc("Player.GetProperties", playerid=1, properties=[
        "audiostreams", "subtitles", "currentaudiostream", "currentsubtitle", "subtitleenabled", "time"])


def seconds(p):
    t = p.get("time") or {}
    return t.get("hours", 0) * 3600 + t.get("minutes", 0) * 60 + t.get("seconds", 0)


def state(p):
    """(audio language, subtitle language or "", subtitles on) of what's playing."""
    audio = (p.get("currentaudiostream") or {}).get("language", "")
    sub = (p.get("currentsubtitle") or {}).get("language", "") if p.get("subtitleenabled") else ""
    return audio, sub, bool(p.get("subtitleenabled"))


def apply(choice, p):
    """Switch to the remembered audio language and subtitles, where the episode has
    them. True if anything had to change."""
    audio_lang, sub_lang, sub_on = choice.get("audio", ""), choice.get("sub", ""), choice.get("subon", False)
    changed = False
    current = p.get("currentaudiostream") or {}
    if audio_lang and current.get("language") != audio_lang:
        match = next((a for a in p.get("audiostreams") or [] if a.get("language") == audio_lang), None)
        if match:
            mediahub.rpc("Player.SetAudioStream", playerid=1, stream=match["index"])
            changed = True
    if not sub_on:
        if p.get("subtitleenabled"):
            mediahub.rpc("Player.SetSubtitle", playerid=1, subtitle="off")
            changed = True
        return changed
    subs = p.get("subtitles") or []
    # (the same language; a full track before a "forced" one)
    candidates = [s for s in subs if s.get("language") == sub_lang]
    candidates.sort(key=lambda s: bool(s.get("isforced")))
    current = p.get("currentsubtitle") or {}
    if candidates and not (p.get("subtitleenabled") and current.get("language") == sub_lang):
        mediahub.rpc("Player.SetSubtitle", playerid=1, subtitle=candidates[0]["index"], enable=True)
        changed = True
    return changed


class Memory:
    def __init__(self):
        self.next = 0.0
        self.path = None
        self.show = ""
        self.started = 0.0
        self.baseline = None  # the languages after we (or Kodi) set them up
        self.tries = 0

    def tick(self):
        now = time.time()
        if now < self.next:
            return
        self.next = now + EVERY
        if not xbmc.getCondVisibility("Player.HasVideo") or \
                xbmc.getCondVisibility("Skin.HasSetting(MH.NoLangMemory) | VideoPlayer.Content(livetv)"):
            self.path = None
            return
        path = xbmc.getInfoLabel("Player.Filenameandpath")
        if path != self.path:
            self.path, self.show = path, xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
            self.started, self.baseline, self.tries = now, None, 0
        if not self.show or now - self.started < SETTLE:
            return
        p = streams()
        if not p:
            return
        # (just after the switch to the next episode Kodi can still report the last
        # one's streams: go by the player's clock having started over; and it can
        # still set up its own choice in the first seconds, hence the second look)
        if self.baseline is None and not 1 <= seconds(p) <= now - self.started + 3:
            return
        if self.baseline is None:
            choice = load().get(self.show)
            # (switch, then look again next time: only once it has stuck, or we've
            # tried three times, is this the episode's starting point)
            if choice and self.tries < 3 and apply(choice, p):
                self.tries += 1
                return
            self.baseline = state(p)
            return
        now_state = state(p)
        if now_state != self.baseline:  # you changed something: remember it for the show
            self.baseline = now_state
            data = load()
            data[self.show] = {"audio": now_state[0], "sub": now_state[1], "subon": now_state[2], "t": now}
            save(data)
