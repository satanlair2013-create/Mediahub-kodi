"""MediaHub Helper - notices when Kodi closed unexpectedly, and offers Safe mode.

While Kodi runs, the service keeps a small note of where you are (running.json:
the screen, the focused control and item, and whether a trailer preview or a
video was playing - the last few places, rewritten when they change). When Kodi
closes normally, or this add-on is stopped for an update, the note is removed.

If the note is still there when Kodi starts again, Kodi closed on its own (a
crash, or Apple TV closing it for using too much memory). The places (with the
window, view and memory in use at each) and the last lines of the log of the
session that closed are written to the log. If you were moving around the menus
(not watching something), MediaHub says where it happened and offers Safe mode:
trailer previews and moving effects off - Skin Settings has them all, to turn
back on one at a time.
The skin shows that (window 1120); this only sets what it says.
"""
import json
import os
import re
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import mediahub

NOTE = "special://profile/addon_data/script.mediahub.helper/running.json"
EVERY = 2.0  # seconds between looks
HISTORY = 6  # places kept
ACTIVE_WITHIN = 30  # a remote button this recently = you were using the menus
STARTUP, WELCOME = 12999, 1119
COPIED = "before the close"  # marks the lines copied from kodi.old.log
ROW_LISTS = range(9301, 9337)  # the home row lists: 12 positions x 3 (gen_rows.py LIST_BASE)


def note_path():
    return xbmcvfs.translatePath(NOTE)


def read_note():
    try:
        with open(note_path()) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def write_note(data):
    path = note_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path + ".tmp", "w") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def remove_note():
    try:
        os.remove(note_path())
    except OSError:
        pass


def place():
    """Where the user is now, as a short readable path."""
    parts = [xbmc.getInfoLabel("System.CurrentWindow")]
    control = xbmc.getInfoLabel("System.CurrentControl")
    control_id = xbmc.getInfoLabel("System.CurrentControlID")
    if control_id.isdigit() and int(control_id) in ROW_LISTS:  # a home row: say which
        row = (int(control_id) - ROW_LISTS[0]) // 3 + 1  # three lists per row position
        parts.append("row %d (%s)" % (row, mediahub.prop("MH.RowKey.%d" % row) or "?"))
    item = xbmc.getInfoLabel("ListItem.Label")
    for part in (control, item):
        if part and part not in parts:
            parts.append(part)
    return " > ".join(p for p in parts if p)


def details():
    """More about where you are, for the log only: window and control ids, the view,
    how many items it has, and how much memory is in use (Apple TV closes an app
    that uses too much)."""
    return "window %s/%s, control %s, view %s, %s items, memory %s used, %s free" % (
        xbmcgui.getCurrentWindowId(), xbmcgui.getCurrentWindowDialogId(),
        xbmc.getInfoLabel("System.CurrentControlID") or "-",
        xbmc.getInfoLabel("Container.Viewmode") or "-", xbmc.getInfoLabel("Container.NumItems") or "-",
        xbmc.getInfoLabel("System.Memory(used.percent)") or "?", xbmc.getInfoLabel("System.FreeMemory") or "?")


def old_log_tail(lines=150, max_bytes=65536):
    """The last lines of kodi.old.log - the log of the session that closed (Kodi starts
    a new kodi.log each time, and the one before that is gone after one more start)."""
    path = xbmcvfs.translatePath("special://logpath/kodi.old.log")
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - max_bytes))
            data = f.read().decode("utf-8", "replace")
    except OSError:
        return []
    tail = data.splitlines()[1:] if size > max_bytes else data.splitlines()  # (the first may be cut)
    tail = [line for line in tail if line.strip() and COPIED not in line]  # (not what we copied last time)
    return [line if len(line) <= 400 else line[:400] + " ..." for line in tail][-lines:]


def short_place():
    """The same, just the screen and the title, for the dialog."""
    item = xbmc.getInfoLabel("ListItem.Label")
    window = xbmc.getInfoLabel("System.CurrentWindow")
    return "%s, %s" % (window, item) if item and item != window else window


def safe_mode_on():
    return xbmc.getInfoLabel("Skin.String(MH.RowPreviews)") == "off" and \
        xbmc.getCondVisibility("Skin.HasSetting(MH.NoHeroPreview) + Skin.HasSetting(MH.ReduceMotion)")


def turn_on_safe_mode():
    xbmc.executebuiltin("Skin.SetString(MH.RowPreviews,off)")
    xbmc.executebuiltin("Skin.SetBool(MH.NoHeroPreview)")
    xbmc.executebuiltin("Skin.SetBool(MH.ReduceMotion)")


def menus_ready():
    return xbmc.getCondVisibility("Window.IsActive(home) + !System.HasModalDialog + !Window.IsVisible(%d) + "
                                  "!Window.IsVisible(%d)" % (STARTUP, WELCOME))


def skin_has_window():
    """MediaHub 1.9.1 and newer have the "Kodi closed unexpectedly" window (1120)."""
    if xbmc.getSkinDir() != "skin.mediahub":
        return False
    try:
        version = xbmcaddon.Addon("skin.mediahub").getAddonInfo("version")
    except RuntimeError:
        return False
    return tuple(int(p) for p in re.findall(r"\d+", version)[:3]) >= (1, 9, 1)


def offer(where, monitor):
    """After an unexpected close: say where, and offer Safe mode (in its own thread).

    Never a dialog from here: a helper thread waiting in a Kodi dialog can't end when
    Kodi stops the helper (to update it, say - likely just after start-up), and after
    5 seconds Kodi kills the helper, which can crash Kodi. The skin's window 1120 shows
    it instead, and its Safe mode button sends MH.Req.Action = safemode."""
    for _ in range(240):  # wait for the home screen (after the intro), up to 2 minutes
        if monitor.waitForAbort(0.5):
            return
        if menus_ready():
            break
    else:
        return
    if monitor.waitForAbort(1.5):
        return
    message = mediahub.text(32122) % where
    if not skin_has_window():
        xbmcgui.Dialog().notification(mediahub.text(32121), message, xbmcgui.NOTIFICATION_WARNING, 8000, False)
        return
    safe = safe_mode_on()
    mediahub.prop("MH.Crash.Safe", "1" if safe else "")
    mediahub.prop("MH.Crash.Text", message + "[CR]" + mediahub.text(32126 if safe else 32123))


def safe_mode():
    """The Safe mode button (MH.Req.Action = safemode)."""
    turn_on_safe_mode()
    xbmcgui.Dialog().notification("MediaHub", mediahub.text(32127), xbmcgui.NOTIFICATION_INFO, 4000, False)


class Guard:
    def __init__(self):
        self.next_look = 0.0
        self.history = []

    def start(self, monitor):
        """At start-up: did Kodi close on its own last time?"""
        last = read_note()
        remove_note()
        if not last:
            return
        places = last.get("history") or []
        xbmc.log("MediaHub Helper: Kodi closed unexpectedly last time. Last places (newest last): %s"
                 % " | ".join("%s%s%s" % (p.get("where", "?"), " [preview]" if p.get("preview") else "",
                                          " [video]" if p.get("video") else "") for p in places), xbmc.LOGWARNING)
        for p in places:
            if p.get("details"):
                xbmc.log("MediaHub Helper:   %s - %s" % (p.get("where", "?"), p["details"]), xbmc.LOGWARNING)
        # the last lines Kodi wrote before it closed, into this session's log, so a log
        # uploaded now shows them (the crashed session's own log is gone after one more start)
        for line in old_log_tail():
            xbmc.log("MediaHub Helper: %s | %s" % (COPIED, line), xbmc.LOGWARNING)
        latest = places[-1] if places else {}
        if latest and latest.get("active") and not latest.get("video") and time.time() - last.get("time", 0) < 7 * 86400:
            where = latest.get("short") or latest.get("where") or "?"
            if latest.get("preview"):
                where = mediahub.text(32128) % where
            mediahub.in_thread(offer, where, monitor)

    def tick(self):
        now = time.time()
        if now < self.next_look:
            return
        self.next_look = now + EVERY
        where, short = place(), short_place()
        if not where and self.history:  # (Kodi's busy spinner, e.g. while a trailer opens, has no name)
            where, short = self.history[-1]["where"], self.history[-1]["short"]
        state = {"where": where, "short": short, "preview": mediahub.prop("MH.Preview"),
                 "video": xbmc.getCondVisibility("Player.HasVideo + Window.IsActive(fullscreenvideo)"),
                 "active": not xbmc.getCondVisibility("System.IdleTime(%d)" % ACTIVE_WITHIN)}
        if self.history and {k: v for k, v in self.history[-1].items() if k != "details"} == state:
            return
        state["details"] = details()
        self.history = (self.history + [state])[-HISTORY:]
        write_note({"time": now, "history": self.history})

    def stop(self):
        """Kodi is closing normally (or this add-on is being updated or turned off)."""
        remove_note()
