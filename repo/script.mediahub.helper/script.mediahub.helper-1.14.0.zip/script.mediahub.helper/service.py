"""MediaHub Helper - background service.

The one place the add-on's Python runs: the skin sets request properties on
Window(Home) and this loop answers them (see resources/lib/mediahub.py). Keeping
it all in one long-running script means the skin never starts several add-on
scripts at once, which Kodi builds on Python 3.12 can crash on.
"""
import os
import re
import sys
import time

import xbmc
import xbmcgui

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import crashguard  # noqa: E402
import details  # noqa: E402
import family  # noqa: E402
import finding  # noqa: E402
import intro  # noqa: E402
import mediahub  # noqa: E402
import ondemand  # noqa: E402
import channels  # noqa: E402
import lite  # noqa: E402
import upcoming  # noqa: E402
import whatsnew  # noqa: E402
import focusnote  # noqa: E402
import health  # noqa: E402
import odprogress  # noqa: E402
import xtreamrows  # noqa: E402
import audiorows  # noqa: E402
import cinema  # noqa: E402
import doorbell  # noqa: E402
import quiz  # noqa: E402
import themes  # noqa: E402
import trailernight  # noqa: E402
import odart  # noqa: E402
import cache  # noqa: E402
import langmemory  # noqa: E402
import weather  # noqa: E402
import personal  # noqa: E402
import previews  # noqa: E402
import recent  # noqa: E402
import screensaver  # noqa: E402
import streams  # noqa: E402
import watching  # noqa: E402
import updates  # noqa: E402

REFRESH_ON = ("VideoLibrary.OnUpdate", "VideoLibrary.OnScanFinished", "VideoLibrary.OnRemove",
              "VideoLibrary.OnCleanFinished", "Player.OnStop")


class Service(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.rows_due = False
        # first update check a minute after start-up, then every few hours
        self.next_update_check = time.time() + 60
        self.next_finish_check = time.time() + 5  # an update started before a restart
        self.next_splash_check = time.time() + 10  # after the intro
        self.screensaver = screensaver.Screensaver()
        self.previews = previews.Previews()
        self.watching = watching.Watching()
        self.bedtime = family.Bedtime()
        self.screentime = family.ScreenTime()
        self.people = finding.People()
        self.downloads = personal.Downloads()
        self.stopped = None
        self.guard = crashguard.Guard()
        self.ondemand = ondemand.Keeper()
        self.channels = channels.Keeper()
        self.history = channels.History()
        self.lite = lite.Watcher()
        self.upcoming = upcoming.Keeper()
        self.whatsnew = whatsnew.Watcher()
        self.focusnote = focusnote.FocusNote()
        self.odprogress = odprogress.Tracker()
        self.xtream = xtreamrows.Watcher()
        self.audio = audiorows.Watcher()
        self.cinema = cinema.Cinema()
        self.quiz = quiz.Quiz()
        self.trailernight = trailernight.TrailerNight()
        self.doorbell = doorbell.Doorbell()
        self.themes = themes.ThemeMusic()
        self.odart = odart.Fetcher()
        self.langmemory = langmemory.Memory()
        self.weather = weather.Weather()

    def onNotification(self, sender, method, data):
        if method in REFRESH_ON:
            self.rows_due = True
        if method == "Player.OnStop":
            self.stopped = data  # handled in the loop

    def take(self, name):
        home = xbmcgui.Window(10000)
        value = home.getProperty(name)
        if value:
            home.clearProperty(name)
        return value

    def run(self):
        mediahub.prop("MH.HelperRunning", "1")
        mediahub.in_thread(intro.play, self)
        personal.show_avatar()
        watching.restore_sound_mode()
        previews.restore_mute()
        self.guard.start(self)
        ondemand.status()
        channels.ids()
        while not self.waitForAbort(0.1):
            try:
                action = self.take("MH.Req.Action")
                if action == "update":
                    mediahub.in_thread(updates.update, self)
                elif action == "checkupdates":
                    mediahub.in_thread(updates.check, True, True)
                elif action.startswith("stillwatching|"):
                    self.watching.still_watching(action.partition("|")[2])
                elif action == "safemode":
                    crashguard.safe_mode()
                elif action.startswith("screensaver|"):
                    screensaver.set_kodi_screensaver(action.endswith("|on"))
                elif lite.handle(action):
                    self.rows_due = True
                elif action == "weatheruse":
                    mediahub.in_thread(weather.use_mediahub_weather)
                elif action == "cinematest":
                    mediahub.in_thread(cinema.test)
                elif action in ("quiz", "quizstart", "quizclose", "match", "matchplay", "matchmore"):
                    how, work = quiz.handle(action, self.quiz)
                    mediahub.in_thread(work) if how == "thread" else work()
                elif action in ("trailernight", "tnwatch", "tnnext", "tnprev", "tnlist", "tnclose"):
                    how, work = trailernight.handle(action, self.trailernight)
                    mediahub.in_thread(work) if how == "thread" else work()
                elif action in ("doortest", "doorresume", "doorclosed"):
                    how, work = doorbell.handle(action, self.doorbell)
                    mediahub.in_thread(work) if how == "thread" else work()
                elif action == "needyoutube":
                    mediahub.in_thread(xtreamrows.offer_youtube)
                elif xtreamrows.handle(action) or audiorows.handle(action) or channels.handle(action) or \
                        odprogress.handle(action):
                    pass
                elif action:
                    kind, work = watching.handle(action)
                    if kind is None:
                        kind, work = finding.handle(action)
                    if kind is None:
                        kind, work = personal.handle(action)
                    if kind is None:
                        kind, work = details.handle(action)
                    if kind is None:
                        kind, work = family.handle(action, self.bedtime, self.screentime)
                    if kind is None:
                        kind, work = ondemand.handle(action, self)
                    if kind is None:
                        kind, work = upcoming.handle(action, self)
                    if kind is None:
                        kind, work = health.handle(action, self)
                    if kind is None:
                        kind, work = cache.handle(action, self)
                    if kind is None:
                        kind, work = self.weather.handle(action, self)
                    if kind == "thread":
                        mediahub.in_thread(work)
                    elif kind is None and not streams.handle(action, self) and mediahub.do_action(action):
                        self.rows_due = True
                if time.time() >= self.next_update_check:
                    self.next_update_check = time.time() + updates.CHECK_EVERY
                    mediahub.in_thread(updates.check)
                if time.time() >= self.next_splash_check:
                    self.next_splash_check = time.time() + 60
                    intro.sync_splash()
                if time.time() >= self.next_finish_check:
                    self.next_finish_check = time.time() + 5
                    updates.finish_update()
                if self.take("MH.Req.Streams"):
                    streams.refresh(focus=True)
                similar = self.take("MH.Req.Similar")
                if similar:
                    mediahub.refresh_similar(similar)
                    details.refresh(similar)
                    family.refresh(similar)
                # a set id, or a collection folder's path (videodb://movies/sets/<id>/...)
                movieset = re.search(r"(?:^|sets/)(\d+)", self.take("MH.Req.Set"))
                if movieset:
                    mediahub.refresh_set(int(movieset.group(1)))
                show = self.take("MH.Req.Show")
                if show.isdigit():
                    mediahub.refresh_show(show)
                self.screensaver.tick(mediahub.kids_ok, mediahub.kids_mode)
                self.previews.tick()
                self.guard.tick()
                self.ondemand.tick(self)
                self.channels.tick()
                self.history.tick()
                self.lite.tick()
                self.upcoming.tick(self)
                self.whatsnew.tick()
                self.focusnote.tick()
                self.odprogress.tick()
                self.odart.tick(self)
                self.langmemory.tick()
                self.weather.tick(self)
                self.themes.tick()
                self.watching.tick()
                self.cinema.tick()
                self.quiz.tick()
                self.trailernight.tick()
                self.doorbell.tick()
                self.bedtime.tick(mediahub.kids_mode)
                self.screentime.tick(mediahub.kids_mode)
                if self.stopped is not None:
                    data, self.stopped = self.stopped, None
                    movie = self.watching.on_stop(data)
                    if movie:
                        mediahub.in_thread(mediahub.post_play, movie)
                self.people.tick()
                self.downloads.tick()
                if recent.RECENT.due():
                    self.rows_due = True  # a new day: the NEW badges move on
                if self.xtream.tick():
                    self.rows_due = True  # (MediaHub IPTV wrote new cards)
                if self.audio.tick():
                    self.rows_due = True  # (MediaHub Radio or Podcasts did)
                if self.take("MH.Req.Rows") or self.rows_due:
                    self.rows_due = False
                    mediahub.refresh_rows()
            except Exception as exc:  # keep serving whatever one request did
                xbmc.log("MediaHub Helper: %r" % exc, xbmc.LOGERROR)
        mediahub.release_workers()
        self.screensaver.stop()
        self.previews.stop(exiting=True)
        self.guard.stop()
        self.whatsnew.stop()
        self.odprogress.finish()
        mediahub.prop("MH.HelperRunning", "")


if __name__ == "__main__":
    Service().run()
