"""MediaHub Helper - Library health (Custom_1122_Health.xml): what in the library
needs a look.

- Missing artwork: movies and TV shows without a poster or a backdrop.
- Duplicates: the same movie in the library twice (same IMDb / TMDB id, or the
  same title and year) - often two copies of a file.
- Not identified: movies and shows the scraper didn't recognise (no plot and no
  artwork), usually a file name it couldn't make sense of.
- What's missing (whatsmissing.py, when asked): episodes that have been on TV but
  aren't in the library, and the films of a collection you have part of.

The page lists them (MH.Health.<n>.*) with the counts (MH.Health.*). Its buttons
look for missing artwork again (Kodi refreshes those items from the scraper) and
clean the library (Kodi removes what's no longer on disk).
"""
import re

import xbmcgui

import mediahub

LIST_MAX = 60
REFRESH_MAX = 50  # items refreshed per "Look for missing artwork"
MOVIE = ["title", "year", "art", "plot", "uniqueid", "file"]
SHOW = ["title", "year", "art", "plot"]
FIELDS = ("Label", "Label2", "Poster", "Action", "Kind")


def key(title):
    return re.sub(r"[^a-z0-9]+", "", (title or "").lower())


def scan():
    movies = mediahub.all_items("movie", MOVIE)
    shows = mediahub.all_items("tvshow", SHOW)
    missing, unknown, dupes = [], [], []

    def entry(kind, d, reason):
        art = d.get("art") or {}
        return {"Label": "%s%s" % (d.get("title", ""), " (%s)" % d["year"] if d.get("year") else ""),
                "Label2": reason, "Poster": art.get("poster") or art.get("thumb") or "",
                "Action": "info|%s|%d" % (kind, d[kind + "id"]), "Kind": kind, "id": d[kind + "id"]}

    for kind, items in (("movie", movies), ("tvshow", shows)):
        for d in items:
            art = d.get("art") or {}
            if not d.get("plot") and not art.get("poster") and not art.get("fanart"):
                unknown.append(entry(kind, d, mediahub.text(32155)))
            elif not art.get("poster") or not art.get("fanart"):
                gone = [mediahub.text(32157) if not art.get("poster") else "",
                        mediahub.text(32158) if not art.get("fanart") else ""]
                missing.append(entry(kind, d, mediahub.text(32156) % " + ".join(g for g in gone if g)))
    seen = {}
    for d in movies:
        ids = d.get("uniqueid") or {}
        marks = ["id:%s" % v for k, v in ids.items() if k in ("imdb", "tmdb") and v]
        marks.append("t:%s:%s" % (key(d.get("title")), d.get("year") or ""))
        first = next((seen[m] for m in marks if m in seen), None)
        if first is not None:
            name = first.get("file", "").replace("\\", "/").rstrip("/").rsplit("/", 1)[-1]
            dupes.append(entry("movie", d, mediahub.text(32159) % name))
        for m in marks:
            seen.setdefault(m, d)
    return missing, dupes, unknown


def publish():
    import whatsmissing
    missing, dupes, unknown = scan()
    gaps, _, _ = whatsmissing.gaps()
    items = (gaps + dupes + unknown + missing)[:LIST_MAX]
    home = xbmcgui.Window(10000)
    for i in range(1, LIST_MAX + 1):
        f = items[i - 1] if i <= len(items) else {}
        for k in FIELDS:
            home.setProperty("MH.Health.%d.%s" % (i, k), str(f.get(k, "")))
    home.setProperty("MH.Health.Missing", str(len(missing)))
    home.setProperty("MH.Health.Duplicates", str(len(dupes)))
    home.setProperty("MH.Health.Unknown", str(len(unknown)))
    home.setProperty("MH.Health.Gaps", str(sum(g.get("n", 1) for g in gaps)))
    home.setProperty("MH.Health.Count", str(len(items)))
    home.setProperty("MH.Health.Ready", "1")
    return missing


def refresh_art(monitor):
    """Ask Kodi to look the items without artwork up again (from the scraper)."""
    missing, _, _ = scan()
    todo = missing[:REFRESH_MAX]
    if not todo:
        return
    bar = xbmcgui.DialogProgressBG()
    bar.create("MediaHub", mediahub.text(32160))
    try:
        for n, e in enumerate(todo):
            if monitor.abortRequested():
                break
            bar.update(int(100 * n / len(todo)), "MediaHub", e["Label"])
            method = "VideoLibrary.RefreshMovie" if e["Kind"] == "movie" else "VideoLibrary.RefreshTVShow"
            params = {"movieid": e["id"]} if e["Kind"] == "movie" else {"tvshowid": e["id"]}
            mediahub.rpc(method, ignorenfo=False, **params)
            monitor.waitForAbort(1.0)
    finally:
        bar.close()
    publish()


def handle(action, monitor):
    """health (the page opened), healthart, healthmissing, healthclean."""
    if action == "health":
        mediahub.prop("MH.Health.Ready", "")
        return "thread", publish
    if action == "healthart":
        return "thread", lambda: refresh_art(monitor)
    if action == "healthmissing":
        def look():
            import whatsmissing
            whatsmissing.check(monitor)
            publish()
        return "thread", look
    if action == "healthclean":
        def clean():
            mediahub.rpc("VideoLibrary.Clean", showdialogs=True)
            monitor.waitForAbort(3)
            publish()
        return "thread", clean
    return None, None
