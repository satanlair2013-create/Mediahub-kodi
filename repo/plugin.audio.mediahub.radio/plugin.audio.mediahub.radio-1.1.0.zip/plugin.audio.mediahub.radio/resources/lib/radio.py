"""MediaHub Radio - radio-browser.info and what's kept between visits.

radio-browser.info is a free, community-run list of internet radio stations
(no account or key). Its servers are looked up from all.api.radio-browser.info
and one is picked at random, as the service asks; if it doesn't answer the next
one is tried. Lists are kept on disk for a while (station lists for an hour,
countries, genres and languages for a day), so pages open at once.

Kept in the add-on's data folder:
- favourites.json: your stations, in the order you added them
- recent.json: the stations you played last (newest first)
- home.json: ready-made cards for MediaHub's home rows (the MediaHub Helper reads it)
"""
import gzip
import hashlib
import json
import os
import random
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.audio.mediahub.radio"
CERTS = "special://xbmc/system/certs/cacert.pem"
# (a test server can stand in)
FIXED_API = os.environ.get("MEDIAHUB_RADIO_API", "").rstrip("/")
DIRECTORY = "https://all.api.radio-browser.info/json/servers"
FALLBACK = ("de1.api.radio-browser.info", "fi1.api.radio-browser.info", "de2.api.radio-browser.info")
RECENT = 30
HOME_CARDS = 20
LIST_AGE = 3600
NAMES_AGE = 24 * 3600


class Error(Exception):
    pass


def profile(name=""):
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)


def load_json(name, default):
    try:
        with open(profile(name), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(name, data):
    path = profile(name)
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def ssl_context():
    certs = xbmcvfs.translatePath(CERTS)
    try:
        return ssl.create_default_context(cafile=certs) if os.path.exists(certs) else ssl.create_default_context()
    except (OSError, ssl.SSLError):
        return ssl.create_default_context()


def fetch(url, timeout=10):
    agent = "MediaHubRadio/%s" % xbmcaddon.Addon(ADDON_ID).getAddonInfo("version")
    request = urllib.request.Request(url, headers={"User-Agent": agent, "Accept-Encoding": "gzip"})
    try:
        with urllib.request.urlopen(request, timeout=timeout, context=ssl_context()) as reply:
            body = reply.read()
            if (reply.headers.get("Content-Encoding") or "").lower() == "gzip" or body[:2] == b"\x1f\x8b":
                body = gzip.decompress(body)
        return json.loads(body.decode("utf-8", "replace") or "null")
    except urllib.error.HTTPError as exc:
        raise Error("HTTP %d" % exc.code)
    except (OSError, ValueError, ssl.SSLError) as exc:
        raise Error(repr(exc))


def servers():
    """The API servers to try, a random one first (kept for a day)."""
    if FIXED_API:
        return [FIXED_API]
    known = load_json("servers.json", {})
    names = known.get("names") if time.time() - known.get("t", 0) < NAMES_AGE else None
    if not names:
        try:
            names = sorted({s["name"] for s in fetch(DIRECTORY, timeout=6) or [] if s.get("name")})
        except (Error, TypeError, KeyError):
            names = []
        if names:
            save_json("servers.json", {"names": names, "t": time.time()})
    names = list(names or FALLBACK)
    random.shuffle(names)
    return ["https://" + n for n in names]


def api(path, max_age=LIST_AGE, **params):
    """GET /json/<path> from a radio-browser server (the answer kept max_age seconds)."""
    query = urllib.parse.urlencode(sorted(params.items()))
    key = hashlib.sha1(("%s?%s" % (path, query)).encode()).hexdigest()[:16]
    cache = os.path.join(profile("cache"), key + ".json")
    if max_age:
        try:
            if time.time() - os.path.getmtime(cache) < max_age:
                with open(cache, encoding="utf-8") as f:
                    return json.load(f)
        except (OSError, ValueError):
            pass
    last = None
    for base in servers()[:3]:
        try:
            data = fetch("%s/json/%s%s" % (base, path, "?" + query if query else ""))
            break
        except Error as exc:
            last = exc
    else:
        raise last or Error("no server")
    if max_age:
        os.makedirs(os.path.dirname(cache), exist_ok=True)
        try:
            with open(cache, "w", encoding="utf-8") as f:
                json.dump(data, f)
        except OSError:
            pass
    return data


def station(s):
    """A radio-browser station as the add-on keeps it."""
    tags = [t.strip() for t in (s.get("tags") or "").split(",") if t.strip()]
    return {"id": s.get("stationuuid") or "", "name": (s.get("name") or "").strip(),
            "url": s.get("url_resolved") or s.get("url") or "", "icon": s.get("favicon") or "",
            "tags": tags[:6], "country": s.get("country") or "", "cc": s.get("countrycode") or "",
            "language": s.get("language") or "", "codec": s.get("codec") or "",
            "bitrate": int(s.get("bitrate") or 0), "votes": int(s.get("votes") or 0),
            "homepage": s.get("homepage") or ""}


def stations(path, max_age=LIST_AGE, **params):
    params.setdefault("hidebroken", "true")
    found = []
    for s in api(path, max_age, **params) or []:
        if isinstance(s, dict) and s.get("stationuuid") and (s.get("url_resolved") or s.get("url")):
            found.append(station(s))
    return found


def listen(station_id):
    """Tell radio-browser a station is being played (its popularity lists count
    these), and get its current address."""
    try:
        reply = api("url/" + urllib.parse.quote(station_id), max_age=0)
        return reply.get("url") if isinstance(reply, dict) and reply.get("ok") in (True, "true") else None
    except Error:
        return None


# --------------------------------------------------------------------------- your stations

def favourites():
    return [s for s in load_json("favourites.json", []) if isinstance(s, dict) and s.get("id")]


def is_favourite(station_id):
    return any(s["id"] == station_id for s in favourites())


def set_favourite(s, on):
    found = [f for f in favourites() if f["id"] != s["id"]]
    if on:
        found.append(s)
    save_json("favourites.json", found)
    write_home()


def move_favourite(station_id, step):
    found = favourites()
    at = next((n for n, s in enumerate(found) if s["id"] == station_id), None)
    if at is None or not 0 <= at + step < len(found):
        return
    found[at], found[at + step] = found[at + step], found[at]
    save_json("favourites.json", found)
    write_home()


def recent():
    return [s for s in load_json("recent.json", []) if isinstance(s, dict) and s.get("id")]


def note_played(s):
    save_json("recent.json", ([s] + [r for r in recent() if r["id"] != s["id"]])[:RECENT])
    write_home()


def clear_recent():
    save_json("recent.json", [])
    write_home()


def describe(s):
    """"Jazz, Smooth • United Kingdom • 128 kbps MP3"."""
    quality = ("%d kbps %s" % (s["bitrate"], s["codec"]) if s.get("bitrate") else s.get("codec", "")).strip()
    return "  •  ".join(p for p in (", ".join(t.title() for t in s.get("tags", [])[:2]), s.get("country", ""),
                                     quality) if p)


def play_address(s):
    return "plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode(
        {"mode": "play", "id": s["id"], "name": s["name"], "url": s["url"], "icon": s.get("icon", ""),
         "extra": json.dumps({k: s.get(k) for k in ("tags", "country", "cc", "codec", "bitrate", "language")})}))


def write_home():
    """home.json: MediaHub's Radio: Your Stations and Radio: Recently Played rows."""
    def card(s):
        return {"Label": s["name"], "Label2": describe(s), "Title": s["name"], "Square": s.get("icon") or
                "special://home/addons/%s/resources/icon.png" % ADDON_ID,
                "Action": "radio|run|" + play_address(s), "Kind": "radio", "kids": True}
    save_json("home.json", {"radiofavs": [card(s) for s in favourites()[:HOME_CARDS]],
                            "radiorecent": [card(s) for s in recent()[:HOME_CARDS]]})
    xbmcgui.Window(10000).setProperty("MHR.Home", str(time.time()))  # (the helper refreshes the rows)


def home_country():
    """Your country's code: the add-on's setting, or a guess from Kodi's region."""
    cc = (xbmcaddon.Addon(ADDON_ID).getSetting("country") or "").strip().upper()
    if len(cc) == 2:
        return cc
    region = xbmc.getLanguage(xbmc.ISO_639_1, True) or ""  # "en-gb"
    guess = region.split("-")[-1].upper() if "-" in region else ""
    return guess if len(guess) == 2 else "GB"
