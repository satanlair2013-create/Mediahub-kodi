"""MediaHub Radio - the alarm clock's alarms (alarms.json).

An alarm: {"id", "time": "07:00", "days": [0..6] (Monday is 0; none: once),
"station": {id, name, url, icon}, "volume": 10..100, "fade": minutes, "on": bool,
"last": the date it last rang}. The service (service.py) rings them; the add-on's
Alarm clock page sets them up.
"""
import datetime
import time
import uuid

import xbmc

import radio

SNOOZE = 9 * 60
WEEKDAYS = [0, 1, 2, 3, 4]
WEEKEND = [5, 6]


def alarms():
    return [a for a in radio.load_json("alarms.json", []) if isinstance(a, dict) and a.get("id")]


def save(found):
    radio.save_json("alarms.json", found)


def get(alarm_id):
    return next((a for a in alarms() if a["id"] == alarm_id), None)


def put(alarm):
    found = [a for a in alarms() if a["id"] != alarm["id"]] + [alarm]
    save(sorted(found, key=lambda a: a.get("time", "")))


def remove(alarm_id):
    save([a for a in alarms() if a["id"] != alarm_id])


def new(station):
    return {"id": uuid.uuid4().hex[:10], "time": "07:00", "days": list(WEEKDAYS), "station": station,
            "volume": 60, "fade": 5, "on": True, "last": ""}


def minutes(hhmm):
    try:
        h, m = hhmm.split(":")
        return int(h) * 60 + int(m)
    except (ValueError, AttributeError):
        return None


def next_time(alarm, now=None):
    """When the alarm rings next (a datetime), or None if it's off."""
    if not alarm.get("on") or minutes(alarm.get("time")) is None:
        return None
    now = now or datetime.datetime.now()
    mins = minutes(alarm["time"])
    for ahead in range(0, 8):
        day = (now + datetime.timedelta(days=ahead)).replace(hour=mins // 60, minute=mins % 60, second=0,
                                                             microsecond=0)
        if day <= now or day.date().isoformat() == alarm.get("last"):
            continue
        if alarm.get("days") and day.weekday() not in alarm["days"]:
            continue
        return day
    return None


def due(alarm, now=None):
    """It's the alarm's minute (or up to five minutes after, if Kodi was busy), today,
    and it hasn't rung today."""
    if not alarm.get("on") or minutes(alarm.get("time")) is None:
        return False
    now = now or datetime.datetime.now()
    if alarm.get("last") == now.date().isoformat():
        return False
    if alarm.get("days") and now.weekday() not in alarm["days"]:
        return False
    late = now.hour * 60 + now.minute - minutes(alarm["time"])
    return 0 <= late < 5


def rang(alarm):
    """Note that it rang today; a one-off alarm turns itself off."""
    alarm = dict(alarm, last=datetime.date.today().isoformat())
    if not alarm.get("days"):
        alarm["on"] = False
    put(alarm)


def day_names(days, text):
    """Every day / Weekdays / Weekends / Once / Mon, Wed."""
    days = sorted(set(days or []))
    if not days:
        return text(30031)
    if days == list(range(7)):
        return text(30032)
    if days == WEEKDAYS:
        return text(30033)
    if days == WEEKEND:
        return text(30034)
    return ", ".join(xbmc.getLocalizedString(41 + d) for d in days)  # (Mon .. Sun, short)


def next_label(text):
    """The next alarm, for the MediaHub skin: "Mon 07:00" (or "")."""
    upcoming = [t for t in (next_time(a) for a in alarms()) if t]
    if not upcoming:
        return ""
    t = min(upcoming)
    if t.date() == datetime.date.today():
        return t.strftime("%H:%M")
    return "%s %s" % (xbmc.getLocalizedString(41 + t.weekday()), t.strftime("%H:%M"))


def epoch(dt):
    return time.mktime(dt.timetuple())
