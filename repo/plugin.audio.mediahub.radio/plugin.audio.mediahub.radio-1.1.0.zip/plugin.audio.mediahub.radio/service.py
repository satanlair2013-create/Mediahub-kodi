"""MediaHub Radio - the alarm clock, in the background while Kodi runs.

At an alarm's time: wake the TV (HDMI-CEC, where the TV has it), start the station
quietly and turn it up to the alarm's volume over its fade-in minutes, and ask
Stop or Snooze (nine minutes). An alarm doesn't ring over a film or episode that's
playing; it says so instead. The next alarm is in Window(Home) MHR.NextAlarm, for
the MediaHub skin's clock.
"""
import json
import os
import sys
import threading
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import alarms  # noqa: E402

ADDON_ID = "plugin.audio.mediahub.radio"
START_VOLUME = 5


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                       "params": params})))
    return reply.get("result")


def text(string_id):
    return xbmcaddon.Addon(ADDON_ID).getLocalizedString(string_id)


def play_station(s):
    xbmc.executebuiltin("RunPlugin(plugin://%s/?%s)" % (ADDON_ID, urllib.parse.urlencode(
        {"mode": "play", "id": s.get("id", ""), "name": s.get("name", ""), "url": s.get("url", ""),
         "icon": s.get("icon", "")})))


class Service(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.snoozed = None     # (alarm, when to ring again)
        self.ringing = False
        self.next_label = None

    def tick(self):
        label = alarms.next_label(text)
        if label != self.next_label:
            self.next_label = label
            home = xbmcgui.Window(10000)
            if label:
                home.setProperty("MHR.NextAlarm", label)
            else:
                home.clearProperty("MHR.NextAlarm")
        if self.ringing:
            return
        test = xbmcgui.Window(10000).getProperty("MHR.AlarmTest")  # (Try it now, on the alarm's page)
        if test:
            xbmcgui.Window(10000).clearProperty("MHR.AlarmTest")
            alarm = alarms.get(test)
            if alarm:
                return self.ring(dict(alarm, fade=min(alarm.get("fade") or 0, 1)))
        if self.snoozed and time.time() >= self.snoozed[1]:
            alarm, self.snoozed = self.snoozed[0], None
            return self.ring(alarm)
        for alarm in alarms.alarms():
            if alarms.due(alarm):
                alarms.rang(alarm)
                return self.ring(alarm)

    def ring(self, alarm):
        if xbmc.getCondVisibility("Player.HasVideo + Window.IsActive(fullscreenvideo)"):  # (not a trailer preview)
            xbmcgui.Dialog().notification(text(30027), text(30045) % alarm["time"], xbmcgui.NOTIFICATION_INFO, 8000)
            return
        self.ringing = True
        threading.Thread(target=self.ringing_thread, args=(alarm,), daemon=True).start()

    def ringing_thread(self, alarm):
        try:
            self.wake_up(alarm)
        except Exception as exc:  # (never take the service down)
            xbmc.log("MediaHub Radio alarm: %r" % exc, xbmc.LOGERROR)
        finally:
            self.ringing = False

    def wake_up(self, alarm):
        xbmc.executebuiltin("CECActivateSource")  # (turns the TV on and to Kodi, where it can)
        rpc("Input.ExecuteAction", action="noop")  # (ends the screensaver)
        target = max(10, min(100, int(alarm.get("volume") or 60)))
        fade = max(0, int(alarm.get("fade") or 0)) * 60
        rpc("Application.SetMute", mute=False)
        rpc("Application.SetVolume", volume=START_VOLUME if fade else target)
        play_station(alarm.get("station") or {})
        # (Kodi changes to the now-playing screen when the station starts, which would close
        # a question already on screen: ask once it has)
        for _ in range(40):
            if xbmc.getCondVisibility("Player.HasAudio") or self.waitForAbort(0.5):
                break
        self.waitForAbort(2)
        # turn it up little by little while the question is on screen
        stop = threading.Event()

        def fade_in():
            began = time.time()
            while fade and not stop.is_set() and not self.abortRequested():
                share = min(1.0, (time.time() - began) / fade)
                rpc("Application.SetVolume", volume=int(START_VOLUME + (target - START_VOLUME) * share))
                if share >= 1.0:
                    break
                stop.wait(5)
        threading.Thread(target=fade_in, daemon=True).start()
        station = (alarm.get("station") or {}).get("name", "")
        stopped = xbmcgui.Dialog().yesno(text(30027), "%s  •  %s" % (alarm["time"], station),
                                         nolabel=text(30046), yeslabel=text(30047))
        stop.set()
        if stopped:
            xbmc.executebuiltin("PlayerControl(Stop)")
            rpc("Application.SetVolume", volume=target)
        else:  # snooze: quiet until then
            xbmc.executebuiltin("PlayerControl(Stop)")
            rpc("Application.SetVolume", volume=target)
            self.snoozed = (alarm, time.time() + alarms.SNOOZE)
            xbmcgui.Dialog().notification(text(30027), text(30048) % time.strftime(
                "%H:%M", time.localtime(self.snoozed[1])), xbmcgui.NOTIFICATION_INFO, 5000, False)

    def run(self):
        while not self.waitForAbort(5):
            try:
                self.tick()
            except Exception as exc:
                xbmc.log("MediaHub Radio alarm: %r" % exc, xbmc.LOGERROR)


if __name__ == "__main__":
    Service().run()
