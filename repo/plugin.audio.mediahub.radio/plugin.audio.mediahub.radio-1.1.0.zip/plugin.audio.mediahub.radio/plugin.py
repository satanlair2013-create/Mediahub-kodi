"""MediaHub Radio - thousands of internet radio stations, from radio-browser.info.

Your stations (favourites) and the ones you played last, what's popular in your
country, the most-voted and most-listened stations, by country, genre and
language, and search. Hold OK on a station to add it to Your stations.
"""
import json
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import radio  # noqa: E402
import alarms  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name")
FANART = os.path.join(ADDON.getAddonInfo("path"), "resources", "fanart.jpg")
PAGE = 100


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)


def notify(message, error=False):
    xbmcgui.Dialog().notification(NAME, message, xbmcgui.NOTIFICATION_WARNING if error else
                                  xbmcgui.NOTIFICATION_INFO, 4000, False)


def folder(label, target, icon="DefaultFolder.png", label2=""):
    item = xbmcgui.ListItem(label, label2)
    item.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=True)


def action(label, target, icon="DefaultIconInfo.png"):
    item = xbmcgui.ListItem(label)
    item.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=False)


def end(content="", title="", cache=False):
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.setPluginCategory(HANDLE, title or NAME)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED, labelMask="%L", label2Mask="%A")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE, labelMask="%L", label2Mask="%A")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)


def careful(work):
    """Run a page; if radio-browser can't be reached, say so instead of failing."""
    try:
        work()
    except radio.Error as exc:
        xbmc.log("MediaHub Radio: %s" % exc, xbmc.LOGWARNING)
        notify(text(30020), True)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


# --------------------------------------------------------------------------- pages

def root():
    if radio.favourites():
        folder(text(30001), url(mode="favourites"), "DefaultMusicPlaylists.png")
    if radio.recent():
        folder(text(30002), url(mode="recent"), "DefaultMusicRecentlyPlayed.png")
    cc = radio.home_country()
    item = xbmcgui.ListItem(text(30003) % country_name(cc))
    item.setArt({"icon": "DefaultMusicTop100.png", "thumb": "DefaultMusicTop100.png", "fanart": FANART})
    item.addContextMenuItems([(text(30023), "RunPlugin(%s)" % url(mode="country"))])
    xbmcplugin.addDirectoryItem(HANDLE, url(mode="list", path="stations/bycountrycodeexact/" + cc,
                                            order="clickcount", title=country_name(cc)), item, isFolder=True)
    folder(text(30004), url(mode="list", path="stations/topclick", title=text(30004)), "DefaultMusicTop100.png")
    folder(text(30005), url(mode="list", path="stations/topvote", title=text(30005)), "DefaultMusicTop100.png")
    folder(text(30006), url(mode="list", path="stations/lastclick", title=text(30006)),
           "DefaultMusicRecentlyAdded.png")
    folder(text(30007), url(mode="genres"), "DefaultMusicGenres.png")
    folder(text(30008), url(mode="countries"), "DefaultCountry.png")
    folder(text(30009), url(mode="languages"), "DefaultLanguage.png")
    folder(xbmc.getLocalizedString(137), url(mode="search"), "DefaultAddonsSearch.png")
    folder(text(30027), url(mode="alarms"), "DefaultIconInfo.png", alarms.next_label(text))
    action(text(30024), url(mode="country"), "DefaultCountry.png")
    end()


COUNTRIES = {}


def country_name(cc):
    if not COUNTRIES:
        try:
            for c in radio.api("countries", radio.NAMES_AGE) or []:
                if c.get("iso_3166_1"):
                    COUNTRIES[c["iso_3166_1"].upper()] = c.get("name") or c["iso_3166_1"]
        except radio.Error:
            pass
    return COUNTRIES.get(cc, cc)


def station_item(s, where=""):
    item = xbmcgui.ListItem(s["name"], radio.describe(s))
    icon = s.get("icon") or "DefaultAudio.png"
    item.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
    tag = item.getMusicInfoTag()
    tag.setTitle(s["name"])
    tag.setAlbum(s["name"])
    tag.setArtist(radio.describe(s))  # (shows under the name, until the station sends its song titles)
    tag.setGenres([t.title() for t in s.get("tags", [])])
    tag.setComment(radio.describe(s))
    item.setProperty("IsPlayable", "true")
    info = json.dumps(s)
    menu = [(text(30012), "RunPlugin(%s)" % url(mode="favourite", on=0, station=info))
            if radio.is_favourite(s["id"]) else
            (text(30011), "RunPlugin(%s)" % url(mode="favourite", on=1, station=info))]
    if where == "favourites":
        menu += [(text(30013), "RunPlugin(%s)" % url(mode="move", id=s["id"], step=-1)),
                 (text(30014), "RunPlugin(%s)" % url(mode="move", id=s["id"], step=1))]
    if s.get("tags"):
        tag0 = s["tags"][0]
        menu.append((text(30015) % tag0.title(), "Container.Update(%s)" % url(
            mode="list", path="stations/bytagexact/" + tag0, order="clickcount", title=tag0.title())))
    if where == "recent":
        menu.append((text(30016), "RunPlugin(%s)" % url(mode="clearrecent")))
    item.addContextMenuItems(menu)
    return item


def show_stations(found, title, where="", more=None):
    for s in found:
        xbmcplugin.addDirectoryItem(HANDLE, radio.play_address(s), station_item(s, where), isFolder=False)
    if more:
        folder(text(30017), more, "DefaultFolder.png")
    end("songs", title)


def station_list():
    """A page of stations from radio-browser (ARGS: path, order, title, offset)."""
    offset = int(ARGS.get("offset", 0))
    params = {"limit": PAGE, "offset": offset}
    if ARGS.get("order"):
        params.update(order=ARGS["order"], reverse="true")
    path = ARGS["path"]
    if path in ("stations/topclick", "stations/topvote", "stations/lastclick"):
        params = {"limit": PAGE}  # (these take no order or offset: they're the top 100)
    found = radio.stations(path, **params)
    more = None
    if len(found) >= PAGE and "offset" in params:
        more = url(**dict(ARGS, offset=offset + PAGE))
    show_stations(found, ARGS.get("title", ""), more=more)


def names_page(kind):
    """Genres (tags), countries or languages, the ones with the most stations first."""
    if kind == "genres":
        found = radio.api("tags", radio.NAMES_AGE, order="stationcount", reverse="true", hidebroken="true",
                          limit=200)
    elif kind == "countries":
        found = radio.api("countries", radio.NAMES_AGE, hidebroken="true")
    else:
        found = radio.api("languages", radio.NAMES_AGE, order="stationcount", reverse="true", hidebroken="true",
                          limit=150)
    rows = [n for n in found or [] if isinstance(n, dict) and n.get("name") and int(n.get("stationcount") or 0) > 0]
    if kind == "countries":
        mine = radio.home_country()
        rows.sort(key=lambda n: ((n.get("iso_3166_1") or "").upper() != mine, n["name"].lower()))
    for n in rows:
        count = int(n.get("stationcount") or 0)
        label = n["name"].title() if kind != "countries" else n["name"]
        if kind == "genres":
            path = "stations/bytagexact/" + n["name"]
        elif kind == "countries":
            path = "stations/bycountrycodeexact/" + (n.get("iso_3166_1") or "")
        else:
            path = "stations/bylanguageexact/" + n["name"]
        folder(label, url(mode="list", path=path, order="clickcount", title=label),
               "DefaultMusicGenres.png" if kind == "genres" else
               "DefaultCountry.png" if kind == "countries" else "DefaultLanguage.png",
               label2=text(30018) % count)
    end("files", text({"genres": 30007, "countries": 30008}.get(kind, 30009)))


def search():
    words = ARGS.get("q")
    if not words:
        words = xbmcgui.Dialog().input(text(30019))
        if not words:
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        xbmc.executebuiltin("Container.Update(%s,replace)" % url(mode="search", q=words))
        return end()
    found = radio.stations("stations/search", name=words, order="clickcount", reverse="true", limit=PAGE)
    if not found:  # (a genre or a place, then)
        found = radio.stations("stations/search", tag=words.lower(), order="clickcount", reverse="true",
                               limit=PAGE)
    show_stations(found, '%s: "%s"' % (xbmc.getLocalizedString(137), words))


def play():
    s = {"id": ARGS.get("id", ""), "name": ARGS.get("name", ""), "url": ARGS.get("url", ""),
         "icon": ARGS.get("icon", "")}
    try:
        s.update(json.loads(ARGS.get("extra") or "{}"))
    except ValueError:
        pass
    if not ARGS.get("extra"):  # (started from elsewhere, like the web remote: what's kept about it)
        known = next((k for k in radio.favourites() + radio.recent() if k["id"] == s["id"]), {})
        s = dict(known, **{k: v for k, v in s.items() if v})
    for k, v in (("tags", []), ("country", ""), ("cc", ""), ("codec", ""), ("bitrate", 0), ("language", "")):
        s.setdefault(k, v)
        if s[k] is None:
            s[k] = v
    address = radio.listen(s["id"]) or s["url"]
    if not address:
        return xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    s["url"] = address
    item = station_item(s)
    item.setPath(address)
    if ".m3u8" in address.lower():
        item.setMimeType("application/vnd.apple.mpegurl")
        item.setContentLookup(False)
    if HANDLE >= 0:
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
    else:  # (from MediaHub's home row: RunPlugin, so there's nothing to resolve)
        xbmc.Player().play(address, item)
    radio.note_played(s)


def favourite():
    try:
        s = json.loads(ARGS.get("station") or "{}")
    except ValueError:
        return
    if not s.get("id"):
        return
    on = ARGS.get("on") == "1"
    radio.set_favourite(s, on)
    notify(text(30021 if on else 30022) % s.get("name", ""))
    xbmc.executebuiltin("Container.Refresh")


def choose_country():
    """Your country, for Popular in ... (picked from radio-browser's list)."""
    found = sorted((c for c in radio.api("countries", radio.NAMES_AGE, hidebroken="true") or []
                    if isinstance(c, dict) and c.get("iso_3166_1") and c.get("name")), key=lambda c: c["name"].lower())
    if not found:
        return
    mine = radio.home_country()
    at = next((n for n, c in enumerate(found) if c["iso_3166_1"].upper() == mine), -1)
    picked = xbmcgui.Dialog().select(text(30024), [c["name"] for c in found], preselect=at)
    if picked >= 0:
        ADDON.setSetting("country", found[picked]["iso_3166_1"].upper())
        xbmc.executebuiltin("Container.Refresh")


# --------------------------------------------------------------------------- alarm clock

FADES = (0, 1, 2, 5, 10, 15)


def alarms_page():
    action(text(30028), url(mode="alarmadd"), "DefaultAddSource.png")
    for a in alarms.alarms():
        label = "%s  %s" % (a["time"], alarms.day_names(a.get("days"), text))
        if not a.get("on"):
            label += "  " + text(30044)
        item = xbmcgui.ListItem(label, (a.get("station") or {}).get("name", ""))
        icon = (a.get("station") or {}).get("icon") or "DefaultIconInfo.png"
        item.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
        item.addContextMenuItems([(text(30038) if a.get("on") else text(30039),
                                   "RunPlugin(%s)" % url(mode="alarmedit", id=a["id"], do="toggle")),
                                  (text(30041), "RunPlugin(%s)" % url(mode="alarmedit", id=a["id"], do="delete"))])
        xbmcplugin.addDirectoryItem(HANDLE, url(mode="alarmedit", id=a["id"]), item, isFolder=False)
    end("files", text(30027))


def stations_to_choose():
    seen, found = set(), []
    for s in radio.favourites() + radio.recent():
        if s.get("id") and s["id"] not in seen:
            seen.add(s["id"])
            found.append({k: s.get(k, "") for k in ("id", "name", "url", "icon")})
    return found


def ask_time(alarm):
    value = xbmcgui.Dialog().numeric(2, text(30029), alarm.get("time", "07:00"))
    if value and alarms.minutes(value) is not None:
        h, m = value.split(":")
        alarm["time"] = "%02d:%02d" % (int(h) % 24, int(m) % 60)
        return True
    return False


def ask_days(alarm):
    picked = xbmcgui.Dialog().multiselect(text(30030), [xbmc.getLocalizedString(11 + d) for d in range(7)],
                                          preselect=alarm.get("days") or [])
    if picked is None:
        return False
    alarm["days"] = sorted(picked)
    return True


def ask_station(alarm):
    found = stations_to_choose()
    if not found:
        notify(text(30042), True)
        return False
    at = next((n for n, s in enumerate(found) if s["id"] == (alarm.get("station") or {}).get("id")), -1)
    pick = xbmcgui.Dialog().select(text(30035), [s["name"] for s in found], preselect=at)
    if pick < 0:
        return False
    alarm["station"] = found[pick]
    return True


def ask_volume(alarm):
    levels = list(range(20, 101, 10))
    at = levels.index(alarm["volume"]) if alarm.get("volume") in levels else -1
    pick = xbmcgui.Dialog().select(text(30036), ["%d%%" % v for v in levels], preselect=at)
    if pick >= 0:
        alarm["volume"] = levels[pick]
    return pick >= 0


def ask_fade(alarm):
    names = [text(30049) if f == 0 else text(30043) % f for f in FADES]
    at = FADES.index(alarm["fade"]) if alarm.get("fade") in FADES else -1
    pick = xbmcgui.Dialog().select(text(30037), names, preselect=at)
    if pick >= 0:
        alarm["fade"] = FADES[pick]
    return pick >= 0


def alarm_add():
    found = stations_to_choose()
    if not found:
        return notify(text(30042), True)
    alarm = alarms.new(found[0])
    if ask_time(alarm) and ask_days(alarm) and ask_station(alarm):
        alarms.put(alarm)
        notify("%s  %s" % (alarm["time"], alarms.day_names(alarm["days"], text)))
        xbmc.executebuiltin("Container.Refresh")


def alarm_edit(alarm_id, do=""):
    alarm = alarms.get(alarm_id)
    if not alarm:
        return
    if not do:
        station = (alarm.get("station") or {}).get("name", "")
        fade = text(30049) if not alarm.get("fade") else text(30043) % alarm["fade"]
        choices = [("toggle", text(30038) if alarm.get("on") else text(30039)),
                   ("time", "%s: %s" % (text(30050), alarm["time"])),
                   ("days", "%s: %s" % (text(30030), alarms.day_names(alarm.get("days"), text))),
                   ("station", "%s: %s" % (text(30035), station)),
                   ("volume", "%s: %d%%" % (text(30036), alarm.get("volume", 60))),
                   ("fade", "%s: %s" % (text(30037), fade)),
                   ("test", text(30040)), ("delete", text(30041))]
        pick = xbmcgui.Dialog().select("%s  %s" % (alarm["time"], station), [label for _do, label in choices])
        if pick < 0:
            return
        do = choices[pick][0]
    changed = False
    if do == "toggle":
        alarm["on"], changed = not alarm.get("on"), True
    elif do in ("time", "days", "station", "volume", "fade"):
        changed = {"time": ask_time, "days": ask_days, "station": ask_station, "volume": ask_volume,
                   "fade": ask_fade}[do](alarm)
        if changed:
            alarm["on"] = True
            alarm["last"] = ""
    elif do == "test":
        xbmcgui.Window(10000).setProperty("MHR.AlarmTest", alarm["id"])
    elif do == "delete":
        alarms.remove(alarm["id"])
        xbmc.executebuiltin("Container.Refresh")
        return
    if changed:
        alarms.put(alarm)
        xbmc.executebuiltin("Container.Refresh")


def main():
    mode = ARGS.get("mode")
    if mode is None:
        careful(root)
    elif mode == "favourites":
        show_stations(radio.favourites(), text(30001), "favourites")
    elif mode == "recent":
        show_stations(radio.recent(), text(30002), "recent")
    elif mode == "list":
        careful(station_list)
    elif mode in ("genres", "countries", "languages"):
        careful(lambda: names_page(mode))
    elif mode == "search":
        careful(search)
    elif mode == "play":
        play()
    elif mode == "favourite":
        favourite()
    elif mode == "move":
        radio.move_favourite(ARGS.get("id", ""), int(ARGS.get("step", 0)))
        xbmc.executebuiltin("Container.Refresh")
    elif mode == "clearrecent":
        radio.clear_recent()
        xbmc.executebuiltin("Container.Refresh")
    elif mode == "refreshhome":  # (MediaHub Sync changed the lists)
        radio.write_home()
    elif mode == "country":
        careful(choose_country)
    elif mode == "alarms":
        alarms_page()
    elif mode == "alarmadd":
        alarm_add()
    elif mode == "alarmedit":
        alarm_edit(ARGS.get("id", ""), ARGS.get("do", ""))


if __name__ == "__main__":
    main()
