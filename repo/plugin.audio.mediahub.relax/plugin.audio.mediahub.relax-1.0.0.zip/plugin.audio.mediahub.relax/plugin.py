"""MediaHub Relax - rain, a thunderstorm, waves, a fire and white, pink or brown
noise, with a sleep timer and a dim screen that slowly moves. Made, not recorded:
it all works with no network.
"""
import os
import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import relax  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
FANART = relax.path("resources", "fanart.jpg")


def url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)


def entry(label, target, about="", icon=None):
    item = xbmcgui.ListItem(label)
    icon = icon or relax.path("resources", "icon.png")
    item.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
    tag = item.getMusicInfoTag()
    tag.setTitle(label)
    tag.setComment(about)
    item.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=False)


def root():
    for name, title, about, _scene, _colours in relax.SOUNDS:
        entry(relax.text(title), url(mode="play", sound=name), relax.text(about),
              relax.path("resources", "media", name + ".png"))
    left = relax.minutes_left()
    entry("%s: %s" % (relax.text(30010), relax.text(30011) if left is None else relax.timer_label()),
          url(mode="timer"), relax.text(30028))
    if relax.playing():
        entry(relax.text(30016), url(mode="screen"), relax.text(30015))
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.setContent(HANDLE, "songs")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def main():
    mode = ARGS.get("mode")
    if mode is None:
        return root()
    if mode == "play":
        relax.start_timer_from_settings()
        relax.play(ARGS.get("sound", "rain"))
        if relax.addon().getSetting("screen") != "false":
            relax.open_screen()
    elif mode == "timer":
        if relax.choose_timer():
            xbmcgui.Dialog().notification(relax.addon().getAddonInfo("name"), relax.timer_label(),
                                          relax.path("resources", "icon.png"), 3000, False)
    elif mode == "screen":
        relax.open_screen()
    xbmc.executebuiltin("Container.Refresh")  # (the timer, and whether something plays)


if __name__ == "__main__":
    main()
