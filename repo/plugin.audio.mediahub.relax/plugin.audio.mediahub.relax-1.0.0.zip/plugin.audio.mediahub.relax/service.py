"""MediaHub Relax - in the background while Kodi runs.

- The sleep timer: over its last minute the sound fades out, then it stops and the
  volume goes back to where it was.
- When a Relax sound stops or something else plays, Kodi's "repeat one" (which
  loops the sounds) goes back off, so the next songs don't repeat.
"""
import json
import os
import sys
import time

import xbmc

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import relax  # noqa: E402

FADE = 60  # seconds


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return reply.get("result")


class Service(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.volume = None      # the volume before the fade
        self.looping = False    # a Relax sound has had "repeat one"

    def tick(self):
        now = relax.playing()
        if now:
            self.looping = True
        elif self.looping and not relax.home().getProperty(relax.SOUND + ".Switching"):
            self.looping = False
            relax.home().clearProperty(relax.SOUND)
            relax.set_timer(0)
            xbmc.executebuiltin("PlayerControl(RepeatOff)")
            self.restore()
        at = relax.home().getProperty(relax.SLEEP_AT)
        if not at or not now:
            return self.restore()
        left = float(at) - time.time()
        if left > FADE:
            return self.restore()
        if self.volume is None:
            self.volume = (rpc("Application.GetProperties", properties=["volume"]) or {}).get("volume", 100)
        if left <= 0:
            relax.set_timer(0)
            xbmc.executebuiltin("PlayerControl(RepeatOff)")
            xbmc.Player().stop()
            xbmc.sleep(500)
            return self.restore()
        rpc("Application.SetVolume", volume=int(self.volume * left / FADE))

    def restore(self):
        if self.volume is not None:
            rpc("Application.SetVolume", volume=int(self.volume))
            self.volume = None

    def run(self):
        while not self.waitForAbort(1):
            try:
                self.tick()
            except Exception as exc:  # (never take the service down)
                xbmc.log("MediaHub Relax: %r" % exc, xbmc.LOGERROR)
        self.restore()


if __name__ == "__main__":
    Service().run()
