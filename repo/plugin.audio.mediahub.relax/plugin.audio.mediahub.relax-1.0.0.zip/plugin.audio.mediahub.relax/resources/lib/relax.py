"""MediaHub Relax - calm sounds to fall asleep to, and a dim screen that slowly moves.

The sounds are in the add-on (resources/sounds/, made by kodi/tools/make_relax_sounds.py),
so they play with no network. Each one is a seamless loop that Kodi repeats.

  Window(Home) MHX.Sound: the sound playing (while it plays; the service tidies up after)
  Window(Home) MHX.SleepAt: when the sleep timer stops it (seconds since 1970)
"""
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.audio.mediahub.relax"
SOUND = "MHX.Sound"
SLEEP_AT = "MHX.SleepAt"
TIMERS = (0, 15, 30, 45, 60, 90, 120)  # minutes (0: no timer)
IDLE = 8  # seconds before the words fade and the screen dims
# name: (title string, about string, the screen's scene, its three colours)
SOUNDS = [("rain", 30001, 30021, "rain", ("FF2B5C8A", "FF1C3F66", "FF3E7EAE")),
          ("storm", 30002, 30022, "storm", ("FF34425E", "FF1E2638", "FF4B5A7A")),
          ("waves", 30003, 30023, "waves", ("FF1F7A7A", "FF15506A", "FF2F8F9A")),
          ("fire", 30004, 30024, "fire", ("FFC4561A", "FF8A2A0E", "FFE08A2A")),
          ("white", 30005, 30025, "noise", ("FF5A6070", "FF3A4050", "FF7A8090")),
          ("pink", 30006, 30026, "noise", ("FF8A4A7A", "FF5A2A5A", "FFAA6A8A")),
          ("brown", 30007, 30027, "noise", ("FF7A5230", "FF4A3020", "FF9A6A40"))]


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def text(string_id):
    return addon().getLocalizedString(string_id)


def home():
    return xbmcgui.Window(10000)


def path(*parts):
    return os.path.join(addon().getAddonInfo("path"), *parts)


def sound_file(name):
    return path("resources", "sounds", name + ".ogg")


def find(name):
    return next((s for s in SOUNDS if s[0] == name), SOUNDS[0])


def playing():
    """The sound playing now, or ""."""
    if not xbmc.getCondVisibility("Player.HasAudio"):
        return ""
    now = xbmc.getInfoLabel("Player.Filenameandpath").replace("\\", "/")
    return next((s[0] for s in SOUNDS if now.endswith("/sounds/%s.ogg" % s[0]) and ADDON_ID in now), "")


def play(name):
    """Play a sound over and over."""
    name, title, about, _scene, _colours = find(name)
    item = xbmcgui.ListItem(text(title), path=sound_file(name))
    tag = item.getMusicInfoTag()
    tag.setTitle(text(title))
    tag.setArtist(addon().getAddonInfo("name"))
    tag.setComment(text(about))
    icon = path("resources", "icon.png")
    item.setArt({"thumb": icon, "icon": icon, "fanart": path("resources", "fanart.jpg")})
    songs = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    home().setProperty(SOUND + ".Switching", "1")  # (for the service: it hasn't stopped)
    songs.clear()
    songs.add(sound_file(name), item)
    home().setProperty(SOUND, name)
    xbmc.Player().play(songs)
    for _ in range(40):  # (repeat it, once it has started)
        if playing() == name:
            break
        xbmc.sleep(100)
    xbmc.executebuiltin("PlayerControl(RepeatOne)")
    xbmc.sleep(1500)
    home().clearProperty(SOUND + ".Switching")


def minutes_left():
    at = home().getProperty(SLEEP_AT)
    try:
        return max(0, int((float(at) - time.time() + 59) // 60)) if at else None
    except ValueError:
        return None


def set_timer(minutes):
    if minutes:
        home().setProperty(SLEEP_AT, str(time.time() + minutes * 60))
    else:
        home().clearProperty(SLEEP_AT)


def timer_label():
    left = minutes_left()
    return text(30014) if left is None else text(30013) % left


def choose_timer():
    names = [text(30011) if m == 0 else text(30012) % m for m in TIMERS]
    pick = xbmcgui.Dialog().select(text(30010), names)
    if pick < 0:
        return False
    set_timer(TIMERS[pick])
    return True


def start_timer_from_settings():
    """The sleep timer to start with (Settings), when none is running."""
    if minutes_left() is None:
        try:
            minutes = TIMERS[int(addon().getSetting("timer") or 0)]
        except (ValueError, IndexError):
            minutes = 0
        set_timer(minutes)


# --------------------------------------------------------------------------- the screen

ACTION_LEFT, ACTION_RIGHT = 1, 2
ACTION_SELECT = 7
ACTION_BACK, ACTION_MENU, ACTION_NAV_BACK = 10, 117, 92
ACTION_STOP = 13
ACTION_MOUSE_MOVE = 107


class Screen(xbmcgui.WindowXML):
    """Dim and slowly moving; the words fade after a few seconds. OK: sleep timer,
    Left/Right: another sound, Back: leave it playing, Stop: stop it."""

    def onInit(self):
        self.touched = time.time()
        self.show(playing() or home().getProperty(SOUND) or SOUNDS[0][0])
        if not getattr(self, "open", False):
            self.open = True
            threading.Thread(target=self.watch, daemon=True).start()

    def show(self, name):
        name, title, about, scene, colours = find(name)
        self.setProperty("Name", text(title))
        self.setProperty("About", text(about))
        self.setProperty("Scene", scene)
        for i, c in enumerate(colours, 1):
            self.setProperty("Tint%d" % i, c)
        self.setProperty("Timer", timer_label())

    def watch(self):
        monitor = xbmc.Monitor()
        gone = 0
        while self.open and not monitor.abortRequested():
            self.setProperty("Timer", timer_label())
            self.setProperty("Idle", "1" if time.time() - self.touched > IDLE else "")
            gone = gone + 1 if not playing() else 0
            if gone >= 6:  # (it stopped: the timer, or someone else)
                self.open = False
                self.close()
                return
            monitor.waitForAbort(0.5)

    def step(self, by):
        names = [s[0] for s in SOUNDS]
        now = playing() or home().getProperty(SOUND) or names[0]
        name = names[(names.index(now) + by) % len(names)] if now in names else names[0]
        self.show(name)
        threading.Thread(target=play, args=(name,), daemon=True).start()

    def onAction(self, action):
        act = action.getId()
        was_idle = time.time() - self.touched > IDLE
        self.touched = time.time()
        self.setProperty("Idle", "")
        if act in (ACTION_BACK, ACTION_NAV_BACK, ACTION_MENU):
            self.open = False
            return self.close()
        if act == ACTION_STOP:
            self.open = False
            xbmc.Player().stop()
            return self.close()
        if was_idle or act == ACTION_MOUSE_MOVE:
            return  # (the first press only brings the words back)
        if act == ACTION_LEFT:
            self.step(-1)
        elif act == ACTION_RIGHT:
            self.step(1)
        elif act == ACTION_SELECT:
            if choose_timer():
                self.setProperty("Timer", timer_label())


def open_screen():
    screen = Screen("mediahub-relax.xml", addon().getAddonInfo("path"), "Default", "1080i")
    screen.doModal()
    del screen
