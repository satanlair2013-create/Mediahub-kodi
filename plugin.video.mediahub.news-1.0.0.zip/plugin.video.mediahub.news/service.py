"""MediaHub News - in the background: the chosen sites' headlines every quarter of
an hour, for MediaHub's News: Headlines row and its news ticker."""
import os
import sys
import threading
import time

import xbmc

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import news  # noqa: E402

FIRST = 40      # seconds after Kodi starts
EVERY = 15 * 60


class Service(xbmc.Monitor):
    def run(self):
        news.write_home()  # (what was kept, straight away)
        due = time.time() + FIRST
        worker = None
        while not self.waitForAbort(5):
            if time.time() >= due and not (worker and worker.is_alive()):
                due = time.time() + EVERY
                worker = threading.Thread(target=self.refresh, daemon=True)
                worker.start()

    def refresh(self):
        try:
            news.refresh()
        except Exception as exc:  # (never take the service down)
            xbmc.log("MediaHub News: %r" % exc, xbmc.LOGWARNING)


if __name__ == "__main__":
    Service().run()
