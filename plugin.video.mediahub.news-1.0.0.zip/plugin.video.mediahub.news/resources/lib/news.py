"""MediaHub News - headlines from the news sites you choose, and news bulletins.

Every news site keeps an RSS (or Atom) feed of its stories: a headline, a few
lines, a picture and a link. Some are podcasts or video feeds of bulletins, which
play. You choose from a list of well-known sites or add any feed's address.

Kept in the add-on's data folder:
- sites.json: the feeds you chose [{id, name, url}]
- feeds/: each feed's stories as last read
- home.json: MediaHub's News: Headlines row
Window(Home): MHE.Ticker (today's headlines, one line, for MediaHub's news ticker)
and MHE.Home (set when the cards change).
"""
import email.utils
import gzip
import hashlib
import html
import json
import os
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.mediahub.news"
CERTS = "special://xbmc/system/certs/cacert.pem"
FEED_AGE = 15 * 60
HOME_CARDS = 20
TICKER = 15
# (id, name, address, language) - well-known feeds; "bulletin" ones are audio or video
SITES = [
    ("bbc", "BBC News", "https://feeds.bbci.co.uk/news/rss.xml", "en"),
    ("bbcworld", "BBC News: World", "https://feeds.bbci.co.uk/news/world/rss.xml", "en"),
    ("guardian", "The Guardian: World", "https://www.theguardian.com/world/rss", "en"),
    ("sky", "Sky News", "https://feeds.skynews.com/feeds/rss/home.xml", "en"),
    ("npr", "NPR News", "https://feeds.npr.org/1001/rss.xml", "en"),
    ("aljazeera", "Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml", "en"),
    ("dw", "DW News", "https://rss.dw.com/rdf/rss-en-all", "en"),
    ("france24", "France 24", "https://www.france24.com/en/rss", "en"),
    ("cbc", "CBC News", "https://www.cbc.ca/webfeed/rss/rss-topstories", "en"),
    ("abc", "ABC News (Australia)", "https://www.abc.net.au/news/feed/51120/rss.xml", "en"),
    ("verge", "The Verge", "https://www.theverge.com/rss/index.xml", "en"),
    ("nprnow", "NPR News Now (bulletin)", "https://feeds.npr.org/500005/podcast.xml", "en"),
    ("bbcglobal", "BBC Global News Podcast (bulletin)", "https://podcasts.files.bbci.co.uk/p02nq0gn.rss", "en"),
    ("tagesschau", "tagesschau", "https://www.tagesschau.de/xml/rss2/", "de"),
    ("elpais", "El País", "https://feeds.elpais.com/mrss-s/pages/ep/site/elpais.com/portada", "es"),
    ("lemonde", "Le Monde", "https://www.lemonde.fr/rss/une.xml", "fr"),
    ("ansa", "ANSA", "https://www.ansa.it/sito/ansait_rss.xml", "it"),
    ("g1", "g1", "https://g1.globo.com/rss/g1/", "pt"),
]
MEDIA = "{http://search.yahoo.com/mrss/}"
ATOM = "{http://www.w3.org/2005/Atom}"


class Error(Exception):
    pass


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def text(string_id):
    return addon().getLocalizedString(string_id)


def profile(name=""):
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)


def load_json(name, default):
    try:
        with open(profile(name), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(name, data):
    path = profile(name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def key(value):
    return hashlib.sha1(value.encode("utf-8")).hexdigest()[:16]


def ssl_context():
    certs = xbmcvfs.translatePath(CERTS)
    try:
        return ssl.create_default_context(cafile=certs) if os.path.exists(certs) else ssl.create_default_context()
    except (OSError, ssl.SSLError):
        return ssl.create_default_context()


def fetch(address, timeout=15):
    request = urllib.request.Request(address, headers={"User-Agent": xbmc.getUserAgent(), "Accept-Encoding": "gzip"})
    try:
        with urllib.request.urlopen(request, timeout=timeout, context=ssl_context()) as reply:
            body = reply.read(6 * 1024 * 1024)
        return gzip.decompress(body) if body[:2] == b"\x1f\x8b" else body
    except urllib.error.HTTPError as exc:
        raise Error("HTTP %d" % exc.code)
    except (OSError, ValueError, ssl.SSLError) as exc:
        raise Error(repr(exc))


# --------------------------------------------------------------------------- your sites

def sites():
    return load_json("sites.json", [])


def set_sites(chosen):
    save_json("sites.json", chosen)


def language():
    return xbmc.getLanguage(xbmc.ISO_639_1) or "en"


def suggested():
    """The list of well-known sites, the ones in Kodi's language first."""
    lang = language()
    return sorted(SITES, key=lambda s: (s[3] != lang, SITES.index(s)))


# --------------------------------------------------------------------------- reading a feed

def local(tag):
    return tag.rsplit("}", 1)[-1].lower()


def child(node, *names):
    for c in node:
        if local(c.tag) in names:
            return c
    return None


def child_text(node, *names):
    c = child(node, *names)
    return (c.text or "").strip() if c is not None and c.text else ""


def plain(value):
    value = re.sub(r"<(br|p|/p|li|div)[^>]*>", "\n", value or "", flags=re.I)
    value = html.unescape(re.sub(r"<[^>]+>", "", value))
    return re.sub(r"\n\s*\n+", "\n\n", re.sub(r"[ \t\r]+", " ", value)).strip()


def when(value):
    """A feed's date (RFC 822 or ISO 8601) as epoch seconds, or 0."""
    value = (value or "").strip()
    if not value:
        return 0
    try:
        return int(email.utils.parsedate_to_datetime(value).timestamp())
    except (TypeError, ValueError, IndexError):
        pass
    found = re.match(r"(\d{4})-(\d\d)-(\d\d)[T ](\d\d):(\d\d)(?::(\d\d))?(?:\.\d+)?(Z|[+-]\d\d:?\d\d)?", value)
    if not found:
        return 0
    y, mo, d, h, mi, s, zone = found.groups()
    t = time.mktime((int(y), int(mo), int(d), int(h), int(mi), int(s or 0), 0, 0, 0)) - time.timezone
    if zone and zone != "Z":
        sign = 1 if zone[0] == "+" else -1
        zone = zone[1:].replace(":", "")
        t -= sign * (int(zone[:2]) * 3600 + int(zone[2:]) * 60)
    return int(t)


def picture_of(item, description):
    """A story's picture: media:content / media:thumbnail, an image enclosure, or the first <img>."""
    best, width = "", -1
    for c in item.iter():
        name = local(c.tag)
        if name in ("content", "thumbnail") and c.tag.startswith(MEDIA) and c.get("url"):
            kind = (c.get("type") or c.get("medium") or "image").lower()
            if "image" in kind or name == "thumbnail":
                w = int(c.get("width") or 0) if (c.get("width") or "").isdigit() else 0
                if w > width:
                    best, width = c.get("url"), w
        elif name == "enclosure" and (c.get("type") or "").startswith("image/") and c.get("url") and not best:
            best = c.get("url")
    if not best:
        found = re.search(r"<img[^>]+src=[\"']([^\"']+)", description or "", re.I)
        best = html.unescape(found.group(1)) if found else ""
    return best


def media_of(item):
    """(address, "audio" | "video") of a bulletin's sound or film, or ("", "")."""
    for c in item.iter():
        name = local(c.tag)
        kind = (c.get("type") or "").lower()
        if name == "enclosure" and c.get("url") and kind.startswith(("audio/", "video/")):
            return c.get("url"), kind.split("/")[0]
        if name == "content" and c.tag.startswith(MEDIA) and c.get("url") and \
                (kind.startswith(("audio/", "video/")) or c.get("medium") in ("audio", "video")):
            return c.get("url"), "video" if kind.startswith("video/") or c.get("medium") == "video" else "audio"
        if name == "link" and c.tag.startswith(ATOM) and c.get("rel") == "enclosure" and \
                (c.get("type") or "").startswith(("audio/", "video/")):
            return c.get("href"), c.get("type").split("/")[0]
    return "", ""


def parse(body, site):
    """[{id, title, summary, link, t, picture, media, kind, site}] from RSS 2.0, RSS 1.0 or Atom."""
    try:
        root = ET.fromstring(body)
    except ET.ParseError as exc:
        raise Error("not a feed: %s" % exc)
    channel_image = ""
    for c in root.iter():
        if local(c.tag) == "image":
            channel_image = child_text(c, "url") or c.get("href") or ""
            if channel_image:
                break
    stories = []
    for item in root.iter():
        if local(item.tag) not in ("item", "entry"):
            continue
        title = plain(child_text(item, "title"))
        if not title:
            continue
        description = child_text(item, "description", "summary", "encoded") or \
            (child(item, "content").text if child(item, "content") is not None and child(item, "content").text else "")
        link = child_text(item, "link")
        if not link:
            for c in item:
                if local(c.tag) == "link" and c.get("href") and c.get("rel", "alternate") == "alternate":
                    link = c.get("href")
                    break
        media, kind = media_of(item)
        stories.append({"id": key(child_text(item, "guid", "id") or link or title), "title": title,
                        "summary": plain(description)[:1500], "link": link,
                        "t": when(child_text(item, "pubdate", "published", "updated", "date")),
                        "picture": picture_of(item, description) or channel_image, "media": media, "kind": kind,
                        "site": site.get("name", "")})
    return stories


def stories(site, max_age=FEED_AGE):
    """A site's stories, newest first (from what was kept when it's fresh, or when the site can't be reached)."""
    name = os.path.join("feeds", key(site["url"]) + ".json")
    kept = load_json(name, {})
    if kept.get("t", 0) > time.time() - max_age:
        return kept.get("stories") or []
    try:
        found = parse(fetch(site["url"]), site)
    except Error as exc:
        xbmc.log("MediaHub News: %s: %s" % (site.get("name"), exc), xbmc.LOGWARNING)
        if kept:
            return kept.get("stories") or []
        raise
    found.sort(key=lambda s: s["t"], reverse=True)
    save_json(name, {"t": time.time(), "stories": found[:80]})
    return found[:80]


def top_stories(max_age=FEED_AGE):
    """Every chosen site's stories together, newest first (a site that fails is left out)."""
    found = []
    for site in sites():
        try:
            found += stories(site, max_age)
        except Error:
            continue
    found.sort(key=lambda s: s["t"], reverse=True)
    return found


def try_feed(address):
    """A feed address's name and stories (to add it), or Error."""
    body = fetch(address)
    root = ET.fromstring(body) if body else None
    name = ""
    if root is not None:
        channel = child(root, "channel")
        name = plain(child_text(channel if channel is not None else root, "title"))
    found = parse(body, {"name": name})
    if not found:
        raise Error("no stories")
    return name or urllib.parse.urlparse(address).netloc, found


# --------------------------------------------------------------------------- for MediaHub

def story_address(story):
    return "plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode(
        {"mode": "story", "id": story["id"]}))


def find_story(story_id):
    for site in sites():
        kept = load_json(os.path.join("feeds", key(site["url"]) + ".json"), {})
        for s in kept.get("stories") or []:
            if s["id"] == story_id:
                return s
    return None


def age(t):
    """"12 min", "3 hr", or the date."""
    if not t:
        return ""
    gone = max(0, time.time() - t)
    if gone < 3600:
        return text(30030) % max(1, int(gone // 60))
    if gone < 86400:
        return text(30031) % int(gone // 3600)
    return time.strftime(xbmc.getRegion("dateshort"), time.localtime(t))


def write_home():
    found = top_stories(max_age=10 * 365 * 86400)  # (what's kept: the service fetches)
    cards = [{"Label": s["title"], "Label2": "%s  •  %s" % (s["site"], age(s["t"])), "Title": s["title"],
              "Landscape": s["picture"], "Poster": s["picture"], "Plot": s["summary"][:400],
              "Action": "news|run|" + story_address(s), "Kind": "news", "kids": False}
             for s in found if s["picture"]][:HOME_CARDS]
    save_json("home.json", {"newshead": cards})
    ticker = "     •     ".join("%s: %s" % (s["site"], s["title"]) for s in found[:TICKER])
    home = xbmcgui.Window(10000)
    home.setProperty("MHE.Ticker", ticker)
    home.setProperty("MHE.Home", str(time.time()))  # (the MediaHub Helper refreshes the rows)


def refresh():
    for site in sites():
        try:
            stories(site, max_age=FEED_AGE - 60)
        except Error:
            continue
    write_home()
