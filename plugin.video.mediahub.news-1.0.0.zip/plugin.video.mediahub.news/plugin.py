"""MediaHub News - the headlines from the news sites you choose.

Top stories (every site you chose, newest first), each site on its own, and the
bulletins some sites keep as podcasts or videos (they play). A story shows its
headline, its few lines and when it came out; the whole article is on the web
(Kodi can't show web pages).
"""
import os
import sys
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import news  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name")
FANART = os.path.join(ADDON.getAddonInfo("path"), "resources", "fanart.jpg")


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)


def notify(message, error=False):
    xbmcgui.Dialog().notification(NAME, message, xbmcgui.NOTIFICATION_WARNING if error else
                                  xbmcgui.NOTIFICATION_INFO, 4000, False)


def entry(label, target, icon, folder=True, menu=None, label2=""):
    item = xbmcgui.ListItem(label, label2)
    item.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
    if menu:
        item.addContextMenuItems(menu)
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=folder)


def end(content="", title=""):
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.setPluginCategory(HANDLE, title or NAME)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


# --------------------------------------------------------------------------- pages

def root():
    mine = news.sites()
    if not mine:
        entry(text(30002), url(mode="choose"), "DefaultAddonService.png", folder=False)
        return end()
    entry(text(30001), url(mode="top"), "DefaultAddonNews.png")
    for site in mine:
        entry(site["name"], url(mode="site", url=site["url"], name=site["name"]), "DefaultAddonNews.png",
              menu=[(text(30005), "RunPlugin(%s)" % url(mode="remove", url=site["url"]))])
    entry(text(30002), url(mode="choose"), "DefaultAddonService.png", folder=False)
    entry(text(30003), url(mode="add"), "DefaultAddSource.png", folder=False)
    end()


def story_item(s):
    label2 = "%s  •  %s" % (s["site"], news.age(s["t"])) if s["site"] else news.age(s["t"])
    item = xbmcgui.ListItem(s["title"], label2)
    picture = s["picture"] or "DefaultAddonNews.png"
    item.setArt({"thumb": picture, "icon": picture, "poster": picture, "fanart": s["picture"] or FANART,
                 "landscape": picture})
    tag = item.getVideoInfoTag()
    tag.setTitle(s["title"])
    tag.setPlot(s["summary"])
    tag.setStudios([s["site"]] if s["site"] else [])
    if s["t"]:
        tag.setDateAdded(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(s["t"])))
        tag.setPremiered(time.strftime("%Y-%m-%d", time.localtime(s["t"])))
    if s["media"]:  # (a bulletin: it plays)
        item.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(HANDLE, s["media"], item, isFolder=False)
    else:
        xbmcplugin.addDirectoryItem(HANDLE, url(mode="story", id=s["id"]), item, isFolder=False)


def top():
    found = news.top_stories()
    if not found:
        notify(text(30020), True)
    for s in found[:150]:
        story_item(s)
    end("videos", text(30001))


def site_page(address, name):
    try:
        found = news.stories({"url": address, "name": name})
    except news.Error:
        notify(text(30020), True)
        return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    for s in found:
        story_item(s)
    end("videos", name)


def story(story_id):
    s = news.find_story(story_id)
    if not s:
        return
    if s["media"]:
        return xbmc.Player().play(s["media"], xbmcgui.ListItem(s["title"]))
    lines = ["[B]%s[/B]" % s["title"], "[COLOR FF8890A0]%s  •  %s[/COLOR]" % (s["site"], news.age(s["t"])), "",
             s["summary"] or text(30011)]
    if s["link"]:
        lines += ["", "[COLOR FF8890A0]%s[/COLOR]" % text(30010), s["link"]]
    xbmcgui.Dialog().textviewer(s["site"] or NAME, "\n".join(lines))


# --------------------------------------------------------------------------- choosing sites

def choose():
    mine = news.sites()
    chosen = {s["url"] for s in mine}
    offer = news.suggested()
    picked = xbmcgui.Dialog().multiselect(text(30002), [name for _id, name, _url, _lang in offer],
                                          preselect=[i for i, s in enumerate(offer) if s[2] in chosen])
    if picked is None:
        return
    known = {s[2] for s in news.SITES}
    keep = [s for s in mine if s["url"] not in known]  # (feeds you added yourself stay)
    news.set_sites([{"id": offer[i][0], "name": offer[i][1], "url": offer[i][2]} for i in picked] + keep)
    after_change()


def add():
    address = xbmcgui.Dialog().input(text(30004), "https://").strip()
    if not address or address == "https://":
        return
    if not address.startswith(("http://", "https://")):
        address = "https://" + address
    try:
        name, _found = news.try_feed(address)
    except news.Error:
        return xbmcgui.Dialog().ok(NAME, text(30021) % address)
    name = xbmcgui.Dialog().input(text(30006), name) or name
    mine = [s for s in news.sites() if s["url"] != address]
    news.set_sites(mine + [{"id": news.key(address), "name": name, "url": address}])
    notify(text(30007) % name)
    after_change()


def remove(address):
    news.set_sites([s for s in news.sites() if s["url"] != address])
    after_change()


def after_change():
    news.refresh()
    xbmc.executebuiltin("Container.Refresh")


def main():
    mode = ARGS.get("mode")
    if mode is None:
        root()
    elif mode == "top":
        top()
    elif mode == "site":
        site_page(ARGS["url"], ARGS.get("name", ""))
    elif mode == "story":
        story(ARGS.get("id", ""))
    elif mode == "choose":
        choose()
    elif mode == "add":
        add()
    elif mode == "remove":
        remove(ARGS.get("url", ""))
    elif mode == "refresh":
        news.refresh()


if __name__ == "__main__":
    main()
