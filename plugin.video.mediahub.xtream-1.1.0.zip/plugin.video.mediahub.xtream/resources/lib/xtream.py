"""MediaHub IPTV - talking to an Xtream Codes service.

Every Xtream Codes panel answers the same web API (player_api.php) with the
username and password the provider gave you: the account, the categories of live
channels, films and series, the entries in each category, a film's or a series'
details, and a channel's programmes. Streams are plain addresses:

    live:     <server>/live/<user>/<pass>/<id>.ts (or .m3u8)
    film:     <server>/movie/<user>/<pass>/<id>.<ext>
    episode:  <server>/series/<user>/<pass>/<id>.<ext>
    catch-up: <server>/timeshift/<user>/<pass>/<minutes>/<YYYY-MM-DD:HH-MM>/<id>.ts

Answers are kept on disk for a while (cache/), so going back and forth is quick
and the service isn't asked the same thing twice.
"""
import base64
import hashlib
import json
import os
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = "plugin.video.mediahub.xtream"
PROFILE = "special://profile/addon_data/%s/" % ADDON_ID
CERTS = "special://xbmc/system/certs/cacert.pem"
MINUTE, HOUR, DAY = 60, 3600, 86400


class Error(Exception):
    """The service couldn't be reached, or said no."""


def profile(name=""):
    path = xbmcvfs.translatePath(PROFILE + name)
    os.makedirs(os.path.dirname(path) if name else path, exist_ok=True)
    return path


def ssl_context():
    certs = xbmcvfs.translatePath(CERTS)
    try:
        return ssl.create_default_context(cafile=certs) if os.path.exists(certs) else ssl.create_default_context()
    except (OSError, ssl.SSLError):
        return ssl.create_default_context()


def normalise_server(server):
    """"example.com:8080" or "http://example.com:8080/" -> "http://example.com:8080"."""
    server = (server or "").strip().rstrip("/")
    if server and not re.match(r"^https?://", server, re.I):
        server = "http://" + server
    # (a pasted playlist or panel address: keep just the server)
    return re.sub(r"(https?://[^/]+).*$", r"\1", server, flags=re.I)


class Account:
    def __init__(self, server=None, username=None, password=None):
        addon = xbmcaddon.Addon(ADDON_ID)
        self.server = normalise_server(server if server is not None else addon.getSetting("server"))
        self.username = (username if username is not None else addon.getSetting("username")).strip()
        self.password = (password if password is not None else addon.getSetting("password")).strip()
        self.live_ext = "m3u8" if addon.getSetting("live_format") == "1" else "ts"

    def ready(self):
        return bool(self.server and self.username and self.password)

    # ------------------------------------------------------------------ the API

    def get(self, timeout=20, monitor=None, **params):
        """GET player_api.php with these parameters; the decoded JSON."""
        query = dict(username=self.username, password=self.password, **params)
        url = "%s/player_api.php?%s" % (self.server, urllib.parse.urlencode(query))
        return fetch_json(url, timeout, monitor)

    def cached(self, max_age, timeout=20, monitor=None, **params):
        """get(), from the cache when it's newer than max_age seconds (and from an
        older copy when the service can't be reached)."""
        path = self.cache_path(params)
        try:
            age = time.time() - os.path.getmtime(path)
        except OSError:
            age = None
        if age is not None and age < max_age:
            try:
                with open(path, encoding="utf-8") as f:
                    return json.load(f)
            except (OSError, ValueError):
                pass
        try:
            data = self.get(timeout=timeout, monitor=monitor, **params)
        except Error:
            if age is None:
                raise
            with open(path, encoding="utf-8") as f:  # (stale is better than nothing)
                return json.load(f)
        try:
            with open(path + ".tmp", "w", encoding="utf-8") as f:
                json.dump(data, f)
            os.replace(path + ".tmp", path)
        except OSError:
            pass
        return data

    def cache_path(self, params):
        key = hashlib.sha1(json.dumps([self.server, self.username, params], sort_keys=True).encode()).hexdigest()
        return profile("cache/%s.json" % key)

    def peek(self, **params):
        """What the cache has for this request, however old (None: nothing), without asking."""
        try:
            with open(self.cache_path(params), encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return None

    def login(self):
        """{"user_info": {...}, "server_info": {...}}; raises Error when refused."""
        data = self.get(timeout=15)
        info = (data or {}).get("user_info") if isinstance(data, dict) else None
        if not info or str(info.get("auth", 1)) == "0":
            raise Error("login")
        return data

    def categories(self, kind, timeout=20, monitor=None):
        """kind: live, vod or series."""
        data = self.cached(6 * HOUR, timeout=timeout, monitor=monitor, action="get_%s_categories" % kind)
        return data if isinstance(data, list) else []

    def streams(self, kind, category_id=None, max_age=3 * HOUR, timeout=20, monitor=None):
        """The entries of a category: live channels, films or series."""
        action = {"live": "get_live_streams", "vod": "get_vod_streams", "series": "get_series"}[kind]
        params = {"category_id": category_id} if category_id not in (None, "") else {}
        data = self.cached(max_age, timeout=timeout, monitor=monitor, action=action, **params)
        return data if isinstance(data, list) else []

    def vod_info(self, vod_id, timeout=20, monitor=None):
        data = self.cached(7 * DAY, timeout=timeout, monitor=monitor, action="get_vod_info", vod_id=vod_id)
        return data if isinstance(data, dict) else {}

    def series_info(self, series_id, max_age=6 * HOUR, timeout=20):
        data = self.cached(max_age, timeout=timeout, action="get_series_info", series_id=series_id)
        return data if isinstance(data, dict) else {}

    def short_epg(self, stream_id, limit=2, timeout=6):
        data = self.cached(10 * MINUTE, timeout=timeout, action="get_short_epg", stream_id=stream_id, limit=limit)
        return [programme(p) for p in (data or {}).get("epg_listings") or []] if isinstance(data, dict) else []

    def channel_epg(self, stream_id):
        """All the programmes the service has for a channel, past (catch-up) and to come."""
        data = self.cached(30 * MINUTE, action="get_simple_data_table", stream_id=stream_id)
        return [programme(p) for p in (data or {}).get("epg_listings") or []] if isinstance(data, dict) else []

    # ------------------------------------------------------------------ addresses

    def live_url(self, stream_id):
        return "%s/live/%s/%s/%s.%s" % (self.server, self.q(self.username), self.q(self.password), stream_id,
                                        self.live_ext)

    def movie_url(self, stream_id, ext):
        return "%s/movie/%s/%s/%s.%s" % (self.server, self.q(self.username), self.q(self.password), stream_id,
                                         ext or "mp4")

    def episode_url(self, episode_id, ext):
        return "%s/series/%s/%s/%s.%s" % (self.server, self.q(self.username), self.q(self.password), episode_id,
                                          ext or "mp4")

    def catchup_url(self, stream_id, start, minutes):
        """start: the programme's start as the service gives it ("2026-09-25 20:00:00",
        in the service's own time zone)."""
        stamp = "%s:%s" % (start[:10], start[11:16].replace(":", "-"))  # 2026-09-25:20-00
        return "%s/timeshift/%s/%s/%d/%s/%s.ts" % (self.server, self.q(self.username), self.q(self.password),
                                                   max(1, int(minutes)), stamp, stream_id)

    def playlist_url(self):
        return "%s/get.php?%s" % (self.server, urllib.parse.urlencode(
            {"username": self.username, "password": self.password, "type": "m3u_plus", "output": "ts"}))

    def epg_url(self):
        return "%s/xmltv.php?%s" % (self.server, urllib.parse.urlencode(
            {"username": self.username, "password": self.password}))

    @staticmethod
    def q(part):
        return urllib.parse.quote(part, safe="")


def fetch_json(url, timeout=20, monitor=None):
    request = urllib.request.Request(url, headers={"User-Agent": xbmc.getUserAgent(),
                                                   "Accept-Encoding": "gzip"})
    try:
        with urllib.request.urlopen(request, timeout=timeout, context=ssl_context()) as reply:
            chunks = []
            while True:
                if monitor is not None and monitor.abortRequested():
                    raise Error("stopping")
                chunk = reply.read(256 * 1024)
                if not chunk:
                    break
                chunks.append(chunk)
            body = b"".join(chunks)
            if (reply.headers.get("Content-Encoding") or "").lower() in ("gzip", "x-gzip", "deflate") \
                    or body[:2] == b"\x1f\x8b":
                body = zlib.decompress(body, zlib.MAX_WBITS | 32)
    except urllib.error.HTTPError as exc:
        raise Error("HTTP %d" % exc.code)
    except (OSError, ValueError, ssl.SSLError, zlib.error) as exc:
        raise Error(repr(exc))
    try:
        return json.loads(body.decode("utf-8", "replace") or "null")
    except ValueError:
        raise Error("not JSON")


def b64(text):
    """EPG titles and descriptions come base64-encoded."""
    if not text:
        return ""
    try:
        return base64.b64decode(text).decode("utf-8", "replace").strip()
    except (ValueError, TypeError):
        return text


def programme(p):
    def stamp(value, fallback):
        try:
            return int(value)
        except (TypeError, ValueError):
            return fallback
    start = stamp(p.get("start_timestamp"), 0)
    return {"title": b64(p.get("title")), "plot": b64(p.get("description")), "start": start,
            "stop": stamp(p.get("stop_timestamp"), start), "start_text": p.get("start") or "",
            "archive": str(p.get("has_archive") or "0") == "1", "now": str(p.get("now_playing") or "0") == "1"}


def number(value, default=0):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def rating(value):
    try:
        r = float(value)
        return r if 0 < r <= 10 else 0.0
    except (TypeError, ValueError):
        return 0.0


YEAR = re.compile(r"[\(\[](\d{4})[\)\]]\s*$|\s-\s(\d{4})\s*$")


def year_of(entry):
    """A film's year: its own field, or "(2020)" at the end of its name."""
    for key in ("year", "releaseDate", "releasedate", "release_date"):
        y = str(entry.get(key) or "")[:4]
        if y.isdigit() and 1900 < int(y) < 2100:
            return int(y)
    m = YEAR.search(entry.get("name") or "")
    return int(m.group(1) or m.group(2)) if m else 0


def clean_name(name):
    """"Film Name (2020)" -> "Film Name"."""
    return YEAR.sub("", name or "").strip() or (name or "")
