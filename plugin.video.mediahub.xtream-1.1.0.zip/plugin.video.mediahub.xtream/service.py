"""MediaHub IPTV - in the background while Kodi runs.

- Notes how far into a film or episode from the add-on you are (store.Tracker).
- Fetches the plots and backdrops of the films on the page you're looking at
  (the film lists only have names and posters), then refreshes the page.
- Once a day, while nothing plays, reads the list of channels, films and series
  for Search, Catch-up, Recently added and MediaHub's home rows (store.build).

Requests from here wait at most a few seconds, and it checks between each one
whether Kodi wants it to stop, so Kodi never has to force it.
"""
import json
import os
import sys
import threading
import time

import xbmc
import xbmcgui

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import store  # noqa: E402
import xtream  # noqa: E402

EVERY_DAY = 24 * 3600
FIRST_BUILD = 90  # seconds after Kodi starts before the first daily read
CHANNELS_EVERY = 30 * 60  # what's on your favourite channels, for MediaHub's row


def watching():
    """Something plays full screen (not MediaHub's trailer previews on the home
    screen): leave the network and the disk alone until it ends."""
    return xbmc.getCondVisibility("Player.HasMedia + Window.IsActive(fullscreenvideo)")


class Service(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.tracker = store.Tracker()
        self.worker = None
        self.started = time.time()
        self.next_build_check = self.started + FIRST_BUILD
        self.changed = None  # MHX.Changed when home.json was last written
        self.home_written = 0.0

    def busy(self):
        return self.worker is not None and self.worker.is_alive()

    def run_in_background(self, target, *args):
        self.worker = threading.Thread(target=self.guard, args=(target,) + args, daemon=True)
        self.worker.start()

    @staticmethod
    def guard(target, *args):
        try:
            target(*args)
        except Exception as exc:  # (never take the service down)
            xbmc.log("MediaHub IPTV: %r" % exc, xbmc.LOGERROR)

    def fetch_wanted(self, request):
        acc = xtream.Account()
        if not acc.ready():
            return
        got = 0
        for vod_id in request.get("ids") or []:
            if self.abortRequested():
                return
            if acc.peek(action="get_vod_info", vod_id=vod_id) is not None:
                continue
            try:
                acc.vod_info(vod_id, timeout=4, monitor=self)
                got += 1
            except xtream.Error:
                pass
            if self.waitForAbort(0.2):
                return
        if got and xbmc.getInfoLabel("Container.FolderPath") == request.get("path"):
            xbmc.executebuiltin("Container.Refresh")

    def build(self):
        acc = xtream.Account()
        if store.build(acc, self, timeout=4):
            # (the newest films' plots and backdrops, for MediaHub's IPTV: New Movies row)
            self.fetch_wanted({"ids": [e["id"] for e in store.recent("vod", 20, kids=False)]})
            store.check_new_episodes(acc, self)
            self.write_home()

    def write_home(self):
        self.home_written = time.time()
        store.write_home(xtream.Account(), self)

    def tick(self):
        home = xbmcgui.Window(10000)
        self.tracker.tick()
        if self.busy():
            return
        want = home.getProperty("MHX.Want")
        if want:
            home.clearProperty("MHX.Want")
            try:
                self.run_in_background(self.fetch_wanted, json.loads(want))
            except ValueError:
                pass
            return
        changed = home.getProperty("MHX.Changed")
        if changed != self.changed and not watching():
            self.changed = changed  # (progress, hidden categories: MediaHub's home rows)
            self.run_in_background(self.write_home)
            return
        if time.time() - self.home_written > CHANNELS_EVERY and store.favourites() and \
                not watching():
            self.run_in_background(self.write_home)  # (what's on your channels now)
            return
        asked = home.getProperty("MHX.Build")
        now = time.time()
        if asked or now >= self.next_build_check:
            home.clearProperty("MHX.Build")
            self.next_build_check = now + 3600
            if xtream.Account().ready() and not watching() and \
                    (asked or now - store.built() > EVERY_DAY):
                self.run_in_background(self.build)

    def run(self):
        while not self.waitForAbort(1):
            try:
                self.tick()
            except Exception as exc:
                xbmc.log("MediaHub IPTV: %r" % exc, xbmc.LOGERROR)
        self.tracker.finish()


if __name__ == "__main__":
    Service().run()
