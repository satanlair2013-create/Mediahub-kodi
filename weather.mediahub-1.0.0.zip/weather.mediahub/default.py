"""MediaHub Weather - Kodi's weather from Open-Meteo (free, no account or key).

Kodi runs this with a location's number (1-3) to fetch its weather, and it fills in
the Weather window's properties the way Kodi and skins expect: Kodi's own
Weather.* labels (the temperature in your region's unit), Current.*, Day0-6.*
(Kodi's forecast), and Daily.1-7.* and Hourly.1-24.* for skins that show more
(ready to show, in your region's units). "Location1" (etc.) as the argument asks
for a town, from the add-on's settings.
"""
import datetime
import json
import os
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
BASE = os.environ.get("MEDIAHUB_OPENMETEO")  # (a test server can stand in)
GEOCODE = (BASE or "https://geocoding-api.open-meteo.com") + "/v1/search"
FORECAST = (BASE or "https://api.open-meteo.com") + "/v1/forecast"
CERTS = "special://xbmc/system/certs/cacert.pem"
WINDOW = xbmcgui.Window(12600)
LOCATIONS = 3
HOURS = 24

# WMO weather codes -> (Kodi's icon by day, by night, text id)
KINDS = [((0,), 32, 31, 30020), ((1,), 34, 33, 30021), ((2,), 30, 29, 30022), ((3,), 26, 26, 30023),
         ((45, 48), 20, 20, 30024), ((51, 53, 55), 9, 9, 30025), ((56, 57), 8, 8, 30026),
         ((61, 63), 11, 11, 30027), ((65,), 12, 12, 30028), ((66, 67), 10, 10, 30029),
         ((71, 73, 77), 14, 14, 30030), ((75,), 16, 16, 30031), ((80, 81), 11, 11, 30032),
         ((82,), 12, 12, 30033), ((85, 86), 13, 13, 30034), ((95,), 4, 4, 30035), ((96, 99), 3, 3, 30036)]
DIRECTIONS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def ssl_context():
    certs = xbmcvfs.translatePath(CERTS)
    try:
        return ssl.create_default_context(cafile=certs) if os.path.exists(certs) else ssl.create_default_context()
    except (OSError, ssl.SSLError):
        return ssl.create_default_context()


def get_json(url):
    request = urllib.request.Request(url, headers={"User-Agent": xbmc.getUserAgent()})
    try:
        with urllib.request.urlopen(request, timeout=15, context=ssl_context()) as reply:
            return json.loads(reply.read(4 * 1024 * 1024).decode("utf-8"))
    except (OSError, ValueError, urllib.error.URLError, ssl.SSLError) as exc:
        xbmc.log("MediaHub Weather: %r" % exc, xbmc.LOGWARNING)
        return None


def kind(code, day=True):
    found = next((k for k in KINDS if code in k[0]), None)
    if not found:
        return "na", "na", ""
    icon = found[1] if day else found[2]
    return "%s.png" % icon, str(icon), text(found[3])


# --------------------------------------------------------------------------- units (the region's)

def fahrenheit():
    return "F" in (xbmc.getRegion("tempunit") or "").upper()


def temperature(celsius):
    if celsius is None:
        return ""
    value = celsius * 9 / 5 + 32 if fahrenheit() else celsius
    return "%d%s" % (round(value), xbmc.getRegion("tempunit") or "°C")


def speed(kmh):
    unit = (xbmc.getRegion("speedunit") or "km/h").lower()
    factors = {"mph": 0.621371, "m/s": 1 / 3.6, "kts": 0.539957, "km/h": 1.0, "kmh": 1.0, "beaufort": None}
    factor = factors.get(unit, 1.0)
    if factor is None:
        beaufort = next((n for n, top in enumerate((1, 6, 12, 20, 29, 39, 50, 62, 75, 89, 103, 118)) if kmh < top), 12)
        return "%d Bft" % beaufort
    return "%d %s" % (round(kmh * factor), xbmc.getRegion("speedunit") or "km/h")


def clock(stamp):
    """"14:00" (or "2:00 PM") from Open-Meteo's local "2026-09-26T14:00"."""
    try:
        when = datetime.datetime.strptime(stamp, "%Y-%m-%dT%H:%M")
    except (TypeError, ValueError):
        return ""
    return when.strftime(xbmc.getRegion("time").replace(":%S", "").replace("%H%H", "%H"))


def day_name(date, n):
    if n == 0:
        return xbmc.getLocalizedString(33006)  # Today
    try:
        return datetime.datetime.strptime(date, "%Y-%m-%d").strftime("%A")
    except (TypeError, ValueError):
        return ""


# --------------------------------------------------------------------------- towns

def find_town():
    """Settings > Location n: search for a town, pick it, keep its name and place."""
    setting = sys.argv[1]
    words = xbmcgui.Dialog().input(text(30011))
    if not words:
        return
    reply = get_json("%s?%s" % (GEOCODE, urllib.parse.urlencode({"name": words, "count": 10, "format": "json",
                                                                   "language": xbmc.getLanguage(xbmc.ISO_639_1)})))
    results = (reply or {}).get("results") or []
    if reply is None:
        return xbmcgui.Dialog().ok(ADDON.getAddonInfo("name"), text(30013))
    if not results:
        return xbmcgui.Dialog().ok(ADDON.getAddonInfo("name"), text(30012) % words)
    labels = [", ".join(x for x in (r.get("name"), r.get("admin1"), r.get("country")) if x) for r in results]
    pick = xbmcgui.Dialog().select(text(30011), labels)
    if pick < 0:
        return
    r = results[pick]
    ADDON.setSetting(setting, ", ".join(x for x in (r.get("name"), r.get("country")) if x))
    ADDON.setSetting(setting + "Lat", str(r["latitude"]))
    ADDON.setSetting(setting + "Lon", str(r["longitude"]))
    refresh_kodi()


def rpc_setting(value=None):
    method = "Settings.GetSettingValue" if value is None else "Settings.SetSettingValue"
    params = {"setting": "weather.addon"} if value is None else {"setting": "weather.addon", "value": value}
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return (reply.get("result") or {}).get("value") if value is None else None


def refresh_kodi():
    """Kodi only asks again when its weather setting changes (Weather.Refresh waits for its
    own timer): so, when this is Kodi's weather, set it again."""
    if rpc_setting() == ADDON.getAddonInfo("id"):
        rpc_setting("")
        rpc_setting(ADDON.getAddonInfo("id"))


# --------------------------------------------------------------------------- the weather

def clear_forecast():
    for name in ("Current.IsFetched", "Today.IsFetched", "Daily.IsFetched", "Hourly.IsFetched",
                 "Forecast.IsFetched"):
        WINDOW.clearProperty(name)


def set_locations():
    count = 0
    for n in range(1, LOCATIONS + 1):
        name = ADDON.getSetting("Location%d" % n)
        if name:
            count += 1
            WINDOW.setProperty("Location%d" % n, name)
        else:
            WINDOW.clearProperty("Location%d" % n)
    WINDOW.setProperty("Locations", str(count))
    WINDOW.setProperty("WeatherProvider", "Open-Meteo")
    WINDOW.setProperty("WeatherProviderLogo", xbmcvfs.translatePath(
        os.path.join(ADDON.getAddonInfo("path"), "resources", "icon.png")))
    return count


def forecast(n):
    name = ADDON.getSetting("Location%d" % n)
    lat, lon = ADDON.getSetting("Location%dLat" % n), ADDON.getSetting("Location%dLon" % n)
    if not name or not lat or not lon:
        clear_forecast()
        return
    query = {"latitude": lat, "longitude": lon, "timezone": "auto", "forecast_days": 7, "forecast_hours": HOURS,
             "current": "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,"
                        "cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m,dew_point_2m",
             "hourly": "temperature_2m,weather_code,precipitation_probability,is_day",
             "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,"
                      "sunrise,sunset,uv_index_max,wind_speed_10m_max"}
    reply = get_json("%s?%s" % (FORECAST, urllib.parse.urlencode(query)))
    current = (reply or {}).get("current") or {}
    if current.get("temperature_2m") is None:
        clear_forecast()
        return
    daily = reply.get("daily") or {}
    hourly = reply.get("hourly") or {}
    w = WINDOW.setProperty

    def at(values, i, default=None):
        return values[i] if isinstance(values, list) and i < len(values) and values[i] is not None else default

    w("Location", name)
    w("Current.Location", name)
    w("Updated", time.strftime("%s %s" % (xbmc.getRegion("dateshort"), xbmc.getRegion("time").replace(":%S", ""))))
    icon, fanart, words = kind(current.get("weather_code"), bool(current.get("is_day", 1)))
    # (Kodi's own labels: numbers in Celsius and km/h, which Kodi turns into the region's units)
    w("Current.Condition", words)
    w("Current.Temperature", str(round(current["temperature_2m"])))
    w("Current.FeelsLike", str(round(current.get("apparent_temperature") or current["temperature_2m"])))
    w("Current.DewPoint", str(round(current.get("dew_point_2m") or 0)))
    w("Current.Humidity", str(round(current.get("relative_humidity_2m") or 0)))  # (Kodi adds the %)
    w("Current.Wind", str(round(current.get("wind_speed_10m") or 0)))
    w("Current.WindDirection", DIRECTIONS[int(((current.get("wind_direction_10m") or 0) + 11.25) // 22.5) % 16])
    # (and ready to show, in the region's units, for MediaHub's weather page)
    w("Current.FeelsLike.Text", temperature(current.get("apparent_temperature") or current["temperature_2m"]))
    w("Current.Wind.Text", "%s  %s" % (speed(current.get("wind_speed_10m") or 0),
                                       DIRECTIONS[int(((current.get("wind_direction_10m") or 0) + 11.25) // 22.5) % 16]))
    w("Current.UVIndex", str(round(at(daily.get("uv_index_max"), 0, 0))))
    w("Current.Precipitation", "%s mm" % (current.get("precipitation") or 0))
    w("Current.Cloudiness", "%d%%" % round(current.get("cloud_cover") or 0))
    w("Current.Pressure", "%d mb" % round(current.get("pressure_msl") or 0))
    w("Current.OutlookIcon", icon)
    w("Current.FanartCode", fanart)
    w("Today.Sunrise", clock(at(daily.get("sunrise"), 0, "")))
    w("Today.Sunset", clock(at(daily.get("sunset"), 0, "")))
    dates = daily.get("time") or []
    for i in range(7):
        date = at(dates, i, "")
        icon, fanart, words = kind(at(daily.get("weather_code"), i), True)
        high, low = at(daily.get("temperature_2m_max"), i), at(daily.get("temperature_2m_min"), i)
        # Kodi's forecast (Day0-6): Celsius numbers
        w("Day%d.Title" % i, day_name(date, i))
        w("Day%d.HighTemp" % i, str(round(high)) if high is not None else "")
        w("Day%d.LowTemp" % i, str(round(low)) if low is not None else "")
        w("Day%d.Outlook" % i, words)
        w("Day%d.OutlookIcon" % i, icon)
        w("Day%d.FanartCode" % i, fanart)
        # skins' daily forecast (Daily.1-7): ready to show
        d = "Daily.%d." % (i + 1)
        w(d + "ShortDay", day_name(date, i)[:3] if i else day_name(date, i))
        w(d + "LongDay", day_name(date, i))
        w(d + "ShortDate", date[5:].replace("-", "/") if date else "")
        w(d + "HighTemperature", temperature(high))
        w(d + "LowTemperature", temperature(low))
        w(d + "Outlook", words)
        w(d + "OutlookIcon", icon)
        w(d + "FanartCode", fanart)
        w(d + "Precipitation", "%d%%" % (at(daily.get("precipitation_probability_max"), i, 0)))
        w(d + "WindSpeed", speed(at(daily.get("wind_speed_10m_max"), i, 0)))
    for i in range(HOURS):
        h = "Hourly.%d." % (i + 1)
        stamp = at(hourly.get("time"), i, "")
        icon, fanart, words = kind(at(hourly.get("weather_code"), i), bool(at(hourly.get("is_day"), i, 1)))
        w(h + "Time", clock(stamp))
        w(h + "Temperature", temperature(at(hourly.get("temperature_2m"), i)))
        w(h + "Outlook", words)
        w(h + "OutlookIcon", icon)
        w(h + "FanartCode", fanart)
        w(h + "Precipitation", "%d%%" % (at(hourly.get("precipitation_probability"), i, 0)))
    for name in ("Current.IsFetched", "Today.IsFetched", "Daily.IsFetched", "Hourly.IsFetched", "Forecast.IsFetched"):
        w(name, "true")


if __name__ == "__main__":
    argument = sys.argv[1] if len(sys.argv) > 1 else ""
    if argument.startswith("Location"):
        find_town()
    else:
        if set_locations():
            forecast(int(argument) if argument.isdigit() and 0 < int(argument) <= LOCATIONS else 1)
        else:
            clear_forecast()
