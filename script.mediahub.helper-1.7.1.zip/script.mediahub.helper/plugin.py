"""MediaHub Helper - the On demand pages (plugin://script.mediahub.helper/), and
the add-on folder picker for custom home rows (?mode=pickrow&n=<1-3>).

The pages read the list resources/lib/ondemand.py builds from the IPTV playlist:
TV Shows > A-Z > show > season > episodes, Movies > A-Z, and Search. Everything
is paged, so a catalogue of hundreds of thousands of entries stays light.
"""
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import ondemand  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
PAGE = 200
LETTERS = ["#"] + [chr(c) for c in range(ord("A"), ord("Z") + 1)]
ADDON = xbmcaddon.Addon()
ONDEMAND = ADDON.getLocalizedString(32140)


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)


def folder(label, target, icon="DefaultFolder.png", label2="", art=None):
    item = xbmcgui.ListItem(label, label2)
    item.setArt(dict({"icon": icon, "thumb": icon}, **(art or {})))
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=True)


def playable(row, kind):
    """A list item that plays the entry's address directly."""
    _id, show, season, episode, title, year, logo, grp, address = row
    if kind == "episode":
        title = title or "%s %d" % (xbmc.getLocalizedString(20359), episode)  # "Episode 3"
        label = "%dx%02d. %s" % (season, episode, title)
    else:
        label = "%s (%d)" % (title, year) if year else title
    item = xbmcgui.ListItem(label)
    tag = item.getVideoInfoTag()
    tag.setTitle(title or label)
    tag.setMediaType(kind)
    if kind == "episode":
        tag.setTvShowTitle(show)
        tag.setSeason(season)
        tag.setEpisode(episode)
    elif year:
        tag.setYear(year)
    if grp:
        tag.setGenres([grp])
    if logo:
        item.setArt({"thumb": logo, "poster": logo, "icon": logo})
    xbmcplugin.addDirectoryItem(HANDLE, address, item, isFolder=False)


def end(content="", title=""):
    """Finish the page: in the order given (A-Z already), titled On demand / the show."""
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.setPluginCategory(HANDLE, title or ONDEMAND)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED, labelMask="%L")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)


# --------------------------------------------------------------------------- pages

def root():
    info = ondemand.built()
    if info:
        _, shows, episodes, movies = info
        folder(text(32131), url(mode="letters", kind="episode"), "DefaultTVShows.png", "%d" % shows)
        folder(text(32132), url(mode="letters", kind="movie"), "DefaultMovies.png", "%d" % movies)
        folder(xbmc.getLocalizedString(137), url(mode="search"), "DefaultAddonsSearch.png")
        folder(text(32133), url(mode="build"), "DefaultAddonsUpdates.png")
    elif ondemand.playlists():
        folder(text(32134), url(mode="build"), "DefaultAddonsUpdates.png")
    else:
        folder(text(32135), url(mode="none"), "DefaultIconInfo.png")
    end()


def letters(kind):
    con = ondemand.connect()
    try:
        col = "COUNT(DISTINCT showkey)" if kind == "episode" else "COUNT(*)"
        counts = dict(con.execute("SELECT letter, %s FROM items WHERE kind=? GROUP BY letter" % col, (kind,)))
    finally:
        con.close()
    for letter in LETTERS:
        if counts.get(letter):
            folder(letter, url(mode="shows" if kind == "episode" else "movies", letter=letter),
                   "DefaultFolder.png", str(counts[letter]))
    end(title=text(32131 if kind == "episode" else 32132))


def next_page(mode, page, **params):
    folder("[B]%s >[/B]" % xbmc.getLocalizedString(33078), url(mode=mode, page=page + 1, **params),
           "DefaultFolder.png")


def shows(letter, page):
    con = ondemand.connect()
    try:
        rows = con.execute("SELECT showkey, MIN(show), COUNT(*), MAX(logo) FROM items WHERE kind='episode' AND letter=?"
                           " GROUP BY showkey ORDER BY showkey LIMIT ? OFFSET ?",
                           (letter, PAGE + 1, page * PAGE)).fetchall()
    finally:
        con.close()
    for key, name, count, logo in rows[:PAGE]:
        art = {"poster": logo, "thumb": logo} if logo else None
        folder(name, url(mode="seasons", show=key), "DefaultTVShows.png", "%d" % count, art)
    if len(rows) > PAGE:
        next_page("shows", page, letter=letter)
    end("tvshows", "%s: %s" % (text(32131), letter))


def seasons(key):
    con = ondemand.connect()
    try:
        rows = con.execute("SELECT season, COUNT(*), MAX(logo), MIN(show) FROM items WHERE showkey=?"
                           " AND kind='episode' GROUP BY season ORDER BY season", (key,)).fetchall()
    finally:
        con.close()
    if len(rows) == 1:
        return episodes(key, rows[0][0])
    for season, count, logo, name in rows:
        art = {"poster": logo, "thumb": logo} if logo else None
        folder("%s %d" % (xbmc.getLocalizedString(20373), season), url(mode="episodes", show=key, season=season),
               "DefaultTVShows.png", "%d" % count, art)
    end("seasons", rows[0][3] if rows else "")


def episodes(key, season):
    con = ondemand.connect()
    try:
        rows = con.execute("SELECT id, show, season, episode, title, year, logo, grp, url FROM items"
                           " WHERE showkey=? AND season=? AND kind='episode' ORDER BY episode, id",
                           (key, int(season))).fetchall()
    finally:
        con.close()
    for row in rows:
        playable(row, "episode")
    end("episodes", "%s - %s %d" % (rows[0][1], xbmc.getLocalizedString(20373), int(season)) if rows else "")


def movies(letter, page):
    con = ondemand.connect()
    try:
        rows = con.execute("SELECT id, show, season, episode, title, year, logo, grp, url FROM items"
                           " WHERE kind='movie' AND letter=? ORDER BY showkey, year LIMIT ? OFFSET ?",
                           (letter, PAGE + 1, page * PAGE)).fetchall()
    finally:
        con.close()
    for row in rows[:PAGE]:
        playable(row, "movie")
    if len(rows) > PAGE:
        next_page("movies", page, letter=letter)
    end("movies", "%s: %s" % (text(32132), letter))


def search():
    words = ARGS.get("q") or xbmcgui.Dialog().input(xbmc.getLocalizedString(137))
    if not words:
        return end()
    like = "%" + ondemand.sort_key(words) + "%"
    con = ondemand.connect()
    try:
        found_shows = con.execute("SELECT showkey, MIN(show), COUNT(*), MAX(logo) FROM items WHERE kind='episode'"
                                  " AND showkey LIKE ? GROUP BY showkey ORDER BY showkey LIMIT 100", (like,)).fetchall()
        found_movies = con.execute("SELECT id, show, season, episode, title, year, logo, grp, url FROM items"
                                   " WHERE kind='movie' AND showkey LIKE ? ORDER BY showkey LIMIT 200",
                                   (like,)).fetchall()
    finally:
        con.close()
    for key, name, count, logo in found_shows:
        art = {"poster": logo, "thumb": logo} if logo else None
        folder(name, url(mode="seasons", show=key), "DefaultTVShows.png", "%d" % count, art)
    for row in found_movies:
        playable(row, "movie")
    end("videos", "%s: %s" % (xbmc.getLocalizedString(137), words))


def build():
    xbmcgui.Window(10000).setProperty("MH.Req.Action", "ondemandbuild")
    end()


# --------------------------------------------------------------------------- custom rows from add-ons

def rpc(method, **params):
    import json
    reply = json.loads(xbmc.executeJSONRPC(json.dumps(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return reply.get("result", {})


def pick_row(n):
    """Choose a folder of any video add-on for custom row n (Skin.String(MH.CustomRow<n>.Path))."""
    addons = rpc("Addons.GetAddons", type="xbmc.addon.video", enabled=True,
                 properties=["name"]).get("addons", [])
    addons = sorted((a for a in addons if a["addonid"] != "script.mediahub.helper"), key=lambda a: a["name"].lower())
    if not addons:
        xbmcgui.Dialog().notification("MediaHub", text(32136), xbmcgui.NOTIFICATION_INFO, 4000, False)
        return
    pick = xbmcgui.Dialog().select(text(32137), [a["name"] for a in addons])
    if pick < 0:
        return
    path, name = "plugin://%s/" % addons[pick]["addonid"], addons[pick]["name"]
    trail = []
    while True:
        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
        try:
            items = rpc("Files.GetDirectory", directory=path, media="video").get("files", [])
        finally:
            xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
        folders = [f for f in items if f.get("filetype") == "directory"]
        if not folders and trail:  # (nothing further down: this is the one)
            break
        choices = ["[B]%s[/B]" % (text(32138) % name)] + [f["label"] for f in folders]
        pick = xbmcgui.Dialog().select(name, choices)
        if pick < 0:
            if not trail:
                return
            path, name = trail.pop()
            continue
        if pick == 0:
            break
        trail.append((path, name))
        path, name = folders[pick - 1]["file"], folders[pick - 1]["label"]
    xbmc.executebuiltin('Skin.SetString(MH.CustomRow%d.Path,"%s")' % (n, path.replace('"', '\\"')))
    if not xbmc.getInfoLabel("Skin.String(MH.CustomRow%d.Name)" % n):
        xbmc.executebuiltin('Skin.SetString(MH.CustomRow%d.Name,"%s")' % (n, name.replace('"', "'")))
    xbmcgui.Dialog().notification("MediaHub", text(32139) % name, xbmcgui.NOTIFICATION_INFO, 3000, False)


def main():
    mode = ARGS.get("mode", "root")
    if mode == "pickrow":
        return pick_row(int(ARGS.get("n", "1")))
    if mode == "root":
        return root()
    if mode == "build":
        return build()
    if mode == "none":
        return end()
    if not ondemand.built():
        return root()
    if mode == "letters":
        return letters(ARGS.get("kind", "episode"))
    if mode == "shows":
        return shows(ARGS.get("letter", "#"), int(ARGS.get("page", "0")))
    if mode == "seasons":
        return seasons(ARGS.get("show", ""))
    if mode == "episodes":
        return episodes(ARGS.get("show", ""), ARGS.get("season", "1"))
    if mode == "movies":
        return movies(ARGS.get("letter", "#"), int(ARGS.get("page", "0")))
    if mode == "search":
        return search()
    return root()


if __name__ == "__main__":
    main()
