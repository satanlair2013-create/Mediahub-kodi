"""MediaHub Helper - My channels: the Live TV channels you pick, as a home row.

"My channels: add / remove" in the context menu of a channel (context.py) keeps
the channel in mychannels.json. The service fills the home row (skin:
MyChannelsRow) from it, with what's on now and next, and keeps that current -
properties, like the other helper rows, so showing Home runs no add-on script.
Selecting a card sends MH.Req.Action = playchannel|<channel id>.
"""
import calendar
import json
import os
import time

import xbmc
import xbmcgui
import xbmcvfs

FILE = "special://profile/addon_data/script.mediahub.helper/mychannels.json"
PREFIX = "MH.MyChan"
FIELDS = ("Label", "Label2", "Title", "Icon", "Next", "Percent", "ID", "NoGuide")
REFRESH = 60  # seconds between refreshes of what's on
MAX = 20  # cards in the row (MyChannelsRow has this many items)


def path():
    return xbmcvfs.translatePath(FILE)


def load():
    try:
        with open(path()) as f:
            data = json.load(f)
        return [c for c in data if isinstance(c, dict) and c.get("id")]
    except (OSError, ValueError):
        return []


def save(chans):
    p = path()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p + ".tmp", "w") as f:
        json.dump(chans[:MAX], f)
    os.replace(p + ".tmp", p)
    ids(chans)


def ids(chans=None):
    """MH.MyChannels.Ids: ",1,5," - which channels are in (the service refills the row
    when it changes), empty when none (the row hides)."""
    chans = load() if chans is None else chans
    value = "," + ",".join(str(c["id"]) for c in chans) + "," if chans else ""
    xbmcgui.Window(10000).setProperty("MH.MyChannels.Ids", value)
    return value


def toggle(entry):
    """Add the channel, or remove it if it is there. True = added."""
    chans = load()
    if any(c["id"] == entry["id"] for c in chans):
        save([c for c in chans if c["id"] != entry["id"]])
        return False
    save(chans + [entry])
    return True


def clock(stamp):
    """A broadcast's UTC "2026-09-25 18:00:00" as the local time "18:00"."""
    try:
        return time.strftime("%H:%M", time.localtime(calendar.timegm(time.strptime(stamp, "%Y-%m-%d %H:%M:%S"))))
    except (TypeError, ValueError):
        return ""


def cards():
    import mediahub
    found = []
    for chan in load()[:MAX]:
        d = mediahub.rpc("PVR.GetChannelDetails", channelid=int(chan["id"]),
                         properties=["channel", "icon", "broadcastnow", "broadcastnext", "hidden"]).get("channeldetails")
        if d and d.get("hidden"):
            continue
        d = d or {}
        now, nxt = d.get("broadcastnow") or {}, d.get("broadcastnext") or {}
        name = d.get("channel") or chan.get("name", "")
        found.append({
            "Label": name,
            "Label2": "%s - %s" % (clock(now.get("starttime")), clock(now.get("endtime"))) if now else "",
            "Title": now.get("title") or name,
            "Icon": d.get("icon") or chan.get("icon", ""),
            "Next": "%s  %s" % (clock(nxt.get("starttime")), nxt.get("title", "")) if nxt else "",
            "Percent": str(int(now.get("progresspercentage") or 0)) if now else "",
            "ID": str(chan["id"]),
            "NoGuide": "" if now else "1",
        })
    return found


def fill():
    home = xbmcgui.Window(10000)
    found = cards()
    for i in range(1, MAX + 1):
        fields = found[i - 1] if i <= len(found) else {}
        for key in FIELDS:
            home.setProperty("%s.%d.%s" % (PREFIX, i, key), fields.get(key, ""))
    home.setProperty(PREFIX + ".Count", str(len(found)))


def play(channelid):
    """playchannel|<id>: switch to the channel (by its address if the id is gone -
    the channel list was made again)."""
    import mediahub
    if mediahub.rpc("Player.Open", item={"channelid": channelid}) != "OK":
        where = next((c.get("path") for c in load() if c["id"] == channelid), "")
        if where:
            xbmc.executebuiltin('PlayMedia("%s")' % where)


def handle(action):
    if action.startswith("playchannel|") and action[12:].isdigit():
        play(int(action[12:]))
        return True
    return False


class Keeper:
    """Fill the row when the channels change, and every minute (what's on moves on)."""

    def __init__(self):
        self.next = 0
        self.filled = None

    def tick(self):
        now = time.time()
        current = xbmcgui.Window(10000).getProperty("MH.MyChannels.Ids")
        if current == self.filled and now < self.next:
            return
        self.next = now + REFRESH
        if not current:
            if self.filled:  # (the last one was removed)
                fill()
            self.filled = current
            return
        if current != self.filled or xbmc.getCondVisibility("Window.IsVisible(home)"):
            fill()
            self.filled = current
