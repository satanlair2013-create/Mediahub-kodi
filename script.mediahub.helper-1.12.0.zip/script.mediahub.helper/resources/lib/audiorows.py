"""MediaHub Helper - home rows from MediaHub Radio and MediaHub Podcasts.

Those add-ons keep ready-made cards in their home.json (Radio: Your Stations and
Radio: Recently Played; Podcasts: New Episodes and Continue Listening), with a
square picture (a station's logo, a podcast's cover). A card's action runs the
add-on: "radio|run|<plugin address>" or "podcast|run|<plugin address>".
"""
import json

import xbmc
import xbmcvfs

import mediahub

SOURCES = {"radiofavs": "plugin.audio.mediahub.radio", "radiorecent": "plugin.audio.mediahub.radio",
           "podlatest": "plugin.audio.mediahub.podcasts", "podcontinue": "plugin.audio.mediahub.podcasts"}
STAMPS = ("MHR.Home", "MHP.Home")  # (set when the add-ons write new cards)


def load(addon_id):
    try:
        with open(xbmcvfs.translatePath("special://profile/addon_data/%s/home.json" % addon_id),
                  encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def row(key):
    """The cards of one row (a function(kids) for mediahub.refresh_rows)."""
    def cards(kids):
        addon_id = SOURCES[key]
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id):
            return []
        found = [c for c in load(addon_id).get(key) or [] if isinstance(c, dict) and (not kids or c.get("kids"))]
        return [{k: v for k, v in c.items() if k != "kids"} for c in found][:mediahub.MAX_ITEMS]
    return cards


class Watcher:
    def __init__(self):
        self.seen = None

    def tick(self):
        """True when the rows should be filled again (an add-on wrote new cards)."""
        stamp = tuple(mediahub.prop(s) for s in STAMPS)
        changed, first = stamp != self.seen, self.seen is None
        self.seen = stamp
        return changed and not first


def handle(action):
    """radio|run|<address>, podcast|run|<address>."""
    parts = action.split("|", 2)
    if len(parts) != 3 or parts[0] not in ("radio", "podcast") or parts[1] != "run":
        return False
    if parts[2].startswith(("plugin://plugin.audio.mediahub.radio/", "plugin://plugin.audio.mediahub.podcasts/")):
        xbmc.executebuiltin("RunPlugin(%s)" % parts[2])
    return True
