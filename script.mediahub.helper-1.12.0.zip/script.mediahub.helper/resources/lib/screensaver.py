"""MediaHub Helper - the MediaHub screensaver.

Kodi's screensavers are separate add-ons; this one lives in the skin instead
(Custom_1112_Screensaver.xml). When the skin setting MH.Screensaver is on and
nothing has been pressed for MH.ScreensaverMinutes (default 5), and no video is
playing, the service sets MH.SS.Active and every few seconds shows another title
from the library: its fanart, logo, name and year / genre. The "Big clock" style
(MH.SS.Style, or a library with no fanart yet) shows a large clock instead
(MH.SS.Clock); both show today's weather (weather.py).

Two slots, A and B, take turns so the pictures cross-fade: the next title is
written to the hidden slot, then MH.SS.Slot flips to it.

Turning the setting on also sets Kodi's own screensaver to None (and turning it
off puts Kodi's Dim screensaver back), so the two don't fight.
"""
import json
import random
import time

import xbmc
import xbmcgui

ROTATE = 12  # seconds per title
KODI_DEFAULT = "screensaver.xbmc.builtin.dim"


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return reply.get("result", {})


def set_kodi_screensaver(on):
    """Our screensaver on -> Kodi's off, and back."""
    rpc("Settings.SetSettingValue", setting="screensaver.mode", value="" if on else KODI_DEFAULT)


class Screensaver:
    def __init__(self):
        self.active = False
        self.next_change = 0
        self.next_check = 0
        self.pool = []
        self.slot = "B"

    def home(self):
        return xbmcgui.Window(10000)

    def minutes(self):
        try:
            return max(1, int(xbmc.getInfoLabel("Skin.String(MH.ScreensaverMinutes)") or 5))
        except ValueError:
            return 5

    def load(self, kids_ok, kids):
        pool = []
        for method, key, kind in (("VideoLibrary.GetMovies", "movies", "movie"),
                                  ("VideoLibrary.GetTVShows", "tvshows", "tvshow")):
            for d in rpc(method, properties=["title", "art", "year", "genre", "mpaa"]).get(key, []):
                art = d.get("art") or {}
                if art.get("fanart") and (not kids or kids_ok(d.get("mpaa"))):
                    pool.append(d)
        random.shuffle(pool)
        self.pool = pool

    def show_next(self):
        if not self.pool:
            return
        d = self.pool.pop(0)
        self.pool.append(d)
        art = d.get("art") or {}
        self.slot = "B" if self.slot == "A" else "A"
        home = self.home()
        prefix = "MH.SS.%s." % self.slot
        home.setProperty(prefix + "Fanart", art.get("fanart", ""))
        home.setProperty(prefix + "Logo", art.get("clearlogo", ""))
        home.setProperty(prefix + "Title", d.get("title", ""))
        meta = [str(d["year"])] if d.get("year") else []
        meta += (d.get("genre") or [])[:2]
        home.setProperty(prefix + "Meta", "  •  ".join(meta))
        # give the picture a moment to load before fading to it
        xbmc.sleep(300)
        home.setProperty("MH.SS.Slot", self.slot)

    def start(self, kids_ok, kids):
        clock = xbmc.getInfoLabel("Skin.String(MH.SS.Style)") == "clock"
        self.pool = []
        if not clock:
            self.load(kids_ok, kids)
        self.active = True
        if self.pool:
            self.home().clearProperty("MH.SS.Clock")
            self.show_next()
        else:  # (the clock style, or nothing with fanart yet)
            self.home().setProperty("MH.SS.Clock", "1")
        self.home().setProperty("MH.SS.Active", "1")
        self.next_change = time.time() + ROTATE

    def stop(self):
        self.active = False
        self.home().clearProperty("MH.SS.Active")

    def tick(self, kids_ok, kids_mode):
        """Called from the service loop."""
        now = time.time()
        if now < self.next_check:
            return
        self.next_check = now + 0.5
        enabled = xbmc.getCondVisibility("Skin.HasSetting(MH.Screensaver)")
        idle = xbmc.getGlobalIdleTime()
        allowed = enabled and not xbmc.getCondVisibility("Player.HasVideo")
        if self.active:
            if not allowed or idle < self.minutes() * 60:
                self.stop()  # a button was pressed, or a video started
            elif now >= self.next_change:
                self.next_change = now + ROTATE
                self.show_next()
        elif allowed and idle >= self.minutes() * 60:
            self.start(kids_ok, kids_mode())
