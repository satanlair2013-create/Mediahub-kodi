"""MediaHub Helper - trailer previews in the home rows.

When a card in a home row keeps the focus for a few seconds, its trailer plays
in a small panel at the top of the home screen (Includes_Home.xml, RowPreview),
like the previews on Disney+ and Netflix. Moving on stops it.

Skin.String(MH.RowPreviews): "" = local trailers only (the default: a trailer from
the YouTube add-on shows Kodi's busy spinner while it loads, which blocks the
remote), "all" = any trailer, "off" = none.

The banner at the top of the home screen (the hero, list 9100) does the same
after a few seconds, silently, in its right half (MH.Preview = "hero"): Kodi is
muted while it plays and unmuted after (a file remembers that we muted it, in
case Kodi stops meanwhile). Skin.HasSetting(MH.NoHeroPreview) turns it off.
"""
import json
import os
import time

import xbmc
import xbmcgui
import xbmcvfs

STOPPING = xbmc.Monitor()  # abortRequested() once Kodi asks the helper to stop

DELAY = 4  # seconds on one card before its trailer starts
HERO_DELAY = 5
ROW_LISTS = range(9301, 9400)  # the home row lists (gen_rows.py LIST_BASE)
HERO_LIST = "9100"
MUTED_FLAG = "special://profile/addon_data/script.mediahub.helper/preview-muted"


def rpc(method, **params):
    if STOPPING.abortRequested():  # the helper is stopping (see mediahub.rpc)
        return {}
    reply = json.loads(xbmc.executeJSONRPC(json.dumps(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return reply.get("result", {})


def set_muted_flag(on):
    path = xbmcvfs.translatePath(MUTED_FLAG)
    try:
        if on:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            open(path, "w").close()
        elif os.path.exists(path):
            os.remove(path)
    except OSError:
        pass


def restore_mute():
    """At start-up: Kodi stopped while a banner preview had it muted? Unmute."""
    if os.path.exists(xbmcvfs.translatePath(MUTED_FLAG)):
        rpc("Application.SetMute", mute=False)
        set_muted_flag(False)


def home():
    return xbmcgui.Window(10000)


class Previews:
    def __init__(self):
        self.key = None
        self.since = 0.0
        self.playing = False
        self.done_key = None  # the card whose trailer already played to the end
        self.started = 0.0
        self.next_check = 0.0
        self.muted = False  # we muted Kodi for a banner preview

    def stop(self, exiting=False):
        if self.playing:
            self.playing = False
            # (Player.HasMedia, not HasVideo: the trailer may still be opening)
            if xbmc.getCondVisibility("Player.HasMedia") and \
                    home().getProperty("MH.Preview") in ("1", "hero"):
                xbmc.executebuiltin("PlayerControl(Stop)")
            for name in ("MH.Preview", "MH.Preview.Title", "MH.Preview.Logo"):
                home().clearProperty(name)
        self.unmute(exiting)

    def unmute(self, exiting=False):
        if not self.muted:
            return
        self.muted = False
        if exiting or STOPPING.abortRequested():
            # The helper is stopping: Kodi won't answer Application.SetMute now (see
            # rpc). The flag stays, so the helper unmutes Kodi when it starts again
            # (after an update, or the next time Kodi starts).
            return
        rpc("Application.SetMute", mute=False)
        set_muted_flag(False)

    def allowed(self, trailer, hero=False):
        mode = xbmc.getInfoLabel("Skin.String(MH.RowPreviews)")
        if mode == "off" or not trailer:
            return False
        if hero and xbmc.getCondVisibility("Skin.HasSetting(MH.NoHeroPreview)"):
            return False
        if trailer.startswith("plugin://plugin.video.youtube") and \
                not xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            return False  # (no YouTube add-on: nothing would play)
        remote = trailer.startswith(("plugin://", "http://", "https://"))
        return mode == "all" or not remote

    def tick(self):
        now = time.time()
        if now < self.next_check:
            return
        self.next_check = now + 0.25
        # Kodi's "busy" spinner while the trailer opens takes the focus for a
        # moment: that isn't leaving the card. (Any other dialog is.)
        if xbmc.getCondVisibility("Window.IsActive(busydialog) | Window.IsActive(busydialognocancel)"):
            return
        on_row = xbmc.getCondVisibility("Window.IsActive(home) + !Window.IsVisible(1112)")
        control = xbmc.getInfoLabel("System.CurrentControlID")
        if not on_row or not control.isdigit() or (int(control) not in ROW_LISTS and control != HERO_LIST):
            key = None
        else:
            key = (control, xbmc.getInfoLabel("ListItem.DBType"), xbmc.getInfoLabel("ListItem.DBID"),
                   xbmc.getInfoLabel("ListItem.Trailer"))
        if key != self.key:
            self.stop()
            self.key, self.since = key, now
            return
        if self.playing:
            # (give it a few seconds to start before deciding it has ended)
            if now - self.started > 6 and not xbmc.getCondVisibility("Player.HasVideo"):
                # the trailer ended; don't start it again for the same card
                self.playing = False
                for name in ("MH.Preview", "MH.Preview.Title", "MH.Preview.Logo"):
                    home().clearProperty(name)
                self.unmute()
                self.done_key = key
            return
        hero = bool(key) and key[0] == HERO_LIST
        if key and key != self.done_key and now - self.since >= (HERO_DELAY if hero else DELAY) \
                and self.allowed(key[3], hero) and not xbmc.getCondVisibility("Player.HasMedia"):
            logo = xbmc.getInfoLabel("ListItem.Art(clearlogo)") or xbmc.getInfoLabel("ListItem.Art(tvshow.clearlogo)")
            home().setProperty("MH.Preview.Title", xbmc.getInfoLabel("ListItem.Label"))
            home().setProperty("MH.Preview.Logo", logo)
            if hero and not xbmc.getCondVisibility("Player.Muted"):
                self.muted = True
                set_muted_flag(True)
                rpc("Application.SetMute", mute=True)
            home().setProperty("MH.Preview", "hero" if hero else "1")
            self.playing = True
            self.started = now
            xbmc.executebuiltin('PlayMedia("%s",1)' % key[3].replace('"', '\\"'))
