"""MediaHub Helper - Cinema mode: Home Assistant sets the room for a film.

Skin settings > Cinema mode (Home Assistant): the Home Assistant address, a
long-lived access token (Home Assistant > your profile > Security), and a scene
or script for each moment:

- MH.HA.Start: a film (or, with MH.CinemaEpisodes, an episode) starts or carries on
  after a pause, full screen (not the trailers on the home screen)
- MH.HA.Pause: it's paused
- MH.HA.End: the end credits (the last few minutes), or it stops

Each can be a scene (scene.*), a script (script.*) or an automation (automation.*,
which is triggered). Any left empty is skipped. The calls go out in the background,
so a slow or missing Home Assistant never holds up the player.
"""
import json
import threading
import urllib.error
import urllib.request

import xbmc
import xbmcgui

import mediahub

SERVICES = {"scene": ("scene", "turn_on"), "script": ("script", "turn_on"),
            "automation": ("automation", "trigger"), "light": ("light", "turn_on"),
            "switch": ("switch", "turn_on"), "input_boolean": ("input_boolean", "turn_on")}
CREDITS_MIN = 180  # seconds before the end that count as the credits (at least) ...
CREDITS_SHARE = 0.04  # ... or this share of the film, whichever is longer


def setting(name):
    return xbmc.getInfoLabel("Skin.String(%s)" % name).strip()


def call(entity, done=None):
    """Turn on / trigger one Home Assistant entity (in the background)."""
    base, token = setting("MH.HA.Url").rstrip("/"), setting("MH.HA.Token")
    if not entity or not base or not token:
        return
    domain = entity.split(".", 1)[0]
    if domain not in SERVICES:
        return
    service = "%s/api/services/%s/%s" % (base, *SERVICES[domain])

    def send():
        request = urllib.request.Request(service, data=json.dumps({"entity_id": entity}).encode(), method="POST",
                                         headers={"Authorization": "Bearer " + token,
                                                  "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(request, timeout=5) as reply:
                ok, why = 200 <= reply.status < 300, str(reply.status)
        except urllib.error.HTTPError as exc:
            ok, why = False, "HTTP %d" % exc.code
        except (OSError, ValueError) as exc:
            ok, why = False, str(getattr(exc, "reason", exc))
        if not ok:
            xbmc.log("MediaHub cinema mode: %s: %s" % (entity, why), xbmc.LOGWARNING)
        if done:
            done(ok, why)
    threading.Thread(target=send, daemon=True).start()


class Cinema:
    """Watches the player and calls the scene for each moment, once."""

    def __init__(self):
        self.state = None  # None, "playing", "paused", "credits"

    def watched(self):
        if not xbmc.getCondVisibility("Skin.HasSetting(MH.Cinema)"):
            return False
        if not xbmc.getCondVisibility("Player.HasVideo + Window.IsActive(fullscreenvideo)"):
            return False
        return xbmc.getCondVisibility("VideoPlayer.Content(movies) | [VideoPlayer.Content(episodes) + "
                                      "Skin.HasSetting(MH.CinemaEpisodes)]")

    def tick(self):
        if self.state is None:
            if self.watched():
                self.enter("playing")
            return
        if not xbmc.getCondVisibility("Player.HasVideo"):
            if self.state != "credits":
                call(setting("MH.HA.End"))
            self.state = None
            return
        if self.state == "credits":
            return
        try:
            player = xbmc.Player()
            left, total = player.getTotalTime() - player.getTime(), player.getTotalTime()
        except RuntimeError:
            return
        if total > 600 and left <= max(CREDITS_MIN, total * CREDITS_SHARE):
            self.enter("credits")
        elif xbmc.getCondVisibility("Player.Paused"):
            if self.state != "paused":
                self.enter("paused")
        elif self.state == "paused":
            self.enter("playing")

    def enter(self, state):
        self.state = state
        call(setting({"playing": "MH.HA.Start", "paused": "MH.HA.Pause", "credits": "MH.HA.End"}[state]))


def test():
    """Skin settings > Test cinema mode: the Film starts scene, then (after ten
    seconds) the end one, saying whether Home Assistant answered."""
    start, end = setting("MH.HA.Start"), setting("MH.HA.End")
    if not setting("MH.HA.Url") or not setting("MH.HA.Token") or not (start or end):
        return xbmcgui.Dialog().ok(mediahub.text(32190), mediahub.text(32191))

    def said(ok, why):
        xbmcgui.Dialog().notification(mediahub.text(32190), mediahub.text(32192) if ok else mediahub.text(32193) % why,
                                      xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_WARNING, 5000)
    call(start or end, said)
    if start and end:
        threading.Timer(10, call, args=(end,)).start()
