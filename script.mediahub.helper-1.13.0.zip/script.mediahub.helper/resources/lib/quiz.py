"""MediaHub Helper - Movie quiz night.

Ten questions about the films in your library, for up to four players answering
on their phones (MediaHub Web Remote) or one player with the TV remote:

- still: a still from the film (its fanart), zoomed right in and slowly zooming out
- cast:  which film stars these actors?
- plot:  which film is this about? (its title words blanked out)
- year:  when did this film come out?

Four answers each; the faster a right answer, the more points (500 to 1000).

The game lives in Window(Home) properties, so the skin (Custom_1135_Quiz.xml) and
the Web Remote (another add-on) both see it:

  MHQ.Phase     lobby / question / reveal / end ("" when there is no game)
  MHQ.Num / MHQ.Total / MHQ.Qid / MHQ.Kind / MHQ.Question / MHQ.Image / MHQ.Spot
  MHQ.Opt1..4, MHQ.Correct (at the reveal), MHQ.Left (seconds), MHQ.Slot (A/B,
  flips every question so the skin's animations start again)
  MHQ.P<n>.Name / .Score / .Answered / .Right / .Gain / .Rank   (n = 1..4)
  MHQ.Solo      1 when it's played with the TV remote

Answers come in as MHQ.In.<n> = "<qid>|<1-4>" (a phone: the Web Remote sets it;
the TV remote: the skin sets MHQ.In.1 = "tv|<1-4>"). Phones join by setting
MHQ.P<n>.Name themselves (the Web Remote does that).
"""
import json
import random
import re
import time

import xbmc
import xbmcgui

import mediahub

WINDOW = 1135
QUESTIONS = 10
ANSWER_TIME = 20   # seconds to answer
REVEAL_TIME = 5    # seconds showing the answer
PLAYERS = 4
KINDS = ("still", "cast", "plot", "year")


def home():
    return xbmcgui.Window(10000)


def prop(name, value=None):
    if value is None:
        return home().getProperty("MHQ." + name)
    home().setProperty("MHQ." + name, str(value))
    return value


def clear(name):
    home().clearProperty("MHQ." + name)


def focus(control):
    """Move the TV remote's focus in the quiz window (its buttons change with the phase)."""
    xbmc.sleep(100)
    xbmc.executebuiltin("SetFocus(%d)" % control)


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                       "params": params})))
    return reply.get("result") or {}


# --------------------------------------------------------------------------- questions

def films(kids):
    found = rpc("VideoLibrary.GetMovies", properties=["title", "year", "art", "cast", "plot", "genre", "mpaa"])
    out = []
    for m in found.get("movies") or []:
        if kids and not mediahub.kids_ok(m.get("mpaa")):
            continue
        out.append(m)
    return out


def blank_title(plot, title):
    """The plot with the film's name (and the words in it) blanked out."""
    words = [w for w in re.findall(r"\w+", title) if len(w) > 3]
    plot = re.sub(re.escape(title), "_____", plot, flags=re.I)
    for w in words:
        plot = re.sub(r"\b%s\b" % re.escape(w), "_____", plot, flags=re.I)
    if len(plot) > 320:
        plot = plot[:320].rsplit(" ", 1)[0] + "…"
    return plot


def can_ask(kind, m):
    if kind == "still":
        return bool((m.get("art") or {}).get("fanart"))
    if kind == "cast":
        return len([c for c in m.get("cast") or [] if c.get("name")]) >= 2
    if kind == "plot":
        return len(m.get("plot") or "") > 60
    return bool(m.get("year"))


def wrong_titles(m, pool, n=3):
    """Other films to choose from: ones sharing a genre first."""
    genres = set(m.get("genre") or [])
    others = [o for o in pool if o["movieid"] != m["movieid"] and o["title"] != m["title"]]
    random.shuffle(others)
    others.sort(key=lambda o: -len(genres & set(o.get("genre") or [])))
    return [o["title"] for o in others[:n]]


def wrong_years(year):
    years = set()
    while len(years) < 3:
        guess = year + random.choice([-1, 1]) * random.randint(1, 8)
        if guess != year and guess <= time.localtime().tm_year:
            years.add(guess)
    return [str(y) for y in years]


def make_questions(pool, count=QUESTIONS):
    """[{kind, question, image, options[4], correct(1-4)}], no film asked twice."""
    questions = []
    films_left = pool[:]
    random.shuffle(films_left)
    kinds = [KINDS[i % len(KINDS)] for i in range(count)]
    random.shuffle(kinds)
    for kind in kinds:
        m = next((f for f in films_left if can_ask(kind, f)), None)
        if m is None:
            m = next((f for f in films_left if any(can_ask(k, f) for k in KINDS)), None)
            if m is None:
                break
            kind = next(k for k in KINDS if can_ask(k, m))
        films_left.remove(m)
        q = {"kind": kind, "image": "", "question": ""}
        if kind == "year":
            right = str(m["year"])
            options = wrong_years(m["year"]) + [right]
            q["question"] = mediahub.text(32209) % m["title"]
            q["image"] = (m.get("art") or {}).get("poster", "")
        else:
            right = m["title"]
            options = wrong_titles(m, pool) + [right]
            if len(options) < 4:
                continue
            if kind == "still":
                q["question"] = mediahub.text(32206)
                q["image"] = m["art"]["fanart"]
            elif kind == "cast":
                names = [c["name"] for c in sorted(m["cast"], key=lambda c: c.get("order", 99)) if c.get("name")][:3]
                q["question"] = mediahub.text(32207) % ", ".join(names)
            else:
                q["question"] = mediahub.text(32208) + "\n" + blank_title(m["plot"], m["title"])
        random.shuffle(options)
        q["options"] = options
        q["correct"] = options.index(right) + 1
        questions.append(q)
    return questions


# --------------------------------------------------------------------------- the game

class Quiz:
    def __init__(self):
        self.questions = []
        self.index = -1
        self.phase = ""
        self.until = 0
        self.started = 0
        self.answers = {}   # player -> (choice, seconds taken)
        self.opened = 0

    # the skin: MH.Req.Action quiz / quizstart / quizagain
    def open(self):
        pool = films(mediahub.kids_mode())
        if len(pool) < 4:
            xbmcgui.Dialog().ok(mediahub.text(32210), mediahub.text(32211))
            return
        self.reset()
        self.phase = prop("Phase", "lobby")
        self.opened = time.time()
        if xbmc.getCondVisibility("System.HasAddon(service.mediahub.webremote)"):
            xbmc.executebuiltin("RunScript(service.mediahub.webremote,quizqr)")
        xbmc.executebuiltin("ActivateWindow(%d)" % WINDOW)

    def reset(self):
        for name in ("Phase", "Num", "Total", "Qid", "Kind", "Question", "Image", "Spot", "Left", "Correct",
                     "Solo", "Slot", "Winner"):
            clear(name)
        for i in range(1, 5):
            clear("Opt%d" % i)
        for n in range(1, PLAYERS + 1):
            clear("In.%d" % n)
            for field in ("Name", "Score", "Answered", "Right", "Gain", "Rank", "Key"):
                clear("P%d.%s" % (n, field))
            for field in ("Name", "Score", "Rank"):
                clear("Board%d.%s" % (n, field))
        self.phase, self.index, self.questions = "", -1, []
        # the lobby's pairing code (any phone could use it) ends with the quiz
        try:
            if json.loads(home().getProperty("MHW.Pair") or "{}").get("multi"):
                home().clearProperty("MHW.Pair")
        except ValueError:
            pass
        for name in ("MHW.QuizQR", "MHW.QuizUrl", "MHW.QuizCode"):
            home().clearProperty(name)

    def players(self):
        return [n for n in range(1, PLAYERS + 1) if prop("P%d.Name" % n)]

    def start(self):
        if self.phase not in ("lobby", "end"):
            return
        pool = films(mediahub.kids_mode())
        self.questions = make_questions(pool)
        if not self.questions:
            return
        if self.phase == "end":  # play again: same players, scores back to 0
            for n in self.players():
                prop("P%d.Score" % n, 0)
                clear("P%d.Rank" % n)
            clear("Winner")
            for i in range(1, PLAYERS + 1):
                for field in ("Name", "Score", "Rank"):
                    clear("Board%d.%s" % (i, field))
        phones = [n for n in self.players() if prop("P%d.Key" % n)]
        if phones:  # (phones joined after a game with the TV remote: the TV's player goes)
            clear("Solo")
            for n in self.players():
                if n not in phones:
                    clear("P%d.Name" % n)
        else:  # nobody joined on a phone: one player, with the TV remote
            prop("Solo", 1)
            prop("P1.Name", mediahub.text(32212))
        for n in self.players():
            prop("P%d.Score" % n, 0)
        prop("Total", len(self.questions))
        self.index = -1
        self.next_question()

    def next_question(self):
        self.index += 1
        if self.index >= len(self.questions):
            return self.finish()
        q = self.questions[self.index]
        self.answers = {}
        for n in range(1, PLAYERS + 1):
            clear("In.%d" % n)
            for field in ("Answered", "Right", "Gain"):
                clear("P%d.%s" % (n, field))
        clear("Correct")
        prop("Num", self.index + 1)
        prop("Qid", "%d-%d" % (int(time.time()), self.index))
        prop("Kind", q["kind"])
        prop("Question", q["question"])
        prop("Image", q["image"])
        prop("Spot", random.randint(1, 4))
        for i, option in enumerate(q["options"], 1):
            prop("Opt%d" % i, option)
        prop("Left", ANSWER_TIME)
        prop("Slot", "B" if prop("Slot") == "A" else "A")
        self.started = time.time()
        self.until = self.started + ANSWER_TIME
        self.phase = prop("Phase", "question")
        focus(21 if prop("Solo") else 13)

    def reveal(self):
        q = self.questions[self.index]
        prop("Correct", q["correct"])
        for n in self.players():
            choice, took = self.answers.get(n, (None, None))
            right = choice == q["correct"]
            gain = 500 + int(round(500 * max(0.0, ANSWER_TIME - took) / ANSWER_TIME)) if right else 0
            prop("P%d.Right" % n, 1 if right else 0)
            prop("P%d.Gain" % n, "+%d" % gain if gain else "")
            prop("P%d.Score" % n, int(prop("P%d.Score" % n) or 0) + gain)
        prop("Left", 0)
        self.until = time.time() + REVEAL_TIME
        self.phase = prop("Phase", "reveal")

    def finish(self):
        board = sorted(self.players(), key=lambda n: -int(prop("P%d.Score" % n) or 0))
        rank, last = 0, None
        for i, n in enumerate(board, 1):
            score = int(prop("P%d.Score" % n) or 0)
            if score != last:
                rank, last = i, score
            prop("P%d.Rank" % n, rank)
            prop("Board%d.Name" % i, prop("P%d.Name" % n))
            prop("Board%d.Score" % i, score)
            prop("Board%d.Rank" % i, rank)
        if board:
            prop("Winner", prop("P%d.Name" % board[0]))
        self.phase = prop("Phase", "end")
        focus(12)

    def take_answers(self):
        qid = prop("Qid")
        for n in range(1, PLAYERS + 1):
            given = prop("In.%d" % n)
            if not given:
                continue
            clear("In.%d" % n)
            who, _, choice = given.partition("|")
            if not choice.isdigit() or n in self.answers or not prop("P%d.Name" % n):
                continue
            if who != qid and not (who == "tv" and prop("Solo")):
                continue  # (an answer to an earlier question)
            self.answers[n] = (int(choice), time.time() - self.started)
            prop("P%d.Answered" % n, 1)

    def tick(self):
        if not self.phase:
            return
        if not xbmc.getCondVisibility("Window.IsActive(%d)" % WINDOW) and time.time() - self.opened > 3:
            self.reset()  # the quiz window was closed
            return
        now = time.time()
        if self.phase == "question":
            self.take_answers()
            left = max(0, int(self.until - now + 0.99))
            if str(left) != prop("Left"):
                prop("Left", left)
            players = self.players()
            if now >= self.until or (players and all(n in self.answers for n in players)):
                self.reveal()
        elif self.phase == "reveal" and now >= self.until:
            self.next_question()

    def close(self):
        self.reset()


def handle(action, quiz):
    if action == "quiz":
        return "thread", quiz.open
    if action == "quizstart":
        return "now", quiz.start
    if action == "quizclose":
        return "now", quiz.close
    return None, None
