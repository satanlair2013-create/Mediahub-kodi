"""MediaHub Recipes - something to cook tonight, from TheMealDB.

The recipe of the day, Surprise me, recipes by kind (beef, pasta, vegetarian,
desserts...) and by country, search, and Saved recipes. A recipe opens its own
page: the ingredients, the method step by step, its video, and Cook along (one
big step at a time, with timers).
"""
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import meals  # noqa: E402
import screens  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name")
FANART = os.path.join(ADDON.getAddonInfo("path"), "resources", "fanart.jpg")
ICON = os.path.join(ADDON.getAddonInfo("path"), "resources", "icon.png")


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)


def folder(label, target, icon="DefaultFolder.png", plot="", fanart=FANART):
    item = xbmcgui.ListItem(label)
    item.setArt({"icon": icon, "thumb": icon, "poster": icon, "fanart": fanart})
    if plot:
        item.getVideoInfoTag().setPlot(plot)
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=True)


def recipe_item(r, label=None):
    item = xbmcgui.ListItem(label or r["name"])
    item.setArt({"icon": r["thumb"], "thumb": r["thumb"], "poster": r["thumb"], "landscape": r["thumb"],
                 "fanart": r["thumb"] or FANART})
    tag = item.getVideoInfoTag()
    tag.setTitle(r["name"])
    if r.get("category"):
        tag.setGenres([r["category"]])
    if r.get("method"):
        tag.setPlot(r["method"][:600])
    saved = meals.is_saved(r["id"])
    item.addContextMenuItems([(text(30031) if saved else text(30030),
                               "RunPlugin(%s)" % url(mode="save", id=r["id"], on=int(not saved)))])
    xbmcplugin.addDirectoryItem(HANDLE, url(mode="recipe", id=r["id"]), item, isFolder=False)


def end(title="", content="videos"):
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.setPluginCategory(HANDLE, title or NAME)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def careful(work):
    try:
        work()
    except meals.Error as exc:
        xbmc.log("MediaHub Recipes: %s" % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(NAME, text(30020), xbmcgui.NOTIFICATION_WARNING, 4000, False)
        if HANDLE >= 0 and ARGS.get("mode") not in ("recipe", "surprise", "save"):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


# --------------------------------------------------------------------------- pages

def root():
    try:
        r = meals.today()
        recipe_item(r, "%s: %s" % (text(30001), r["name"]))
    except meals.Error:
        pass
    item = xbmcgui.ListItem(text(30002))
    item.setArt({"icon": ICON, "thumb": ICON, "fanart": FANART})
    xbmcplugin.addDirectoryItem(HANDLE, url(mode="surprise"), item, isFolder=False)
    if meals.saved():
        folder(text(30003), url(mode="saved"), "DefaultPlaylist.png")
    folder(text(30004), url(mode="kinds"), "DefaultGenre.png")
    folder(text(30005), url(mode="countries"), "DefaultCountry.png")
    folder(xbmc.getLocalizedString(137), url(mode="search"), "DefaultAddonsSearch.png")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    end()


def kinds():
    for c in meals.categories():
        folder(c["name"], url(mode="kind", name=c["name"]), c["thumb"], c["about"])
    end(text(30004))


def countries():
    for name in meals.countries():
        folder(name, url(mode="country", name=name), "DefaultCountry.png")
    end(text(30005))


def listing(found, title):
    for r in sorted(found, key=lambda r: r["name"].lower()):
        recipe_item(r)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    end(title, "movies")


def search():
    words = ARGS.get("q")
    if not words:
        words = xbmcgui.Dialog().input(text(30006))
        if not words:
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        xbmc.executebuiltin("Container.Update(%s,replace)" % url(mode="search", q=words))
        return end()
    found = meals.search(words)
    if not found:
        xbmcgui.Dialog().notification(NAME, text(30007), ICON, 3000, False)
    listing(found, '%s: "%s"' % (xbmc.getLocalizedString(137), words))


def saved_page():
    for s in meals.saved():
        recipe_item({"id": s["id"], "name": s["name"], "thumb": s["thumb"]})
    end(text(30003), "movies")


def main():
    mode = ARGS.get("mode")
    if mode is None:
        careful(root)
    elif mode == "kinds":
        careful(kinds)
    elif mode == "countries":
        careful(countries)
    elif mode == "kind":
        careful(lambda: listing(meals.in_category(ARGS["name"]), ARGS["name"]))
    elif mode == "country":
        careful(lambda: listing(meals.from_country(ARGS["name"]), ARGS["name"]))
    elif mode == "search":
        careful(search)
    elif mode == "saved":
        saved_page()
    elif mode == "recipe":
        careful(lambda: screens.open_recipe(meals.recipe(ARGS["id"])))
    elif mode == "surprise":
        careful(lambda: screens.open_recipe(meals.surprise()))
    elif mode == "save":
        def save():
            r = meals.recipe(ARGS["id"])
            meals.set_saved(r, ARGS.get("on") == "1")
            xbmc.executebuiltin("Container.Refresh")
        careful(save)


if __name__ == "__main__":
    main()
