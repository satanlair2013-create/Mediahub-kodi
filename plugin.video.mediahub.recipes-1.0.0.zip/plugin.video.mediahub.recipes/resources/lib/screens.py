"""MediaHub Recipes' own windows (resources/skins/Default/1080i/), so they work with any skin:

- the recipe: its picture, the ingredients, the method step by step, and buttons for
  Cook along, the video (YouTube) and Save;
- Cook along: one big step at a time for across the kitchen. Left / Right (or OK)
  go through the steps, Down shows the ingredients, and Up starts a timer when
  the step says how long ("simmer for 20 minutes"). The screen saver stays off.
"""
import xbmc
import xbmcaddon
import xbmcgui

import meals

ACTION_LEFT, ACTION_RIGHT, ACTION_UP, ACTION_DOWN = 1, 2, 3, 4
ACTION_SELECT = 7
ACTION_BACK, ACTION_NAV_BACK, ACTION_MENU = 10, 92, 117
ACTION_MOUSE_LEFT = 100

BUTTON_COOK, BUTTON_VIDEO, BUTTON_SAVE = 10, 11, 12
INGREDIENTS, STEPS = 100, 300
YOUTUBE = "plugin.video.youtube"


def addon():
    return xbmcaddon.Addon(meals.ADDON_ID)


def text(string_id):
    return addon().getLocalizedString(string_id)


def ingredient_items(r):
    found = []
    for i in r["ingredients"]:
        item = xbmcgui.ListItem(i["what"], i["amount"])
        item.setArt({"icon": i["thumb"], "thumb": i["thumb"]})
        found.append(item)
    return found


def play_video(r):
    if not r.get("youtube"):
        return
    if not xbmc.getCondVisibility("System.HasAddon(%s)" % YOUTUBE):
        if xbmcgui.Dialog().yesno(addon().getAddonInfo("name"), text(30040)):
            xbmc.executebuiltin("InstallAddon(%s)" % YOUTUBE)
        return
    xbmc.executebuiltin("PlayMedia(plugin://%s/play/?video_id=%s)" % (YOUTUBE, r["youtube"]))


class Recipe(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.recipe = kwargs.pop("recipe")
        self.cook = False
        super().__init__(*args, **kwargs)

    def onInit(self):
        r = self.recipe
        self.setProperty("Name", r["name"])
        self.setProperty("Thumb", r["thumb"])
        self.setProperty("About", "  •  ".join(x for x in (r["category"], r["country"]) if x))
        self.setProperty("Tags", ", ".join(r["tags"]))
        self.setProperty("HasVideo", "1" if r.get("youtube") else "")
        self.setProperty("Count", text(30032) % (len(r["ingredients"]), len(r["steps"])))
        self.show_saved()
        self.getControl(INGREDIENTS).reset()
        self.getControl(INGREDIENTS).addItems(ingredient_items(r))
        steps = []
        for n, step in enumerate(r["steps"], 1):
            item = xbmcgui.ListItem(step, str(n))
            steps.append(item)
        self.getControl(STEPS).reset()
        self.getControl(STEPS).addItems(steps)
        self.setFocusId(BUTTON_COOK)

    def show_saved(self):
        on = meals.is_saved(self.recipe["id"])
        self.setProperty("Saved", "1" if on else "")
        self.setProperty("SaveLabel", text(30031) if on else text(30030))

    def onClick(self, control_id):
        if control_id == BUTTON_COOK:
            self.cook = True
            self.close()
        elif control_id == BUTTON_VIDEO:
            self.close()
            play_video(self.recipe)
        elif control_id == BUTTON_SAVE:
            on = not meals.is_saved(self.recipe["id"])
            meals.set_saved(self.recipe, on)
            self.show_saved()
            xbmcgui.Dialog().notification(self.recipe["name"], text(30035) if on else text(30036),
                                          self.recipe["thumb"], 2500, False)


class CookAlong(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        self.recipe = kwargs.pop("recipe")
        self.at = 0
        super().__init__(*args, **kwargs)

    def onInit(self):
        xbmc.executebuiltin("InhibitScreensaver(true)")
        r = self.recipe
        self.setProperty("Name", r["name"])
        self.setProperty("Thumb", r["thumb"])
        self.getControl(INGREDIENTS).reset()
        self.getControl(INGREDIENTS).addItems(ingredient_items(r))
        self.show()

    def show(self):
        steps = self.recipe["steps"]
        done = self.at >= len(steps)
        step = text(30037) if done else steps[self.at]
        self.setProperty("Step", step)
        self.setProperty("Small", "1" if len(step) > 230 else "")
        self.setProperty("Where", text(30038) if done else text(30033) % (self.at + 1, len(steps)))
        self.setProperty("Percent", str(int(100 * min(self.at + 1, len(steps)) / max(1, len(steps)))))
        minutes = 0 if done else meals.minutes_in(step)
        self.setProperty("Minutes", str(minutes) if minutes else "")
        self.setProperty("TimerHint", text(30034) % minutes if minutes else "")
        try:
            self.getControl(200).setWidth(int(1720 * min(self.at + 1, len(steps)) / max(1, len(steps))))
        except (RuntimeError, TypeError):
            pass

    def timer(self):
        minutes = self.getProperty("Minutes")
        if not minutes:
            return
        xbmc.executebuiltin("CancelAlarm(mhrecipe,true)")
        xbmc.executebuiltin("AlarmClock(mhrecipe,Notification(%s,%s,20000,%s),%s,true)" % (
            self.recipe["name"].replace(",", " "), text(30039).replace(",", " "), self.recipe["thumb"], minutes))
        xbmcgui.Dialog().notification(self.recipe["name"], text(30041) % int(minutes), self.recipe["thumb"], 3000, False)

    def onAction(self, action):
        act = action.getId()
        if act in (ACTION_BACK, ACTION_NAV_BACK):
            if self.getProperty("ShowIngredients"):
                return self.setProperty("ShowIngredients", "")
            xbmc.executebuiltin("InhibitScreensaver(false)")
            return self.close()
        if act in (ACTION_RIGHT, ACTION_SELECT, ACTION_MOUSE_LEFT):
            if self.at < len(self.recipe["steps"]):
                self.at += 1
                self.show()
        elif act == ACTION_LEFT:
            if self.at > 0:
                self.at -= 1
                self.show()
        elif act == ACTION_DOWN or act == ACTION_MENU:
            self.setProperty("ShowIngredients", "" if self.getProperty("ShowIngredients") else "1")
        elif act == ACTION_UP:
            self.timer()


def open_recipe(r):
    """The recipe, and then Cook along if asked."""
    path = addon().getAddonInfo("path")
    page = Recipe("mediahub-recipe.xml", path, "Default", "1080i", recipe=r)
    page.doModal()
    cook = page.cook
    del page
    if cook:
        along = CookAlong("mediahub-cookalong.xml", path, "Default", "1080i", recipe=r)
        along.doModal()
        del along
