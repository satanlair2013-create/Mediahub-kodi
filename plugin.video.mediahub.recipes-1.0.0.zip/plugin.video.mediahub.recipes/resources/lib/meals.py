"""MediaHub Recipes - recipes from TheMealDB (themealdb.com, free; its test key "1").

Kept in the add-on's data folder:
- saved.json: Saved recipes [{id, name, thumb, t}]
- cache/: answers from TheMealDB (lists for a day, recipes for a month)
- today.json: the recipe of the day
"""
import gzip
import hashlib
import json
import os
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = "plugin.video.mediahub.recipes"
API = os.environ.get("MEDIAHUB_MEALDB", "https://www.themealdb.com/api/json/v1/1").rstrip("/")
PICTURES = os.environ.get("MEDIAHUB_MEALDB_IMG", "https://www.themealdb.com/images").rstrip("/")
CERTS = "special://xbmc/system/certs/cacert.pem"
LIST_AGE = 24 * 3600
MEAL_AGE = 30 * 86400


class Error(Exception):
    pass


def text(string_id):
    return xbmcaddon.Addon(ADDON_ID).getLocalizedString(string_id)


# --------------------------------------------------------------------------- files

def profile(name=""):
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)


def load_json(name, default):
    try:
        with open(profile(name), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(name, data):
    path = profile(name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


# --------------------------------------------------------------------------- TheMealDB

def ssl_context():
    certs = xbmcvfs.translatePath(CERTS)
    try:
        return ssl.create_default_context(cafile=certs) if os.path.exists(certs) else ssl.create_default_context()
    except (OSError, ssl.SSLError):
        return ssl.create_default_context()


def get(page, max_age=LIST_AGE, **params):
    """TheMealDB's answer (kept for a while; an old copy when it can't be reached)."""
    url = "%s/%s" % (API, page) + ("?" + urllib.parse.urlencode(params) if params else "")
    cache = "cache/%s.json" % hashlib.sha1(url.encode("utf-8")).hexdigest()[:16]
    kept = load_json(cache, {})
    if "data" in kept and time.time() - kept.get("t", 0) < max_age:
        return kept["data"]
    request = urllib.request.Request(url, headers={"User-Agent": xbmc.getUserAgent(), "Accept-Encoding": "gzip"})
    try:
        with urllib.request.urlopen(request, timeout=15, context=ssl_context()) as reply:
            body = reply.read(4 * 1024 * 1024)
        if body[:2] == b"\x1f\x8b":
            body = gzip.decompress(body)
        data = json.loads(body.decode("utf-8", "replace") or "null") or {}
    except (OSError, ValueError, ssl.SSLError, urllib.error.URLError) as exc:
        if "data" in kept:
            return kept["data"]
        raise Error(repr(exc))
    if max_age:
        save_json(cache, {"data": data, "t": time.time()})
    return data


def categories():
    """[{name, thumb, about}]"""
    return [{"name": c.get("strCategory", ""), "thumb": c.get("strCategoryThumb", ""),
             "about": (c.get("strCategoryDescription") or "").strip()}
            for c in get("categories.php").get("categories") or [] if c.get("strCategory")]


def countries():
    return sorted(a["strArea"] for a in get("list.php", a="list").get("meals") or []
                  if a.get("strArea") and a["strArea"] != "Unknown")


def short(m):
    return {"id": str(m.get("idMeal", "")), "name": m.get("strMeal", ""), "thumb": m.get("strMealThumb", "")}


def in_category(name):
    return [short(m) for m in get("filter.php", c=name).get("meals") or [] if m.get("idMeal")]


def from_country(name):
    return [short(m) for m in get("filter.php", a=name).get("meals") or [] if m.get("idMeal")]


def search(words):
    return [recipe_from(m) for m in get("search.php", s=words).get("meals") or [] if m.get("idMeal")]


def steps_of(instructions):
    """The method as steps: its own lines ("STEP 1" headings dropped), or a long
    paragraph cut into two sentences at a time."""
    lines = [re.sub(r"^\s*(step\s*\d+[:.)]?|\d+[.)])\s*", "", l, flags=re.I).strip()
             for l in re.split(r"[\r\n]+", instructions or "")]
    lines = [l for l in lines if len(l) > 2 and not re.fullmatch(r"step\s*\d*", l, re.I)]
    if len(lines) > 1:
        return lines
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+(?=[A-Z])", " ".join(lines)) if s.strip()]
    return [" ".join(sentences[i:i + 2]) for i in range(0, len(sentences), 2)]


def ingredient_picture(name):
    return "%s/ingredients/%s-Small.png" % (PICTURES, urllib.parse.quote(name.strip()))


def recipe_from(m):
    parts = []
    for n in range(1, 21):
        what = (m.get("strIngredient%d" % n) or "").strip()
        if what:
            parts.append({"what": what, "amount": (m.get("strMeasure%d" % n) or "").strip(),
                          "thumb": ingredient_picture(what)})
    video = m.get("strYoutube") or ""
    found = re.search(r"(?:v=|youtu\.be/|/embed/)([\w-]{11})", video)
    return {"id": str(m.get("idMeal", "")), "name": m.get("strMeal", ""), "thumb": m.get("strMealThumb", ""),
            "category": m.get("strCategory") or "", "country": m.get("strArea") or "",
            "tags": [t for t in (m.get("strTags") or "").split(",") if t.strip()],
            "ingredients": parts, "steps": steps_of(m.get("strInstructions")),
            "method": (m.get("strInstructions") or "").strip(), "youtube": found.group(1) if found else "",
            "source": m.get("strSource") or ""}


def recipe(meal_id):
    meals = get("lookup.php", MEAL_AGE, i=meal_id).get("meals") or []
    if not meals:
        raise Error("no recipe %s" % meal_id)
    return recipe_from(meals[0])


def surprise():
    meals = get("random.php", 0).get("meals") or []
    if not meals:
        raise Error("no random recipe")
    return recipe_from(meals[0])


def today():
    """The recipe of the day (a new one each day)."""
    kept = load_json("today.json", {})
    if kept.get("day") == time.strftime("%Y-%m-%d") and kept.get("recipe"):
        return kept["recipe"]
    r = surprise()
    pick = {"id": r["id"], "name": r["name"], "thumb": r["thumb"]}
    save_json("today.json", {"day": time.strftime("%Y-%m-%d"), "recipe": pick})
    return pick


# --------------------------------------------------------------------------- saved

def saved():
    return [s for s in load_json("saved.json", []) if isinstance(s, dict) and s.get("id")]


def is_saved(meal_id):
    return any(s["id"] == meal_id for s in saved())


def set_saved(r, on):
    found = [s for s in saved() if s["id"] != r["id"]]
    if on:
        found.insert(0, {"id": r["id"], "name": r["name"], "thumb": r["thumb"], "t": time.time()})
    save_json("saved.json", found)


def minutes_in(step):
    """A step's cooking time, for its timer ("simmer for 20 minutes": 20), or 0."""
    found = re.search(r"(\d+)\s*(?:-|to)?\s*(\d+)?\s*(?:mins?|minutes)\b", step, re.I)
    if found:
        return int(found.group(2) or found.group(1))
    found = re.search(r"(\d+)\s*(?:hours?|hrs?)\b", step, re.I)
    return int(found.group(1)) * 60 if found else 0
