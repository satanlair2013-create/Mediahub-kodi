"""MediaHub Helper - home rows from the MediaHub IPTV add-on (plugin.video.mediahub.xtream).

That add-on keeps ready-made cards in its home.json: Continue Watching: IPTV,
IPTV: New Movies and IPTV: New Series. These rows show them (in Kids mode only
the ones from children's categories), and a card's action runs the add-on:
"xtream|run|<plugin address>" plays, "xtream|open|<plugin address>" opens a page.
"""
import json

import xbmc
import xbmcvfs

import mediahub

FILE = "special://profile/addon_data/plugin.video.mediahub.xtream/home.json"
ROWS = ("iptvcontinue", "iptvmovies", "iptvseries")


def load():
    try:
        with open(xbmcvfs.translatePath(FILE), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def row(key):
    """The cards of one row (a function(kids) for mediahub.refresh_rows)."""
    def cards(kids):
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.mediahub.xtream)"):
            return []
        found = [c for c in load().get(key) or [] if isinstance(c, dict) and (not kids or c.get("kids"))]
        return [{k: v for k, v in c.items() if k != "kids"} for c in found][:mediahub.MAX_ITEMS]
    return cards


class Watcher:
    """Refresh the home rows when the add-on has written new cards."""

    def __init__(self):
        self.seen = None

    def changed(self):
        stamp = mediahub.prop("MHX.Home")
        if stamp == self.seen:
            return False
        first, self.seen = self.seen is None, stamp
        return not first


def handle(action):
    """xtream|run|<address> or xtream|open|<address>."""
    if not action.startswith("xtream|"):
        return False
    parts = action.split("|", 2)
    if len(parts) == 3 and parts[2].startswith("plugin://plugin.video.mediahub.xtream/"):
        if parts[1] == "open":
            xbmc.executebuiltin("ActivateWindow(Videos,%s,return)" % parts[2])
        else:
            xbmc.executebuiltin("RunPlugin(%s)" % parts[2])
    return True
