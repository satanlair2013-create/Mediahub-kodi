"""MediaHub Helper - "update available" check for the skin and this add-on.

Reads the MediaHub repository's addons.xml (the address comes from the installed
repository.mediahub add-on, or the public site if that isn't installed) and
compares it with what's installed. When something is newer it sets:

  MH.Update.Available = 1
  MH.Update.Version   = the new skin version (or the helper's, if only it changed)
  MH.Update.News      = the <news> text of that version

and the skin shows a banner with an Update button, which sends MH.Req.Action = update.
"""
import re
import time
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDONS = ("skin.mediahub", "script.mediahub.helper")
REPO_ID = "repository.mediahub"
PUBLIC_INDEX = "https://satanlair2013-create.github.io/Mediahub-kodi/repo/addons.xml"
CHECK_EVERY = 6 * 3600


def version_tuple(v):
    return tuple(int(p) for p in re.findall(r"\d+", v or "0")[:4])


def installed_version(addon_id):
    try:
        return xbmcaddon.Addon(addon_id).getAddonInfo("version")
    except RuntimeError:  # not installed
        return ""


def index_url():
    """The addons.xml the MediaHub repository add-on reads."""
    try:
        path = xbmcvfs.translatePath(xbmcaddon.Addon(REPO_ID).getAddonInfo("path"))
        root = ET.parse(path.rstrip("/\\") + "/addon.xml").getroot()
        info = root.find(".//info")
        if info is not None and info.text:
            return info.text.strip()
    except (RuntimeError, OSError, ET.ParseError):
        pass
    return PUBLIC_INDEX


def read(url):
    # Kodi's own file layer, so https works with Kodi's certificates on every platform
    f = xbmcvfs.File(url)
    try:
        return f.read()
    finally:
        f.close()


def available():
    """{addon id: (version, news)} from the repository."""
    found = {}
    root = ET.fromstring(read(index_url()))
    for addon in root.findall("addon"):
        if addon.get("id") in ADDONS:
            news = addon.find(".//news")
            found[addon.get("id")] = (addon.get("version"), (news.text or "").strip() if news is not None else "")
    return found


def outdated():
    """[(addon id, new version, news)] for our add-ons that have a newer version."""
    result = []
    for addon_id, (version, news) in available().items():
        have = installed_version(addon_id)
        if have and version_tuple(version) > version_tuple(have):
            result.append((addon_id, version, news))
    return result


def prop(name, value):
    xbmcgui.Window(10000).setProperty(name, value)


def check(notify=True, manual=False):
    """Look for updates and tell the skin. Returns the outdated list."""
    try:
        found = outdated()
    except Exception as exc:  # offline, site down, bad XML...
        xbmc.log("MediaHub Helper: update check failed: %r" % exc, xbmc.LOGWARNING)
        prop("MH.Update.Checked", "error")
        return []
    prop("MH.Update.Checked", time.strftime("%H:%M"))
    if not found:
        prop("MH.Update.Available", "")
        prop("MH.Update.Version", "")
        prop("MH.Update.News", "")
        if manual:
            xbmcgui.Dialog().notification("MediaHub", text(32030) % installed_version("skin.mediahub"),
                                          xbmcgui.NOTIFICATION_INFO, 3000, False)
        return []
    skin = [f for f in found if f[0] == "skin.mediahub"]
    addon_id, version, news = (skin or found)[0]
    already_told = xbmcgui.Window(10000).getProperty("MH.Update.Version") == version
    prop("MH.Update.Version", version)
    prop("MH.Update.News", news)
    prop("MH.Update.Available", "1")
    if notify and not already_told:
        xbmcgui.Dialog().notification("MediaHub", text(32031) % version, xbmcgui.NOTIFICATION_INFO, 5000, False)
    return found


def text(string_id):
    return xbmcaddon.Addon().getLocalizedString(string_id)


def rpc_setting(setting, value=None):
    import json
    if value is None:
        request = {"jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue", "params": {"setting": setting}}
    else:
        request = {"jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
                   "params": {"setting": setting, "value": value}}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get("result", {})


def update(monitor):
    """Install the MediaHub updates through Kodi's own add-on installer."""
    found = check(notify=False)
    if not found:
        return
    before = {addon_id: installed_version(addon_id) for addon_id, _, _ in found}
    progress = xbmcgui.DialogProgressBG()
    progress.create("MediaHub", text(32032))
    # Kodi only installs what its repository cache knows about, so refresh it first
    xbmc.executebuiltin("UpdateAddonRepos(true)")
    for _ in range(60):
        if monitor.waitForAbort(0.5) or int(xbmc.getInfoLabel("System.AddonUpdateCount") or 0) >= len(found):
            break
    waiting = int(xbmc.getInfoLabel("System.AddonUpdateCount") or 0)
    if waiting > len(found):
        # Other add-ons have updates too: let the user pick instead of updating those as well
        progress.close()
        xbmc.executebuiltin("ActivateWindow(addonbrowser,addons://outdated/,return)")
        return
    # Only MediaHub is waiting: have Kodi install updates automatically just for this
    mode = rpc_setting("general.addonupdates").get("value", 0)
    if mode != 0:
        rpc_setting("general.addonupdates", 0)
    try:
        xbmc.executebuiltin("UpdateAddonRepos(true)")
        for step in range(120):
            progress.update(min(95, step), "MediaHub", text(32032))
            if monitor.waitForAbort(0.5):
                return
            if all(installed_version(a) != v for a, v in before.items()):
                break
    finally:
        if mode != 0:
            rpc_setting("general.addonupdates", mode)
        progress.close()
    if any(installed_version(a) == v for a, v in before.items()):
        # Still not installed: show Kodi's list so the user can finish by hand
        xbmc.executebuiltin("ActivateWindow(addonbrowser,addons://outdated/,return)")
    else:
        prop("MH.Update.Available", "")
        xbmcgui.Dialog().notification("MediaHub", text(32033) % installed_version("skin.mediahub"),
                                      xbmcgui.NOTIFICATION_INFO, 5000, False)
