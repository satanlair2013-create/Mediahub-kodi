"""MediaHub Helper - the lists and actions behind the MediaHub skin.

Everything runs inside the add-on's one background service (service.py). The skin
asks for things by setting Window(Home) properties, and the service answers by
filling properties the skin's rows read:

  MH.Req.Rows = <anything new>   refresh the helper rows on the home screen. For row n
                                 the skin sets MH.RowKey.<n> to its row type; the
                                 service fills MH.Row<n>.<i>.* for Up Next, My List
                                 and Recommended rows
  MH.Req.Similar = <type>|<dbid> fill MH.Similar.<i>.* ("More Like This")
  MH.Req.Show = <tvshowid>       fill MH.Show.* for the show page: .ID .Next ("S1 E4")
                                 .NextTitle .Started .InList .Rating .Seasons
  MH.Req.Action = <action>|...   do something:
      play|<episodeid>           play an episode (resuming) with the next ones queued
      resume|<type>|<dbid>       resume a movie or episode (the details page button)
      restart|<type>|<dbid>      play it from the beginning
      playshow|<tvshowid>        play the next episode of a show
      open|<type>|<dbid>         details page of a movie, or a show's seasons
      info|<type>|<dbid>         details page of a movie or show (from a details page)
      mylist|<type>|<dbid>       add to / remove from My List
      rate|<type>|<dbid>|<value> thumbs: 2 = down, 8 = up, 10 = love (again = clear)
      backspace                  remove the last letter of Skin.String(MH.Search)
      colors|<name>              switch the skin colour theme
      update / checkupdates      install / look for a MediaHub update (see updates.py)

Each list item has .Label .Label2 .Title .Landscape .ArtHasTitle .Poster .Logo
.Percent .Watched .DBType .DBID and .Action (the request to send when it is selected); <prefix>.Count
holds the number of items.
"""
import json
import random
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

MAX_ITEMS = 20
MYLIST_TAG = "My List"
EPISODE_PROPS = ["title", "showtitle", "season", "episode", "playcount", "resume", "lastplayed",
                 "art", "runtime", "tvshowid"]
MOVIE_PROPS = ["title", "year", "genre", "studio", "director", "art", "rating", "userrating",
               "playcount", "resume", "mpaa", "tag", "file"]
SHOW_PROPS = ["title", "year", "genre", "studio", "art", "rating", "userrating",
              "playcount", "mpaa", "tag", "episode", "watchedepisodes"]
# Age ratings allowed in Kids mode (with or without the scraper's "Rated " prefix)
KIDS_RATINGS = {"g", "pg", "u", "tv-y", "tv-y7", "tv-y7-fv", "tv-g", "tv-pg", "0", "6", "7", "fsk 0", "fsk 6"}
HELPER_ROWS = ("upnext", "mylist", "recommended")


def prop(name, value=None):
    home = xbmcgui.Window(10000)
    if value is None:
        return home.getProperty(name)
    home.setProperty(name, value)
    return value


def text(string_id):
    return xbmcaddon.Addon().getLocalizedString(string_id)


def rpc(method, **params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return reply.get("result", {})


def kids_mode():
    return xbmc.getCondVisibility("Skin.HasSetting(MH.KidsMode)")


def kids_ok(mpaa):
    return (mpaa or "").lower().replace("rated ", "").strip() in KIDS_RATINGS


def notify(title, string_id):
    xbmcgui.Dialog().notification(title, text(string_id), xbmcgui.NOTIFICATION_INFO, 2500, False)


# --------------------------------------------------------------------------- filling lists

def fill(prefix, entries):
    """Write a list of (fields) dicts to <prefix>.<i>.* and clear the rest."""
    home = xbmcgui.Window(10000)
    keys = ("Label", "Label2", "Title", "Landscape", "ArtHasTitle", "Poster", "Logo", "Percent",
            "Watched", "DBType", "DBID", "Action")
    for i in range(1, MAX_ITEMS + 1):
        fields = entries[i - 1] if i <= len(entries) else {}
        for key in keys:
            home.setProperty("%s.%d.%s" % (prefix, i, key), str(fields.get(key, "")))
    home.setProperty(prefix + ".Count", str(len(entries)))


def percent(resume):
    resume = resume or {}
    if resume.get("position") and resume.get("total"):
        return str(int(100 * resume["position"] / resume["total"]))
    return ""


def title_fields(kind, d):
    art = d.get("art") or {}
    return {
        "Label": d["title"],
        "Label2": str(d.get("year") or ""),
        "Title": d["title"],
        "Landscape": art.get("landscape") or art.get("fanart") or "",
        "ArtHasTitle": "1" if art.get("landscape") else "",
        "Poster": art.get("poster") or "",
        "Logo": art.get("clearlogo") or "",
        "Percent": percent(d.get("resume")),
        "Watched": "1" if d.get("playcount") and kind == "movie" else "",
        "DBType": kind,
        "DBID": d[kind + "id"],
        "Action": "open|%s|%d" % (kind, d[kind + "id"]),
    }


def episode_fields(ep):
    art = ep.get("art") or {}
    return {
        "Label": ep["showtitle"],
        "Label2": "S%d E%d  %s" % (ep["season"], ep["episode"], ep["title"]),
        "Title": ep["title"],
        "Landscape": art.get("thumb") or art.get("tvshow.landscape") or art.get("tvshow.fanart") or "",
        "Poster": art.get("tvshow.poster") or art.get("season.poster") or "",
        "Logo": art.get("tvshow.clearlogo") or "",
        "Percent": percent(ep.get("resume")),
        "DBType": "episode",
        "DBID": ep["episodeid"],
        "Action": "play|%d" % ep["episodeid"],
    }


# --------------------------------------------------------------------------- Up Next

def show_episodes(tvshowid):
    eps = rpc("VideoLibrary.GetEpisodes", tvshowid=tvshowid, properties=EPISODE_PROPS,
              sort={"method": "episode", "order": "ascending"}).get("episodes", [])
    return [e for e in eps if e.get("season", 0) > 0]  # specials don't count


def next_episode(eps):
    """The partly watched episode, or the first unwatched one after the last watched."""
    started = [e for e in eps if e["playcount"] > 0 or e["resume"]["position"] > 0]
    if not started:
        return None
    last = max(started, key=lambda e: e.get("lastplayed") or "")
    if last["playcount"] == 0 and last["resume"]["position"] > 0:
        return last
    for e in eps[eps.index(last) + 1:]:
        if e["playcount"] == 0:
            return e
    return None


def up_next(kids):
    shows = rpc("VideoLibrary.GetTVShows", properties=["title", "mpaa"],
                filter={"field": "inprogress", "operator": "true", "value": ""}).get("tvshows", [])
    found = []
    for show in shows:
        if kids and not kids_ok(show.get("mpaa")):
            continue
        eps = show_episodes(show["tvshowid"])
        ep = next_episode(eps)
        if ep:
            found.append((max(e.get("lastplayed") or "" for e in eps), ep))
    found.sort(key=lambda pair: pair[0], reverse=True)  # most recently watched show first
    return [episode_fields(ep) for _, ep in found[:MAX_ITEMS]]


def play(episodeid, resume=True):
    """Play an episode (from where you stopped, unless resume is False) with the next
    few queued after it. Kodi ignores "resume" when it starts a playlist, so the
    episode is started on its own and the rest are added once it is playing."""
    ep = rpc("VideoLibrary.GetEpisodeDetails", episodeid=episodeid, properties=["tvshowid"]).get("episodedetails")
    if not ep:
        return
    ids = [e["episodeid"] for e in show_episodes(ep["tvshowid"])]
    start = ids.index(episodeid) + 1 if episodeid in ids else len(ids)
    rpc("Playlist.Clear", playlistid=1)
    rpc("Player.Open", item={"episodeid": episodeid}, options={"resume": resume})
    player, monitor = xbmc.Player(), xbmc.Monitor()
    for _ in range(40):  # wait up to 20 seconds for playback to start
        if player.isPlayingVideo() or monitor.waitForAbort(0.5):
            break
    following = ids[start:start + 9]
    if following and player.isPlayingVideo():
        rpc("Playlist.Add", playlistid=1, item=[{"episodeid": eid} for eid in following])


def play_movie(movieid, resume=True):
    rpc("Player.Open", item={"movieid": movieid}, options={"resume": resume})


def play_show(tvshowid):
    eps = show_episodes(tvshowid)
    if eps:
        ep = next_episode(eps) or next((e for e in eps if e["playcount"] == 0), eps[0])
        play(ep["episodeid"])


# --------------------------------------------------------------------------- movies and shows

def details(kind, dbid, props):
    if kind == "movie":
        return rpc("VideoLibrary.GetMovieDetails", movieid=dbid, properties=props).get("moviedetails")
    if kind == "tvshow":
        return rpc("VideoLibrary.GetTVShowDetails", tvshowid=dbid, properties=props).get("tvshowdetails")
    return None


def all_items(kind, props, **extra):
    if kind == "movie":
        return rpc("VideoLibrary.GetMovies", properties=props, **extra).get("movies", [])
    return rpc("VideoLibrary.GetTVShows", properties=props, **extra).get("tvshows", [])


def open_item(kind, dbid, from_info=False):
    if kind == "tvshow" and not from_info:
        xbmc.executebuiltin("ActivateWindow(Videos,videodb://tvshows/titles/%d/,return)" % dbid)
        return
    d = details(kind, dbid, MOVIE_PROPS if kind == "movie" else SHOW_PROPS)
    if not d:
        return
    if from_info:
        xbmc.executebuiltin("Dialog.Close(movieinformation,true)")
        xbmc.sleep(200)
    path = d.get("file") if kind == "movie" else "videodb://tvshows/titles/%d/" % dbid
    li = xbmcgui.ListItem(d["title"], path=path, offscreen=True)
    tag = li.getVideoInfoTag()
    tag.setMediaType(kind)
    tag.setDbId(dbid)
    tag.setTitle(d["title"])
    if kind == "movie":
        tag.setFilenameAndPath(path)
    li.setArt(d.get("art") or {})
    # Dialog().info() only returns when the page is closed, so it gets its own
    # thread and the service carries on answering the page's own requests
    in_thread(xbmcgui.Dialog().info, li)


# --------------------------------------------------------------------------- My List

def mylist_file():
    return xbmcvfs.translatePath("special://profile/addon_data/script.mediahub.helper/mylist.json")


def load_mylist():
    try:
        with open(mylist_file(), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def save_mylist(entries):
    folder = xbmcvfs.translatePath("special://profile/addon_data/script.mediahub.helper/")
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    with open(mylist_file(), "w", encoding="utf-8") as f:
        json.dump(entries, f)


def toggle_mylist(kind, dbid):
    d = details(kind, dbid, ["title", "tag"])
    if not d:
        return
    tags = d.get("tag") or []
    entries = [e for e in load_mylist() if not (e[0] == kind and e[1] == dbid)]
    added = MYLIST_TAG not in tags
    if added:
        tags = tags + [MYLIST_TAG]
        entries.insert(0, [kind, dbid, int(time.time())])
    else:
        tags = [t for t in tags if t != MYLIST_TAG]
    method = "VideoLibrary.SetMovieDetails" if kind == "movie" else "VideoLibrary.SetTVShowDetails"
    rpc(method, **{kind + "id": dbid, "tag": tags})
    save_mylist(entries)
    # The skin reads these straight away; the library item itself refreshes later
    prop("MH.MyList.Type", kind)
    prop("MH.MyList.DBID", str(dbid))
    prop("MH.MyList.State", "1" if added else "0")
    notify(d["title"], 32001 if added else 32002)


def mylist(kids):
    order = {(e[0], e[1]): e[2] for e in load_mylist()}
    found = []
    for kind in ("movie", "tvshow"):
        tag_filter = {"field": "tag", "operator": "is", "value": MYLIST_TAG}
        for d in all_items(kind, MOVIE_PROPS if kind == "movie" else SHOW_PROPS, filter=tag_filter):
            if not kids or kids_ok(d.get("mpaa")):
                found.append((order.get((kind, d[kind + "id"]), 0), title_fields(kind, d)))
    found.sort(key=lambda row: row[0], reverse=True)  # most recently added first
    return [fields for _, fields in found[:MAX_ITEMS]]


# --------------------------------------------------------------------------- thumbs

def rate(kind, dbid, value):
    if kind == "episode":
        cur = rpc("VideoLibrary.GetEpisodeDetails", episodeid=dbid, properties=["userrating", "title"]).get("episodedetails")
    else:
        cur = details(kind, dbid, ["userrating", "title"])
    if not cur:
        return
    new = 0 if cur.get("userrating") == value else value
    method = {"movie": "VideoLibrary.SetMovieDetails", "tvshow": "VideoLibrary.SetTVShowDetails",
              "episode": "VideoLibrary.SetEpisodeDetails"}[kind]
    rpc(method, **{kind + "id": dbid, "userrating": new})
    prop("MH.Rated.Type", kind)
    prop("MH.Rated.DBID", str(dbid))
    prop("MH.Rated.Value", str(new))
    notify(cur["title"], {0: 32003, 2: 32004, 8: 32005, 10: 32006}.get(new, 32005))


# --------------------------------------------------------------------------- recommendations

def taste(items):
    """Genre/studio/director weights from what you rated and watched."""
    weights = {}
    for d in items:
        r = d.get("userrating") or 0
        w = 3 if r >= 9 else 2 if r >= 5 else -2 if r >= 1 else (0.5 if d.get("playcount") else 0)
        if not w:
            continue
        keys = ["g:" + g for g in d.get("genre") or []]
        keys += ["s:" + s for s in (d.get("studio") or [])[:2]] + ["d:" + p for p in d.get("director") or []]
        for k in keys:
            weights[k] = weights.get(k, 0) + (w if k[0] == "g" else w / 2)
    return weights


def score(d, weights):
    keys = ["g:" + g for g in d.get("genre") or []] + ["s:" + s for s in d.get("studio") or []] + \
           ["d:" + p for p in d.get("director") or []]
    return sum(weights.get(k, 0) for k in keys) + (d.get("rating") or 0) / 4


def recommended(kids):
    movies = all_items("movie", MOVIE_PROPS)
    weights = taste(movies)
    rng = random.Random(time.strftime("%Y%m%d"))  # the same shuffle all day
    pool = []
    for d in movies:
        r = d.get("userrating") or 0
        if d.get("playcount") or 1 <= r <= 4 or (kids and not kids_ok(d.get("mpaa"))):
            continue
        pool.append((score(d, weights) + rng.random(), d))
    pool.sort(key=lambda row: row[0], reverse=True)
    return [title_fields("movie", d) for _, d in pool[:MAX_ITEMS]]


def similar(kind, dbid, kids):
    props = MOVIE_PROPS if kind == "movie" else SHOW_PROPS
    me = details(kind, dbid, props)
    if not me:
        return []
    genres, studios = set(me.get("genre") or []), set(me.get("studio") or [])
    directors = set(me.get("director") or [])
    found = []
    for d in all_items(kind, props):
        if d[kind + "id"] == dbid or (kids and not kids_ok(d.get("mpaa"))):
            continue
        s = 2 * len(genres & set(d.get("genre") or [])) + len(studios & set(d.get("studio") or [])) + \
            2 * len(directors & set(d.get("director") or []))
        if s:
            found.append((s + (d.get("rating") or 0) / 20, d))
    found.sort(key=lambda row: row[0], reverse=True)
    fields = []
    for _, d in found[:MAX_ITEMS]:
        f = title_fields(kind, d)
        f["Action"] = "info|%s|%d" % (kind, d[kind + "id"])
        fields.append(f)
    return fields


# --------------------------------------------------------------------------- requests

def refresh_rows():
    kids = kids_mode()
    lists = {}
    for n in range(1, 13):
        key = prop("MH.RowKey.%d" % n)
        if key not in HELPER_ROWS:
            continue
        if key not in lists:
            lists[key] = {"upnext": up_next, "mylist": mylist, "recommended": recommended}[key](kids)
        fill("MH.Row%d" % n, lists[key])


def refresh_similar(request):
    kind, dbid = request.split("|")
    fill("MH.Similar", similar(kind, int(dbid), kids_mode()))
    prop("MH.Similar.Type", kind)
    prop("MH.Similar.DBID", dbid)


def refresh_show(request):
    tvshowid = int(request)
    d = details("tvshow", tvshowid, ["title", "tag", "userrating", "season"])
    if not d:
        return
    eps = show_episodes(tvshowid)
    started = next_episode(eps)
    ep = started or next((e for e in eps if e["playcount"] == 0), eps[0] if eps else None)
    prop("MH.Show.Next", "S%d E%d" % (ep["season"], ep["episode"]) if ep else "")
    prop("MH.Show.NextTitle", ep["title"] if ep else "")
    prop("MH.Show.Started", "1" if started else "")
    prop("MH.Show.InList", "1" if MYLIST_TAG in (d.get("tag") or []) else "")
    prop("MH.Show.Rating", str(d.get("userrating") or ""))
    prop("MH.Show.Seasons", str(d.get("season") or ""))
    prop("MH.Show.ID", str(tvshowid))


def in_thread(target, *args):
    """Run something that waits for the user (a dialog) without holding up the service."""
    def run():
        try:
            target(*args)
        except Exception as exc:
            xbmc.log("MediaHub Helper: %r" % exc, xbmc.LOGERROR)
    threading.Thread(target=run, daemon=True).start()



def backspace():
    text_now = xbmc.getInfoLabel("Skin.String(MH.Search)")
    xbmc.executebuiltin('Skin.SetString(MH.Search,"%s")' % text_now[:-1].replace('"', ""))


def do_action(request):
    parts = request.split("|")
    name, args = parts[0], parts[1:]
    if name == "play":
        in_thread(play, int(args[0]))
    elif name == "playshow":
        in_thread(play_show, int(args[0]))
    elif name in ("resume", "restart"):
        # details page: Resume (from where you stopped) or Restart (from the beginning)
        kind, dbid = args[0], int(args[1])
        if kind == "episode":
            in_thread(play, dbid, name == "resume")
        elif kind == "movie":
            play_movie(dbid, name == "resume")
    elif name in ("open", "info"):
        open_item(args[0], int(args[1]), from_info=name == "info")
    elif name == "mylist":
        toggle_mylist(args[0], int(args[1]))
        return True
    elif name == "rate":
        rate(args[0], int(args[1]), int(args[2]))
        return True
    elif name == "backspace":
        backspace()
    elif name == "colors":
        rpc("Settings.SetSettingValue", setting="lookandfeel.skincolors", value=args[0])
    return False
