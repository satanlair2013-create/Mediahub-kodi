"""MediaHub Cinema - what's on at the cinema and coming soon, from TMDB.

TMDB (themoviedb.org) needs a free API key: the add-on's own setting, or the one
in MediaHub's Skin settings (On demand: pictures from TMDB). Lists are for your
country (the setting, or Kodi's language's country).

Kept in the add-on's folder:
- waiting.json: films you want to hear about when they're out at home
  ({id: {title, year, poster, fanart, added}})
- out.json: those that are out now ({id: {..., out: "2026-10-01", library: bool}})
- cache/: TMDB's answers, for a few hours
- home.json: cards for MediaHub's Cinema: Now Showing and Cinema: Coming Soon rows
"""
import datetime
import hashlib
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.mediahub.cinema"
API = os.environ.get("MEDIAHUB_TMDB", "https://api.themoviedb.org/3")
IMAGES = os.environ.get("MEDIAHUB_TMDB_IMG", "https://image.tmdb.org/t/p")
HOUR = 3600
HOME_CARDS = 20
HOME_TYPES = (4, 5)  # TMDB's release types: 4 digital, 5 physical


class Error(Exception):
    pass


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def profile(name=""):
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)


def load_json(name, default):
    try:
        with open(profile(name), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def save_json(name, data):
    path = profile(name)
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def key():
    return (addon().getSetting("tmdb_key") or xbmc.getInfoLabel("Skin.String(MH.OD.TmdbKey)")).strip()


def kodi_locale():
    """Kodi's language as ("en", "GB"), from its setting (resource.language.en_gb)."""
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue",
                                                       "params": {"setting": "locale.language"}})))
    value = str((reply.get("result") or {}).get("value") or "")
    parts = value.rsplit(".", 1)[-1].split("_")
    if len(parts) == 2 and len(parts[0]) == 2 and len(parts[1]) == 2:
        return parts[0].lower(), parts[1].upper()
    return "en", "GB"


def region():
    chosen = (addon().getSetting("region") or "").strip().upper()
    return chosen if len(chosen) == 2 and chosen.isalpha() else kodi_locale()[1]


def language():
    lang, country = kodi_locale()
    return "%s-%s" % (lang, country)


def api(path, max_age=6 * HOUR, **params):
    """A TMDB answer, from the cache when it's newer than max_age (or older, when TMDB
    can't be reached)."""
    if not key():
        raise Error("no key")
    params = dict(params, api_key=key(), language=language())
    address = "%s%s?%s" % (API, path, urllib.parse.urlencode(sorted(params.items())))
    name = hashlib.sha1(address.replace(key(), "").encode("utf-8")).hexdigest()
    cached = profile(os.path.join("cache", name + ".json"))
    try:
        fresh = time.time() - os.path.getmtime(cached) < max_age
    except OSError:
        fresh = None
    if fresh:
        try:
            with open(cached, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            pass
    try:
        request = urllib.request.Request(address, headers={"User-Agent": xbmc.getUserAgent(),
                                                           "Accept": "application/json"})
        with urllib.request.urlopen(request, timeout=10) as reply:
            data = json.loads(reply.read().decode("utf-8"))
    except (OSError, ValueError, urllib.error.URLError) as exc:
        if fresh is not None:
            with open(cached, encoding="utf-8") as f:
                return json.load(f)
        raise Error(str(exc))
    if isinstance(data, dict) and data.get("status_code") in (7, 10):
        raise Error("key")
    os.makedirs(os.path.dirname(cached), exist_ok=True)
    with open(cached, "w", encoding="utf-8") as f:
        json.dump(data, f)
    return data


def image(path, size="w500"):
    return "%s/%s%s" % (IMAGES, size, path) if path else ""


def genres():
    try:
        found = api("/genre/movie/list", 7 * 24 * HOUR).get("genres") or []
    except Error:
        return {}
    return {g["id"]: g["name"] for g in found if isinstance(g, dict)}


def films(kind, page=1):
    """now_playing or upcoming, for your country; coming soon without anything already out."""
    data = api("/movie/%s" % kind, 6 * HOUR, region=region(), page=page)
    found = [f for f in data.get("results") or [] if isinstance(f, dict) and not f.get("adult")]
    if kind == "upcoming":
        today = datetime.date.today().isoformat()
        found = [f for f in found if (f.get("release_date") or "") > today]
        found.sort(key=lambda f: f.get("release_date") or "")
    return found, int(data.get("total_pages") or 1)


def search(words):
    return [f for f in api("/search/movie", HOUR, query=words, region=region()).get("results") or []
            if isinstance(f, dict) and not f.get("adult")]


def details(film_id, max_age=12 * HOUR):
    return api("/movie/%d" % int(film_id), max_age, append_to_response="videos,release_dates,credits")


def trailer(d):
    """A YouTube trailer's id (a Trailer first, then a Teaser)."""
    videos = [v for v in (d.get("videos") or {}).get("results") or [] if v.get("site") == "YouTube" and v.get("key")]
    videos.sort(key=lambda v: {"Trailer": 0, "Teaser": 1}.get(v.get("type"), 2))
    return videos[0]["key"] if videos else ""


def home_release(d):
    """The day it comes out at home in your country (digital or on disc), or ""."""
    for country in (d.get("release_dates") or {}).get("results") or []:
        if country.get("iso_3166_1") != region():
            continue
        days = sorted(r["release_date"][:10] for r in country.get("release_dates") or []
                      if r.get("type") in HOME_TYPES and r.get("release_date"))
        return days[0] if days else ""
    return ""


# --------------------------------------------------------------------------- waiting for home release

def waiting():
    return load_json("waiting.json", {})


def out():
    return load_json("out.json", {})


def summary(f):
    return {"title": f.get("title") or "", "year": (f.get("release_date") or "")[:4],
            "poster": image(f.get("poster_path")), "fanart": image(f.get("backdrop_path"), "w1280"),
            "added": int(time.time())}


def set_waiting(f, on):
    found = waiting()
    fid = str(f["id"])
    if on:
        found[fid] = summary(f)
    else:
        found.pop(fid, None)
    save_json("waiting.json", found)


def in_library(title, year):
    rule = {"field": "title", "operator": "is", "value": title}
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "VideoLibrary.GetMovies",
                                                       "params": {"filter": rule, "properties": ["year"]}})))
    for m in (reply.get("result") or {}).get("movies") or []:
        if not year or abs((m.get("year") or 0) - int(year)) <= 1:
            return True
    return False


def check_waiting(monitor=None):
    """Tell of each film you're waiting for that's now out at home (or in your library)."""
    found, gone = waiting(), out()
    today = datetime.date.today().isoformat()
    name = addon().getAddonInfo("name")
    for fid, f in list(found.items()):
        if monitor and monitor.abortRequested():
            return
        try:
            day = home_release(details(fid, 24 * HOUR))
        except Error:
            continue
        library = in_library(f["title"], f.get("year"))
        if (day and day <= today) or library:
            found.pop(fid)
            gone[fid] = dict(f, out=day or today, library=library)
            message = addon().getLocalizedString(30032 if library else 30031) % f["title"]
            xbmcgui.Dialog().notification(name, message, f.get("poster") or xbmcgui.NOTIFICATION_INFO, 8000)
        elif day and f.get("day") != day:
            found[fid] = dict(f, day=day)  # (shown on Waiting for)
    save_json("waiting.json", found)
    save_json("out.json", gone)


# --------------------------------------------------------------------------- MediaHub's home rows

def card(f, soon):
    date = f.get("release_date") or ""
    label2 = date_label(date) if soon else str(date[:4])
    return {"Label": f.get("title") or "", "Label2": label2, "Title": f.get("title") or "",
            "Landscape": image(f.get("backdrop_path"), "w780"), "Poster": image(f.get("poster_path"), "w342"),
            "Plot": f.get("overview") or "", "Kind": "cinema",
            "Action": "cinema|run|plugin://%s/?%s" % (ADDON_ID, urllib.parse.urlencode({"mode": "film", "id": f["id"]}))}


def date_label(date):
    try:
        d = datetime.date.fromisoformat(date[:10])
    except ValueError:
        return ""
    return "%s %d %s" % (xbmc.getLocalizedString(41 + d.weekday()), d.day, xbmc.getLocalizedString(51 + d.month - 1))


def write_home():
    rows = {}
    for kind, row, soon in (("now_playing", "cinemanow", False), ("upcoming", "cinemasoon", True)):
        try:
            found, _pages = films(kind)
        except Error:
            found = []
        rows[row] = [card(f, soon) for f in found[:HOME_CARDS]]
    save_json("home.json", rows)
    xbmcgui.Window(10000).setProperty("MHC.Home", str(time.time()))  # (the helper refreshes the rows)
