"""MediaHub Cinema - what's on at the cinema and coming soon (TMDB), with trailers.

Now showing and Coming soon in your country, Search, and "Tell me when it's out at
home": the add-on's service checks each day and says when a film you picked comes
out to watch at home (to buy or rent, or on disc) or turns up in your library.
Selecting a film plays its trailer (with the YouTube add-on). Local cinema times
aren't here: there's no free, open listing of them.
"""
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import cinema  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name")
FANART = os.path.join(ADDON.getAddonInfo("path"), "resources", "fanart.jpg")
YOUTUBE = "plugin.video.youtube"


def text(string_id):
    return ADDON.getLocalizedString(string_id)


def url(**params):
    return BASE + "?" + urllib.parse.urlencode(params)


def notify(message, error=False):
    xbmcgui.Dialog().notification(NAME, message, xbmcgui.NOTIFICATION_WARNING if error else
                                  xbmcgui.NOTIFICATION_INFO, 4000, False)


def folder(label, target, icon="DefaultFolder.png", label2=""):
    item = xbmcgui.ListItem(label, label2)
    item.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=True)


def action(label, target, icon="DefaultIconInfo.png"):
    item = xbmcgui.ListItem(label)
    item.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=False)


def end(content="", title="", cache=False):
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.setPluginCategory(HANDLE, title or NAME)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)


def careful(work):
    """Run a page; without a key, or when TMDB can't be reached, say so."""
    try:
        work()
    except cinema.Error as exc:
        xbmc.log("MediaHub Cinema: %s" % exc, xbmc.LOGWARNING)
        if HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        if str(exc) in ("no key", "key"):
            if xbmcgui.Dialog().yesno(NAME, text(30020)):
                ADDON.openSettings()
        else:
            notify(text(30021), True)


# --------------------------------------------------------------------------- pages

def root():
    if not cinema.key():
        action(text(30019), url(mode="settings"), "DefaultAddonProgram.png")
        return end()
    folder(text(30001), url(mode="list", kind="now_playing"), "DefaultMovies.png")
    folder(text(30002), url(mode="list", kind="upcoming"), "DefaultRecentlyAddedMovies.png")
    if cinema.out():
        folder(text(30003), url(mode="out"), "DefaultMovies.png", str(len(cinema.out())))
    if cinema.waiting():
        folder(text(30004), url(mode="waiting"), "DefaultIconInfo.png", str(len(cinema.waiting())))
    folder(xbmc.getLocalizedString(137), url(mode="search"), "DefaultAddonsSearch.png")
    action(text(30005), url(mode="settings"), "DefaultAddonProgram.png")
    end()


def film_item(f, names, soon=False, note=""):
    title = f.get("title") or ""
    date = f.get("release_date") or ""
    label2 = cinema.date_label(date) if soon else date[:4]
    item = xbmcgui.ListItem(title, note or label2)
    poster = f.get("poster_url") or cinema.image(f.get("poster_path"), "w342")
    item.setArt({"poster": poster, "thumb": poster,
                 "fanart": f.get("fanart_url") or cinema.image(f.get("backdrop_path"), "w1280") or FANART})
    tag = item.getVideoInfoTag()
    tag.setMediaType("movie")
    tag.setTitle(title)
    tag.setPlot(f.get("overview") or "")
    if date[:4].isdigit():
        tag.setYear(int(date[:4]))
    if len(date) >= 10:
        tag.setPremiered(date[:10])
    tag.setGenres([names[g] for g in f.get("genre_ids") or [] if g in names])
    if f.get("vote_average"):
        tag.setRating(float(f["vote_average"]))
    item.setProperty("IsPlayable", "true")
    waiting = str(f["id"]) in cinema.waiting()
    item.addContextMenuItems([
        (text(30011) if waiting else text(30010), "RunPlugin(%s)" % url(mode="wait", id=f["id"], on=int(not waiting))),
        (text(30012), "RunPlugin(%s)" % url(mode="about", id=f["id"]))])
    xbmcplugin.addDirectoryItem(HANDLE, url(mode="trailer", id=f["id"]), item, isFolder=False)


def film_list(kind, page):
    found, pages = cinema.films(kind, page)
    names = cinema.genres()
    for f in found:
        film_item(f, names, soon=kind == "upcoming")
    if page < min(pages, 10):
        folder(text(30006), url(mode="list", kind=kind, page=page + 1), "DefaultFolder.png")
    end("movies", text(30001 if kind == "now_playing" else 30002))


def saved_list(which):
    """Out at home, or Waiting for: from what's kept (no TMDB call)."""
    found = cinema.out() if which == "out" else cinema.waiting()
    for fid, s in sorted(found.items(), key=lambda kv: kv[1].get("out") or kv[1].get("day") or "", reverse=which == "out"):
        f = {"id": int(fid), "title": s.get("title"), "release_date": s.get("year", ""),
             "poster_url": s.get("poster", ""), "fanart_url": s.get("fanart", "")}
        if which == "out":
            note = text(30025) if s.get("library") else text(30013) % cinema.date_label(s.get("out", ""))
        else:
            note = text(30014) % cinema.date_label(s["day"]) if s.get("day") else ""
        film_item(f, {}, note=note)
    end("movies", text(30003 if which == "out" else 30004))


def search():
    words = xbmcgui.Dialog().input(xbmc.getLocalizedString(137))
    if not words:
        return end()
    names = cinema.genres()
    for f in cinema.search(words):
        film_item(f, names)
    end("movies", words)


def play_trailer(film_id):
    d = cinema.details(film_id)
    key = cinema.trailer(d)
    if not key:
        notify(text(30015), True)
        return xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    if not xbmc.getCondVisibility("System.HasAddon(%s)" % YOUTUBE):
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        if xbmcgui.Dialog().yesno(NAME, text(30016)):
            xbmc.executebuiltin("InstallAddon(%s)" % YOUTUBE)
        return
    item = xbmcgui.ListItem(d.get("title") or "", path="plugin://%s/play/?video_id=%s" % (YOUTUBE, key))
    if HANDLE >= 0:
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
    else:
        xbmc.Player().play(item.getPath(), item)


def about(film_id):
    d = cinema.details(film_id)
    lines = []
    if d.get("tagline"):
        lines.append("[I]%s[/I]" % d["tagline"])
    facts = [x for x in (d.get("release_date", "")[:4], "%d min" % d["runtime"] if d.get("runtime") else "",
                         ", ".join(g["name"] for g in d.get("genres") or [])) if x]
    lines.append("  •  ".join(facts))
    lines += ["", d.get("overview") or ""]
    cast = [c["name"] for c in (d.get("credits") or {}).get("cast") or [] if c.get("name")][:8]
    if cast:
        lines += ["", "[B]%s[/B]  %s" % (text(30017), ", ".join(cast))]
    home = cinema.home_release(d)
    if home:
        lines += ["", "[B]%s[/B]  %s" % (text(30018), cinema.date_label(home))]
    xbmcgui.Dialog().textviewer(d.get("title") or NAME, "\n".join(lines))


def wait(film_id, on):
    d = cinema.details(film_id)
    cinema.set_waiting(d, on)
    notify(text(30022) % d.get("title", "") if on else text(30023) % d.get("title", ""))
    xbmc.executebuiltin("Container.Refresh")


def film_menu(film_id):
    """A film from MediaHub's home rows: trailer, tell me when it's out, about."""
    d = cinema.details(film_id)
    waiting = str(film_id) in cinema.waiting()
    choices = [(text(30024), lambda: play_trailer(film_id)),
               (text(30011) if waiting else text(30010), lambda: wait(film_id, not waiting)),
               (text(30012), lambda: about(film_id))]
    pick = xbmcgui.Dialog().select(d.get("title") or NAME, [label for label, _do in choices])
    if pick >= 0:
        choices[pick][1]()


def main():
    mode = ARGS.get("mode")
    if mode is None:
        root()
    elif mode == "settings":
        ADDON.openSettings()
    elif mode == "list":
        careful(lambda: film_list(ARGS.get("kind", "now_playing"), int(ARGS.get("page", 1))))
    elif mode in ("out", "waiting"):
        saved_list(mode)
    elif mode == "search":
        careful(search)
    elif mode == "trailer":
        careful(lambda: play_trailer(ARGS["id"]))
    elif mode == "about":
        careful(lambda: about(ARGS["id"]))
    elif mode == "wait":
        careful(lambda: wait(ARGS["id"], ARGS.get("on") == "1"))
    elif mode == "film":
        careful(lambda: film_menu(ARGS["id"]))
    elif mode == "refreshhome":
        careful(cinema.write_home)


if __name__ == "__main__":
    main()
