"""MediaHub Cinema - in the background while Kodi runs.

A couple of minutes after Kodi starts, and then twice a day: the cards for
MediaHub's Cinema rows (home.json), and whether a film you're waiting for is out
at home now or in your library (cinema.check_waiting).
"""
import os
import sys
import time

import xbmc

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import cinema  # noqa: E402

FIRST = 120
EVERY = 12 * 3600


class Service(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.next_run = time.time() + FIRST

    def work(self):
        if not cinema.key():
            return
        cinema.write_home()
        cinema.check_waiting(self)

    def run(self):
        while not self.waitForAbort(10):
            if time.time() < self.next_run or xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
                continue
            self.next_run = time.time() + EVERY
            try:
                self.work()
            except Exception as exc:  # (TMDB unreachable, or anything else: try again later)
                xbmc.log("MediaHub Cinema: %r" % exc, xbmc.LOGWARNING)
                self.next_run = time.time() + 3600

    def onSettingsChanged(self):
        self.next_run = time.time() + 5  # (a key or a country was just set)


if __name__ == "__main__":
    Service().run()
